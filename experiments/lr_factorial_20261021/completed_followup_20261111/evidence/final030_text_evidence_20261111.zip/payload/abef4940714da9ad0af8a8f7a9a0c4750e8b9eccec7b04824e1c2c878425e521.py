"""Read-only production admission from the complete immutable GPU proof.

No Torch, pickle, training, evaluation, file publication or process launch.
The frozen numerical reader owns numerical comparisons. This reader rechecks
their exact report bytes, complete coverage and every underlying receipt/file.
It cannot turn fabricated CPU fixtures into evidence of actual GPU execution.
"""
import math
from pathlib import Path, PurePosixPath
from continuation_artifact_receipts import (
    Context, ROOT, PROTOCOL_SHA, encoded, digest, loads, receipt_path,
    verify_receipt, verify_complete_request,
)
from continuation_preflight_runtime import (
    no_latches, verify_completed_bases, resources, check_limits, DISPATCHER,
)

SOURCE = ROOT / 'continuation_production_gate.py'
READER = ROOT / 'continuation_preflight_reader.py'
FINALIZER = ROOT / 'finalize_continuation_preflight.py'
GATE = ROOT / 'CONTINUATION_PREFLIGHT_PASSED.json'
REPORT = ROOT / 'continuation_preflight/numerical_report.json'
COLLECTED = ROOT / 'CONTINUATION_PREFLIGHT_COLLECTED.json'


def exact_integer(value, expected):
    assert type(value) is int and value == expected


def counts(value, attempted):
    assert value.keys() == {'attempted', 'applied', 'skipped'}
    assert all(type(v) is int and v >= 0 for v in value.values())
    assert value['attempted'] == attempted == value['applied'] + value['skipped']
    assert value['applied'] > 0


def completed_dispatcher(context, gate, collection):
    # The gate is published inside the dispatcher. It becomes usable only
    # after the same dispatcher has exited successfully, without a failure latch.
    name = gate['dispatcher_attempt']
    relative = PurePosixPath(name)
    assert relative.parent == PurePosixPath((ROOT / 'attempts').as_posix())
    assert relative.suffix == '.json'
    row = loads(context.files.read(name))
    assert row['label'] == 'continuation_preflight_dispatcher_CPU'
    assert row['GPU_job'] is False and row['status'] == 'completed'
    exact_integer(row['returncode'], 0)
    assert type(row['pid']) is int and row['pid'] > 0
    assert 'stop_reason' not in row
    for key in ('started_unix', 'ended_unix'):
        assert type(row[key]) in (float, int) and math.isfinite(row[key]) and row[key] > 0
    assert row['ended_unix'] >= row['started_unix']
    assert row['command'] == [str(context.files.project / 'venv/bin/python'), '-u',
                              DISPATCHER.as_posix(), '--device', str(collection['device'])]
    return name, context.files.sha(name)


def verify_report(context, collection, report):
    assert report['schema'] == 'continuation_preflight_numerical_report_v1'
    assert report['status'] == 'all12_numerical_cases_passed_only_not_production_admission'
    assert collection['schema'] == 'continuation_preflight_collection_v1'
    assert collection['status'] == '84_receipts_48_closed_requests_12_case_checks_complete_not_production_gate'
    assert collection['protocol_sha256'] == report['protocol_sha256'] == PROTOCOL_SHA
    assert collection['context'] == report['context'] == context.identifiers()
    assert report['reader_sha256'] == context.bindings[READER.as_posix()]
    assert report['observational_parity_all_rates_arms'] is True
    assert report['interrupted_replay_exact'] is True
    assert type(collection['device']) is int and collection['device'] in (0, 1)
    assert type(collection['GPU_uuid']) is str and collection['GPU_uuid'].startswith('GPU-')
    cases = context.roster['cases']
    assert len(cases) == 12 and set(report['cases']) == {c['id'] for c in cases}
    assert len(context.invocations) == 84 and set(report['receipt_sha256']) == set(context.invocations)
    assert len(context.requests) == 48 and set(report['closed_request_sha256']) == set(context.requests)
    assert collection['receipt_sha256'] == report['receipt_sha256']
    assert collection['closed_request_sha256'] == report['closed_request_sha256']
    numerical_files = {}
    for case in cases:
        full = report['cases'][case['id']]
        assert full['schema'] == 'continuation_preflight_numerical_case_v1'
        assert full['kind'] == 'complete_case' and full['status'] == 'observational_and_replay_parity_passed'
        assert full['case_id'] == case['id'] and full['protocol_sha256'] == PROTOCOL_SHA
        assert full['context'] == context.identifiers() and full['reader_sha256'] == report['reader_sha256']
        expected_ids = {i['id'] for i in context.roster['invocations'] if i['request_id'] in case['requests'].values()}
        assert len(expected_ids) == 7 and full['receipt_sha256'] == {k: report['receipt_sha256'][k] for k in expected_ids}
        checks = full['checks']
        for key in ('serialized_validation_model_matches_raw_EMA_at_saved_FP16_precision',
                    'all_four_atomic_segment_states_checked', 'actual_starting_checkpoint_parameters_and_teacher_hash_checked'):
            assert checks[key] is True
        for key, attempted in (('observation', 32), ('replay', 96)):
            assert checks[key]['status'] == 'numerical_case_passed_only'
            counts(checks[key]['actual_step_counts'], attempted)
        exact_integer(checks['replay']['epochs_compared'], 12)
        exact_integer(checks['replay']['batches_per_trajectory'], 96)
        assert checks['replay']['validation_commit_bytes_preserved_across_final_resume'] is True
        obs_ids = {i['id'] for i in context.roster['invocations'] if i['request_id'] in
                   [case['requests'][k] for k in ('reference_observation', 'candidate_observation')]}
        observation = {**full, 'kind': 'observation', 'status': 'observational_parity_passed',
                       'receipt_sha256': {k: v for k, v in full['receipt_sha256'].items() if k in obs_ids},
                       'checks': {'observation': checks['observation']}}
        for kind, value in [('observation', observation), ('complete_case', full)]:
            name = (ROOT / 'continuation_preflight/numerical_cases' / f'{case["id"]}__{kind}.json').as_posix()
            raw = context.files.read(name)
            assert raw == encoded(value), 'Numerical case file differs from bound report'
            numerical_files[name] = digest(raw)
    assert len(numerical_files) == 24 and collection['numerical_case_file_sha256'] == numerical_files
    # Recheck all tensor/RNG/raw-state files by hash without deserialization.
    for ident, expected in report['receipt_sha256'].items():
        receipt, value = verify_receipt(context, ident)
        assert value == expected
        assert receipt['device'] == collection['device'] and receipt['GPU_uuid'] == collection['GPU_uuid']
    for ident, expected in report['closed_request_sha256'].items():
        assert verify_complete_request(context, ident)[1] == expected
    return numerical_files


def verify_bound_gate(context, manifest_hash):
    """Internal file proof check; public admission always constructs real Context."""
    f = context.files
    no_latches(f); context.verify()
    assert context.manifest_hash == manifest_hash
    for name in (SOURCE, READER, FINALIZER):
        assert name.as_posix() in context.bindings, f'Unfrozen gate dependency: {name}'
    gate_raw = f.read(GATE.as_posix()); gate = loads(gate_raw)
    assert gate['schema'] == 'continuation_preflight_gate_v1' and gate['status'] == 'passed'
    assert gate['protocol_sha256'] == PROTOCOL_SHA and gate['source_manifest_sha256'] == manifest_hash
    assert gate['observational_parity_all_rates_arms'] is True and gate['interrupted_replay_exact'] is True
    for key, value in [('numerical_case_count', 12), ('GPU_invocations', 84),
                       ('fixed_training_minibatches', 3072), ('closed_requests', 48)]:
        exact_integer(gate[key], value)
    report_raw = f.read(REPORT.as_posix(), gate['numerical_report_sha256'])
    collection_raw = f.read(COLLECTED.as_posix(), gate['collection_sha256'])
    report, collection = loads(report_raw), loads(collection_raw)
    bases = verify_completed_bases(context)
    required = dict(context.bindings)
    for name, value in bases.items():
        assert name not in required or required[name] == value
        required[name] = value
    required.update({REPORT.as_posix(): digest(report_raw), COLLECTED.as_posix(): digest(collection_raw)})
    assert gate['bound_input_and_evidence_sha256'] == required, 'Incomplete or unrelated gate bindings'
    f.verify(required)
    case_files = verify_report(context, collection, report)
    attempt, attempt_hash = completed_dispatcher(context, gate, collection)
    check_limits(gate['resources_at_publication'])
    assert gate['resources_at_publication']['active_GPU_attempts'] == []
    # No stale PASS may bypass a failure recorded after publication or during admission.
    context.verify(); f.verify(required); f.verify(case_files)
    assert f.read(GATE.as_posix()) == gate_raw and f.sha(attempt) == attempt_hash
    no_latches(f)
    return {'gate_sha256': digest(gate_raw), 'numerical_report_sha256': digest(report_raw),
            'collection_sha256': digest(collection_raw), 'dispatcher_attempt_sha256': attempt_hash}


def verify_gate(project, manifest_hash):
    context = Context(project)  # pinned real anchors; no test override
    assert Path(__file__).resolve() == context.files.path(SOURCE.as_posix()).resolve()
    assert digest(Path(__file__).read_bytes()) == context.bindings[SOURCE.as_posix()]
    result = verify_bound_gate(context, manifest_hash)
    _, usage = resources(context.files); check_limits(usage); no_latches(context.files)
    return result
