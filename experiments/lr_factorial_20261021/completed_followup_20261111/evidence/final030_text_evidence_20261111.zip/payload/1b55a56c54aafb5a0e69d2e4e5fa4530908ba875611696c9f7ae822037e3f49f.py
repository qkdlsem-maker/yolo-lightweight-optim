"""Bounded, single-use CPU byte authentication after all training exits.

The existing collector is unchanged. This wrapper admits no evaluation and has
no wait-for-training, retry, resume, model loading or GPU execution option.
"""
import fcntl
import os
from pathlib import Path
import resource
import signal
import sys
import threading
import time
import traceback

from continuation_artifact_receipts import ROOT, PROTOCOL_SHA, Files, loads, encoded
from continuation_preflight_runtime import check_limits, process_command
from incident020_resources import resources
from run_continuations import register_attempt
from continuation_wave_runner import finish
from validation_journal import publish_immutable
import continuation_after020_evidence as guarded
import factorial_training_model_bindings as evidence

SELF = ROOT / 'run_factorial_training_acceptance.py'
PREFIX = ROOT / 'factorial_training_acceptance'
MANIFEST = ROOT / 'factorial_training_acceptance_sources.json'
PREPARED = ROOT / 'factorial_training_binding_sources.json'
PREPARED_SHA = 'e4abefe0e8db2882b04ed53d6c49acd92035128017f42a734bec9475f1ddb3b3'
WALL_SECONDS = 1800
CPU_SECONDS = 1800
POLL_SECONDS = 5
JOIN_SECONDS = 20


def command(files, expected):
    return [str(files.project / 'venv/bin/python'), '-B', '-u', str(SELF), expected]


def verify_sources(files, expected):
    assert len(expected) == 64 and all(c in '0123456789abcdef' for c in expected)
    manifest = loads(files.read(str(MANIFEST), expected))
    assert manifest['schema'] == 'factorial_training_acceptance_sources_v1'
    assert manifest['protocol_sha256'] == PROTOCOL_SHA
    assert manifest['execution_admitted'] is False
    assert manifest['wall_seconds_limit'] == WALL_SECONDS
    assert manifest['CPU_seconds_limit'] == CPU_SECONDS
    bindings = {str(ROOT / v['name']): v['sha256'] for v in manifest['files']}
    assert len(bindings) == len(manifest['files']) and str(SELF) in bindings
    prepared = loads(files.read(str(PREPARED), PREPARED_SHA))
    assert bindings[str(PREPARED)] == PREPARED_SHA
    for item in prepared['files']:
        assert bindings[str(ROOT / item['name'])] == item['sha256']
    assert Path(__file__).resolve() == files.path(str(SELF)).resolve()
    files.verify(bindings)
    return bindings


def gate(files):
    # Check completion before expensive scans; do not wait or launch training.
    value = loads(files.read(str(guarded.HERE / 'TRAINING_RECEIPTS_COMPLETE.json')))
    assert value['status'] == '15_new_wave_receipts_plus_twelve_prior_paths_accepted'
    assert value['protocol_sha256'] == PROTOCOL_SHA and len(value['receipt_sha256']) == 15
    ticket = loads(files.read(str(ROOT / 'continuation_after020_launcher_ticket.json')))
    assert process_command(ticket['pid']) is None, 'Training parent must have exited'
    guarded.guard(files)
    guarded.latches(files, loads(files.read(str(guarded.REVIEW))))
    rows, usage = resources(files)
    check_limits(usage)
    assert not usage['active_GPU_attempts'], 'No overlap with training or GPU work'
    for row in rows.values():
        if 'ended_unix' not in row:
            assert not row['label'].startswith('continuation_after020_'), 'Training session still open'
    assert 'torch' not in sys.modules and os.environ.get('CUDA_VISIBLE_DEVICES') == ''
    return usage


def validate_result(value):
    assert value['schema'] == 'factorial_training_model_bindings_v1'
    assert value['status'] == 'completed_training_model_bytes_bound_not_evaluation_admission'
    assert value['protocol_sha256'] == PROTOCOL_SHA
    assert value['completed_new_bases'] == 6 and value['completed_new_continuations'] == 27
    endpoints = value['new_evaluation_endpoints']
    assert len(endpoints) == len({v['endpoint_id'] for v in endpoints}) == 60
    assert value['reused24_authentication_sha256'] == evidence.REUSE24_SHA
    for name in ('model_loaded', 'model_audit_repeated', 'new_GPU_work', 'evaluation_admitted'):
        assert value[name] is False
    assert value['model_bound_request_blueprint']['execution_admitted'] is False


def run(project, expected):
    assert os.name == 'posix' and 'torch' not in sys.modules
    assert os.environ.get('CUDA_VISIBLE_DEVICES') == ''
    files = Files(project)
    # A duplicate must not write a failure into the active/completed operation.
    lock = files.path(str(PREFIX) + '.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    result_path = files.path(str(PREFIX) + '.json')
    failure_path = files.path(str(PREFIX) + '_FAILURE.json')
    intent_path = files.path(str(PREFIX) + '_execution.json')
    assert not any(p.exists() for p in (result_path, failure_path, intent_path)), 'Single-use acceptance; no automatic retry'
    started = time.time()
    cmd = command(files, expected)
    assert process_command(os.getpid()) == cmd
    assert os.getsid(0) == os.getpgid(0) == os.getpid()
    name, row = register_attempt(files, 'factorial_training_acceptance_CPU', cmd, None, pid=os.getpid())
    stopped, faults = threading.Event(), []
    watcher = None

    def interrupted(signum, frame):
        raise RuntimeError('Bounded CPU acceptance interrupted by signal ' + str(signum))

    handlers = {s: signal.signal(s, interrupted) for s in (signal.SIGTERM, signal.SIGINT, signal.SIGALRM, signal.SIGXCPU)}
    signal.alarm(WALL_SECONDS)
    try:
        resource.setrlimit(resource.RLIMIT_CPU, (max(1, CPU_SECONDS - 10), CPU_SECONDS))
        os.nice(15)
        publish_immutable(intent_path, encoded({'attempt': name, 'pid': os.getpid(), 'command': cmd,
            'started_unix': started, 'source_manifest_sha256': expected, 'GPU_job': False,
            'wall_seconds_limit': WALL_SECONDS, 'CPU_seconds_limit': CPU_SECONDS}))
        initial = gate(files)

        def watch():
            while not stopped.wait(POLL_SECONDS):
                try:
                    gate(files)
                    assert not failure_path.exists()
                    assert loads(files.read(name)) == row, 'Attempt stopped by independent guard'
                except BaseException as error:
                    faults.append(repr(error))
                    os.kill(os.getpid(), signal.SIGTERM)
                    return

        watcher = threading.Thread(target=watch, daemon=True)
        watcher.start()
        bindings = verify_sources(files, expected)
        value = evidence.collect(files.project)
        validate_result(value)
        stopped.set()
        watcher.join(JOIN_SECONDS)
        assert not watcher.is_alive() and not faults, 'CPU supervisor failed'
        final = gate(files)
        files.verify(bindings)
        assert loads(files.read(name)) == row, 'Terminal guard record cannot be replaced'
        value.update(attempt=name, command=cmd, pid=os.getpid(), started_unix=started,
            ended_unix=time.time(), source_manifest_sha256=expected,
            wrapper_initial_usage=initial, wrapper_final_usage=final,
            CPU_seconds=time.process_time(), wall_seconds_limit=WALL_SECONDS,
            CPU_seconds_limit=CPU_SECONDS, runtime_model_imported=False)
        publish_immutable(result_path, encoded(value))
        terminal = finish(files, name, row, 0)
        assert terminal['status'] == 'completed' and terminal['returncode'] == 0
        print('TRAINING_MODEL_BYTE_AUTHENTICATION_PASSED_NOT_EVALUATION_ADMISSION', flush=True)
        return value
    except BaseException as error:
        stopped.set()
        if watcher is not None:
            watcher.join(JOIN_SECONDS)
        publish_immutable(failure_path, encoded({'attempt': name, 'pid': os.getpid(),
            'source_manifest_sha256': expected, 'error': repr(error),
            'traceback': traceback.format_exc(), 'watchdog_errors': faults,
            'automatic_retry': False, 'scientific_artifacts_modified': False,
            'new_GPU_work': False, 'unix': time.time()}))
        finish(files, name, row, 1, error)
        raise
    finally:
        stopped.set()
        signal.alarm(0)
        for sig, handler in handlers.items():
            signal.signal(sig, handler)
        lock.close()


if __name__ == '__main__':
    assert len(sys.argv) == 2, 'Only the frozen source-manifest SHA is accepted'
    run(Path.cwd(), sys.argv[1])
