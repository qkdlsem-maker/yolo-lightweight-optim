"""Real Linux process bounds; evidence/model/guard boundaries are synthetic.

All overrides are memory-only in this test. The production wrapper has no
testing argument, duration override, alternative collector or retry option.
"""
import copy
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import run_factorial_training_acceptance as w
from continuation_artifact_receipts import encoded, loads, Files, ROOT, PROTOCOL_SHA


def synthetic_result():
    return {'schema': 'factorial_training_model_bindings_v1',
        'status': 'completed_training_model_bytes_bound_not_evaluation_admission',
        'protocol_sha256': PROTOCOL_SHA, 'completed_new_bases': 6,
        'completed_new_continuations': 27,
        'new_evaluation_endpoints': [{'endpoint_id': 'synthetic_' + str(i)} for i in range(60)],
        'reused24_authentication_sha256': w.evidence.REUSE24_SHA,
        'model_loaded': False, 'model_audit_repeated': False,
        'new_GPU_work': False, 'evaluation_admitted': False,
        'model_bound_request_blueprint': {'execution_admitted': False}}


def child(case, directory):
    root = Path(directory).resolve()
    f = Files(root)
    w.command = lambda files, expected: [sys.executable, '-B', '-u', str(Path(__file__).resolve()), '--child', case, str(root)]
    w.WALL_SECONDS = 1 if case == 'wall_timeout' else 12
    w.CPU_SECONDS = 2 if case == 'CPU_timeout' else 30
    w.POLL_SECONDS, w.JOIN_SECONDS = .03, 2
    binding = str(ROOT / 'synthetic_source.txt')
    original = f.sha(binding)
    counter = [0]

    def gate(files):
        counter[0] += 1
        if case == 'initial_gate_failure' or case == 'watchdog_failure' and counter[0] >= 2:
            raise RuntimeError('Synthetic gate rejects')
        return {'synthetic': True, 'active_GPU_attempts': []}

    def source(files, expected):
        assert expected == 'a' * 64
        if case == 'source_reject':
            raise AssertionError('Synthetic source rejection')
        return {binding: original}

    def collect(project):
        if case == 'collector_failure':
            raise RuntimeError('Synthetic collector fails')
        if case in ('wall_timeout', 'watchdog_failure', 'external_SIGTERM', 'active_duplicate'):
            time.sleep(20)
        if case == 'CPU_timeout':
            while True:
                hashlib.sha256(b'CPU limit fixture').digest()
        if case == 'source_mutation':
            f.path(binding).write_text('mutated synthetic source')
        if case == 'guard_terminal':
            p = next(f.path(str(ROOT / 'attempts')).glob('*.json'))
            row = loads(p.read_bytes())
            p.write_bytes(encoded(dict(row, status='failed', returncode=1,
                ended_unix=time.time(), stop_reason='synthetic independent guard terminal')))
        value = synthetic_result()
        if case == 'invalid_result':
            value['evaluation_admitted'] = True
        return value

    w.gate, w.verify_sources, w.evidence.collect = gate, source, collect
    w.run(root, 'a' * 64)


def run_processes(folder):
    outcomes = []
    env = dict(os.environ, CUDA_VISIBLE_DEVICES='', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
    for case in ('success', 'initial_gate_failure', 'source_reject', 'collector_failure',
                 'invalid_result', 'source_mutation', 'guard_terminal', 'watchdog_failure',
                 'wall_timeout', 'CPU_timeout', 'external_SIGTERM', 'active_duplicate'):
        root = folder / case
        phase = root / ROOT
        phase.mkdir(parents=True)
        (phase / 'synthetic_source.txt').write_text('immutable synthetic source')
        cmd = [sys.executable, '-B', '-u', str(Path(__file__).resolve()), '--child', case, str(root)]
        log = (root / 'process.log').open('xb')
        proc = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
        prefix = phase / 'factorial_training_acceptance'
        execution = Path(str(prefix) + '_execution.json')
        deadline = time.monotonic() + 8
        while not execution.exists() and proc.poll() is None:
            assert time.monotonic() < deadline
            time.sleep(.01)
        assert execution.exists()
        if case == 'active_duplicate':
            duplicate = subprocess.run(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True, timeout=5)
            (root / 'duplicate.log').write_bytes(duplicate.stdout)
            assert duplicate.returncode != 0 and proc.poll() is None
            assert not Path(str(prefix) + '_FAILURE.json').exists()
            assert len(list((phase / 'attempts').glob('*.json'))) == 1
        if case in ('external_SIGTERM', 'active_duplicate'):
            os.kill(proc.pid, signal.SIGTERM)
        code = proc.wait(timeout=18)
        log.close()
        assert w.process_command(proc.pid) is None
        attempts = list((phase / 'attempts').glob('*.json'))
        assert len(attempts) == 1
        row = loads(attempts[0].read_bytes())
        assert row['GPU_job'] is False and row['device'] is None
        assert row['pid'] == proc.pid and row['command'] == cmd and row['ended_unix'] >= row['started_unix']
        success = case == 'success'
        assert (code == 0) == success and (row['status'] == 'completed') == success
        assert Path(str(prefix) + '.json').exists() == success
        assert Path(str(prefix) + '_FAILURE.json').exists() != success
        if case == 'guard_terminal':
            assert row['stop_reason'] == 'synthetic independent guard terminal'
        if success:
            value = loads(Path(str(prefix) + '.json').read_bytes())
            w.validate_result(value)
            assert value['attempt'] == str(attempts[0].relative_to(root))
            assert value['runtime_model_imported'] is False
        preserved = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in phase.rglob('*') if p.is_file()}
        # Completed AND failed operations refuse any second execution, unchanged.
        duplicate = subprocess.run(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True, timeout=5)
        (root / 'terminal_duplicate.log').write_bytes(duplicate.stdout)
        assert duplicate.returncode != 0
        assert preserved == {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in phase.rglob('*') if p.is_file()}
        outcomes.append({'case': case, 'returncode': code, 'duplicate_rejected_unchanged': True,
            'CPU_only_closed_attempt': True, 'process_exited': True})
    return outcomes


def test_gate(folder):
    f = Files(folder)
    f.path(str(ROOT)).mkdir(parents=True)
    complete_name = str(w.guarded.HERE / 'TRAINING_RECEIPTS_COMPLETE.json')
    complete = {'status': '15_new_wave_receipts_plus_twelve_prior_paths_accepted',
        'protocol_sha256': PROTOCOL_SHA, 'receipt_sha256': {str(i): 'synthetic' for i in range(15)}}
    ticket = {'pid': 87654321}
    values = {complete_name: complete,
        str(ROOT / 'continuation_after020_launcher_ticket.json'): ticket,
        str(w.guarded.REVIEW): {'synthetic': True}}
    for name, value in values.items():
        path = f.path(name)
        path.parent.mkdir(exist_ok=True, parents=True)
        path.write_bytes(encoded(value))
    usage = {'allocated_GPU_hours': 100, 'preflight_GPU_hours': .7,
        'wall_days': 3, 'phase_disk_GiB': 20, 'free_disk_GiB': 1000,
        'active_GPU_attempts': []}
    original = {name: getattr(w, name) for name in ('resources', 'process_command')}
    old_guard, old_latches = w.guarded.guard, w.guarded.latches
    outcomes = []
    try:
        w.guarded.guard = lambda files: None
        w.guarded.latches = lambda files, review: None
        w.process_command = lambda pid: None
        w.resources = lambda files: ({}, usage)
        assert w.gate(f) == usage
        for case in ('missing_complete', 'bad_status', 'bad_protocol', 'missing_receipt',
                     'parent_alive', 'active_GPU', 'open_worker', 'gpu_cap', 'preflight_cap',
                     'wall_cap', 'disk_cap', 'free_cap', 'guard_lost', 'new_latch'):
            current = copy.deepcopy(complete)
            u, rows = copy.deepcopy(usage), {}
            w.process_command = lambda pid: None
            w.guarded.guard, w.guarded.latches = lambda files: None, lambda files, review: None
            if case == 'bad_status': current['status'] = 'in_progress'
            if case == 'bad_protocol': current['protocol_sha256'] = 'b' * 64
            if case == 'missing_receipt': current['receipt_sha256'].pop('0')
            if case == 'parent_alive': w.process_command = lambda pid: ['synthetic', 'alive']
            if case == 'active_GPU': u['active_GPU_attempts'] = ['synthetic']
            if case == 'open_worker': rows['synthetic'] = {'label': 'continuation_after020_worker__synthetic'}
            if case == 'gpu_cap': u['allocated_GPU_hours'] = 220
            if case == 'preflight_cap': u['preflight_GPU_hours'] = 3
            if case == 'wall_cap': u['wall_days'] = 10
            if case == 'disk_cap': u['phase_disk_GiB'] = 200
            if case == 'free_cap': u['free_disk_GiB'] = 149
            def reject(*args): raise RuntimeError('Synthetic guard or latch fails')
            if case == 'guard_lost': w.guarded.guard = reject
            if case == 'new_latch': w.guarded.latches = reject
            w.resources = lambda files: (rows, u)
            p = f.path(complete_name)
            p.write_bytes(encoded(current))
            if case == 'missing_complete': p.unlink()
            try: w.gate(f)
            except (AssertionError, FileNotFoundError, RuntimeError): outcomes.append(case)
            else: raise AssertionError('Gate accepted ' + case)
    finally:
        for name, value in original.items(): setattr(w, name, value)
        w.guarded.guard, w.guarded.latches = old_guard, old_latches
    return outcomes


def main():
    if len(sys.argv) == 4 and sys.argv[1] == '--child':
        return child(sys.argv[2], sys.argv[3])
    assert len(sys.argv) == 2
    folder = Path(sys.argv[1]).resolve()
    folder.mkdir()  # exclusive run; failed attempts are retained
    os.environ['CUDA_VISIBLE_DEVICES'] = ''
    results = run_processes(folder)
    gates = test_gate(folder / 'gate_boundaries')
    assert 'torch' not in sys.modules
    result = {'status': 'passed', 'process_cases': results, 'gate_rejection_cases': gates,
        'real_Linux_process_cases': len(results), 'real_gate_rejection_cases': len(gates),
        'GPU_work': False, 'production_collect_executed': False,
        'source_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (Path(__file__), Path(w.__file__))},
        'limits': 'Model, completed receipt, source admission and independent guard boundaries are synthetic; actual full-training collection is still pending.'}
    (folder / 'RESULT.json').write_bytes(encoded(result))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
