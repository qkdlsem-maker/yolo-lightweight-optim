"""Linux file/request tests; all model and produced evaluator metadata synthetic.

Consumes the actual frozen blueprint and the existing input proof as data only.
Never runs completed authentication, original evaluators, model loading or GPU.
"""
import copy
import importlib.util
import json
import os
from pathlib import Path
import sys

import factorial_evaluation_adapter as a
from continuation_artifact_receipts import Files, ROOT, loads


def synthetic_acceptance(bp):
    prepared=copy.deepcopy(bp)
    endpoints=[]
    for j in prepared['jobs']:
        cp=copy.deepcopy(j['native_bdd_request']['checkpoint'])
        cp['sha256']=a.digest(('synthetic model '+cp['path']).encode())
        proof={'fixture':'synthetic completed receipt, not actual training evidence'}
        for q in (j['native_bdd_request'],*j['prediction_requests'].values()):q['checkpoint']=copy.deepcopy(cp)
        j['completion_evidence_required']=proof
        endpoints.append({'endpoint_id':j['endpoint_id'],'role':j['role'],'checkpoint':cp,'completion_evidence':proof})
    prepared['status']='completed_model_hashes_bound_current_data_and_execution_admission_pending'
    return {'schema':'factorial_training_model_bindings_v1','status':'completed_training_model_bytes_bound_not_evaluation_admission',
        'protocol_sha256':a.PROTOCOL_SHA,'completed_new_bases':6,'completed_new_continuations':27,
        'evaluation_admitted':False,'new_GPU_work':False,'model_loaded':False,'model_audit_repeated':False,
        'new_evaluation_endpoints':endpoints,'model_bound_request_blueprint':prepared}


def main(folder, project):
    assert os.name=='posix'
    folder.mkdir(exist_ok=False);f=Files(folder)
    source=Path(__file__).resolve().parent
    raw=(source/'factorial_evaluation_request_blueprint.json').read_bytes()
    assert a.digest(raw)==a.BLUEPRINT_SHA
    bp=loads(raw);accepted=synthetic_acceptance(bp)
    ref={'path':str(ROOT/'factorial_training_acceptance.json'),'sha256':'1'*64}
    plan=a.plan_from_bound(accepted,bp,ref)
    assert len(plan['jobs'])==60 and len(plan['reuse_only'])==24
    assert [j['lane'] for j in plan['jobs']]==[0,1]*30
    assert [j['wave'] for j in plan['jobs']]==[v for v in range(1,31) for _ in range(2)]
    assert plan['execution_admitted'] is False
    cases=[]

    def reject(name,fn):
        try:fn()
        except (AssertionError,KeyError,TypeError,ValueError,FileNotFoundError):cases.append(name)
        else:raise AssertionError('Accepted invalid fixture: '+name)

    for key,val in [('completed_new_bases',5),('completed_new_continuations',26),('status','pending'),
                    ('model_loaded',True),('model_audit_repeated',True),('evaluation_admitted',True),('new_GPU_work',True)]:
        v=copy.deepcopy(accepted);v[key]=val
        reject('acceptance_'+key,lambda v=v:a.plan_from_bound(v,bp,ref))
    for name,mutate in [
        ('missing_endpoint',lambda v:v['new_evaluation_endpoints'].pop()),
        ('duplicate_endpoint',lambda v:v['new_evaluation_endpoints'].__setitem__(1,copy.deepcopy(v['new_evaluation_endpoints'][0]))),
        ('wrong_order',lambda v:v['new_evaluation_endpoints'].reverse()),
        ('wrong_role',lambda v:v['new_evaluation_endpoints'][0].__setitem__('role','primary')),
        ('unbound_model',lambda v:v['new_evaluation_endpoints'][0]['checkpoint'].__setitem__('sha256',None)),
        ('wrong_model_path',lambda v:v['new_evaluation_endpoints'][0]['checkpoint'].__setitem__('path','other.pt')),
        ('path_traversal',lambda v:v['new_evaluation_endpoints'][0]['checkpoint'].__setitem__('path','../other.pt')),
        ('changed_model_bound_request',lambda v:v['model_bound_request_blueprint']['jobs'][0]['native_bdd_request']['checkpoint'].__setitem__('sha256','2'*64)),
        ('changed_source',lambda v:v['model_bound_request_blueprint']['jobs'][0]['native_bdd_request']['source_sha256'].__setitem__('run_native_bdd_validation.py','2'*64)),
        ('changed_output',lambda v:v['model_bound_request_blueprint']['jobs'][0].__setitem__('output','elsewhere')),
        ('changed_reuse',lambda v:v['model_bound_request_blueprint']['reuse_only'].pop()),
        ('changed_caps',lambda v:v['model_bound_request_blueprint']['global_resource_caps'].__setitem__('hard_allocated_GPU_hours',221))]:
        v=copy.deepcopy(accepted);mutate(v)
        reject(name,lambda v=v:a.plan_from_bound(v,bp,ref))
    reject('wrong_acceptance_location',lambda:a.plan_from_bound(accepted,bp,{'path':'other.json','sha256':'1'*64}))
    reject('invalid_stage',lambda:a.spec('extra_inference'))

    proofraw=(source/'factorial_current_inputs_auth.json').read_bytes()
    assert a.digest(proofraw)=='5a2e9efb95fe8609f7a25c698cb49ed96a68863923b5122de825709a1080ab00'
    proof=loads(proofraw);contract=a.runtime_contract(proof)
    assert len(contract['prediction_sources'])==6 and len(contract['validation_sources'])==9
    for name,mutate in [
        ('missing_native_source',lambda v:v['bound_artifacts'].pop(next(k for k in v['bound_artifacts'] if k.endswith('/ultralytics/engine/predictor.py')))),
        ('missing_default_cfg',lambda v:v['bound_artifacts'].pop(next(k for k in v['bound_artifacts'] if k.endswith('/ultralytics/cfg/default.yaml')))),
        ('wrong_input_status',lambda v:v.__setitem__('status','pending'))]:
        v=copy.deepcopy(proof);mutate(v);reject(name,lambda v=v:a.runtime_contract(v))
    def put(name,value):
        path=f.path(name);path.parent.mkdir(parents=True,exist_ok=True)
        path.write_bytes(value if isinstance(value,bytes) else a.canonical(value))
        return f.sha(name)

    # Output verification fixture uses synthetic image manifests. Request schema,
    # endpoint ordering, scientific settings and original script sources remain.
    for dataset,count in [('bdd',10000),('kitti',7481)]:
        images=[{'id':i,'file_name':str(i)+'.png','width':640,'height':480,'sha256':'3'*64} for i in range(count)]
        name='fixture_inputs/'+dataset+'.json';sha=put(name,images)
        for job in plan['jobs']:
            job['prediction_requests'][dataset]['image_manifest']={'path':name,'sha256':sha}
    original=project/plan['evaluation_tools']/'run_final_evaluation_v2.py'
    module_spec=importlib.util.spec_from_file_location('original_orchestrator_readonly',original)
    legacy=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(legacy)
    # Only the original pure request builder is called, never validate/execute.
    oldcwd=Path.cwd();os.chdir(folder)
    successes=[];pair=plan['jobs'][:2]
    try:
        for job in pair:
            uuid='GPU-fixture-device-'+str(job['lane'])
            rt={n:copy.deepcopy(contract[n]) for n in ('python','platform','packages')}
            rt.update(native_source_sha256=contract['prediction_sources'],requested_device=str(job['lane']),
                CUDA_VISIBLE_DEVICES=str(job['lane']),selected_device='cuda:0',gpu={'uuid':uuid},torch_cuda_build='12.1',
                torch_num_threads=2,evaluation_seed=0,deterministic_algorithms=True,deterministic_warn_only=True,
                cudnn_deterministic=True,cudnn_benchmark=False)
            reject('early_scoring_'+str(job['lane']),lambda:a.request(f,plan,job,'bdd_common'))
            for stage,script,gpu in a.STEPS:
                q=a.request(f,plan,job,stage);qp=a.request_path(plan,job,stage);qh=put(qp,q)
                cmd=a.task(f,plan,job,stage)
                assert cmd['command']==[str(folder/'venv/bin/python'),str(Path(plan['evaluation_tools'])/script),
                    '--request',qp,'--output',job['output']+'/'+stage]+(['--device',str(job['lane'])] if gpu else [])
                assert cmd['device']==(job['lane'] if gpu else None)
                assert cmd['environment']=={'PYTHONPATH':str(folder/a.ISOLATED)}
                if stage=='native_bdd':
                    m={'schema':'native_bdd_validation_manifest_v1','request':q,'runtime':rt,
                       'native_validation_source_sha256':contract['validation_sources']}
                    c={'schema':'native_bdd_validation_complete_v1','files':{}}
                elif stage in ('bdd_predictions','kitti_predictions'):
                    count=10000 if q['dataset_id']=='bdd' else 7481
                    b={'endpoint_id':q['endpoint_id'],'dataset_id':q['dataset_id'],'checkpoint_sha256':q['checkpoint']['sha256'],
                       'protocol_sha256':a.PROTOCOL_SHA,'source_sha256':dict(q['source_sha256'],frozen_request=a.digest(a.canonical(q))),
                       'runtime':rt,'inference':bp['inference']}
                    m={'schema':'prediction_archive_v1','bindings':b,'batch_size':32,'images':loads(f.read(q['image_manifest']['path']))}
                    c={'schema':'prediction_archive_complete_v1','images':count,'batches':(count+31)//32,'batch_commit_sha256':['4'*64]*((count+31)//32)}
                else:
                    assert q==legacy.scoring_request(plan,job,stage.split('_')[0],stage=='kitti_native')
                    b=loads(f.read(q['archive_path']+'/MANIFEST.json'))['bindings']
                    if stage=='kitti_native':
                        m={'schema':'native_kitti_archive_scoring_manifest_v1','request':q,'prediction_bindings':b,
                           'core_sha256':a.NATIVE_CORE,'images':7481,'label_member_sha256':{str(i):'5'*64 for i in range(7481)},
                           'runtime':{'python':contract['python']+' synthetic build string','platform':contract['platform']}}
                        c={'schema':'native_kitti_archive_scores_complete_v1','files':{}}
                    else:
                        m={'schema':'common_archive_scoring_manifest_v1','request':q,'prediction_bindings':b,
                           'runtime':{'pycocotools_version':contract['isolated_pycocotools'],'numpy_version':contract['packages']['numpy'],
                            'cocoeval_python_sha256':contract['isolated_dependency_files']['pycocotools/cocoeval.py']}}
                        c={'schema':'common_archive_scores_complete_v1','outputs':{k+'.json':'6'*64 for k in q['annotation_views']}}
                mp=job['output']+'/'+stage+'/MANIFEST.json';cp=job['output']+'/'+stage+'/COMPLETE.json'
                c['manifest_sha256']=put(mp,m);put(cp,c)
                result=a.verify_step(f,plan,job,stage,qh,uuid,contract)
                assert result=={qp:qh,mp:f.sha(mp),cp:f.sha(cp)};successes.append(job['endpoint_id']+'/'+stage)
                # Negative output tests use the first lane; second lane tests GPU1 binding positively.
                if job['lane']==0:
                    original_m=copy.deepcopy(m);original_c=copy.deepcopy(c)
                    mutations=[('schema',lambda x:x.__setitem__('schema','wrong'))]
                    if gpu:
                        def runtime(x):return x['runtime'] if stage=='native_bdd' else x['bindings']['runtime']
                        for key,val in [('requested_device','1'),('CUDA_VISIBLE_DEVICES','1'),('selected_device','cuda:1'),
                                        ('evaluation_seed',1),('torch_num_threads',1),('torch_cuda_build','other'),
                                        ('deterministic_algorithms',False),('deterministic_warn_only',False),
                                        ('cudnn_deterministic',False),('cudnn_benchmark',True),('gpu',{'uuid':'GPU-wrong'}),
                                        ('packages',{}),('native_source_sha256',{}),('platform','other')]:
                            mutations.append(('runtime_'+key,lambda x,k=key,v=val:runtime(x).__setitem__(k,v)))
                    if stage=='native_bdd':mutations.append(('validation_source',lambda x:x.__setitem__('native_validation_source_sha256',{})))
                    elif stage.endswith('predictions'):
                        for key,val in [('endpoint_id','other'),('dataset_id','other'),('checkpoint_sha256','9'*64),
                                        ('protocol_sha256','9'*64),('source_sha256',{}),('inference',{})]:
                            mutations.append((key,lambda x,k=key,v=val:x['bindings'].__setitem__(k,v)))
                        mutations += [('image_order',lambda x:x['images'].reverse()),('batch_size',lambda x:x.__setitem__('batch_size',64))]
                    elif stage=='kitti_native':
                        mutations += [('core',lambda x:x.__setitem__('core_sha256',{})),('labels',lambda x:x['label_member_sha256'].pop('0'))]
                    else:mutations += [('CPU_runtime',lambda x:x['runtime'].__setitem__('numpy_version','other')),
                                       ('prediction_binding',lambda x:x.__setitem__('prediction_bindings',{}))]
                    for name,mutate in mutations:
                        changed=copy.deepcopy(original_m);mutate(changed);changed_c=copy.deepcopy(original_c)
                        changed_c['manifest_sha256']=put(mp,changed);put(cp,changed_c)
                        reject(stage+'_'+name,lambda:a.verify_step(f,plan,job,stage,qh,uuid,contract))
                    put(mp,original_m);put(cp,original_c)
                    changed=copy.deepcopy(original_c);changed['manifest_sha256']='0'*64;put(cp,changed)
                    reject(stage+'_completion_hash',lambda:a.verify_step(f,plan,job,stage,qh,uuid,contract))
                    put(cp,original_c)
                    reject(stage+'_request_hash',lambda:a.verify_step(f,plan,job,stage,'0'*64,uuid,contract))
                    assert a.verify_step(f,plan,job,stage,qh,uuid,contract)==result
            audit=a.audit_task(f,plan,job,{'path':str(ROOT/'prepared_fixture_plan.json'),'sha256':'8'*64})
            assert audit['device'] is None and audit['command'][-2:]==['--endpoint',job['endpoint_id']]
            assert '--device' not in audit['command']
        # Actual file path boundary, not a mocked path reader.
        link=f.path('link.json');link.symlink_to(f.path(a.request_path(plan,pair[0],'native_bdd')))
        reject('symlink_evidence',lambda:f.read('link.json'))
        reject('path_escape',lambda:f.read('../outside.json'))
        assert 'torch' not in sys.modules
        return {'status':'passed','plan_assembly_endpoints':60,'plan_reuse_only':24,'paired_stage_successes':len(successes),
            'original_scoring_request_parity':6,'single_endpoint_auditor_commands':2,'rejection_cases':len(cases),'cases':cases,
            'source_sha256':{p.name:a.digest(p.read_bytes()) for p in (Path(a.__file__),Path(__file__))},
            'consumed_data_sha256':{'blueprint':a.digest(raw),'existing_current_input_proof':a.digest(proofraw),
                'original_orchestrator':a.digest(original.read_bytes())},'GPU_work':False,'production_evaluation_launched':False,
            'fixture':str(folder),'limits':['Actual Linux filesystem/request/command/runtime-metadata tests; no process workflow or real evaluator execution.',
                'Synthetic model/receipt/image manifests/evaluator outputs/GPU UUID and runtime metadata. Uses authentic blueprint and existing completed input-proof bytes as test data.',
                'Original scoring_request() pure builder called for parity only. No completed authentication, numerical audits, model loading, inference or scoring repeated.',
                'Metadata verification is not independent full archive/numerical audit or production admission. Full dispatcher and evidence/guard integration remain pending.']}
    finally:os.chdir(oldcwd)


if __name__=='__main__':
    print(json.dumps(main(Path(sys.argv[1]).resolve(),Path(sys.argv[2]).resolve()),indent=2))
