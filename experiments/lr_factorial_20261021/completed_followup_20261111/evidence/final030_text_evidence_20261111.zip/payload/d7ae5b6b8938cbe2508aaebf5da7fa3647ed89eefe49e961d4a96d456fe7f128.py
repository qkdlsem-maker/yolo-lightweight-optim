"""Filesystem and provenance integration tests; all model/prediction bytes synthetic.

No inference, numerical audit replay, metric comparison or research data selection.
Run on Linux to exercise real symlinks as well as path and batch inventories.
"""
import copy
import json
import os
from pathlib import Path
import sys
import tempfile
import time
import factorial_reused_evaluation_evidence_v2 as e

H='a'*64

def write(root,name,value):
    p=root/name;p.parent.mkdir(parents=True,exist_ok=True)
    raw=value if isinstance(value,bytes) else e.canonical(value)
    p.write_bytes(raw);return e.digest(raw)

def archive(root,folder='ep/bdd_predictions',dataset='bdd',device='0'):
    images=[{'id':i+1,'file_name':'%06d.png'%i,'width':50,'height':40,'sha256':H} for i in range(33)]
    ih=write(root,dataset+'_images.json',images)
    q={'endpoint_id':'old','dataset_id':dataset,'checkpoint':{'path':'model.pt','sha256':H},
       'protocol':{'path':'protocol.json','sha256':H},'source_sha256':{'a.py':H},
       'image_manifest':{'path':dataset+'_images.json','sha256':ih}}
    runtime={'requested_device':device,'CUDA_VISIBLE_DEVICES':device,'gpu':{'uuid':'GPU-'+e.GPU_UUID[device]}}
    m={'schema':'prediction_archive_v1','batch_size':32,'images':images,
       'bindings':{'endpoint_id':'old','dataset_id':dataset,'checkpoint_sha256':H,'protocol_sha256':H,
       'source_sha256':dict(q['source_sha256'],frozen_request=e.digest(e.canonical(q))),
       'runtime':runtime,'inference':{'fixed':'synthetic'}}}
    (root/folder/'staging').mkdir(parents=True);(root/folder/'.lock').touch()
    mh=write(root,folder+'/MANIFEST.json',m);hashes=[]
    for i in range(2):
        ims=images[i*32:(i+1)*32];records=[];base=folder+'/batches/%06d/'%i
        for im in ims:
            name='%08d.json'%im['id'];h=write(root,base+name,b'synthetic payload\n')
            records.append({'file':name,'sha256':h,'image_sha256':im['sha256']})
        commit={'schema':'prediction_batch_v1','archive_manifest_sha256':mh,'batch_index':i,'records':records,
          'actual_forward_inputs':[{'shape':[len(ims),3,640,640],'dtype':'torch.float32','device':'cuda:0'}]}
        hashes.append(write(root,base+'COMMIT.json',commit))
    c={'schema':'prediction_archive_complete_v1','manifest_sha256':mh,'images':33,'batches':2,'batch_commit_sha256':hashes}
    write(root,folder+'/COMPLETE.json',c)
    return m,c,q

def make_endpoint(root,lane=0,override=False):
    folder='old/endpoints/old';output='old';device=str(lane)
    checkpoint={'path':'model.pt','sha256':write(root,'model.pt',b'synthetic checkpoint')}
    # Bind model hash before publishing archives, preserving their complete chain.
    row={'endpoint_id':'new_alias','historical_endpoint_id':'old','checkpoint':checkpoint,'directory':folder}
    job={'endpoint_id':'old','output':folder,'lane':lane,'prediction_requests':{}}
    plan={'output_root':output,'_inference':{'fixed':'synthetic'},'common_source_sha256':{'common.py':H},
      'kitti_source_sha256':{'kitti.py':H},'annotation_views':{k:{'path':k,'sha256':H} for k in ('bdd_common','kitti_source_ignore','kitti_no_ignore_sensitivity')},
      'native_core_paths':{k:'core/'+k for k in e.CORE},'label_zip':{'path':'labels.zip','sha256':H}}
    marker={'endpoint_id':'old','outputs':{}};proof={'endpoint_id':'old','status':'passed','plan_sha256':e.OLD_PLAN_SHA,'audit_source_sha256':e.OLD_AUDITOR_SHA}
    recovery={'completed_device_overrides':{}};manifests={}
    def publish(step,q,m,c):
        mh=write(root,folder+'/'+step+'/MANIFEST.json',m);c['manifest_sha256']=mh
        ch=write(root,folder+'/'+step+'/COMPLETE.json',c)
        rh=write(root,output+'/requests/old/'+step+'.json',q)
        marker['outputs'][step]={'request_sha256':rh,'manifest_sha256':mh,'complete_sha256':ch};manifests[step]=m
    for dataset in ('bdd','kitti'):
        step=dataset+'_predictions';m,c,q=archive(root,folder+'/'+step,dataset,device)
        q['checkpoint']=checkpoint;m['bindings']['checkpoint_sha256']=checkpoint['sha256']
        m['bindings']['source_sha256']['frozen_request']=e.digest(e.canonical(q));mh=e.digest(e.canonical(m))
        for i in range(2):
            path=folder+'/'+step+'/batches/%06d/COMMIT.json'%i
            cm=json.loads((root/path).read_text());cm['archive_manifest_sha256']=mh
            c['batch_commit_sha256'][i]=write(root,path,cm)
        publish(step,q,m,c);job['prediction_requests'][dataset]=q
    q={'checkpoint':checkpoint,'endpoint_id':'old'};job['native_bdd_request']=q
    nd='0' if override else device
    m={'schema':'native_bdd_validation_manifest_v1','request':q,'runtime':{'requested_device':nd,'CUDA_VISIBLE_DEVICES':nd,'gpu':{'uuid':e.GPU_UUID[nd]}}}
    sh=write(root,folder+'/native_bdd/score.json',{'synthetic':True})
    c={'schema':'native_bdd_validation_complete_v1','files':{'MANIFEST.json':{'sha256':e.digest(e.canonical(m))},'score.json':{'sha256':sh}}}
    publish('native_bdd',q,m,c)
    proof['native_bdd']={'score_sha256':sh,'saved_statistics_exactly_reproduce_all_results_and_class_AP':True}
    if override:
        recovery['completed_device_overrides']['old/native_bdd']={k:v for k,v in marker['outputs']['native_bdd'].items() if k!='request_sha256'}
        recovery['completed_device_overrides']['old/native_bdd'].update(requested_device='0',gpu_uuid=e.GPU_UUID['0'])
    for step,dataset in [('bdd_common','bdd'),('kitti_common','kitti'),('kitti_native','kitti')]:
        pred=dataset+'_predictions';p=marker['outputs'][pred]
        q={'archive_path':folder+'/'+pred,'archive_manifest_sha256':p['manifest_sha256'],'archive_complete_sha256':p['complete_sha256']}
        m={'request':q,'prediction_bindings':manifests[pred]['bindings']}
        if step.endswith('common'):
            vs=['bdd_common'] if dataset=='bdd' else ['kitti_source_ignore','kitti_no_ignore_sensitivity']
            q.update(schema='common_archive_scoring_request_v1',dataset=dataset,source_sha256=plan['common_source_sha256'],annotation_views={v:plan['annotation_views'][v] for v in vs})
            outputs={v+'.json':write(root,folder+'/'+step+'/'+v+'.json',{'synthetic':True}) for v in vs}
            c={'schema':'common_archive_scores_complete_v1','outputs':outputs}
            proof[step]={'scores':{v:{'score_sha256':outputs[v+'.json'],'all_numeric_fields_replayed_exactly':True} for v in vs}}
        else:
            q.update(schema='native_kitti_archive_scoring_request_v1',source_sha256=plan['kitti_source_sha256'],native_core_paths=plan['native_core_paths'],label_zip=plan['label_zip'])
            m['core_sha256']=e.CORE
            sh=write(root,folder+'/'+step+'/score.json',{'synthetic':True})
            c={'schema':'native_kitti_archive_scores_complete_v1','files':{'MANIFEST.json':e.digest(e.canonical(m)),'score.json':sh}}
            proof['native_kitti']={'score_sha256':sh,'AP_R40_reconstructed_exactly_from_saved_curves':True}
        publish(step,q,m,c)
    return row,job,plan,proof,marker,recovery

def main():
    results=[]
    def case(name,fn,reject=False):
        with tempfile.TemporaryDirectory(prefix='reuse24_test_') as temp:
            root=Path(temp)
            try:fn(root)
            except (AssertionError,KeyError,ValueError,FileNotFoundError):
                if not reject:raise
            else:
                assert not reject,'Invalid evidence accepted: '+name
        results.append({'case':name,'passed':True,'expected_rejection':reject})
    def full(root,lane=0,override=False,mutate=None):
        args=make_endpoint(root,lane,override)
        if mutate:mutate(root,args)
        e.endpoint(e.Reader(root),*args)
    for lane,override in ((0,False),(1,False),(1,True)):
        case('six_output_chain_lane%d_override%s'%(lane,override),lambda r,lane=lane,override=override:full(r,lane,override))
    changes={
      'wrong_checkpoint':lambda r,a:a[0]['checkpoint'].update(sha256='b'*64),
      'failed_prior_audit':lambda r,a:a[3].update(status='failed'),
      'wrong_auditor':lambda r,a:a[3].update(audit_source_sha256='b'*64),
      'wrong_plan':lambda r,a:a[3].update(plan_sha256='b'*64),
      'wrong_endpoint':lambda r,a:a[4].update(endpoint_id='different'),
      'missing_output':lambda r,a:a[4]['outputs'].pop('bdd_common'),
      'missing_score_variant':lambda r,a:a[3]['kitti_common']['scores'].pop('kitti_source_ignore'),
      'audit_numeric_failure':lambda r,a:a[3]['bdd_common']['scores']['bdd_common'].update(all_numeric_fields_replayed_exactly=False),
      'saved_statistics_failure':lambda r,a:a[3]['native_bdd'].update(saved_statistics_exactly_reproduce_all_results_and_class_AP=False),
      'native_curve_failure':lambda r,a:a[3]['native_kitti'].update(AP_R40_reconstructed_exactly_from_saved_curves=False),
      'model_corruption':lambda r,a:(r/'model.pt').write_bytes(b'changed'),
      'score_corruption':lambda r,a:(r/'old/endpoints/old/native_bdd/score.json').write_bytes(b'changed'),
      'missing_payload':lambda r,a:(r/'old/endpoints/old/kitti_predictions/batches/000001/00000033.json').unlink(),
      'unsealed_output_extra':lambda r,a:write(r,'old/endpoints/old/kitti_native/extra.json',{}),
      'missing_override':lambda r,a:a[5]['completed_device_overrides'].clear(),
      'changed_override_hash':lambda r,a:a[5]['completed_device_overrides']['old/native_bdd'].update(manifest_sha256='b'*64),
    }
    for name,mutate in changes.items():
        case(name,lambda r,m=mutate:full(r,1,True,m),True)
    def pred(root,mutation):
        m,c,q=archive(root);mutation(root,m,c,q)
        e.prediction_archive(e.Reader(root),'ep/bdd_predictions',m,c,q,{'fixed':'synthetic'})
    def change_commit(root,c,key,value):
        name='ep/bdd_predictions/batches/000001/COMMIT.json';cm=json.loads((root/name).read_text())
        cm[key]=value;c['batch_commit_sha256'][1]=write(root,name,cm)
    mutations={
      'wrong_total':lambda r,m,c,q:c.update(images=32),
      'missing_commit':lambda r,m,c,q:c['batch_commit_sha256'].pop(),
      'rebound_wrong_batch_index':lambda r,m,c,q:change_commit(r,c,'batch_index',0),
      'rebound_wrong_forward_shape':lambda r,m,c,q:change_commit(r,c,'actual_forward_inputs',[{'shape':[1,3,320,640],'dtype':'torch.float32','device':'cuda:0'}]),
      'rebound_half_precision':lambda r,m,c,q:change_commit(r,c,'actual_forward_inputs',[{'shape':[1,3,640,640],'dtype':'torch.float16','device':'cuda:0'}]),
      'rebound_missing_record':lambda r,m,c,q:change_commit(r,c,'records',[]),
      'payload_corruption':lambda r,m,c,q:write(r,'ep/bdd_predictions/batches/000000/00000001.json',b'changed'),
      'extra_batch':lambda r,m,c,q:(r/'ep/bdd_predictions/batches/000002').mkdir(),
      'extra_prediction':lambda r,m,c,q:write(r,'ep/bdd_predictions/batches/000000/99999999.json',{}),
      'input_roster_corruption':lambda r,m,c,q:write(r,'bdd_images.json',[]),
      'changed_inference':lambda r,m,c,q:m['bindings'].update(inference={'fixed':'changed'}),
      'changed_frozen_request':lambda r,m,c,q:q.update(endpoint_id='other'),
    }
    for name,mutation in mutations.items():case(name,lambda r,m=mutation:pred(r,m),True)
    case('uncommitted_staging_preserved',lambda r:pred(r,lambda r,m,c,q:write(r,'ep/bdd_predictions/staging/partial/file.tmp',b'partial')))
    def links(root,change=False,disallow=False):
        write(root,'target',b'not reread');(root/'native').mkdir();os.symlink('../target',root/'native/link')
        expected={'link':{'symlink_target':'../elsewhere' if change else '../target'}}
        e.inventory(e.Reader(root),'native',expected,not disallow)
    if os.name=='posix':
        case('native_links_match_sealed_text',links)
        case('native_link_changed',lambda r:links(r,True),True)
        case('links_rejected_for_native_kitti',lambda r:links(r,False,True),True)
        def payload_symlink(root):
            m,c,q=archive(root);p=root/'ep/bdd_predictions/batches/000000/00000001.json'
            p.unlink();write(root,'target',b'synthetic payload\n');os.symlink('../../../../target',p)
            e.prediction_archive(e.Reader(root),'ep/bdd_predictions',m,c,q,{'fixed':'synthetic'})
        case('same_bytes_symlink_prediction_rejected',payload_symlink,True)
    for bad in ('../escape','/absolute','a/../b','a\\b','a//b','a/./b'):
        case('unsafe_path_'+bad,lambda r,b=bad:e.Reader(r).files.path(b),True)
    case('duplicate_json_key',lambda r:e.loads(b'{"a":1,"a":2}'),True)
    case('nonfinite_json',lambda r:e.loads(b'{"a":NaN}'),True)
    assert 'torch' not in sys.modules
    out={'schema':'factorial_reused_evaluation_CPU_v1','status':'passed','utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
       'os':os.name,'cases':results,'case_count':len(results),'synthetic_model_prediction_and_audit_boundaries':True,
       'actual_historical24_authenticated':False,'new_inference':False,'new_scoring':False,'new_GPU_numerical_validation':False,
       'source_sha256':{p.name:e.digest(p.read_bytes()) for p in (Path(e.__file__),Path(__file__))}}
    print(json.dumps(out,indent=2))

if __name__=='__main__':main()
