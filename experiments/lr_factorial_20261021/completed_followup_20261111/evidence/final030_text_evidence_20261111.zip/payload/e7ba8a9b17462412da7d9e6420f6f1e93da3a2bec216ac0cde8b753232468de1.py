"""Read-only admission and budget checks for fixed continuation fixtures.

No Torch/CUDA imports, process launch, source mutation or completed-result retry.
Pure functions accept fabricated records in CPU tests; production callers obtain
records, disk usage and process identities directly from the local Linux host.
"""
import itertools
import math
import os
from pathlib import Path
import shutil
import subprocess
import time
from continuation_artifact_receipts import ROOT, PROTOCOL_SHA, Files, loads, expected_command
from continuation_input_bindings import AUDIT_SOURCE, ANCHORS

PREFIX = 'continuation_preflight__'
RUNTIME = ROOT / 'continuation_preflight_runtime.py'
RUNNER = ROOT / 'run_continuation_fixture.py'
DISPATCHER = ROOT / 'run_continuation_preflight.py'
GUARD_SHA = '6d5eea661c55737a96a62907a79cdc7f3f43249a47e66ebae493ff7c5cfcc1f2'
LATCHES = ('BUDGET_STOP.json', 'CONTINUATION_PREFLIGHT_BUDGET_STOP.json',
           'CONTINUATION_PREFLIGHT_FAILURE.json')


class BudgetExceeded(RuntimeError):
    def __init__(self, scope, snapshot):
        self.scope, self.snapshot = scope, snapshot
        super().__init__(scope)


def positive(value, zero=False):
    assert type(value) in (int, float) and math.isfinite(value)
    assert value >= 0 if zero else value > 0


def account(records, now, phase_bytes, free_bytes):
    positive(now); positive(phase_bytes, True); positive(free_bytes, True)
    start, total, preflight = now, 0., 0.
    active = []
    for name, row in records.items():
        positive(row['started_unix']); assert row['started_unix'] <= now
        assert type(row['GPU_job']) is bool
        start = min(start, row['started_unix'])
        ended = row.get('ended_unix', now)
        positive(ended); assert row['started_unix'] <= ended <= now
        if row['GPU_job']:
            seconds = ended - row['started_unix']
            total += seconds
            if row['label'].startswith(PREFIX) or RUNNER.as_posix() in row['command']:
                preflight += seconds
            if 'ended_unix' not in row:
                active.append(name)
    return {'now_unix': now, 'allocated_GPU_hours': total / 3600,
            'preflight_GPU_hours': preflight / 3600, 'wall_days': (now - start) / 86400,
            'phase_disk_GiB': phase_bytes / 2**30, 'free_disk_GiB': free_bytes / 2**30,
            'active_GPU_attempts': active}


def check_limits(snapshot):
    for key, cap, scope in [('allocated_GPU_hours', 220., 'global_GPU_hours'),
                            ('preflight_GPU_hours', 3., 'preflight_GPU_hours'),
                            ('wall_days', 10., 'global_wall_days'),
                            ('phase_disk_GiB', 200., 'global_phase_disk')]:
        positive(snapshot[key], True)
        if snapshot[key] >= cap:
            raise BudgetExceeded(scope, snapshot)
    positive(snapshot['free_disk_GiB'], True)
    if snapshot['free_disk_GiB'] < 150.:
        raise BudgetExceeded('global_free_disk', snapshot)


def read_records(files):
    rows = {}
    for path in sorted(files.path((ROOT / 'attempts').as_posix()).glob('*.json')):
        name = path.relative_to(files.project).as_posix()
        rows[name] = loads(files.read(name))
    return rows


def resources(files):
    rows = read_records(files)
    size = int(subprocess.check_output(['du', '-s', '-B1', str(files.path(ROOT.as_posix()))], text=True).split()[0])
    return rows, account(rows, time.time(), size, shutil.disk_usage(files.project).free)


def no_latches(files):
    for name in LATCHES:
        assert not files.path((ROOT / name).as_posix()).exists(), f'Stop/failure latch: {name}'


def relative(files, name):
    path = Path(name)
    if path.is_absolute():
        path = path.relative_to(files.project)
    key = path.as_posix()
    files.path(key)
    return key


def verify_completed_bases(context):
    """Wait for all six bases, not just representatives, to avoid queue races.

    Reuse the independent audit reports and verify their bound bytes. Never
    reload a model here or invent missing historical AMP counts.
    """
    f = context.files
    bindings = {}
    def read(name):
        name = relative(f, name)
        raw = f.read(name)
        from hashlib import sha256
        value = sha256(raw).hexdigest()
        if name in bindings:
            assert bindings[name] == value
        bindings[name] = value
        return loads(raw)
    gate = read(ROOT / 'completed_base_audit_gate.json')
    assert gate['status'] == 'all_six_completed_bases_passed' and gate['protocol_sha256'] == PROTOCOL_SHA
    assert gate['script_sha256'] == ANCHORS[AUDIT_SOURCE.as_posix()] == f.sha(AUDIT_SOURCE.as_posix())
    done = read(ROOT / 'BASE_TRAINING_COMPLETE.json')
    assert done['status'] == 'complete' and type(done['new_base_runs']) is int and done['new_base_runs'] == 6
    pairs = {(model, tuple(pair)) for model in ('nano', 'large') for pair in itertools.combinations((404, 505, 606), 2)}
    checks = gate['pairwise_checks']
    assert len(checks) == 6 and {(x['model'], tuple(x['seeds'])) for x in checks} == pairs
    for row in checks:
        assert row['different_initial_parameter_names']
        assert row['both_sampled_inputs_differ_at_all_100_epochs'] is True
        assert row['raw_final_and_EMA_parameters_differ'] is True
    for model, seed in itertools.product(('nano', 'large'), (404, 505, 606)):
        proof = read(ROOT / 'completed_base_audits' / f'{model}_seed{seed}.json')
        assert proof['status'] == 'passed' and proof['script_sha256'] == gate['script_sha256']
        assert proof['protocol_sha256'] == PROTOCOL_SHA
        row = proof['run']
        assert (row['model'], row['seed'], row['epochs']) == (model, seed, 100)
        for key in ('finite_saved_tensors', 'fixed_dfl_preserved', 'checkpoint_matches_raw_EMA_at_saved_precision'):
            assert row[key] is True
        counts = row['actual_step_counts']
        assert counts.keys() == {'attempted', 'applied', 'skipped'}
        assert all(type(v) is int and v >= 0 for v in counts.values())
        assert counts['attempted'] == counts['applied'] + counts['skipped'] and counts['applied'] > 0
        assert type(row['native_EMA_updates']) is int and row['native_EMA_updates'] == counts['attempted']
        own = {relative(f, name): value for name, value in proof['bound_input_sha256'].items()}
        assert len(own) == len(proof['bound_input_sha256'])
        folder = ROOT / 'base_records' / f'{model}_seed{seed}'
        checkpoint = ROOT / 'base' / f'{model}_seed{seed}' / 'weights/last.pt'
        required = [folder / name for name in ('COMPLETE.json', 'resume_state.pt', 'config.json', 'initial_parameters.json')]
        required += [checkpoint, AUDIT_SOURCE, ROOT / 'protocol.json']
        assert {p.as_posix() for p in required} <= own.keys()
        assert own[checkpoint.as_posix()] == row['checkpoint_sha256']
        assert own[(folder / 'resume_state.pt').as_posix()] == row['resume_state_sha256']
        for name, value in own.items():
            if name in bindings:
                assert bindings[name] == value
            bindings[name] = value
        complete = read(folder / 'COMPLETE.json')
        assert complete['epochs'] == 100 and complete['finite_state'] is True
    f.verify(bindings)
    return bindings


def process_command(pid):
    try:
        raw = Path(f'/proc/{pid}/cmdline').read_bytes()
        return [part.decode() for part in raw.rstrip(b'\0').split(b'\0')] if raw else None
    except FileNotFoundError:
        return None


def check_process_ownership(context, invocation_id, device, records, pid, command_reader=process_command):
    expected = expected_command(context, invocation_id, device)
    assert command_reader(pid) == expected, 'Runner command differs from fixed invocation'
    matches = [(name, row) for name, row in records.items() if row.get('pid') == pid and row.get('status') == 'running']
    assert len(matches) == 1, 'Runner is not uniquely registered in the shared attempts ledger'
    name, row = matches[0]
    assert row['command'] == expected and row['label'] == PREFIX + invocation_id
    assert row['GPU_job'] is True and type(row['device']) is int and row['device'] == device
    assert 'ended_unix' not in row and 'returncode' not in row and 'stop_reason' not in row
    # Stale unclosed GPU attempts also block admission until investigated.
    assert [n for n, r in records.items() if r['GPU_job'] and 'ended_unix' not in r] == [name]
    f = context.files
    guard = loads(f.read((ROOT / 'budget_guard_launch.json').as_posix()))
    guard_command = ['venv/bin/python', '-u', (ROOT / 'budget_guard.py').as_posix()]
    assert guard['command'] == guard_command and guard['source_sha256'] == GUARD_SHA
    assert f.sha((ROOT / 'budget_guard.py').as_posix()) == GUARD_SHA
    assert command_reader(guard['pid']) == guard_command, 'Existing budget guard is not running'
    for launch_name in ('launch.json', 'base_recovery_launch.json'):
        launch = loads(f.read((ROOT / launch_name).as_posix()))
        assert command_reader(launch['pid']) is None, 'Base coordinator is still alive'
    return name


def gpu_idle_uuid(device, check_output=subprocess.check_output):
    assert type(device) is int and device in (0, 1)
    gpu = check_output(['nvidia-smi', f'--id={device}', '--query-gpu=uuid', '--format=csv,noheader'], text=True).strip()
    assert gpu.startswith('GPU-') and '\n' not in gpu
    rows = check_output(['nvidia-smi', '--query-compute-apps=pid,gpu_uuid', '--format=csv,noheader'], text=True).splitlines()
    assert not any(row.split(',')[-1].strip() == gpu for row in rows if row.strip()), 'Selected GPU is occupied'
    return gpu


def verify_runner_sources(context):
    for name in (RUNTIME, RUNNER, DISPATCHER):
        assert name.as_posix() in context.bindings, f'Unfrozen runtime source: {name}'
        assert context.files.sha(name.as_posix()) == context.bindings[name.as_posix()]
    assert Path(__file__).resolve() == context.files.path(RUNTIME.as_posix()).resolve()


def watch_budget(sample, stopped, on_stop):
    """Daemon-loop helper; callbacks are injected only by synthetic CPU tests.

    Production supplies fresh local ledger/disk readings and a stop action that
    latches evidence before terminating only its own registered process group.
    """
    while not stopped.wait(1.):
        try:
            snapshot = sample()
            check_limits(snapshot)
        except BaseException as error:
            on_stop(error)
            return
