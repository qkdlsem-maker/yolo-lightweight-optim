"""Fixed CPU inputs for the gradient diagnostic, not a model or training loader.

Use isolated native label parsing and validation geometry on TRAINING copies.
The only transform replacement makes the usual BGR->RGB step unconditional,
removing the native Format random.uniform call even when its bgr option is zero.
"""
import hashlib
import inspect
import json
from pathlib import Path
import numpy as np
import torch
from ultralytics.cfg import get_cfg
from ultralytics.data.augment import Format, LetterBox
from ultralytics.data.base import BaseDataset
from ultralytics.data.build import build_yolo_dataset
from ultralytics.data.dataset import YOLODataset
from gradient_input_view import sha

NATIVE_SHA256 = {
    'build.py': '01f326cf4b072189b0af2ffdd2d10915193f933d12dd2a2549c557a981e24f4f',
    'base.py': 'ce2ff59e725bdbd801a98de3aef6cc0b087a44fa5786bd3c0d0d81436fdd853a',
    'dataset.py': '212d3bba593bad73d9f925bfae3605f664be4f13d7398f5b6e8e63a9f7303ea3',
    'augment.py': '45b16105042b13d4dacc3d8c9913cfeb41ca2f7ca19111b47b454c59baca7b72',
}
KEYS = ('img', 'cls', 'bboxes', 'batch_idx')


class DeterministicRGBFormat(Format):
    def _format_img(self, img):
        assert img.dtype == np.uint8 and img.ndim == 3 and img.shape[2] == 3
        return torch.from_numpy(np.ascontiguousarray(img[:, :, ::-1].transpose(2, 0, 1)))


def native_bindings():
    result = {}
    for obj in (build_yolo_dataset, BaseDataset, YOLODataset, Format):
        path = Path(inspect.getfile(obj))
        assert sha(path) == NATIVE_SHA256[path.name], path
        result[str(path)] = sha(path)
    return result


def dataset_for_view(manifest):
    native_bindings()
    destination = Path(manifest['destination'])
    cfg = get_cfg()
    cfg.imgsz = 640; cfg.rect = False; cfg.cache = False; cfg.task = 'detect'
    cfg.classes = None; cfg.single_cls = False; cfg.fraction = 1.0
    data = {'names': manifest['names'], 'nc': len(manifest['names'])}
    dataset = build_yolo_dataset(cfg, str(destination/'images/train'), 32, data, mode='val', rect=False)
    assert len(dataset) == 64 and not dataset.augment and not dataset.rect and dataset.cache is None
    assert all(Path(p).parent == destination/'images/train' for p in dataset.im_files)
    assert all(Path(p).parent == destination/'labels/train' for p in dataset.label_files)
    assert all(not Path(p).exists() for p in dataset.npy_files), 'Unexpected image numpy cache'
    transforms = dataset.transforms.transforms
    assert len(transforms) == 2 and type(transforms[0]) is LetterBox and type(transforms[1]) is Format
    letterbox = transforms[0]
    assert letterbox.new_shape == (640, 640) and not letterbox.auto and not letterbox.scaleFill
    assert not letterbox.scaleup and letterbox.center
    replacement = DeterministicRGBFormat(bbox_format='xywh', normalize=True, batch_idx=True)
    assert vars(replacement) == vars(transforms[1]), 'Unreviewed native formatting options'
    transforms[1] = replacement
    name_index = {Path(p).name: i for i, p in enumerate(dataset.im_files)}
    ordered = [name_index[e['name']] for e in manifest['entries']]
    assert len(set(ordered)) == 64
    return dataset, ordered


def fixed_batches(dataset, ordered):
    assert len(ordered) == len(set(ordered)) == 64
    for start in (0, 32):
        batch = YOLODataset.collate_fn([dataset[i] for i in ordered[start:start+32]])
        assert batch['img'].dtype == torch.uint8 and tuple(batch['img'].shape) == (32, 3, 640, 640)
        yield batch


def fingerprint(value):
    array = value.detach().cpu().contiguous().numpy() if isinstance(value, torch.Tensor) else np.ascontiguousarray(value)
    return {'dtype': str(array.dtype), 'shape': list(array.shape),
            'sha256': hashlib.sha256(array.tobytes(order='C')).hexdigest()}


def normalized_inputs(batch):
    result = {k: batch[k] for k in KEYS}
    result['img'] = result['img'].to(dtype=torch.float32).div(255.0)
    for key in ('cls', 'bboxes', 'batch_idx'):
        result[key] = result[key].to(dtype=torch.float32)
    assert tuple(result['img'].shape) == (32, 3, 640, 640)
    assert all(t.device.type == 'cpu' and bool(torch.isfinite(t).all()) for t in result.values())
    assert tuple(result['bboxes'].shape) == (result['cls'].shape[0], 4)
    assert tuple(result['cls'].shape) == (result['batch_idx'].shape[0], 1)
    assert bool(((result['bboxes'] >= 0) & (result['bboxes'] <= 1)).all())
    assert bool(((result['cls'] >= 0) & (result['cls'] < 10) & (result['cls'] == result['cls'].floor())).all())
    assert bool(((result['batch_idx'] >= 0) & (result['batch_idx'] < 32) & (result['batch_idx'] == result['batch_idx'].floor())).all())
    return result


def save_batch(path, batch, names):
    assert len(names) == 32 and len(set(names)) == 32
    inputs = normalized_inputs(batch)
    with Path(path).open('xb') as stream:
        np.savez_compressed(stream, **{k: batch[k].cpu().contiguous().numpy() for k in KEYS})
    return {'archive': str(Path(path).absolute()), 'archive_sha256': sha(path), 'names': list(names),
            'stored_tensors': {k: fingerprint(batch[k]) for k in KEYS},
            'model_input_tensors': {k: fingerprint(inputs[k]) for k in KEYS},
            'boxes': int(inputs['cls'].shape[0])}


def load_batch(record):
    path = Path(record['archive'])
    assert path.is_file() and not path.is_symlink() and sha(path) == record['archive_sha256']
    with np.load(path, allow_pickle=False) as archive:
        assert set(archive.files) == set(KEYS)
        arrays = {key: archive[key] for key in KEYS}
    assert arrays['img'].dtype == np.uint8
    assert all(arrays[k].dtype == np.float32 for k in KEYS if k != 'img')
    assert {k: fingerprint(arrays[k]) for k in KEYS} == record['stored_tensors']
    batch = {k: torch.from_numpy(np.ascontiguousarray(arrays[k])) for k in KEYS}
    inputs = normalized_inputs(batch)
    assert {k: fingerprint(inputs[k]) for k in KEYS} == record['model_input_tensors']
    return inputs  # Transfer these already-normalized FP32 tensors to the GPU unchanged.
