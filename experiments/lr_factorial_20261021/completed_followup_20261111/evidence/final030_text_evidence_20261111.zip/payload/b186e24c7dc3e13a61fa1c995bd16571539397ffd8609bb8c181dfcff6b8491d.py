"""Admission for the fixed27 production jobs. No Torch, training or file writes.

The separate execution source manifest cannot be frozen until the actual GPU
preflight has passed. An initial launch accepts no existing run or receipt.
Interrupted runs require a separately audited recovery path, never auto-retry.
"""
import math
import time
from pathlib import Path
from continuation_artifact_receipts import Context, ROOT, PROTOCOL_SHA, loads, encoded
from continuation_contract import build_design, OLD_SEEDS, validate_production_args
from continuation_preflight_runtime import (GUARD_SHA, process_command, read_records,
    no_latches, resources, check_limits, verify_completed_bases)
from continuation_production_gate import verify_gate

RUNTIME = ROOT/'continuation_execution_runtime.py'
RUNNER = ROOT/'run_continuation_production_job.py'
DISPATCHER = ROOT/'run_continuations.py'
MANIFEST = ROOT/'continuation_execution_sources.json'
PREFIX = 'continuation_production__'
PARENT_LABEL = 'continuation_production_dispatcher_CPU'
EXTRA_LATCHES = ('CONTINUATION_FAILURE.json', 'CONTINUATION_TRAINING_COMPLETE.json')


def production_latches(files):
    no_latches(files)
    for name in EXTRA_LATCHES:
        assert not files.path((ROOT/name).as_posix()).exists(), 'Production stop/completion latch: '+name


def job_for_label(context, label):
    assert type(label) is str
    f=context.files
    design=loads(f.read((ROOT/'continuation_design.json').as_posix()))
    protocol=loads(f.read((ROOT/'protocol.json').as_posix()))
    reuse=loads(f.read((ROOT/'historical_reuse_manifest.json').as_posix()))
    assert design==build_design(protocol,reuse)
    jobs=[j for j in design['new_jobs'] if j['label']==label]
    assert len(jobs)==1, 'Only27new paths; historical low-rate paths are reuse-only'
    return jobs[0],design


def arguments(job, design, device):
    assert type(device) is int and device in (0,1)
    args=dict(job['args'],device=device,resume=False)
    assert validate_production_args(args,design)==job
    return args


def expected_command(context, label, device):
    job,design=job_for_label(context,label);arguments(job,design,device)
    return [str(context.files.project/'venv/bin/python'),'-u',RUNNER.as_posix(),
            '--label',label,'--device',str(device)]


def dispatcher_command(context):
    return [str(context.files.project/'venv/bin/python'),'-u',DISPATCHER.as_posix()]


def evidence_paths(label):
    assert type(label) is str and Path(label).name==label and '\\' not in label
    folder=ROOT/'production_execution'/label
    return {'admission':(folder/'admission.json').as_posix(),
            'execution':(folder/'execution.json').as_posix(),
            'receipt':(ROOT/'production_receipts'/(label+'.json')).as_posix()}


def untouched_destination(context, job):
    """No completed, partial, or unexplained output is a fresh launch."""
    f=context.files
    for name in (job['args']['out_root'],job['run_directory'],job['run_directory']+'.lock'):
        assert not f.path(name).exists(), 'Existing result/state requires investigation; never restart: '+name
    paths=evidence_paths(job['label'])
    assert not f.path(str(Path(paths['admission']).parent.as_posix())).exists()
    for name in paths.values():
        assert not f.path(name).exists(), 'Existing execution or receipt must be reused/audited, never relaunched'


def checkpoint_bindings(context, job, design):
    f=context.files; protocol=loads(f.read((ROOT/'protocol.json').as_posix()))
    bindings={job['args']['data']:protocol['data']['yaml_sha256']}
    for key,model in (('source','nano'),('teacher','large')):
        if job['pair_seed'] in OLD_SEEDS:
            rows=[x for x in design['reused_base_endpoints'] if x['architecture']==model and x['pair_seed']==job['pair_seed']]
            assert len(rows)==1;digest=rows[0]['checkpoint']['sha256']
        else:
            name=(ROOT/'completed_base_audits'/f'{model}_seed{job["pair_seed"]}.json').as_posix()
            proof=loads(f.read(name));digest=proof['run']['checkpoint_sha256']
            bindings[name]=f.sha(name)
        bindings[job['args'][key]]=digest
    f.verify(bindings)
    return bindings


def source_bindings(context):
    f=context.files;manifest_hash=f.sha(MANIFEST.as_posix())
    value=loads(f.read(MANIFEST.as_posix(),manifest_hash))
    assert value['schema']=='continuation_execution_sources_v1'
    assert value['status']=='frozen_after_actual_GPU_preflight'
    assert value['protocol_sha256']==PROTOCOL_SHA
    assert value['continuation_sources_sha256']==context.manifest_hash
    assert value['preflight_gate_sha256']==f.sha((ROOT/'CONTINUATION_PREFLIGHT_PASSED.json').as_posix())
    assert value['completion_manifest_sha256']==f.sha((ROOT/'continuation_completion_sources.json').as_posix())
    rows=value['files'];names=[r['name'] for r in rows]
    required={RUNTIME.name,RUNNER.name,DISPATCHER.name,'continuation_completion_sources.json',
              'continuation_completion_audit.py','continuation_execution_spec.json',
              'continuation_execution_CPU.json'}
    assert len(names)==len(set(names)) and required<=set(names)
    bindings={MANIFEST.as_posix():manifest_hash}
    for row in rows:
        assert Path(row['name']).name==row['name'] and '\\' not in row['name']
        bindings[(ROOT/row['name']).as_posix()]=row['sha256']
    f.verify(bindings)
    assert Path(__file__).resolve()==f.path(RUNTIME.as_posix()).resolve()
    return bindings


def public_context(project):
    """Always real scientific anchors and actual numeric GPU gate, never CPU mocks."""
    context=Context(project)
    production_latches(context.files)
    bindings=source_bindings(context)
    gate=verify_gate(project,context.manifest_hash)
    bases=verify_completed_bases(context)
    return context,bindings,gate,bases


def supervision(context, records, command_reader=process_command, now=None):
    """Existing guard, exited base/preflight parents, and one owned live parent.

    At most two production GPU attempts, with distinct physical devices and jobs.
    No unrelated or stale GPU allocation is silently ignored.
    """
    now=time.time() if now is None else now
    f=context.files
    guard=loads(f.read((ROOT/'budget_guard_launch.json').as_posix()))
    guard_cmd=['venv/bin/python','-u',(ROOT/'budget_guard.py').as_posix()]
    assert guard['command']==guard_cmd and guard['source_sha256']==GUARD_SHA
    assert f.sha((ROOT/'budget_guard.py').as_posix())==GUARD_SHA
    assert command_reader(guard['pid'])==guard_cmd, 'Independent budget guard absent'
    for name in ('launch.json','base_recovery_launch.json'):
        launch=loads(f.read((ROOT/name).as_posix()))
        assert command_reader(launch['pid']) is None, 'Base coordinator still alive'
    gate=loads(f.read((ROOT/'CONTINUATION_PREFLIGHT_PASSED.json').as_posix()))
    preflight=loads(f.read(gate['dispatcher_attempt']))
    assert preflight['status']=='completed' and preflight['returncode']==0 and 'ended_unix' in preflight
    assert command_reader(preflight['pid']) is None, 'Preflight coordinator still alive'
    launch=loads(f.read((ROOT/'continuation_launch.json').as_posix()))
    parent_cmd=dispatcher_command(context)
    assert launch['command']==parent_cmd and command_reader(launch['pid'])==parent_cmd
    parents=[(n,r) for n,r in records.items() if r.get('label')==PARENT_LABEL and 'ended_unix' not in r]
    assert len(parents)==1
    parent_name,parent=parents[0]
    assert parent['pid']==launch['pid'] and parent['command']==parent_cmd
    assert parent['status']=='running' and parent['GPU_job'] is False and parent['device'] is None
    assert 'returncode' not in parent and 'stop_reason' not in parent
    for row in records.values():
        if 'ended_unix' not in row and (row.get('label','').startswith(PREFIX) or RUNNER.as_posix() in row.get('command',[])):
            assert row['GPU_job'] is True, 'Production worker misclassified as CPU'
    active=[(n,r) for n,r in records.items() if r['GPU_job'] and 'ended_unix' not in r]
    assert len(active)<=2, 'GPU allocation limit exceeded'
    devices=[];labels=[]
    for name,row in active:
        assert row['GPU_job'] is True and type(row['device']) is int and row['device'] in (0,1)
        assert row['label'].startswith(PREFIX)
        label=row['label'][len(PREFIX):]
        command=expected_command(context,label,row['device'])
        assert row['command']==command and row['parent_pid']==launch['pid']
        assert 'returncode' not in row and 'stop_reason' not in row
        assert type(row['started_unix']) in (int,float) and math.isfinite(row['started_unix'])
        assert row['started_unix']<=now
        assert row['status'] in ('starting','running')
        if row['status']=='starting':
            assert 'pid' not in row and now-row['started_unix']<=10, 'Stale unregistered allocation'
        else:
            assert type(row['pid']) is int and row['pid']>0
            observed=command_reader(row['pid'])
            if observed is None:
                # A successful peer can exit just before its parent closes the
                # ledger. Keep charging it and allow at most10s for that handoff.
                result=loads(f.read(evidence_paths(label)['execution']))
                assert result['schema']=='continuation_production_execution_v1'
                assert result['status']=='trainer_returned_requires_independent_CPU_audit'
                assert result['label']==label and result['pid']==row['pid'] and result['attempt']==name
                assert type(result['device']) is int and result['device']==row['device']
                assert type(result['returned_unix']) in (int,float) and math.isfinite(result['returned_unix'])
                assert 0<=now-result['returned_unix']<=10, 'Stale exited allocation'
                job,_=job_for_label(context,label)
                assert result['complete_sha256']==f.sha((Path(job['run_directory'])/'COMPLETE.json').as_posix())
                assert result['admission_sha256']==f.sha(evidence_paths(label)['admission'])
            else:
                assert observed==command, 'Live GPU process command changed'
        devices.append(row['device']);labels.append(label)
    assert len(set(devices))==len(devices) and len(set(labels))==len(labels)
    return {'parent_pid':launch['pid'],'parent_attempt':parent_name,'active_GPU_attempts':[n for n,r in active]}


def ownership(context, label, device, records, pid, parent_pid, command_reader=process_command, now=None):
    check=supervision(context,records,command_reader,now)
    assert check['parent_pid']==parent_pid
    command=expected_command(context,label,device)
    assert command_reader(pid)==command
    matches=[(n,r) for n,r in records.items() if r.get('pid')==pid and 'ended_unix' not in r]
    assert len(matches)==1
    name,row=matches[0]
    assert row['status']=='running' and row['command']==command and row['label']==PREFIX+label
    assert row['GPU_job'] is True and type(row['device']) is int and row['device']==device
    assert row['parent_pid']==parent_pid and name in check['active_GPU_attempts']
    assert Path(name).parent.as_posix()==(ROOT/'attempts').as_posix()
    assert Path(row['log']).parent.as_posix()==(ROOT/'logs').as_posix()
    context.files.path(name);context.files.path(row['log'])
    return name


def wait_for_registration(context,label,device,pid,parent_pid):
    deadline=time.monotonic()+10
    while True:
        records=read_records(context.files)
        if any(r.get('pid')==pid for r in records.values()):
            return ownership(context,label,device,records,pid,parent_pid)
        assert time.monotonic()<deadline, 'No registered shared-ledger attempt'
        time.sleep(.1)


def limits_now(context):
    production_latches(context.files)
    records,snapshot=resources(context.files)
    check_limits(snapshot)
    return records,snapshot
