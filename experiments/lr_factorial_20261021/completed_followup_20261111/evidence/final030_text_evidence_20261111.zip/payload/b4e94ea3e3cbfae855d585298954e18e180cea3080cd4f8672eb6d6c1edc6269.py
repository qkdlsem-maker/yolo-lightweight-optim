"""No scientific execution: test success sequencing and failure latching."""
import os,sys
from pathlib import Path
from unittest.mock import patch
import final_controller as controller
from retained_io import publish,read


def fixture(root,fail_stage=None):
    root.mkdir();events=[];children={};next_pid=910000
    def source_check(expected):
        assert expected=='fixture_manifest'
    def consumed(stage,expected,full=False):
        assert full and expected=='fixture_manifest'
        if stage=='CPU_integration':return {'status':'fixture_only'}
        child=children[stage];assert child.returncode==0
        directory=root/(stage+'_attempt01');directory.mkdir()
        publish(directory/'SEALED.json',{'fixture':True,'stage':stage})
        events.append(('consumed',stage));return {'owner':{'pid':child.pid}}
    class Child:
        def __init__(self,command,**kw):
            nonlocal next_pid
            stage=Path(command[2]).stem.removesuffix('_run')
            assert stage in controller.STAGES and command[-1]=='fixture_manifest'
            assert kw['start_new_session'] and kw['close_fds']
            assert kw['env']['CUDA_VISIBLE_DEVICES']==''
            assert not any(k in kw['env'] for k in ('INCIDENT028_OWNED_TOKEN','INCIDENT028_ROOT_TOKEN','INCIDENT028_ROOT_LEASE_FD'))
            next_pid+=1;self.pid=next_pid;self.stage=stage;self.returncode=None
            children[stage]=self;events.append(('launched',stage))
        def wait(self):
            self.returncode=7 if self.stage==fail_stage else 0
            events.append(('exited',self.stage));return self.returncode
        def poll(self):return self.returncode
    def adopted(expected):
        assert expected=='fixture_manifest'
        assert controller.STAGES==('metrics','analysis')
        return {'status':'fixture_retained_evaluation','new_inference':False,'new_scoring':False}
    def identity(pid):
        child=next((v for v in children.values() if v.pid==pid),None)
        return None if child is not None and child.returncode is not None else {'pid':pid}
    environment={k:v for k,v in os.environ.items() if k not in ('INCIDENT028_OWNED_TOKEN','INCIDENT028_ROOT_TOKEN','INCIDENT028_ROOT_LEASE_FD')}
    with patch.object(controller,'HERE',root),patch.object(controller,'source_check',source_check),patch.object(controller,'consume',consumed),patch.object(controller,'adopt_evaluation',adopted),patch.object(controller,'adopt_gradient',adopted),patch.object(controller,'identity',identity),patch.object(controller.subprocess,'Popen',Child),patch.dict(os.environ,environment,clear=True):
        try:controller.run('fixture_manifest')
        except RuntimeError:
            assert fail_stage is not None
        else:assert fail_stage is None
        before=list(events)
        try:controller.run('fixture_manifest')
        except FileExistsError:pass
        else:raise AssertionError('Existing dispatch was repeated')
        assert events==before
    expected=[]
    for stage in controller.STAGES:
        expected.extend([('launched',stage),('exited',stage)])
        if stage==fail_stage:break
        expected.append(('consumed',stage))
    assert events==expected
    output=root/'fixed_final_dispatch'
    assert read(output/'evaluation_ADOPTED.json')['new_inference'] is False
    assert 'evaluation' not in children and 'gradient' not in children
    assert (output/'gradient_ADOPTED.json').exists()
    if fail_stage is None:
        assert read(output/'COMPLETE.json')['status']=='all_fixed_scientific_stages_exited_and_independently_consumed'
        assert not (output/'FAILURE.json').exists()
    else:
        assert read(output/'FAILURE.json')['automatic_retry'] is False
        assert not (output/'COMPLETE.json').exists()
    return {'success_sequence':fail_stage is None,'failed_stage':fail_stage,'events':events,'no_retry':True}


if __name__=='__main__':
    root=Path(sys.argv[1]);root.mkdir()
    reports=[fixture(root/'success'),fixture(root/'failure','metrics')]
    publish(root/'COMPLETE.json',{'status':'dispatch_control_test_passed','cases':reports,'model_loads':0,'GPU_work':False,'scientific_children_spawned':0})
