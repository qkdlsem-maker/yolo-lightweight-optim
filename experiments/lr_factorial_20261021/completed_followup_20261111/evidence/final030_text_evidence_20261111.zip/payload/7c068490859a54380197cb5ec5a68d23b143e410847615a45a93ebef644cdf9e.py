"""Immutable, hash-bound receipts for the fixed continuation GPU fixtures.

This is a file-integrity layer, not a launcher, numerical comparator or GPU pass.
The future guarded driver must finish one shared-ledger GPU attempt, seal its
artifacts before starting the next segment, then feed verified bytes to the
numerical reader. No pickle/Torch/CUDA is imported or deserialized here.
"""
import hashlib
import json
import math
import os
import re
from pathlib import Path, PurePosixPath
from continuation_contract import ROOT, PROTOCOL_SHA
from continuation_fixture_roster import build_roster, invocation_args, OLD_SOURCE_SHA
from continuation_input_bindings import ANCHORS, OLD_PROTOCOL_SHA
from validation_journal import publish_immutable

PREFLIGHT = ROOT / 'continuation_preflight'
SOURCES = ROOT / 'continuation_sources.json'
REQUESTS = ROOT / 'continuation_preflight_requests.json'
INPUTS = ROOT / 'continuation_preflight_inputs.json'
RUNNER = ROOT / 'run_continuation_fixture.py'
REQUIRED_SOURCES = {
    'continuation.py', 'continuation_contract.py', 'continuation_design.json',
    'continuation_rng.py', 'validation_journal.py', 'continuation_observer.py',
    'continuation_fixture_roster.py', 'continuation_input_bindings.py',
    'continuation_artifact_receipts.py', 'continuation_evidence_checks.py',
    'run_continuation_fixture.py', 'continuation_preflight_plan.json',
    'continuation_preflight_requests.json', 'continuation_preflight_inputs.json',
    'continuation_preflight_runtime.py', 'run_continuation_preflight.py',
}


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def valid_sha(value):
    assert type(value) is str and re.fullmatch('[0-9a-f]{64}', value)


def loads(data):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            assert key not in result, 'Duplicate JSON key'
            result[key] = value
        return result
    def nonfinite(value):
        raise AssertionError('Nonfinite JSON value: ' + value)
    return json.loads(data, object_pairs_hook=unique, parse_constant=nonfinite)


class Files:
    def __init__(self, project):
        self.project = Path(project).resolve()

    def path(self, name):
        name = str(name)
        relative = PurePosixPath(name)
        assert name and '\\' not in name and ':' not in name
        assert not relative.is_absolute() and name == relative.as_posix()
        assert all(p not in ('.', '..') for p in relative.parts)
        path = self.project
        for part in relative.parts:
            path /= part
            assert not path.is_symlink(), 'Symlink in evidence path'
        assert path.resolve().is_relative_to(self.project) and path != self.project
        return path

    def sha(self, name):
        path = self.path(name)
        assert path.is_file(), f'Missing file: {name}'
        h = hashlib.sha256()
        with path.open('rb') as stream:
            for chunk in iter(lambda: stream.read(1024 * 1024), b''):
                h.update(chunk)
        return h.hexdigest()

    def read(self, name, expected=None):
        data = self.path(name).read_bytes()
        if expected is not None:
            valid_sha(expected)
            assert digest(data) == expected, f'Changed bytes: {name}'
        return data

    def verify(self, bindings):
        for name, value in bindings.items():
            valid_sha(value)
            assert self.sha(name) == value, f'Changed file: {name}'


class Context:
    """Frozen local provenance, not cryptographic attestation of remote hardware.

    Public construction always checks pinned scientific anchors. The internal
    anchor parameter exists solely for fabricated-tree CPU rejection tests.
    """
    def __init__(self, project):
        self._initialize(project, ANCHORS)

    def _initialize(self, project, anchors):
        self.files = Files(project)
        self.bindings = dict(anchors)
        self.files.verify(self.bindings)
        self.manifest_hash = self.files.sha(SOURCES.as_posix())
        manifest = loads(self.files.read(SOURCES.as_posix(), self.manifest_hash))
        names = [row['name'] for row in manifest['files']]
        assert len(names) == len(set(names)) and REQUIRED_SOURCES <= set(names)
        for row in manifest['files']:
            name = row['name']
            assert '/' not in name and '\\' not in name and name not in ('.', '..')
            key = (ROOT / name).as_posix()
            if key in self.bindings:
                assert self.bindings[key] == row['sha256']
            self.bindings[key] = row['sha256']
        self.bindings[SOURCES.as_posix()] = self.manifest_hash
        self.files.verify(self.bindings)
        self.roster = loads(self.files.read(REQUESTS.as_posix(), self.bindings[REQUESTS.as_posix()]))
        inputs = loads(self.files.read(INPUTS.as_posix(), self.bindings[INPUTS.as_posix()]))
        assert inputs['schema'] == 'continuation_preflight_input_bindings_v1'
        assert inputs['status'] == 'fixed_inputs_verified_only_not_GPU_ready'
        assert inputs['protocol_sha256'] == self.roster['protocol_sha256'] == PROTOCOL_SHA
        assert inputs['requests_sha256'] == self.bindings[REQUESTS.as_posix()]
        rebuilt = build_roster(self.roster['checkpoint_bindings'], self.roster['fixture_data'])
        assert encoded(self.roster) == encoded(rebuilt), 'Changed fixed roster'
        for name, value in inputs['bound_input_sha256'].items():
            if name in self.bindings:
                assert self.bindings[name] == value
            self.bindings[name] = value
        assert set(anchors) <= inputs['bound_input_sha256'].keys()
        self.bindings['review_20261017_independent/continuation.py'] = OLD_SOURCE_SHA
        self.requests = {r['id']: r for r in self.roster['requests'] + self.roster['reference_requests']}
        self.invocations = {i['id']: i for i in self.roster['invocations']}
        for request in self.requests.values():
            for key in ('source', 'teacher', 'data'):
                path = request['args'][key]
                assert self.bindings.get(path) == request['input_sha256'][key]
        self.verify()

    def verify(self):
        self.files.verify(self.bindings)

    def identifiers(self):
        return {name: self.bindings[path.as_posix()] for name, path in (
            ('source_manifest_sha256', SOURCES), ('requests_sha256', REQUESTS),
            ('input_bindings_sha256', INPUTS))}


def invocation_spec(context, invocation_id, device):
    assert invocation_id in context.invocations
    invocation = context.invocations[invocation_id]
    request = context.requests[invocation['request_id']]
    args = invocation_args(request, invocation, device)
    out = PurePosixPath(args['out_root']) / f"{args['arm']}_seed{args['seed']}_e40"
    snapshot = PurePosixPath(invocation['capture'])
    epoch = invocation['expected_committed_epoch']
    observation = request['kind'].endswith('observation')
    reference = request['kind'] == 'reference_observation'
    validation = not observation and (request['kind'] == 'candidate_uninterrupted' or
                                     invocation['stop']['stop_after_validation_epoch'] == 10 or epoch == 12)
    artifacts = {'snapshot': str(snapshot), 'config': str(out / 'config.json'),
                 'gradient_check': str(out / 'gradient_check.json'),
                 'admission': str(snapshot.with_suffix('.admission.json')),
                 'execution': str(snapshot.with_suffix('.execution.json'))}
    for i in range(1, epoch + 1):
        artifacts[f'epoch_{i:02d}'] = str(out / f'epoch_{i:02d}.json')
        if not reference:
            artifacts[f'steps_{i:02d}'] = str(out / f'epoch_{i:02d}_steps.json')
    if observation:
        artifacts['smoke_complete'] = str(out / 'SMOKE_COMPLETE.json')
    else:
        artifacts['training_state'] = str(snapshot.with_suffix('.training_state.pt'))
        if epoch >= 10:
            artifacts['raw_epoch10'] = str(out / 'raw_state_epoch10.pt')
    if validation:
        for name in ('result.json', 'post_rng.bin', 'manifest.json'):
            artifacts['validation/' + name] = str(out / 'ema_epoch10_validation_commit' / name)
        artifacts['validation/metrics.json'] = str(out / 'ema_epoch10_metrics.json')
        artifacts['validation/checkpoint.pt'] = str(out / 'ema_epoch10.pt')
    chain = [i for i in context.roster['invocations'] if i['request_id'] == request['id']]
    index = chain.index(invocation)
    return {'invocation': invocation, 'request': request, 'args': args, 'out': str(out),
            'artifacts': artifacts, 'observation': observation, 'validation': validation,
            'reference': reference, 'previous': chain[index - 1]['id'] if index else None}


def receipt_path(invocation_id):
    assert re.fullmatch('[A-Za-z0-9_.]+', invocation_id)
    return (PREFLIGHT / 'receipts' / (invocation_id + '.json')).as_posix()


def expected_command(context, invocation_id, device):
    return [str(context.files.project / 'venv/bin/python'), '-u', RUNNER.as_posix(),
            '--invocation-id', invocation_id, '--device', str(device)]


def check_attempt(context, name, invocation_id, device):
    path = PurePosixPath(name)
    assert path.parent == PurePosixPath((ROOT / 'attempts').as_posix()) and path.suffix == '.json'
    data = context.files.read(name)
    attempt = loads(data)
    assert attempt['label'] == 'continuation_preflight__' + invocation_id
    assert attempt['GPU_job'] is True and type(attempt['device']) is int and attempt['device'] == device
    assert type(attempt['returncode']) is int and attempt['returncode'] == 0 and attempt['status'] == 'completed'
    assert type(attempt['pid']) is int and attempt['pid'] > 0
    assert attempt['command'] == expected_command(context, invocation_id, device)
    assert 'stop_reason' not in attempt
    for key in ('started_unix', 'ended_unix'):
        assert type(attempt[key]) in (float, int) and math.isfinite(attempt[key]) and attempt[key] > 0
    assert attempt['ended_unix'] >= attempt['started_unix']
    log = PurePosixPath(attempt['log'])
    assert log.parent == PurePosixPath((ROOT / 'logs').as_posix()) and log.suffix == '.log'
    return attempt, digest(data)


def check_metadata(context, spec, artifacts, device):
    f = context.files
    read = lambda key: loads(f.read(artifacts[key]['path'], artifacts[key]['sha256']))
    config = read('config')
    # A resumed trainer retains the first segment's configuration verbatim.
    first = next(i for i in context.roster['invocations'] if i['request_id'] == spec['request']['id'])
    first_args = invocation_args(spec['request'], first, device)
    for key, value in first_args.items():
        assert type(config[key]) is type(value) and config[key] == value, ('config', key)
    target_sha = context.bindings[spec['request']['target']]
    assert config['script_sha256'] == target_sha
    assert config['protocol_sha256'] == (OLD_PROTOCOL_SHA if spec['reference'] else PROTOCOL_SHA)
    assert config['train_images'] == 69863
    assert config['student_sha256'] == spec['request']['input_sha256']['source']
    assert config['teacher_sha256'] == spec['request']['input_sha256']['teacher']
    if not spec['reference']:
        assert config['contract']['label'] == spec['request']['id']
        assert config['contract']['mode'] == 'preflight_fixture'
        assert config['contract']['protocol_sha256'] == PROTOCOL_SHA
        assert config['contract']['source_manifest_sha256'] == context.manifest_hash
        assert config['contract']['contract_sha256'] == context.bindings[(ROOT / 'continuation_contract.py').as_posix()]
        assert config['contract']['design_sha256'] == context.bindings[(ROOT / 'continuation_design.json').as_posix()]
        for epoch in range(1, spec['invocation']['expected_committed_epoch'] + 1):
            record = read(f'epoch_{epoch:02d}')
            assert type(record['epoch']) is int and record['epoch'] == epoch
            assert record['batch_step_ledger_sha256'] == artifacts[f'steps_{epoch:02d}']['sha256']
    execution = read('execution')
    expected = {'schema': 'continuation_fixture_execution_v1', 'status': 'observer_completed_only',
                'invocation_id': spec['invocation']['id'], 'device': device,
                'protocol_sha256': PROTOCOL_SHA, **context.identifiers(),
                'target_sha256': target_sha,
                'observer_sha256': context.bindings[(ROOT / 'continuation_observer.py').as_posix()],
                'snapshot_sha256': artifacts['snapshot']['sha256']}
    assert execution.keys() == expected.keys() | {'GPU_uuid'}
    assert type(execution['GPU_uuid']) is str and re.fullmatch('GPU-[A-Za-z0-9-]+', execution['GPU_uuid'])
    for key, value in expected.items():
        assert type(execution[key]) is type(value) and execution[key] == value, ('execution', key)
    admission = read('admission')
    assert admission['schema'] == 'continuation_fixture_admission_v1'
    assert admission['status'] == 'registered_input_and_budget_checks_only_not_numerical_pass'
    assert admission['invocation_id'] == spec['invocation']['id']
    assert type(admission['device']) is int and admission['device'] == device
    assert admission['GPU_uuid'] == execution['GPU_uuid']
    assert admission['protocol_sha256'] == PROTOCOL_SHA and admission['context'] == context.identifiers()
    required_audits = {(ROOT / 'completed_base_audits' / f'{m}_seed{s}.json').as_posix()
                       for m in ('nano', 'large') for s in (404, 505, 606)}
    required_audits |= {(ROOT / n).as_posix() for n in ('completed_base_audit_gate.json', 'BASE_TRAINING_COMPLETE.json')}
    assert required_audits <= admission['base_audit_bound_sha256'].keys()
    f.verify(admission['base_audit_bound_sha256'])
    if spec['validation']:
        manifest, result = read('validation/manifest.json'), read('validation/result.json')
        commit = f.path(str(PurePosixPath(spec['out']) / 'ema_epoch10_validation_commit'))
        assert {p.name for p in commit.iterdir()} == {'result.json', 'post_rng.bin', 'manifest.json'}
        assert manifest['schema'] == 'validation_rng_commit_v1'
        assert manifest['result_sha256'] == artifacts['validation/result.json']['sha256'] == artifacts['validation/metrics.json']['sha256']
        assert manifest['post_rng_sha256'] == artifacts['validation/post_rng.bin']['sha256']
        assert manifest['checkpoint_sha256'] == result['checkpoint_sha256'] == artifacts['validation/checkpoint.pt']['sha256']
        record = read('epoch_10')
        expected_bindings = {'source_sha256': spec['request']['input_sha256']['source'],
            'data_yaml_sha256': spec['request']['input_sha256']['data'],
            'config_sha256': artifacts['config']['sha256'], 'trainer_sha256': target_sha,
            'endpoint': 'ema_epoch10', 'state_sha256': record['EMA_state_sha256']}
        assert manifest['bindings'] == expected_bindings
        assert result['state_sha256'] == record['EMA_state_sha256']
    return execution


def retain_state(files, source, destination):
    """Independent streamed copy of the current atomic state, never a hardlink.

    Later trainer replacements cannot alter this segment's retained state.
    A partial copy is preserved and fails closed; there is no automatic retry.
    """
    before = files.sha(source)
    target = files.path(destination)
    if target.exists():
        assert files.sha(destination) == before, 'Differing retained segment state'
        return before
    pending = target.with_suffix(target.suffix + '.pending')
    target.parent.mkdir(parents=True, exist_ok=True)
    with files.path(source).open('rb') as src, pending.open('xb') as dst:
        for chunk in iter(lambda: src.read(1024 * 1024), b''):
            dst.write(chunk)
        dst.flush(); os.fsync(dst.fileno())
    pending_key = pending.relative_to(files.project).as_posix()
    assert files.sha(pending_key) == before == files.sha(source), 'State changed during capture'
    os.link(pending, target)
    pending.unlink()
    return before


def _verify_receipt(context, invocation_id, seen):
    assert invocation_id not in seen
    seen.add(invocation_id)
    data = context.files.read(receipt_path(invocation_id))
    receipt = loads(data)
    assert receipt['schema'] == 'continuation_fixture_receipt_v1'
    assert receipt['status'] == 'artifact_integrity_only_not_numerical_or_GPU_pass'
    assert receipt['invocation_id'] == invocation_id and receipt['protocol_sha256'] == PROTOCOL_SHA
    assert receipt['context'] == context.identifiers()
    spec = invocation_spec(context, invocation_id, receipt['device'])
    assert type(receipt['expected_committed_epoch']) is int and type(receipt['training_batches']) is int
    assert receipt['expected_committed_epoch'] == spec['invocation']['expected_committed_epoch']
    assert receipt['training_batches'] == spec['invocation']['training_batches']
    assert receipt['request_id'] == spec['request']['id']
    artifacts = receipt['artifacts']
    assert artifacts.keys() == spec['artifacts'].keys()
    for key, path in spec['artifacts'].items():
        assert artifacts[key].keys() == {'path', 'sha256'} and artifacts[key]['path'] == path
        context.files.verify({path: artifacts[key]['sha256']})
    attempt, attempt_hash = check_attempt(context, receipt['attempt']['path'], invocation_id, receipt['device'])
    assert attempt_hash == receipt['attempt']['sha256']
    assert receipt['log']['path'] == attempt['log']
    context.files.verify({attempt['log']: receipt['log']['sha256']})
    execution = check_metadata(context, spec, artifacts, receipt['device'])
    assert receipt['GPU_uuid'] == execution['GPU_uuid']
    admission = loads(context.files.read(artifacts['admission']['path'], artifacts['admission']['sha256']))
    assert admission['attempt'] == receipt['attempt']['path']
    assert type(admission['pid']) is int and admission['pid'] == attempt['pid']
    assert admission['previous_receipt_sha256'] == receipt['previous_receipt_sha256']
    if spec['previous'] is None:
        assert receipt['previous_receipt_sha256'] is None
    else:
        prior, prior_hash = _verify_receipt(context, spec['previous'], seen)
        assert receipt['previous_receipt_sha256'] == prior_hash
        assert prior['device'] == receipt['device'] and prior['GPU_uuid'] == receipt['GPU_uuid']
        previous_attempt = loads(context.files.read(prior['attempt']['path'], prior['attempt']['sha256']))
        assert previous_attempt['ended_unix'] <= attempt['started_unix'], 'Overlapping segments'
        for key in prior['artifacts'].keys() & artifacts.keys() - {'snapshot', 'training_state', 'execution', 'admission'}:
            assert prior['artifacts'][key] == artifacts[key], ('Replaced committed artifact', key)
    return receipt, digest(data)


def verify_receipt(context, invocation_id):
    context.verify()
    result = _verify_receipt(context, invocation_id, set())
    context.verify()
    return result


def check_output_boundary(context, spec):
    """Check live output closure only at sealing or a request's final segment.

    Earlier receipts remain readable after later authorized segments add epochs.
    The final aggregator must additionally call verify_complete_request on all
    48 requests so appended or uncommitted output cannot hide behind old receipts.
    """
    out = context.files.path(spec['out'])
    assert not (out / 'COMPLETE.json').exists(), 'Fixture unexpectedly completed40epochs'
    n = spec['invocation']['expected_committed_epoch']
    expected_epochs = {f'epoch_{i:02d}.json' for i in range(1, n + 1)}
    expected_steps = set() if spec['reference'] else {f'epoch_{i:02d}_steps.json' for i in range(1, n + 1)}
    assert {p.name for p in out.glob('epoch_*.json')} == expected_epochs | expected_steps
    expected_raw = set() if spec['observation'] or n < 10 else {'raw_state_epoch10.pt'}
    assert {p.name for p in out.glob('raw_state_epoch*.pt')} == expected_raw
    validation_files = {p.name for p in out.glob('ema_epoch*')}
    if spec['validation']:
        assert {'ema_epoch10_validation_commit', 'ema_epoch10_metrics.json', 'ema_epoch10.pt'} <= validation_files
        assert validation_files <= {'ema_epoch10_validation_commit', 'ema_epoch10_metrics.json',
                                    'ema_epoch10.pt', 'ema_epoch10_validation'}
    else:
        assert not validation_files, 'Unexpected validation before its prescribed boundary'
    if spec['observation']:
        assert not (out / 'training_state.pt').exists()
    else:
        assert not (out / 'SMOKE_COMPLETE.json').exists()


def seal_invocation(context, invocation_id, device, attempt_path):
    """Called by the sole dispatcher after the GPU process exits, before resume."""
    context.verify()
    path = context.files.path(receipt_path(invocation_id))
    if path.exists():
        receipt, _ = verify_receipt(context, invocation_id)
        assert receipt['device'] == device and receipt['attempt']['path'] == attempt_path
        return receipt
    spec = invocation_spec(context, invocation_id, device)
    attempt, attempt_hash = check_attempt(context, attempt_path, invocation_id, device)
    check_output_boundary(context, spec)
    if not spec['observation']:
        retain_state(context.files, str(PurePosixPath(spec['out']) / 'training_state.pt'), spec['artifacts']['training_state'])
    artifacts = {key: {'path': name, 'sha256': context.files.sha(name)} for key, name in spec['artifacts'].items()}
    execution = check_metadata(context, spec, artifacts, device)
    previous_hash = None
    if spec['previous']:
        _, previous_hash = verify_receipt(context, spec['previous'])
    receipt = {'schema': 'continuation_fixture_receipt_v1',
               'status': 'artifact_integrity_only_not_numerical_or_GPU_pass',
               'protocol_sha256': PROTOCOL_SHA, 'context': context.identifiers(),
               'invocation_id': invocation_id, 'request_id': spec['request']['id'],
               'device': device, 'GPU_uuid': execution['GPU_uuid'],
               'expected_committed_epoch': spec['invocation']['expected_committed_epoch'],
               'training_batches': spec['invocation']['training_batches'],
               'artifacts': artifacts, 'previous_receipt_sha256': previous_hash,
               'attempt': {'path': attempt_path, 'sha256': attempt_hash},
               'log': {'path': attempt['log'], 'sha256': context.files.sha(attempt['log'])}}
    context.verify()
    path.parent.mkdir(parents=True, exist_ok=True)
    publish_immutable(path, encoded(receipt))
    # A failed post-publication check is preserved as failure evidence, never a pass.
    verify_receipt(context, invocation_id)
    return receipt


def verify_complete_request(context, request_id):
    assert request_id in context.requests
    invocation = [i for i in context.roster['invocations'] if i['request_id'] == request_id][-1]
    receipt, value = verify_receipt(context, invocation['id'])
    spec = invocation_spec(context, invocation['id'], receipt['device'])
    check_output_boundary(context, spec)
    if not spec['observation']:
        current = str(PurePosixPath(spec['out']) / 'training_state.pt')
        assert context.files.sha(current) == receipt['artifacts']['training_state']['sha256']
    return receipt, value


def verified_artifact_bytes(context, receipt, key):
    """Return only hash-checked bytes; the separate reader owns deserialization."""
    checked, _ = verify_receipt(context, receipt['invocation_id'])
    assert encoded(checked) == encoded(receipt)
    item = checked['artifacts'][key]
    return context.files.read(item['path'], item['sha256'])
