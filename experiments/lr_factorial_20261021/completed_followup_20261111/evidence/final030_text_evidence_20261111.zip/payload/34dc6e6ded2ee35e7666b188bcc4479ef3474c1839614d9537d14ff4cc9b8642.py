"""Read-only inspection of an interrupted continuation's last atomic state.

This does not classify the cause as technical, clear a latch, restore RNG, copy
or repair a file, start a process, or authorize a retry. Successful inspection
still requires an investigated technical cause, preserved recovery capsule,
unchanged sources/conditions, real GPU gate and remaining hard budget.
"""
import argparse
import math
import os
from pathlib import Path,PurePosixPath
import re
import torch
import continuation_completion_audit as completed
from continuation_artifact_receipts import ROOT,PROTOCOL_SHA,Context,encoded,loads,digest
from continuation_execution_runtime import job_for_label,source_bindings,checkpoint_bindings,PREFIX
from continuation_preflight_runtime import verify_completed_bases,read_records,process_command

SELF=ROOT/'continuation_recovery_audit.py'
MANIFEST=ROOT/'continuation_recovery_sources.json'


def inventory(context,job):
    f=context.files;out=f.path(job['run_directory']);assert out.is_dir()
    result={}
    for path in sorted(out.rglob('*')):
        name=path.relative_to(f.project).as_posix();f.path(name)
        if path.is_file():result[name]=f.sha(name)
        else:assert path.is_dir()
    return result


def inspect_validation(run,epoch,state,record,config,source,input_hashes,latest):
    """Earlier endpoints must be committed. Latest may be before/after commit."""
    out=run.files.path(str(run.out));name=f'ema_epoch{epoch:02d}'
    commit=out/(name+'_validation_commit');visible=out/(name+'_metrics.json')
    if not commit.exists():
        assert epoch==latest, 'A past validation cannot be missing after training advanced'
        assert not visible.exists(), 'Visible metrics without atomic validation commit'
        return {'epoch':epoch,'status':'uncommitted_requires_preservation_before_inference',
                'reuse_committed_inference':False,'post_validation_rng':None}
    assert {p.name for p in commit.iterdir()}=={'manifest.json','result.json','post_rng.bin'}
    manifest=run.json(name+'_validation_commit/manifest.json')
    result_bytes=run.raw(name+'_validation_commit/result.json')
    rng_bytes=run.raw(name+'_validation_commit/post_rng.bin')
    result=loads(result_bytes);completed.check_metrics(result,source.names)
    checkpoint=run.tensor(name+'.pt')
    expected={k:v.half() if v.is_floating_point() else v for k,v in state['ema'].items()}
    assert isinstance(checkpoint,dict) and isinstance(checkpoint.get('model'),torch.nn.Module)
    completed.observer.assert_exact(checkpoint['model'].state_dict(),expected,'committed_saved_EMA')
    assert all(p.grad is None for p in checkpoint['model'].parameters())
    if checkpoint.get('ema') is not None:
        completed.observer.assert_exact(checkpoint['ema'].state_dict(),expected,'alternate_committed_EMA')
    assert manifest=={'schema':'validation_rng_commit_v1',
        'bindings':{'source_sha256':input_hashes['source'],'data_yaml_sha256':input_hashes['data'],
            'state_sha256':record['EMA_state_sha256'],'config_sha256':run.bindings[str(run.out/'config.json')],
            'trainer_sha256':config['script_sha256'],'endpoint':name},
        'result_sha256':digest(result_bytes),'post_rng_sha256':digest(rng_bytes),
        'checkpoint_sha256':run.bindings[str(run.out/(name+'.pt'))]}
    assert result['checkpoint_sha256']==manifest['checkpoint_sha256']
    assert result['state_sha256']==record['EMA_state_sha256']
    completed.check_rng(completed.reader.tensor_bytes(rng_bytes))  # never restores RNG
    if visible.exists():assert run.raw(name+'_metrics.json')==result_bytes
    return {'epoch':epoch,'status':'committed_reuse_only','reuse_committed_inference':True,
        'visible_metrics_present':visible.exists(),
        'post_validation_rng':str(run.out/(name+'_validation_commit/post_rng.bin'))}


def inspect_bound_run(context,job,input_hashes):
    """Internal synthetic-test seam; public entry authenticates all real inputs."""
    assert not torch.cuda.is_initialized()
    out=context.files.path(job['run_directory'])
    assert not (out/'COMPLETE.json').exists(), 'Completed trajectories are audit/reuse-only, never recovery training'
    assert not (out/'SMOKE_COMPLETE.json').exists()
    before=inventory(context,job)
    run=completed.BoundRun(context,job)
    config=completed.check_config(run,input_hashes['source'],input_hashes['teacher'])
    initial={}
    for key in ('source','teacher','data'):
        raw=run.raw_path(job['args'][key],input_hashes[key])
        if key!='data':initial[key]=completed.reader.checkpoint_module(completed.reader.tensor_bytes(raw))
    source=initial['source'];assert source.names==initial['teacher'].names and len(source.names)==10
    assert completed.core.training_digest(completed.reader.as_loaded_float(source.state_dict()))==config['initial_raw_student_digest']
    state=run.tensor('training_state.pt');epoch=state['epoch']
    assert type(epoch) is int and 1<=epoch<=40
    records=[run.json(f'epoch_{i:02d}.json') for i in range(1,epoch+1)]
    ledgers=[run.json(f'epoch_{i:02d}_steps.json') for i in range(1,epoch+1)]
    for i,row in enumerate(records,1):
        assert row['batch_step_ledger_sha256']==run.bindings[str(run.out/f'epoch_{i:02d}_steps.json')]
    counts=completed.core.check_epoch_chain(records,ledgers,config['lr'],math.ceil(69863/64),epoch)
    if config['arm']=='control':assert all(r['feature_loss']==0. for r in records)
    raw_check=completed.check_raw(state,records[-1],source,config,ledgers[-1])
    assert state['actual_step_counts']==counts
    # Diagnostics for at most the next uncommitted epoch may precede atomic save.
    allowed={f'epoch_{i:02d}{suffix}.json' for i in range(1,min(epoch+1,40)+1) for suffix in ('','_steps')}
    assert {p.name for p in out.glob('epoch_*.json')}<=allowed
    endpoint_epochs=[e for e in (10,20,40) if e<=epoch]
    assert {p.name for p in out.glob('raw_state_epoch*.pt')}<={f'raw_state_epoch{e:02d}.pt' for e in endpoint_epochs}
    for path in out.glob('ema_epoch*'):
        match=re.match(r'^ema_epoch(\d{2})(?:\D|$)',path.name)
        assert match and int(match.group(1)) in endpoint_epochs, 'Unexpected future validation artifact'
    endpoints={};reconstruct=[]
    for e in endpoint_epochs:
        name=f'raw_state_epoch{e:02d}.pt';path=out/name
        if path.exists():
            raw=run.tensor(name)
            completed.check_raw(raw,records[e-1],source,config,ledgers[e-1])
            if e==epoch:completed.observer.assert_exact(raw,state,'latest_atomic_vs_retained_endpoint')
        else:
            assert e==epoch, 'A missing earlier raw endpoint cannot be reconstructed'
            raw=state;reconstruct.append(str(run.out/name))
        endpoints[str(e)]=inspect_validation(run,e,raw,records[e-1],config,source,input_hashes,epoch)
    rng_source=str(run.out/'training_state.pt')
    if str(epoch) in endpoints and endpoints[str(epoch)]['reuse_committed_inference']:
        rng_source=endpoints[str(epoch)]['post_validation_rng']
    # Full inventory also binds uncommitted tails/temp files without trusting
    # their contents. A separate recovery capsule must preserve them first.
    run.finish();assert inventory(context,job)==before
    assert not torch.cuda.is_initialized()
    return {'schema':'continuation_saved_state_inspection_v1',
        'status':'saved_state_checked_not_recovery_authorization','protocol_sha256':PROTOCOL_SHA,
        'label':job['label'],'committed_epoch':epoch,'remaining_training_epochs':40-epoch,
        'next_training_epoch':epoch+1 if epoch<40 else None,'actual_step_counts':counts,
        'raw_state_check':raw_check,'validation_endpoints':endpoints,'RNG_source_on_resume':rng_source,
        'missing_latest_raw_sidecar_reconstructible_from_atomic_state':reconstruct,
        'bound_input_sha256':dict(sorted(run.bindings.items())),
        'entire_interrupted_run_inventory_sha256':before,
        'required_before_any_resume':['Investigate and document a technical interruption; scientific divergence is not retryable by this check.',
            'Preserve the original failure, closed execution attempts, atomic training state, uncommitted tails and temporary/partial validation files in a hash-bound recovery capsule.',
            'Recheck quiescent ownership, unchanged frozen conditions/sources, all real gates and remaining hard budgets through a separately validated recovery launcher.'],
        'limits':['Read-only CPU reload; no training, inference, RNG restoration, file repair or process launch.',
                  'Only committed saved state is checked; this does not establish why the interruption occurred.',
                  'Latest committed validation must reuse its result and post-validation RNG; earlier validation is not repeated.',
                  'Raw states for earlier non-endpoint epochs are unavailable; recorded digests/runtime checks remain the evidence.']}


def inspect(project,label):
    assert os.environ.get('CUDA_VISIBLE_DEVICES')=='' and not torch.cuda.is_initialized()
    context=Context(project);f=context.files
    assert Path(__file__).resolve()==f.path(SELF.as_posix()).resolve()
    manifest_hash=f.sha(MANIFEST.as_posix());manifest=loads(f.read(MANIFEST.as_posix(),manifest_hash))
    assert manifest['schema']=='continuation_recovery_sources_v1' and manifest['protocol_sha256']==PROTOCOL_SHA
    bindings={(ROOT/r['name']).as_posix():r['sha256'] for r in manifest['files']}
    assert len(bindings)==len(manifest['files']) and SELF.as_posix() in bindings
    bindings[MANIFEST.as_posix()]=manifest_hash;f.verify(bindings)
    execution=source_bindings(context);bases=verify_completed_bases(context)
    assert Path(completed.__file__).resolve()==f.path((ROOT/'continuation_completion_audit.py').as_posix()).resolve()
    assert execution[(ROOT/'continuation_completion_audit.py').as_posix()]==f.sha((ROOT/'continuation_completion_audit.py').as_posix())
    job,design=job_for_label(context,label);inputs=checkpoint_bindings(context,job,design)
    records=read_records(f);relevant={}
    for name,row in records.items():
        if row.get('label')==PREFIX+label or label in row.get('command',[]):
            if 'pid' in row:assert process_command(row['pid']) is None, 'Related execution is still alive'
            relevant[name]=f.sha(name)
    assert relevant, 'No registered execution history for this interrupted path'
    import fcntl
    with f.path(job['run_directory']+'.lock').open('rb') as lock:
        fcntl.flock(lock,fcntl.LOCK_SH|fcntl.LOCK_NB)
        result=inspect_bound_run(context,job,{k:inputs[job['args'][k]] for k in ('source','teacher','data')})
        for mapping in (context.bindings,bindings,execution,bases,inputs,relevant):
            f.verify(mapping);result['bound_input_sha256'].update(mapping)
    return result


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--label',required=True);args=parser.parse_args()
    torch.set_num_threads(1)
    print(encoded(inspect(Path.cwd(),args.label)).decode(),end='')


if __name__=='__main__':main()
