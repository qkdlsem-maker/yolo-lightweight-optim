"""Pure construction of the prespecified84-invocation continuation preflight.

No execution or readiness marker. Caller must bind actual completed/audited base
files and the isolated validation view before publishing an immutable request
roster and source manifest. Synthetic tests supply fabricated bindings only.
"""
import copy
import itertools
from pathlib import Path
from continuation_contract import ROOT, PROTOCOL_SHA

PAIRS = (101, 404)
RATES = (.0001, .001)
ARMS = ('control', 'mse', 'cwd')
STOP_KEYS = ('stop_after_epoch', 'stop_before_validation_epoch', 'stop_after_validation_epoch')
OLD_SOURCE_SHA = '2445e1db2b6289208018f2ab27cc8853cebeb809d20a34ae641b4e1bc482a1ab'


def valid_sha(value):
    assert type(value) is str and len(value) == 64 and all(x in '0123456789abcdef' for x in value)


def stop(after=0, before_validation=0, after_validation=0):
    return dict(zip(STOP_KEYS, (after, before_validation, after_validation)))


def build_roster(checkpoints, fixture_data):
    assert set(checkpoints) == {f'{model}_{pair}' for model, pair in itertools.product(('nano', 'large'), PAIRS)}
    for key, item in checkpoints.items():
        model, pair = key.split('_')
        base = 'review_20261017_independent' if int(pair) == 101 else ROOT.as_posix()
        assert item['path'] == f'{base}/base/{model}_seed{pair}/weights/last.pt'
        valid_sha(item['sha256'])
        valid_sha(item['audit_sha256'])
    data_path = ROOT / 'continuation_preflight' / 'inputs' / 'data.yaml'
    assert fixture_data['path'] == data_path.as_posix()
    assert fixture_data['train_images'] == 69863 and fixture_data['validation_images'] == 32
    valid_sha(fixture_data['sha256'])
    valid_sha(fixture_data['view_manifest_sha256'])
    candidates, references, cases, invocations = [], [], [], []
    for pair, rate, arm in itertools.product(PAIRS, RATES, ARMS):
        case = f'pair{pair}_{arm}_lr{rate:g}'
        common = {'arm': arm, 'seed': pair + 1000, 'epochs': 40, 'batch': 64, 'workers': 4,
                  'lr': rate, 'kd_weight': 0. if arm == 'control' else .3, 'temperature': 4.,
                  'source': checkpoints[f'nano_{pair}']['path'],
                  'teacher': checkpoints[f'large_{pair}']['path'], 'data': fixture_data['path'],
                  'smoke_batches': 0, 'fixture_batches': 0, **stop()}
        inputs = {'source': checkpoints[f'nano_{pair}']['sha256'],
                  'teacher': checkpoints[f'large_{pair}']['sha256'], 'data': fixture_data['sha256']}
        requests = {}
        for kind in ('reference_observation', 'candidate_observation', 'candidate_uninterrupted', 'candidate_interrupted'):
            request_id = case + '__' + kind
            out_root = (ROOT / 'continuation_preflight' / 'runs' / request_id).as_posix()
            args = dict(common, out_root=out_root,
                        smoke_batches=32 if kind.endswith('observation') else 0,
                        fixture_batches=0 if kind.endswith('observation') else 8)
            points = [stop()]
            if kind == 'candidate_uninterrupted':
                points = [stop(after=12)]
            elif kind == 'candidate_interrupted':
                points = [stop(after=2), stop(before_validation=10), stop(after_validation=10), stop(after=12)]
            if kind == 'reference_observation':
                # Original parser does not have new gate or validation-stop flags.
                args.pop('fixture_batches')
                args.pop('stop_after_epoch')
                args.pop('stop_before_validation_epoch')
                args.pop('stop_after_validation_epoch')
                target = 'review_20261017_independent/continuation.py'
            else:
                args['preflight_id'] = request_id
                target = (ROOT / 'continuation.py').as_posix()
            request = {'id': request_id, 'case': case, 'kind': kind, 'args': args,
                       'target': target, 'input_sha256': inputs.copy(),
                       'allowed_stop_points': points, 'data_view_manifest_sha256': fixture_data['view_manifest_sha256'],
                       'checkpoint_audit_sha256': {m: checkpoints[f'{m}_{pair}']['audit_sha256'] for m in ('nano', 'large')}}
            if kind == 'reference_observation':
                request['target_sha256'] = OLD_SOURCE_SHA
                references.append(request)
            else:
                candidates.append(request)
            requests[kind] = request_id
            for segment, point in enumerate(points, 1):
                final_epoch = 1 if kind.endswith('observation') else (2 if point['stop_after_epoch'] == 2 else (10 if any(point[k] for k in STOP_KEYS[1:]) else 12))
                batches = 32 if kind.endswith('observation') else {
                    'candidate_uninterrupted': [96], 'candidate_interrupted': [16, 64, 0, 16]}[kind][segment - 1]
                invocations.append({'id': f'{request_id}__segment{segment}', 'request_id': request_id,
                                    'resume': segment > 1, 'stop': point.copy(),
                                    'capture': (ROOT / 'continuation_preflight' / 'captures' / f'{request_id}__segment{segment}.pt').as_posix(),
                                    'expected_committed_epoch': final_epoch, 'training_batches': batches})
        cases.append({'id': case, 'pair_seed': pair, 'lr': rate, 'arm': arm, 'requests': requests})
    assert len(candidates) == 36 and len(references) == 12 and len(cases) == 12
    assert len(invocations) == 84 and sum(x['training_batches'] for x in invocations) == 3072
    assert len({x['id'] for x in candidates + references}) == 48
    assert len({x['capture'] for x in invocations}) == 84
    return {'schema': 'continuation_preflight_requests_v1', 'protocol_sha256': PROTOCOL_SHA,
            'requests': candidates, 'reference_requests': references, 'cases': cases, 'invocations': invocations,
            'fixture_data': copy.deepcopy(fixture_data), 'checkpoint_bindings': copy.deepcopy(checkpoints),
            'max_allocated_GPU_hours': 3., 'maximum_concurrent_GPU_jobs': 1,
            'status': 'fixed_roster_not_a_GPU_pass_or_permission_to_dispatch'}


def invocation_args(request, invocation, device):
    assert type(device) is int and device in (0, 1)
    assert invocation['request_id'] == request['id']
    assert type(invocation['resume']) is bool
    assert invocation['stop'] in request['allowed_stop_points']
    args = copy.deepcopy(request['args'])
    for key, value in invocation['stop'].items():
        assert type(value) is int
        if key in args:
            args[key] = value
        else:
            assert request['kind'] == 'reference_observation' and value == 0
    args.update(device=device, resume=invocation['resume'])
    return args


def argument_vector(args):
    output = []
    for key, value in args.items():
        if value is None or value is False:
            continue
        flag = '--' + key.replace('_', '-')
        output.append(flag)
        if value is not True:
            output.append(str(value))
    return output
