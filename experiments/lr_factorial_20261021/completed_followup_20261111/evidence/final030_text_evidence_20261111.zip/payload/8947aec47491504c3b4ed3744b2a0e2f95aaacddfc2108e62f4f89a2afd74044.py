"""Independent ownership/cap guard using its own authenticated fresh scanner lane."""
import os,signal,sys,time
from pathlib import Path
OLD=Path('/home/futurenetworklab/choihyerim1129/yolo_lightweight_optim/review_20261021_lr_factorial_auxiliary026/remedy028_20261109_v3')
sys.path.insert(0,str(OLD))
from retained_io import read,publish,Journal
from owned_runtime import identity,members,same,signal_exact
from research_admission import rows,usage,limits,WINDOW_END
from fresh_monitor import Client
from validation_cases import wait_file


def owned_CPU_seconds(owner,token):
    total=0
    for pid in {os.getpid(),owner['pid'],*[row['pid'] for row in members(token)]}:
        try:
            raw=Path(f'/proc/{pid}/stat').read_text();tail=raw[raw.rfind(')')+2:].split()
            total+=sum(int(tail[index]) for index in (11,12,13,14))
        except (FileNotFoundError,ProcessLookupError):pass
    return total/os.sysconf('SC_CLK_TCK')


def run(plan):
    folder=Path(plan['folder']);journal=Journal(folder/'guard.jsonl',128*1024*1024,300000)
    fault=None;client=None
    try:
        publish(folder/'GUARD_READY.json',dict(identity=identity(os.getpid()),owner=plan['owner'],token=plan['token'],deadline=plan['deadline']))
        client=Client(wait_file(folder/'MONITOR_READY.json',min(time.monotonic()+30,plan['work_deadline'])),'worker1.main')
        while True:
            if not same(plan['owner'],identity(plan['owner']['pid'])): raise RuntimeError('Study owner lost')
            if time.monotonic()>=plan['work_deadline'] or time.time()>=WINDOW_END: raise TimeoutError('Fixed study deadline')
            if (folder/'GUARD_FINISH.json').exists():
                assert read(folder/'GUARD_FINISH.json')=={'owner':plan['owner'],'token':plan['token']}
                client.retire();break
            sample=client.sample();records=rows(Path(plan['project']))
            snapshot=usage(Path(plan['project']),records,sample['phase_bytes'],sample['auxiliary_bytes']);limits(snapshot)
            local=sum(r.get('ended_unix',time.time())-r['started_unix'] for r in records.values() if r['GPU_job'] and r.get('token')==plan['token'])
            if local>plan['GPU_hours_limit']*3600: raise RuntimeError('Stage allocation cap')
            if plan.get('CPU_hours_limit') is not None and owned_CPU_seconds(plan['owner'],plan['token'])>=plan['CPU_hours_limit']*3600:raise RuntimeError('Study aggregate CPU cap')
            if plan['validation'] and snapshot['phase_bytes']+snapshot['auxiliary_bytes']-plan['initial_disk_bytes']>=2**30: raise RuntimeError('CPU validation disk limit')
            if (folder/'FAILURE.json').exists(): raise RuntimeError('Study failure marker')
            journal.event('fresh_guard_observation',usage=snapshot,local_GPU_seconds=local)
            until=min(time.monotonic()+5,plan['work_deadline'])
            while time.monotonic()<until and not (folder/'GUARD_FINISH.json').exists(): time.sleep(.1)
    except BaseException as error:
        fault=error
        try: publish(folder/'BUDGET_STOP.json',dict(error=repr(error),owner=plan['owner'],token=plan['token'],automatic_retry=False))
        finally:
            signal_exact(plan['owner'],signal.SIGTERM)
            grace=min(plan['deadline'],time.monotonic()+3)
            while time.monotonic()<plan['deadline']:
                found=members(plan['token'])
                if not found: break
                for who in found:
                    if who['state']!='Z': signal_exact(who,signal.SIGTERM if time.monotonic()<grace else signal.SIGKILL)
                time.sleep(.05)
    finally:
        journal.event('guard_terminal',failure=None if fault is None else repr(fault))
        journal.close()
    if fault is not None: raise fault

if __name__=='__main__': run(read(sys.argv[1]))
