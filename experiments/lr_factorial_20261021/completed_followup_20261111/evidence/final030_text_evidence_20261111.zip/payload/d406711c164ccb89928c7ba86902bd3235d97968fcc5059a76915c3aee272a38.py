"""Real Linux subprocess/session/barrier/ledger tests, with synthetic model gates.

The tested production runner has no bypass mode. Only this separate test process
substitutes model/data authentication and the tensor auditor. No CUDA or training.
"""
import copy, hashlib, json, os, signal, subprocess, sys, time
from pathlib import Path
import continuation_after020_runner as m
import continuation_after020_evidence as e


def synthetic_plan():
    labels=['first','second']+[f'job{i}' for i in range(2,15)]
    return {'waves':[{'wave':6+i//2,'jobs':[{'label':label,'device':device,
        'args':{'out_root':str(m.ROOT/'runs'/label),'device':device,'resume':False}}
        for device,label in enumerate(labels[i:i+2])]} for i in range(0,15,2)]}


def bootstrap():
    case=os.environ['WAVE_TEST_CASE'];project=Path.cwd();r=project/m.ROOT;plan=synthetic_plan()
    def cmd(f,wave=None,label=None):
        return [sys.executable,str(Path(__file__).resolve()),'--bootstrap']+([] if wave is None else ['--wave',str(wave),'--label',label])
    m.command=cmd
    m.check_self=lambda f:None
    class Context:
        def __init__(self,path):
            self.files=m.Files(path);self.bindings={str(m.ROOT/'continuation.py'):self.files.sha(str(m.ROOT/'continuation.py'))}
        def verify(self):pass
    m.Context=Context;e.sources=lambda f:{};e.plan_for=lambda c:(plan,{})
    def job(c,label):
        item=next(i for wave in plan['waves'] for i in wave['jobs'] if i['label']==label)
        return {'label':label,'args':item['args'],'run_directory':str(m.ROOT/'runs'/label)},{}
    m.job_for_label=job;m.arguments=lambda j,d,i:dict(j['args']);m.checkpoint_bindings=lambda *unused:{}
    def untouched(c,j):assert not c.files.path(j['run_directory']).exists()
    m.untouched_destination=untouched
    def latch(f,review):
        from continuation_preflight_runtime import no_latches
        no_latches(f)
        assert not (r/'production_failures/new.json').exists()
        assert not (project/m.HERE/'FAILURE.json').exists()
        assert (r/'CONTINUATION_FAILURE.json').read_bytes()==b'{"original":true}'
    e.latches=latch
    def guard(f):
        if (r/'synthetic_guard_lost').exists():raise AssertionError('Synthetic guard absent')
    m.recovery.guard=guard;m.gpu_idle_uuid=lambda i:'synthetic-'+str(i)
    def auth(f):
        review=m.loads(f.read(m.recovery.REVIEW.as_posix()));e.latches(f,review);guard(f)
        return Context(f.project),plan,review,{'source':{},'bases':{},'new_sources':{},'reuse':{}}
    e.authenticate=auth
    def contract(args):
        label=Path(args.out_root).name
        if case=='admission_failure' and label=='second':raise RuntimeError('Synthetic contract rejected')
        if case=='delayed_peer' and label=='second':time.sleep(1.2)
        value={'label':label,'mode':'production','protocol_sha256':m.PROTOCOL_SHA}
        if case=='tampered_readiness' and label=='second':value['mode']='preflight_fixture'
        return value
    m.enforce_contract=contract
    def trainer(path,args,expected,sha):
        assert args['resume'] is False and 'CUDA_VISIBLE_DEVICES' not in os.environ
        label=Path(args['out_root']).name;number=next(w['wave'] for w in plan['waves'] if any(j['label']==label for j in w['jobs']))
        folder=project/m.HERE/f'wave_{number:02d}'
        release=json.loads((folder/'release.json').read_bytes())
        for peer,h in release['ready_sha256'].items():
            assert hashlib.sha256((folder/peer/'ready.json').read_bytes()).hexdigest()==h
        (folder/label/'synthetic_GPU_started.json').write_text(json.dumps({'unix':time.time()}))
        if number==6:
            if case=='worker_failure' and label=='first':raise RuntimeError('Synthetic trainer failure')
            if case=='unknown_failure' and label=='first':(r/'production_failures/new.json').write_text('{}')
            if case=='guard_missing' and label=='first':(r/'synthetic_guard_lost').write_text('lost')
            if case=='budget_stop' and label=='first':(r/'BUDGET_STOP.json').write_text('{}')
        time.sleep(1.5 if case in ('parent_signal','orphan_parent','unknown_failure','guard_missing','budget_stop') else (.35 if label=='first' else .7))
        out=project/args['out_root'];out.mkdir(parents=True)
        (out/'COMPLETE.json').write_text(json.dumps({'label':label,'synthetic':True}))
    m.execute_trainer=trainer
    def audit(c,j,report,*unused):
        assert report['status']=='synthetic_independent_audit_passed' and report['label']==j['label']
        return {j['run_directory']+'/COMPLETE.json':c.files.sha(j['run_directory']+'/COMPLETE.json')}
    e.audit_report=audit
    if '--wave' in sys.argv:
        n=int(sys.argv[sys.argv.index('--wave')+1]);label=sys.argv[sys.argv.index('--label')+1];m.worker(n,label)
    else:m.parent()


def setup(project):
    r=project/m.ROOT
    for name in ('attempts','production_failures','recovery_investigations','runs'):(r/name).mkdir(parents=True,exist_ok=True)
    (r/'continuation.py').write_bytes(b'synthetic model boundary, not executable')
    (r/'CONTINUATION_FAILURE.json').write_bytes(b'{"original":true}')
    review={'known_failure_sha256':{str(m.ROOT/'CONTINUATION_FAILURE.json'):hashlib.sha256((r/'CONTINUATION_FAILURE.json').read_bytes()).hexdigest()},
            'GPU_uuid':{'0':'synthetic-0','1':'synthetic-1'}}
    (r/'recovery_investigations/020_review.json').write_text(json.dumps(review))
    (project/'venv/bin').mkdir(parents=True);(project/'venv/bin/python').symlink_to(sys.executable)
    (r/'continuation_completion_audit.py').write_text('''import sys,os,json
label=sys.argv[sys.argv.index('--label')+1]
assert os.environ['CUDA_VISIBLE_DEVICES']==''
case=os.environ['WAVE_TEST_CASE']
if case=='audit_failure':raise RuntimeError('Synthetic tensor audit failed')
print(json.dumps({'status':'wrong' if case=='audit_invalid_report' else 'synthetic_independent_audit_passed','label':label,'actual_step_counts':{'attempted':43680,'applied':43665,'skipped':15}}))
''')


def tests():
    root=Path(sys.argv[1]).resolve();root.mkdir(exist_ok=False);results=[]
    cases=('pass','delayed_peer','duplicate_live','admission_failure','tampered_readiness','worker_failure',
           'audit_failure','audit_invalid_report','unknown_failure','guard_missing','budget_stop','parent_signal','orphan_parent')
    for case in cases:
        project=root/case;setup(project);r=project/m.ROOT
        original=(r/'CONTINUATION_FAILURE.json').read_bytes()
        env=os.environ.copy();env.update(WAVE_TEST_CASE=case)
        env.update(m.CPU_ENVIRONMENT)
        cmd=[sys.executable,str(Path(__file__).resolve()),'--bootstrap']
        with (project/'test.log').open('xb') as out:
            p=subprocess.Popen(cmd,cwd=project,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
            if case in ('parent_signal','orphan_parent','duplicate_live'):
                deadline=time.monotonic()+20
                while not (r/'continuation_after020/wave_06/release.json').exists():
                    assert p.poll() is None and time.monotonic()<deadline;time.sleep(.05)
                if case=='duplicate_live':
                    before=len(list((r/'attempts').glob('*.json')))
                    with (project/'duplicate_live_rejected.log').open('xb') as duplicate_log:
                        duplicate=subprocess.Popen(cmd,cwd=project,env=env,stdout=duplicate_log,stderr=subprocess.STDOUT,start_new_session=True)
                        assert duplicate.wait(timeout=10)!=0
                    assert not (r/'continuation_after020/FAILURE.json').exists()
                    assert len(list((r/'attempts').glob('*.json')))==before
                else:os.kill(p.pid,signal.SIGTERM if case=='parent_signal' else signal.SIGKILL)
            code=p.wait(timeout=90)
        if case=='orphan_parent':time.sleep(3)
        rows={str(p.relative_to(project)):json.loads(p.read_bytes()) for p in (r/'attempts').glob('*.json')}
        assert all(m.process_command(row['pid']) is None for row in rows.values() if 'pid' in row),(case,'leaked process')
        assert (r/'CONTINUATION_FAILURE.json').read_bytes()==original
        passed=case in ('pass','delayed_peer','duplicate_live');here=project/m.HERE
        if passed:
            assert code==0 and (here/'TRAINING_RECEIPTS_COMPLETE.json').exists(),(case,(project/'test.log').read_text())
            assert not (here/'FAILURE.json').exists()
            assert len(list((here/'receipts').glob('*.json')))==15
            assert all(row['status']=='completed' and 'ended_unix' in row for row in rows.values())
            charged=[row for row in rows.values() if row['GPU_job']]
            assert len(charged)==15 and all(row['reservation'] for row in charged)
            workers=[row for row in rows.values() if row['label'].startswith('continuation_after020_worker__')]
            assert len(workers)==15 and all(row['GPU_job'] is False for row in workers)
            for number in range(6,14):
                folder=here/f'wave_{number:02d}';release=json.loads((folder/'release.json').read_bytes())
                for label in release['ready_sha256']:
                    ready=json.loads((folder/label/'ready.json').read_bytes())
                    actual=json.loads((folder/label/'synthetic_GPU_started.json').read_bytes())
                    assert ready['ready_unix']<=release['released_unix']<=actual['unix']
            for number in range(6,13):
                sealed=json.loads((here/f'wave_{number:02d}'/'SEALED.json').read_bytes())['sealed_unix']
                next_release=json.loads((here/f'wave_{number+1:02d}'/'release.json').read_bytes())
                for label in next_release['ready_sha256']:
                    worker=next(row for row in workers if row['label'].endswith('__'+label))
                    assert worker['started_unix']>=sealed,'Hot fill across wave boundary'
            final=json.loads((here/'wave_13/release.json').read_bytes())
            assert len(final['reservations'])==1 and {v['device'] for v in final['reservations'].values()}=={0}
            audits=sorted((row for row in rows.values() if row['label'].startswith('continuation_after020_audit__')),key=lambda x:x['started_unix'])
            assert all(b['started_unix']>=a['ended_unix'] for a,b in zip(audits,audits[1:]))
            counted=sum(row['ended_unix']-row['started_unix'] for row in charged)/3600
            _,usage=m.resources(m.Files(project));assert abs(usage['allocated_GPU_hours']-counted)<1e-9
            # A second launch must reject existing evidence before any new worker.
            before=len(rows)
            with (project/'repeat_rejected.log').open('xb') as out:
                again=subprocess.Popen(cmd,cwd=project,env=env,stdout=out,stderr=subprocess.STDOUT,start_new_session=True)
                assert again.wait(timeout=10)!=0
            assert len(list((r/'attempts').glob('*.json')))==before
            assert not (here/'FAILURE.json').exists(),'Rejected duplicate modified completed evidence'
        else:
            assert code!=0 and (here/'FAILURE.json').exists(),(case,(project/'test.log').read_text())
            assert not (here/'TRAINING_RECEIPTS_COMPLETE.json').exists() and not (here/'wave_07').exists()
            if case!='orphan_parent':assert all('ended_unix' in row for row in rows.values()),(case,rows)
            else:
                assert any('ended_unix' not in row for row in rows.values()),'Abrupt parent loss must preserve unclosed charge for investigation'
            if case in ('admission_failure','tampered_readiness'):
                assert not (here/'wave_06/release.json').exists()
                assert not any(row['GPU_job'] for row in rows.values())
        results.append('real_subprocess_'+case)
    return {'status':'passed','real_subprocess_cases':len(cases),'cases':results,
        'tested_sources_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(m.__file__),Path(e.__file__),Path(__file__))},
        'limits':['Actual subprocesses, process sessions, barrier ordering, reservations, teardown and immutable receipts; model/data/auditor boundaries synthetic.',
                  'No CUDA, model training, inference or new numerical replay validation. Real original GPU proof and completed recovery acceptance remain required.']}


if __name__=='__main__':
    if '--bootstrap' in sys.argv:bootstrap()
    else:print(json.dumps(tests(),indent=2))
