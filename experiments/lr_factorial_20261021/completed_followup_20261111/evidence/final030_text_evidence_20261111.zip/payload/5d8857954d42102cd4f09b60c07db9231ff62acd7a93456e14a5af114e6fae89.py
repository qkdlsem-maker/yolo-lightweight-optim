"""One reviewed, same-device/same-state recovery. No general retry capability.

The original sources/latch/attempts remain immutable. This script resumes only
the incident018 MSE trajectory, reserves and charges both GPUs, and audits it
after process exit. It never dispatches another trajectory or repeats a result.
"""
import argparse,os,signal,subprocess,sys,threading,time,traceback
from pathlib import Path
from continuation_artifact_receipts import Context,Files,ROOT,PROTOCOL_SHA,encoded,loads
from continuation_preflight_runtime import resources,check_limits,no_latches,process_command,GUARD_SHA,gpu_idle_uuid,verify_completed_bases
from continuation_execution_runtime import source_bindings,job_for_label,arguments,checkpoint_bindings
from continuation_production_gate import verify_gate
from continuation_recovery_capsule import verify_capsule,run_inventory
from continuation_production_receipts import verify_receipt,CPU_ENVIRONMENT,canonical_bindings,required_run_files
from run_continuation_production_job import execute_trainer
from run_continuations import register_attempt
from run_continuation_preflight import update_owned,stop_owned_child
from validation_journal import publish_immutable

LABEL='pair101_mse_w0.3_lr0.001'
CONTROL='pair101_control_w0_lr0.001'
HERE=ROOT/'incident018_recovery'
SELF=ROOT/'incident018_resume.py'
REASON="AssertionError('Selected GPU is occupied')"
MANIFEST=ROOT/'incident018_resume_sources.json'
REVIEW=ROOT/'recovery_investigations/018_review.json'

def command(files,worker=False):
 return [str(files.project/'venv/bin/python'),'-u',SELF.as_posix()]+(['--worker'] if worker else [])

def validate_original_attempts(parent,child):
 assert parent['pid']==2615699 and parent['GPU_job'] is False and parent['device'] is None
 assert parent['status']=='failed' and parent['returncode']==1 and parent['stop_reason']==REASON
 assert child['pid']==2616122 and child['parent_pid']==2615699 and child['GPU_job'] is True and child['device']==1
 assert child['status']=='failed' and child['returncode']==-15 and child['stop_reason']==REASON
 for row in (parent,child):
  assert type(row['started_unix']) in (int,float) and type(row['ended_unix']) in (int,float)
  assert 0<row['started_unix']<row['ended_unix']
 assert child['ended_unix']<=parent['ended_unix']

def validate_review(review,plan,probe):
 assert review['schema']=='incident018_same_state_recovery_review_v1' and review['protocol_sha256']==PROTOCOL_SHA
 assert review['label']==LABEL and review['device']==1 and review['reserved_GPU_devices']==[0,1]
 assert review['classification']=='technical_supervisor_interruption' and review['conditions_and_scientific_sources_unchanged'] is True
 assert review['same_original_state_resume_only'] is True and review['automatic_retry'] is False
 assert review['maximum_recovery_launches']==1 and review['completed_control_reuse_only'] is True
 assert review['max_recovery_wall_seconds']==8*3600
 assert review['max_allocated_recovery_GPU_hours']==16
 assert plan['label']==LABEL and plan['protocol_sha256']==PROTOCOL_SHA
 report=plan['inspection']
 assert report['status']=='saved_state_checked_not_recovery_authorization' and report['committed_epoch']==16
 assert report['next_training_epoch']==17 and report['remaining_training_epochs']==24
 assert report['actual_step_counts']=={'attempted':17472,'applied':17468,'skipped':4}
 assert report['unclosed_registered_attempts_preserved_not_resolved']==[]
 assert probe['status']=='reproduced_late_device_selection_cross_GPU_context'
 assert probe['original_idle_gate_rejected_GPU0'] is True and probe['selected_validation_device']=='cuda:0'
 assert review['historical_occupant_PID_directly_observed'] is False
 assert review['remedy']=='reserve_both_GPUs_for_unchanged_device1_resume; no fresh dispatch until exit and audit'

def manifest(files):
 value=loads(files.read(MANIFEST.as_posix()))
 assert value['schema']=='incident018_resume_sources_v1' and value['protocol_sha256']==PROTOCOL_SHA
 bindings={(ROOT/row['name']).as_posix():row['sha256'] for row in value['files']}
 assert len(bindings)==len(value['files']) and SELF.as_posix() in bindings and REVIEW.as_posix() in bindings
 files.verify(bindings);bindings[MANIFEST.as_posix()]=files.sha(MANIFEST.as_posix())
 assert Path(__file__).resolve()==files.path(SELF.as_posix()).resolve()
 return bindings

def failure_set(files):
 paths=[ROOT/'CONTINUATION_FAILURE.json']+sorted(files.path((ROOT/'production_failures').as_posix()).glob('*.json'))
 return {str(p.relative_to(files.project) if p.is_absolute() else p):files.sha(str(p.relative_to(files.project) if p.is_absolute() else p)) for p in paths}

def latches(files,review):
 no_latches(files)
 assert failure_set(files)==review['known_failure_sha256'],'Unreviewed or changed production failure'
 for n in (HERE/'FAILURE.json',ROOT/'CONTINUATION_TRAINING_COMPLETE.json'):
  assert not files.path(n.as_posix()).exists(),'Recovery stop/completion marker'

def guard(files):
 row=loads(files.read((ROOT/'budget_guard_launch.json').as_posix()))
 assert files.sha((ROOT/'budget_guard.py').as_posix())==GUARD_SHA and process_command(row['pid'])==row['command']

def validate_accounting(rows,owned,pid,parent_pid,files):
 active={n:r for n,r in rows.items() if r['GPU_job'] and 'ended_unix' not in r}
 assert set(active)==set(owned) and len(active)==2
 assert {r['device'] for r in active.values()}=={0,1}
 for n,row in active.items():
  assert row==owned[n] and row['pid']==pid and row['parent_pid']==parent_pid
  assert row['status']=='running' and row['command']==command(files,True)
 assert process_command(parent_pid)==command(files)
 assert process_command(pid)==command(files,True)

def authenticate(files):
 bindings=manifest(files);review=loads(files.read(REVIEW.as_posix()));latches(files,review);guard(files)
 context=Context(files.project);source=source_bindings(context);bases=verify_completed_bases(context)
 gate=verify_gate(files.project,context.manifest_hash)
 for name in ('launch.json','base_recovery_launch.json','continuation_launch.json'):
  old=loads(files.read((ROOT/name).as_posix()));assert process_command(old['pid']) is None
 files.verify(review['supporting_evidence_sha256'])
 parent=loads(files.read(review['original_parent_attempt']));child=loads(files.read(review['original_child_attempt']))
 validate_original_attempts(parent,child)
 assert process_command(parent['pid']) is None and process_command(child['pid']) is None
 complete=verify_capsule(files,review['capsule']);assert files.sha(review['capsule']+'/CAPTURE_COMPLETE.json')==review['capsule_complete_sha256']
 plan=loads(files.read(review['capsule']+'/plan.json',complete['plan_sha256']))
 probe=loads(files.read((ROOT/'recovery_investigations/018_device_probe_result.json').as_posix()))
 validate_review(review,plan,probe)
 job,design=job_for_label(context,LABEL);assert run_inventory(files,job)==plan['run_inventory_sha256']
 assert not files.path(job['run_directory']+'/COMPLETE.json').exists()
 inputs=checkpoint_bindings(context,job,design)
 control_job,_=job_for_label(context,CONTROL)
 authority={'execution_source_sha256':source,'preflight_gate':gate,'completed_base_bindings':bases,'checkpoint_bindings':checkpoint_bindings(context,control_job,design)}
 receipt,receipt_sha=verify_receipt(context,CONTROL,authority)
 assert receipt_sha==review['completed_control_receipt_sha256']
 _,snapshot=resources(files);check_limits(snapshot);latches(files,review)
 return context,review,job,dict(arguments(job,design,1),resume=True),{'source':source,'bases':bases,'inputs':inputs,'new_sources':bindings,'control_receipt_sha256':receipt_sha,'gate':gate,'capsule':review['capsule'],'pre_resume_inventory_sha256':plan['run_inventory_sha256']}

def publish_failure(files,error):
 value={'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'error':repr(error),'traceback':traceback.format_exc(),'original_failure_and_capsule_preserved':True,'automatic_retry':False}
 p=files.path((HERE/'FAILURE.json').as_posix());p.parent.mkdir(parents=True,exist_ok=True)
 if not p.exists():publish_immutable(p,encoded(value))

def close(files,name,initial,code):
 assert type(code) is int
 row=dict(initial,ended_unix=time.time(),status='completed' if code==0 else 'failed',returncode=code)
 assert update_owned(files,name,initial,row),'Guard retained terminal record'

def worker():
 files=Files(Path.cwd());pid=os.getpid();parent_pid=os.getppid()
 assert os.getsid(pid)==os.getpgid(pid)==pid and process_command(pid)==command(files,True)
 assert 'CUDA_VISIBLE_DEVICES' not in os.environ
 sources=manifest(files);review=loads(files.read(REVIEW.as_posix()));guard(files);latches(files,review)
 deadline=time.time()+10
 while True:
  path=files.path((HERE/'worker_ticket.json').as_posix())
  if path.exists():break
  assert time.time()<deadline;time.sleep(.05)
 ticket=loads(path.read_bytes());assert ticket['pid']==pid and ticket['parent_pid']==parent_pid
 owned=ticket['attempts'];authority=loads(files.read((HERE/'authority.json').as_posix(),ticket['authority_sha256']))
 assert authority['args']['resume'] is True and authority['args']['device']==1
 context=Context(files.project);job,design=job_for_label(context,LABEL)
 assert authority['args']==dict(arguments(job,design,1),resume=True)
 assert run_inventory(files,job)==authority['evidence']['pre_resume_inventory_sha256']
 for key in ('source','bases','inputs','new_sources'):files.verify(authority['evidence'][key])
 stopped=threading.Event();errors=[]
 def sample():
  guard(files);latches(files,review);rows,usage=resources(files);check_limits(usage)
  validate_accounting(rows,owned,pid,parent_pid,files)
  assert time.time()-ticket['started_unix']<review['max_recovery_wall_seconds'],'Recovery-specific fixed wall limit'
  return usage
 def watch():
  while not stopped.wait(1):
   try:sample()
   except BaseException as error:
    errors.append(error);publish_failure(files,error);os.killpg(pid,signal.SIGTERM);return
 sample();uuids={str(i):gpu_idle_uuid(i) for i in (0,1)};assert uuids==review['GPU_uuid']
 publish_immutable(files.path((HERE/'worker_admission.json').as_posix()),encoded({'pid':pid,'parent_pid':parent_pid,'authority_sha256':ticket['authority_sha256'],'GPU_uuid':uuids,'attempts':owned,'resources':sample()}))
 watcher=threading.Thread(target=watch,daemon=True);watcher.start()
 try:
  trainer=(ROOT/'continuation.py').as_posix()
  execute_trainer(files.path(trainer),authority['args'],context.bindings[trainer],lambda p:files.sha(Path(p).relative_to(files.project).as_posix()))
  sample();assert not errors
  context.verify();files.verify(sources)
  for key in ('source','bases','inputs','new_sources'):files.verify(authority['evidence'][key])
  publish_immutable(files.path((HERE/'worker_returned.json').as_posix()),encoded({'status':'trainer_returned_independent_audit_pending','pid':pid,'authority_sha256':ticket['authority_sha256'],'complete_sha256':files.sha(job['run_directory']+'/COMPLETE.json'),'returned_unix':time.time()}))
 except BaseException as error:publish_failure(files,error);raise
 finally:stopped.set();watcher.join(5);assert not watcher.is_alive()

def parent():
 import fcntl
 files=Files(Path.cwd());pid=os.getpid();assert os.getsid(pid)==os.getpgid(pid)==pid and process_command(pid)==command(files)
 os.environ.update(CPU_ENVIRONMENT);locks=[];proc=None;parent_attempt=None;owned={};cpu=None;handles=[]
 def signal_stop(*unused):raise RuntimeError('Recovery parent interrupted; preserve and stop owned child')
 for sig in (signal.SIGTERM,signal.SIGINT):signal.signal(sig,signal_stop)
 try:
  for name in ('continuation_dispatcher.lock','continuation_production_gpu0.lock','continuation_production_gpu1.lock'):
   handle=files.path((ROOT/name).as_posix()).open('a');fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(handle)
  assert not files.path(HERE.as_posix()).exists(),'One recovery launch only'
  context,review,job,args,evidence=authenticate(files)
  _,usage=resources(files);check_limits(usage);assert not usage['active_GPU_attempts']
  assert {str(i):gpu_idle_uuid(i) for i in (0,1)}==review['GPU_uuid']
  files.path(HERE.as_posix()).mkdir()
  parent_attempt,parent_row=register_attempt(files,'incident018_recovery_parent_CPU',command(files),None,pid=pid)
  authority={'status':'reviewed_same_state_resume_only','args':args,'evidence':evidence,'review_sha256':files.sha(REVIEW.as_posix()),'parent_pid':pid}
  publish_immutable(files.path((HERE/'authority.json').as_posix()),encoded(authority))
  started=time.time()
  for device in (0,1):
   name,row=register_attempt(files,f'incident018_MSE_recovery_reserved_gpu{device}',command(files,True),device,parent_pid=pid);owned[name]=row
  log=files.path((HERE/'worker.log').as_posix()).open('xb');handles.append(log)
  env=os.environ.copy();env.pop('CUDA_VISIBLE_DEVICES',None)
  proc=subprocess.Popen(command(files,True),stdout=log,stderr=subprocess.STDOUT,stdin=subprocess.DEVNULL,start_new_session=True,env=env,cwd=files.project)
  for name,row in list(owned.items()):
   running=dict(row,pid=proc.pid,status='running');assert update_owned(files,name,row,running);owned[name]=running
  publish_immutable(files.path((HERE/'worker_ticket.json').as_posix()),encoded({'pid':proc.pid,'parent_pid':pid,'command':command(files,True),'attempts':owned,'started_unix':started,'authority_sha256':files.sha((HERE/'authority.json').as_posix())}))
  print('RECOVERY_WORKER_STARTED',proc.pid,flush=True)
  while proc.poll() is None:
   guard(files);latches(files,review);_,usage=resources(files);check_limits(usage)
   assert time.time()-started<review['max_recovery_wall_seconds'];time.sleep(.5)
  for name,row in list(owned.items()):close(files,name,row,proc.returncode)
  owned.clear();assert proc.returncode==0,'Recovery worker failed; no retry'
  returned=loads(files.read((HERE/'worker_returned.json').as_posix()))
  assert returned['complete_sha256']==files.sha(job['run_directory']+'/COMPLETE.json')
  # The existing CPU tensor auditor is unchanged. This original path had no
  # completed audit; no completed CPU audit is repeated here.
  audit_command=[str(files.project/'venv/bin/python'),'-u',(ROOT/'continuation_completion_audit.py').as_posix(),'--label',LABEL]
  audit_path=files.path((HERE/'completed_audit.json').as_posix());audit_log=files.path((HERE/'audit.log').as_posix())
  audit_name,audit_row=register_attempt(files,'incident018_completed_audit_CPU',audit_command,None,parent_pid=pid)
  output=audit_path.open('xb');err=audit_log.open('xb');handles.extend([output,err])
  env=os.environ.copy();env.update(CPU_ENVIRONMENT)
  cpu=subprocess.Popen(audit_command,stdout=output,stderr=err,stdin=subprocess.DEVNULL,start_new_session=True,env=env,cwd=files.project)
  live=dict(audit_row,pid=cpu.pid,status='running');assert update_owned(files,audit_name,audit_row,live);audit_row=live
  while cpu.poll() is None:
   guard(files);latches(files,review);_,usage=resources(files);check_limits(usage);time.sleep(.5)
  close(files,audit_name,audit_row,cpu.returncode);assert cpu.returncode==0,'Independent recovery audit failed'
  output.close();err.close();report=loads(audit_path.read_bytes())
  assert report['status']=='completed_evidence_passed' and report['label']==LABEL and report['epochs']==40
  assert report['protocol_sha256']==PROTOCOL_SHA and report['pair_seed']==101 and report['arm']=='mse' and report['lr']==.001
  assert report['audit_sources_sha256']==files.sha((ROOT/'continuation_completion_sources.json').as_posix())
  assert set(report['endpoints'])=={'10','20','40'}
  assert report['finite_saved_states'] and report['fixed_DFL_preserved']
  bound=canonical_bindings(files,report['bound_input_sha256']);assert required_run_files(job)<=set(bound);files.verify(bound)
  assert report['actual_step_counts']['attempted']==43680
  assert report['actual_step_counts']['attempted']==report['actual_step_counts']['applied']+report['actual_step_counts']['skipped']
  assert encoded(report['endpoints']['40']['metrics'])==encoded(loads(files.read(job['run_directory']+'/COMPLETE.json')))
  # All pre-interruption epoch evidence and committed epoch10 validation must
  # remain byte-identical. Only atomic current state and previously absent
  # future epochs/endpoints may advance.
  prior=evidence['pre_resume_inventory_sha256'];preserved={n:h for n,h in prior.items() if Path(n).name!='training_state.pt'}
  files.verify(preserved);verify_capsule(files,review['capsule']);context.verify()
  for key in ('source','bases','inputs','new_sources'):files.verify(evidence[key])
  latches(files,review);guard(files)
  ticket=loads(files.read((HERE/'worker_ticket.json').as_posix()));closed_bindings={}
  for name,initial in ticket['attempts'].items():
   row=loads(files.read(name));assert row['status']=='completed' and row['returncode']==0
   assert {k:row[k] for k in initial if k!='status'}=={k:v for k,v in initial.items() if k!='status'}
   assert row['ended_unix']>=returned['returned_unix'] and audit_row['started_unix']>=row['ended_unix']
   closed_bindings[name]=files.sha(name)
  final_cpu=loads(files.read(audit_name));assert final_cpu['status']=='completed' and final_cpu['returncode']==0
  closed_bindings[audit_name]=files.sha(audit_name)
  assert files.sha((ROOT/'production_receipts'/f'{CONTROL}.json').as_posix())==evidence['control_receipt_sha256']
  receipt={'schema':'incident018_recovered_continuation_receipt_v1','status':'same_state_recovery_and_independent_completed_audit_passed','protocol_sha256':PROTOCOL_SHA,'label':LABEL,'source_manifest_sha256':files.sha(MANIFEST.as_posix()),'review_sha256':files.sha(REVIEW.as_posix()),'capsule':review['capsule'],'capsule_complete_sha256':review['capsule_complete_sha256'],'original_attempt':review['original_child_attempt'],'worker_ticket_sha256':files.sha((HERE/'worker_ticket.json').as_posix()),'worker_returned_sha256':files.sha((HERE/'worker_returned.json').as_posix()),'audit_attempt':audit_name,'audit_sha256':files.sha((HERE/'completed_audit.json').as_posix()),'bound_file_sha256':bound,'unchanged_prior_run_sha256':preserved,'actual_step_counts':report['actual_step_counts'],'limits':['Single recovered path; remaining25new paths and all new endpoint analyses/diagnostics/documents remain.','GPU1 training and installed GPU0 validation behavior preserved; both GPUs reserved and charged during recovery.','Original epoch17 partial work was discarded by restoring the atomic epoch16 state; its log and elapsed allocation remain in the capsule/ledger.']}
  receipt['closed_recovery_and_audit_attempt_sha256']=closed_bindings
  publish_immutable(files.path((HERE/'RECEIPT.json').as_posix()),encoded(receipt));close(files,parent_attempt,parent_row,0);parent_attempt=None
  print('RECOVERY_COMPLETED_AUDITED_ONE_PATH_ONLY',flush=True)
 except BaseException as error:
  publish_failure(files,error)
  for p,cmd in ((proc,command(files,True)),(cpu,audit_command if cpu is not None else [])):
   if p is not None and p.poll() is None:stop_owned_child(p,cmd)
  for name,row in owned.items():
   if proc is not None and proc.poll() is not None:close(files,name,row,proc.returncode)
  if cpu is not None and cpu.poll() is not None:
   current=loads(files.read(audit_name))
   if 'ended_unix' not in current:close(files,audit_name,current,cpu.returncode)
  if parent_attempt is not None:close(files,parent_attempt,parent_row,1)
  raise
 finally:
  for h in handles:h.close()
  for h in reversed(locks):h.close()

if __name__=='__main__':
 parser=argparse.ArgumentParser();parser.add_argument('--worker',action='store_true');args=parser.parse_args()
 worker() if args.worker else parent()
