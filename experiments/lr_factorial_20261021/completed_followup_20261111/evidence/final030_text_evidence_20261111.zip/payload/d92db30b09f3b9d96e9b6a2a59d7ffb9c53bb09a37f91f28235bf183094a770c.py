"""Pure prespecified paired contrasts; no model, score-file or GPU access.

The caller must authenticate evaluation files, roster and metric-definition
bytes separately. References are retained, not asserted to be authenticated.
All 72 continuation endpoint slots must be present, including explicit missing
slots. The 12 base references and previous strength grid are reported elsewhere.
"""
import copy
import hashlib
import itertools
import json
import math
import re
import statistics
from decimal import Decimal, localcontext

PROTOCOL_SHA = '8dac98e36fee058726b9475487896c49f53f246e960cdfc0ba7e6acb895cdc9d'
INTERPRETATION_SHA = 'ffea92e15e8f0d7973e6ccc96083227124c3eb42de25d746f4611b76471f02b8'
SEEDS = (101, 202, 303, 404, 505, 606)
RATES = (.0001, .001)
ARMS = ('control', 'mse', 'cwd')
EPOCHS = (20, 40)
PRIMARY_METRIC = 'bdd_ten_class_AP50_95'
T975_DF5 = 2.570581835636314
UNCERTAINTY = ('Descriptive model-based 95% t interval with df=5; six independent '
               'matched base-training pairs, normality and small-sample limitations. '
               'No multiplicity-adjusted significance or equivalence decision.')


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False)+'\n').encode()


def loads(data):
    def unique(pairs):
        out = {}
        for key, value in pairs:
            if key in out:
                raise ValueError('Duplicate JSON key: '+key)
            out[key] = value
        return out
    def invalid(value):
        raise ValueError('Nonfinite JSON constant: '+value)
    return json.loads(data, object_pairs_hook=unique, parse_constant=invalid)


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha(value):
    require(type(value) is str and re.fullmatch('[0-9a-f]{64}', value), 'Invalid SHA256')
    return value


def number(value):
    require(type(value) in (int, float) and math.isfinite(value), 'Expected finite JSON number')
    return Decimal(str(value))


def expected_keys():
    return tuple(itertools.product(SEEDS, RATES, ARMS, EPOCHS))


def validate(payload):
    require(type(payload) is dict and payload.get('schema') == 'factorial_metric_input_v1', 'Input schema')
    require(payload.get('protocol_sha256') == PROTOCOL_SHA, 'Protocol identity')
    require(payload.get('interpretation_sha256') == INTERPRETATION_SHA, 'Interpretation identity')
    require(payload.get('unit') == 'AP_fraction_0_to_1', 'Scores must be AP fractions, not percentages')
    metric = payload.get('metric_id')
    require(type(metric) is str and re.fullmatch('[A-Za-z0-9_]+', metric), 'Metric identifier')
    require(type(payload.get('population')) is str and payload['population'].strip(), 'Population description')
    sha(payload.get('metric_definition_sha256'))
    sha(payload.get('endpoint_roster_sha256'))
    rows = payload.get('rows')
    require(type(rows) is list and len(rows) == 72, 'Require all72 endpoint slots; use unavailable rows explicitly')
    indexed = {}; endpoint_ids = set()
    for row in rows:
        require(type(row) is dict, 'Row object')
        seed, rate, arm, epoch = (row.get(k) for k in ('pair_seed', 'learning_rate', 'arm', 'epoch'))
        require(type(seed) is int and seed in SEEDS, 'Pair seed')
        require(type(epoch) is int and epoch in EPOCHS, 'Fixed epoch20/40 only')
        require(type(rate) in (int, float) and rate in RATES, 'Two fixed learning rates only')
        require(type(arm) is str and arm in ARMS, 'Three fixed arms only')
        require(number(row.get('kd_weight')) == (Decimal(0) if arm == 'control' else Decimal('.3')), 'Fixed KD weight')
        key = (seed, rate, arm, epoch)
        require(key not in indexed, 'Duplicate endpoint slot')
        origin = 'historical_reuse' if seed in SEEDS[:3] and rate == RATES[0] else 'new'
        require(row.get('origin') == origin, 'Historical nine low-rate paths must be reused')
        endpoint = row.get('endpoint_id')
        require(type(endpoint) is str and endpoint.strip() and endpoint not in endpoint_ids, 'Unique endpoint identity')
        endpoint_ids.add(endpoint)
        status = row.get('status')
        require(status in ('completed', 'unavailable'), 'Endpoint status')
        reason, score, evidence = row.get('reason'), row.get('score'), row.get('evidence')
        if status == 'completed':
            require(Decimal(0) <= number(score) <= Decimal(1), 'AP outside[0,1]')
            require(reason is None, 'Completed row must not carry unavailable reason')
        else:
            require(score is None, 'Unavailable scores must be null, never zero or imputed')
            require(type(reason) is str and reason.strip(), 'Explicit unavailable reason required')
        require(type(evidence) is dict and type(evidence.get('artifact')) is str and evidence['artifact'].strip(), 'Evidence reference')
        sha(evidence.get('sha256'))
        indexed[key] = copy.deepcopy(row)
    require(set(indexed) == set(expected_keys()), 'Full factorial roster')
    return indexed


def summary(values, include_interval=False):
    available = [x for x in values if x is not None]
    result = {'expected_pairs': len(values), 'available_pairs': len(available),
              'complete': len(available) == len(values), 'mean_pp': None,
              'sample_sd_pp': None, 'minimum_pp': None, 'maximum_pp': None,
              't_interval_95_pp': None}
    if not result['complete']:
        result['note'] = 'Incomplete prespecified set; aggregate not estimated from a selected subset.'
        return result
    mean, sd = statistics.mean(available), statistics.stdev(available)
    result.update(mean_pp=mean, sample_sd_pp=sd, minimum_pp=min(available), maximum_pp=max(available))
    if include_interval:
        require(len(available) == 6, 'The prespecified interval requires all six pairs')
        halfwidth = T975_DF5 * sd / math.sqrt(6)
        result['t_interval_95_pp'] = {'lower': mean-halfwidth, 'upper': mean+halfwidth,
                                     'df': 5, 'interpretation': UNCERTAINTY}
    return result


def contrast(indexed, epoch, kind, arm, rate=None):
    if kind == 'interaction':
        terms = [(RATES[1], arm, 1), (RATES[1], 'control', -1),
                 (RATES[0], arm, -1), (RATES[0], 'control', 1)]
        formula = '(KD_high-control_high)-(KD_low-control_low)'
    elif kind == 'kd_minus_control':
        terms = [(rate, arm, 1), (rate, 'control', -1)]
        formula = 'KD-control at the specified learning rate'
    else:
        require(kind == 'high_minus_low', 'Contrast kind')
        terms = [(RATES[1], arm, 1), (RATES[0], arm, -1)]
        formula = 'high_rate-low_rate within the specified arm'
    pairs = []
    for seed in SEEDS:
        source = [(indexed[seed, lr, a, epoch], sign) for lr, a, sign in terms]
        missing = [{'endpoint_id': r['endpoint_id'], 'reason': r['reason']}
                   for r, _ in source if r['status'] != 'completed']
        value = None
        if not missing:
            with localcontext() as context:
                context.prec = 50
                value = float(100 * sum((number(r['score'])*sign for r, sign in source), Decimal(0)))
        pairs.append({'pair_seed': seed, 'stratum': 'historical' if seed in SEEDS[:3] else 'new',
                      'value_pp': value, 'missing': missing,
                      'terms': [{'endpoint_id': r['endpoint_id'], 'sign': sign} for r, sign in source]})
    values = [p['value_pp'] for p in pairs]
    return {'kind': kind, 'arm': arm, 'epoch': epoch, 'learning_rate': rate,
            'formula': formula, 'unit': 'AP_percentage_points', 'pairs': pairs,
            'all_six_pairs': summary(values, include_interval=kind == 'interaction'),
            'historical_three_pairs': summary(values[:3]), 'new_three_pairs': summary(values[3:])}


def analyze(payload):
    indexed = validate(payload)
    results = []
    for epoch in EPOCHS:
        for arm in ARMS[1:]:
            item = contrast(indexed, epoch, 'interaction', arm)
            item['role'] = ('primary' if epoch == 40 and payload['metric_id'] == PRIMARY_METRIC else 'secondary')
            results.append(item)
            for rate in RATES:
                item = contrast(indexed, epoch, 'kd_minus_control', arm, rate)
                item['role'] = 'secondary'
                results.append(item)
        for arm in ARMS:
            item = contrast(indexed, epoch, 'high_minus_low', arm)
            item['role'] = 'secondary'
            results.append(item)
    return {'schema': 'factorial_metric_contrasts_v1', 'status': 'numerical_calculation_only',
            'protocol_sha256': PROTOCOL_SHA, 'interpretation_sha256': INTERPRETATION_SHA,
            'input_canonical_sha256': hashlib.sha256(encoded(payload)).hexdigest(),
            'source_bytes_authenticated_by_this_module': False,
            'metric_id': payload['metric_id'], 'population': payload['population'],
            'metric_definition_sha256': payload['metric_definition_sha256'],
            'endpoint_roster_sha256': payload['endpoint_roster_sha256'],
            'endpoint_rows': [indexed[k] for k in expected_keys()], 'contrasts': results,
            'notes': ['Six matched base-training pairs are the replication units; epoch20/40 and two rates are paired, not extra independent samples.',
                      'Epoch20 is nested in the same 40-epoch trajectory and learning-rate schedule.',
                      'Both student and adapters share the manipulated learning rate; their effects are not separately identified.',
                      'No winning rate, method, coefficient, equivalence or significance decision is selected.',
                      'Missing endpoint slots remain explicit; no imputation and no aggregate over a favorable subset.',
                      'Twelve base references and the original48 endpoint strength grid must additionally be preserved in the final report.',
                      'The caller must verify actual checkpoint/evaluation/roster and metric-definition bytes; identifiers and hashes here are references only.']}
