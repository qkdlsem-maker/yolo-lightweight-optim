"""Authenticate and assemble all fixed saved states on CPU, forbidding forwards."""
import copy,gc,hashlib,json,os,sys
from collections import OrderedDict
from pathlib import Path
from unittest.mock import patch
from study_runtime import PROJECT,HERE,source_check,read,publish,need,file_sha


def main(request_path,digest):
    need(file_sha(request_path)==digest,'CPU compatibility request bytes')
    request=read(request_path);source_check(request['manifest_sha256'])
    need(os.environ.get('CUDA_VISIBLE_DEVICES')=='','CPU compatibility device scope')
    import torch
    import gradient_objectives_compatible as objectives
    import gradient_probe_core as core
    need(Path(objectives.__file__).resolve()==HERE/'gradient_objectives_compatible.py','Explicit corrected import route')
    torch.set_num_threads(1)
    need(len(request['paths'])==36 and len({r['label'] for r in request['paths']})==36,'Fixed36 CPU assembly roster')
    positive=[];negative=[]
    for cls in (dict,OrderedDict):
        value=cls([('float',torch.ones(2,dtype=torch.float32)),('integer',torch.tensor([1],dtype=torch.int64))])
        if cls is OrderedDict:value._metadata=OrderedDict([('',{'version':1})])
        before=copy.deepcopy(value);identities=[id(x) for x in value.values()];metadata=getattr(value,'_metadata',None)
        objectives.raw_tensors(value)
        need(identities==[id(x) for x in value.values()] and all(torch.equal(value[k],v) for k,v in before.items()),'Container validation mutated values')
        need(getattr(value,'_metadata',None) is metadata,'Container metadata identity changed')
        positive.append(cls.__name__)
    class OtherMapping(dict):pass
    invalid={'empty_dict':{},'empty_ordered_dict':OrderedDict(),'mapping_subclass':OtherMapping(x=torch.ones(1)),
        'non_mapping':[torch.ones(1)],'non_string_key':{1:torch.ones(1)},'non_tensor':{'x':1},
        'float16':{'x':torch.ones(1,dtype=torch.float16)},'float64':{'x':torch.ones(1,dtype=torch.float64)},
        'nan':{'x':torch.tensor([float('nan')])},'inf':{'x':torch.tensor([float('inf')])}}
    for label,value in invalid.items():
        try:objectives.raw_tensors(value)
        except AssertionError:negative.append(label)
        else:raise RuntimeError('Invalid raw-state fixture accepted: '+label)
    reports=[]
    def no_forward(*args,**kwargs):raise AssertionError('Any model forward forbidden in CPU compatibility admission')
    for row in request['paths']:
        for name,digest in row['bound_files'].items():need(file_sha(PROJECT/name)==digest,'CPU input binding')
        raw=torch.load(PROJECT/row['raw_state'],map_location='cpu',weights_only=False)
        source=torch.load(PROJECT/row['source'],map_location='cpu',weights_only=False)
        teacher_source=torch.load(PROJECT/row['teacher'],map_location='cpu',weights_only=False)
        templates=[source.get('ema') or source['model'],teacher_source.get('ema') or teacher_source['model']]
        config=read(PROJECT/row['config'])
        need(config['arm']==row['arm'] and config['lr']==row['lr'] and config['seed']==row['pair_seed']+1000,'CPU path condition binding')
        before={key:{n:core.tensor_digest(t) for n,t in raw[key].items()} for key in ('student','adapters')}
        metadata={key:copy.deepcopy(getattr(raw[key],'_metadata',None)) for key in ('student','adapters')}
        identities={key:[id(t) for t in raw[key].values()] for key in ('student','adapters')}
        template_before=[core.model_evidence(m) for m in templates]
        with patch.object(torch.nn.Module,'_call_impl',no_forward):
            student,teacher,adapters,assembly=objectives.assemble(*templates,raw,config,'cpu')
        need(before=={key:{n:core.tensor_digest(t) for n,t in raw[key].items()} for key in ('student','adapters')},'CPU assembly changed raw tensors')
        need(metadata=={key:getattr(raw[key],'_metadata',None) for key in metadata},'CPU assembly changed raw metadata')
        need(identities=={key:[id(t) for t in raw[key].values()] for key in identities},'CPU assembly replaced original tensors')
        need(template_before==[core.model_evidence(m) for m in templates],'CPU assembly changed source templates')
        need(not torch.cuda.is_initialized(),'CPU compatibility initialized CUDA')
        for name,digest in row['bound_files'].items():need(file_sha(PROJECT/name)==digest,'CPU assembly altered saved input')
        reports.append(dict(label=row['label'],raw_state=row['raw_state'],raw_state_sha256=row['bound_files'][row['raw_state']],
            containers={key:dict(type=type(raw[key]).__name__,entries=len(raw[key]),metadata_preserved=True) for key in metadata},
            exact_state_load_passed=True,assembly=assembly,model_forwards=0))
        del raw,source,teacher_source,templates,student,teacher,adapters
        gc.collect()
    value=dict(status='all36_authenticated_CPU_assemblies_passed',paths=len(reports),reports=reports,
        positive_container_cases=positive,rejected_cases=negative,model_forwards=0,GPU_work=False,CUDA_initialized=False,
        raw_state_loads=36,model_template_loads=72,optimizer_steps=0,research_gradient_probes=0,
        corrected_objectives_sha256=file_sha(HERE/'gradient_objectives_compatible.py'),saved_inputs_unchanged=True)
    publish(PROJECT/request['output'],value)


if __name__=='__main__':main(Path(sys.argv[1]),sys.argv[2])
