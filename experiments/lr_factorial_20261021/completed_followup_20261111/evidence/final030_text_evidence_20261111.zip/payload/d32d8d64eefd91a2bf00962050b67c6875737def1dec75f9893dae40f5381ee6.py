"""Bounded retained journal segments for a full60-endpoint evaluation."""
import hashlib,threading
from pathlib import Path
from retained_io import Journal,publish,encode,read,read_journal


class SegmentedJournal:
    def __init__(self,path,max_bytes=128*1024*1024,max_events=300000):
        self.path=Path(path);self.part_bytes=min(max_bytes,32*1024*1024);self.part_events=min(max_events,50000)
        self.total_limit=1024*1024*1024;self.event_limit=2000000;self.total_bytes=0;self.total_events=0
        self.parts=[];self.current=None;self.lock=threading.RLock();self.closed=False
        self._open()
    def _open(self):
        path=self.path.with_name(self.path.name+'.part%04d'%len(self.parts))
        self.current=Journal(path,self.part_bytes,self.part_events)
        self.current.event('segment_begin',index=len(self.parts),previous=None if not self.parts else self.parts[-1])
    def _close_part(self):
        self.current.close();path=self.current.path
        raw=path.read_bytes();binding={'file':path.name,'sha256':hashlib.sha256(raw).hexdigest(),'bytes':len(raw),'events':self.current.count}
        self.total_bytes+=len(raw);self.total_events+=self.current.count;self.parts.append(binding);self.current=None
        if self.total_bytes>self.total_limit or self.total_events>self.event_limit:raise RuntimeError('Total monitor journal allowance')
    def event(self,kind,**value):
        with self.lock:
            if self.closed:raise RuntimeError('Closed segmented journal')
            allowance=len(encode({'kind':kind,'value':value}))+2048
            if self.current.count>=self.part_events-1 or self.current.size+allowance>self.part_bytes:
                self._close_part();self._open()
            if self.total_bytes+self.current.size+allowance>self.total_limit or self.total_events+self.current.count>=self.event_limit:raise RuntimeError('Total monitor journal allowance')
            self.current.event(kind,**value)
    def close(self):
        with self.lock:
            if self.closed:return
            self.closed=True
            if self.current is not None:self._close_part()
            publish(self.path.with_name(self.path.name+'.INDEX.json'),{'schema':'retained_segmented_journal_v1','parts':self.parts,
                'total_bytes':self.total_bytes,'total_events':self.total_events,'part_byte_limit':self.part_bytes,'part_event_limit':self.part_events,
                'total_byte_limit':self.total_limit,'total_event_limit':self.event_limit})


def verify(path):
    path=Path(path);index=read(path.with_name(path.name+'.INDEX.json'));previous=None;total=0;count=0;last=None
    for number,binding in enumerate(index['parts']):
        events,actual=read_journal(path.with_name(binding['file']),index['part_byte_limit'],index['part_event_limit'])
        assert actual['sha256']==binding['sha256'] and actual['bytes']==binding['bytes'] and len(events)==binding['events']
        assert events[0]['kind']=='segment_begin' and events[0]['value']=={'index':number,'previous':previous}
        previous=binding;total+=binding['bytes'];count+=len(events);last=events[-1]
    assert total==index['total_bytes']<=index['total_byte_limit'] and count==index['total_events']<=index['total_event_limit']
    assert sorted(p.name for p in path.parent.glob(path.name+'.part*'))==sorted(x['file'] for x in index['parts'])
    return index,last
