"""All36 prespecified final-state paths, two fixed training batches each."""
import copy,json,sys
from pathlib import Path
from study_runtime import Study,PROJECT,PHASE,HERE,source_check,publish,read,need,file_sha
from completed_training_bridge import reroute_checkpoint,PulsedFiles,merge
from continuation_artifact_receipts import loads


def run(ctx):
    f=PulsedFiles(PROJECT,ctx.check)
    accepted=loads(f.read(PHASE+'/factorial_training_acceptance.json'))
    archive=PHASE+'/prepared_history/gradient_path_roster_preparation_20261022_0636/'
    historical=loads(f.read(archive+'gradient_historical_raw_bindings_20261022_0636.json','25a28dcb77d25832cd2818192187e3ad22162a736fe159de04327558f2f8d3fe'))
    roster=loads(f.read(archive+'gradient_path_roster.json','1d217fea0e74b269101d56dcbc1efcf1acd67719966eadcec1ac3fc6af742b63'))
    bound=dict(accepted['bound_file_sha256']);merge(bound,historical['bound_sha256'])
    ready=loads(f.read(PHASE+'/GRADIENT_INPUTS_READY.json'))
    for name,digest in ready['bound_files'].items():
        relative=Path(name).relative_to(PROJECT).as_posix() if Path(name).is_absolute() else name
        merge(bound,{relative:digest})
    for name,digest in ready['native_source_sha256'].items():merge(bound,{Path(name).relative_to(PROJECT).as_posix():digest})
    batch_payload=loads(f.read(PHASE+'/gradient_probe/inputs/batches.json'))
    batches=batch_payload['batches']
    need(len(batches)==2 and ready['images']==64,'Fixed gradient batches')
    paths=[]
    for original in roster['paths']:
        row=copy.deepcopy(original)
        for key in ('raw_state','config','atomic_final_state'):
            if key in row:row[key]=reroute_checkpoint(row[key],row['label'])
        required={name:bound[name] for name in (row['raw_state'],row['config'],row['source'],row['teacher'])}
        for record in batches:
            name=Path(record['archive']).relative_to(PROJECT).as_posix();required[name]=record['archive_sha256'];need(bound[name]==required[name],'Fixed batch binding')
        f.verify(required);row['bound_files']=required;paths.append(row)
    need(len(paths)==36 and len({x['label'] for x in paths})==36,'Gradient fixed36 roster')
    root=PROJECT/PHASE/'gradient_probe/results';root.mkdir(parents=True,exist_ok=False)
    def task(row,mode,device):
        label='synthetic_correctness' if mode=='synthetic_correctness' else row['label']
        request=dict(mode=mode,manifest_sha256=ctx.expected,device=device,GPU_uuid=ctx.uuids[str(device)],path=row,
            bound_files=row['bound_files'],batches=batches,output=(root/label).relative_to(PROJECT).as_posix())
        request_path=ctx.folder/(label+'_request.json');publish(request_path,request)
        return {'endpoint_id':label,'device':device,'environment':{},'command':[sys.executable,'-B',str(HERE/'gradient_worker.py'),str(request_path),file_sha(request_path)]}
    def verify(task):
        output=root/task['endpoint_id'];complete=read(output/'COMPLETE.json')
        need(complete['saved_inputs_unchanged'],'Gradient input preservation')
        refs={(output/'COMPLETE.json').relative_to(PROJECT).as_posix():file_sha(output/'COMPLETE.json')}
        if task['endpoint_id']=='synthetic_correctness':
            need(complete['status']=='passed' and complete['actual_study_batch_probes']==0 and complete['synthetic_full32x640_cases']==3,'Gradient GPU admission fixture')
        else:
            need(complete['status']=='two_fixed_gradient_probes_recorded' and complete['actual_study_batch_probes']==2 and set(complete['batches'])=={'0','1'},'Gradient path completion')
            refs.update({(output/('batch'+index+'.json')).relative_to(PROJECT).as_posix():digest for index,digest in complete['batches'].items()})
        return refs
    ctx.stage(ctx.folder.relative_to(PROJECT)/'synthetic_stage','gradient_fixture',[task(paths[0],'synthetic_correctness',0)],verify,1800)
    bindings={}
    for start in range(0,36,2):
        tasks=[task(row,'fixed_two_batches',device) for device,row in enumerate(paths[start:start+2])]
        result=ctx.stage(ctx.folder.relative_to(PROJECT)/('pair_%02d'%(start//2+1)),'gradient_probe',tasks,verify,1800)
        for values in result['artifacts'].values():merge(bindings,values)
    f.verify(bindings)
    value=dict(status='all_fixed_gradient_probes_recorded',paths=36,batch_probes=72,synthetic_correctness_cases=3,
        bound_result_sha256=bindings,undefined_values_preserved=True,training_performed=False)
    publish(root/'COMPLETE.json',value);return value

if __name__=='__main__':
    expected=sys.argv[1];source_check(expected);Study('gradient',expected,6*3600,6).run(run)
