"""Same fresh bounded scanner; add only the fixed evaluators' atomic destinations."""
import json,re,sys
from pathlib import Path
OLD=Path('/home/futurenetworklab/choihyerim1129/yolo_lightweight_optim/review_20261021_lr_factorial_auxiliary026/remedy028_20261109_v3')
sys.path.insert(0,str(OLD))
import fresh_monitor as original
from segmented_journal import SegmentedJournal
ORIGINAL_TRANSIENT=original.transient_phase


def evaluation_transient(stderr,root,endpoint_ids,metric_ids):
    if ORIGINAL_TRANSIENT(stderr,root): return True
    prefix=str(Path(root))+'/'
    lines=stderr.splitlines()
    if not lines: return False
    for line in lines:
        match=re.fullmatch(r"du: cannot access '([^']+)': No such file or directory",line)
        if match is None or not match[1].startswith(prefix): return False
        path=match[1][len(prefix):]
        if any(p in ('','..','.') for p in path.split('/')): return False
        parts=path.split('/')
        if len(parts)>=4 and parts[:2]==['factorial_evaluation','endpoints'] and parts[2] in endpoint_ids:
            tail='/'.join(parts[3:])
            if re.fullmatch(r'(?:bdd|kitti)_predictions/staging/[0-9]{6}-[0-9a-f]{32}(?:/(?:COMMIT|[0-9]{8})\.json)?',tail): continue
            if re.fullmatch(r'(?:native_bdd|bdd_common|kitti_common|kitti_native)\.partial-[0-9a-f]{32}(?:/[A-Za-z0-9_.-]+)*',tail): continue
        if len(parts)>=3 and parts[:2]==['metric_decomposition','endpoints']:
            match=re.fullmatch(r'(.+)\.partial-[0-9a-f]{32}',parts[2])
            if match and match[1] in metric_ids and (len(parts)==3 or len(parts)==4 and parts[3] in ('MANIFEST.json','COMPLETE.json','factorial.json')): continue
        return False
    return True


def main():
    locations=json.loads((Path.cwd()/'review_20261021_lr_factorial/factorial_endpoint_location_plan.json').read_bytes())
    endpoints={r['endpoint_id'] for r in locations['endpoints'] if r['action']=='new_evaluation_after_admission'}
    metrics=set(locations['metric_decomposition_final_endpoint_ids'])
    assert len(endpoints)==60 and len(metrics)==48
    original.transient_phase=lambda stderr,root:evaluation_transient(stderr,root,endpoints,metrics)
    original.Journal=SegmentedJournal
    original.main()

if __name__=='__main__': main()
