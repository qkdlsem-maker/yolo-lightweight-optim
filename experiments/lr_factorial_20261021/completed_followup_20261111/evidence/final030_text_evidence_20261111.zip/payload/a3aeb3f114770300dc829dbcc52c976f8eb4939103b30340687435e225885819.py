"""Preserve interrupted-run evidence in an independent immutable byte copy.

No cause inference, latch clearing, state repair, RNG restoration or process
launch. A complete capsule is evidence preservation only, never retry approval.
Partial captures remain in place and cannot be accepted as complete captures.
"""
import argparse
import hashlib
import math
import os
from pathlib import Path,PurePosixPath
import shutil
import subprocess
import time
import uuid
from continuation_artifact_receipts import ROOT,PROTOCOL_SHA,Context,Files,encoded,loads,valid_sha,digest
from continuation_execution_runtime import job_for_label,PREFIX,evidence_paths
from continuation_preflight_runtime import read_records,process_command
from validation_journal import publish_immutable,sync_directory

SELF=ROOT/'continuation_recovery_capsule.py'
CAPSULES=ROOT/'recovery_capsules'
METADATA_RESERVE=8*1024**2
CHUNK=1024**2


def merge(target,other):
    for key,value in other.items():
        valid_sha(value)
        if key in target:assert target[key]==value, 'Conflicting evidence hashes'
        target[key]=value


def run_inventory(files,job):
    folder=files.path(job['run_directory']);assert folder.is_dir()
    result={}
    for path in sorted(folder.rglob('*')):
        name=path.relative_to(files.project).as_posix();files.path(name)
        if path.is_file():result[name]=files.sha(name)
        else:assert path.is_dir()
    return result


def check_incident(value,files,label):
    assert value.keys()=={'schema','protocol_sha256','label','classification','summary','evidence_sha256'}
    assert value['schema']=='continuation_incident_record_v1' and value['protocol_sha256']==PROTOCOL_SHA
    assert value['label']==label
    assert value['classification'] in ('unclassified','technical_interruption','scientific_failure','budget_stop')
    assert type(value['summary']) is str and 1<=len(value['summary'].strip())<=16000
    assert type(value['evidence_sha256']) is dict and value['evidence_sha256']
    for name,h in value['evidence_sha256'].items():
        assert PurePosixPath(name).is_relative_to(ROOT);files.path(name);valid_sha(h)
    files.verify(value['evidence_sha256'])
    # This is an investigator's attribution, not a mechanically established
    # reason. Even technical_interruption does not admit a retry.
    return value


def build_plan(files,job,report,incident,history):
    assert report['schema']=='continuation_saved_state_inspection_v1'
    assert report['status']=='saved_state_checked_not_recovery_authorization'
    assert report['label']==job['label'] and report['protocol_sha256']==PROTOCOL_SHA
    check_incident(incident,files,job['label'])
    assert type(history) is dict and history
    inventory=run_inventory(files,job)
    assert inventory==report['entire_interrupted_run_inventory_sha256']
    assert (PurePosixPath(job['run_directory'])/'training_state.pt').as_posix() in inventory
    for name in ('COMPLETE.json','SMOKE_COMPLETE.json'):
        assert not files.path(job['run_directory']+'/'+name).exists(), 'Completed paths are reuse-only'
    bindings={};merge(bindings,report['bound_input_sha256']);merge(bindings,inventory)
    merge(bindings,history);merge(bindings,incident['evidence_sha256'])
    files.verify(bindings)
    copies={};merge(copies,inventory);merge(copies,history);merge(copies,incident['evidence_sha256'])
    for name in copies:assert PurePosixPath(name).is_relative_to(ROOT)
    rows=[{'path':n,'sha256':h,'bytes':files.path(n).stat().st_size} for n,h in sorted(copies.items())]
    return {'schema':'continuation_recovery_capsule_plan_v1','protocol_sha256':PROTOCOL_SHA,
        'label':job['label'],'run_directory':job['run_directory'],'files':rows,
        'bound_original_sha256':dict(sorted(bindings.items())),
        'run_inventory_sha256':inventory,'inspection':report,'incident':incident,
        'classification_is_investigator_attribution_not_machine_verified':True,
        'scope':'Preservation only. No state repair, condition change, latch clearing or resume authorization.'}


def storage_guard(files,remaining):
    assert type(remaining) is int and remaining>=0
    size=int(subprocess.check_output(['du','-s','-B1',str(files.path(ROOT.as_posix()))],text=True).split()[0])
    free=shutil.disk_usage(files.project).free
    if size+remaining>=200*2**30 or free-remaining<150*2**30:
        raise RuntimeError('Recovery evidence copy would exceed frozen disk limits')
    return {'phase_bytes':size,'free_bytes':free,'reserved_remaining_bytes':remaining}


def write_capsule(files,plan,storage=storage_guard):
    """Internal file-copy seam; public capture supplies authenticated evidence."""
    assert plan['schema']=='continuation_recovery_capsule_plan_v1' and plan['protocol_sha256']==PROTOCOL_SHA
    rows=plan['files'];names=[r['path'] for r in rows];assert names==sorted(set(names)) and rows
    for row in rows:
        assert row.keys()=={'path','sha256','bytes'} and type(row['bytes']) is int and row['bytes']>=0
        assert PurePosixPath(row['path']).is_relative_to(ROOT);valid_sha(row['sha256']);files.path(row['path'])
        assert plan['bound_original_sha256'][row['path']]==row['sha256']
    files.verify(plan['bound_original_sha256'])
    assert run_inventory(files,plan)==plan['run_inventory_sha256']
    for n in ('COMPLETE.json','SMOKE_COMPLETE.json'):assert not files.path(plan['run_directory']+'/'+n).exists()
    raw_plan=encoded(plan);assert len(raw_plan)<METADATA_RESERVE//2
    remaining=sum(((r['bytes']+4095)//4096)*4096 for r in rows)+METADATA_RESERVE
    before=storage(files,remaining)
    name=(CAPSULES/(time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'_'+uuid.uuid4().hex)).as_posix()
    folder=files.path(name);folder.parent.mkdir(parents=True,exist_ok=True);folder.mkdir(exist_ok=False)
    started={'schema':'continuation_recovery_capture_started_v1','plan_sha256':digest(raw_plan),
        'created_unix':time.time(),'label':plan['label'],'resources_before_copy':before}
    publish_immutable(folder/'CAPTURE_STARTED.json',encoded(started));publish_immutable(folder/'plan.json',raw_plan)
    try:
        copied={};sizes={}
        for row in rows:
            storage(files,remaining)
            source=files.path(row['path']);target=files.path(name+'/original/'+row['path'])
            target.parent.mkdir(parents=True,exist_ok=True);h=hashlib.sha256();count=0
            with source.open('rb') as src,target.open('xb') as dst:
                for chunk in iter(lambda:src.read(CHUNK),b''):
                    assert count+len(chunk)<=row['bytes'], 'Original file grew during copy'
                    dst.write(chunk);h.update(chunk);count+=len(chunk)
                    if count%(64*CHUNK)==0:storage(files,max(METADATA_RESERVE,remaining-count))
                dst.flush();os.fsync(dst.fileno())
            assert count==row['bytes'] and h.hexdigest()==row['sha256'], 'Original changed during copy'
            copy_name=target.relative_to(files.project).as_posix()
            assert files.sha(copy_name)==row['sha256']
            assert not os.path.samefile(source,target), 'Capsule must not be a hard link'
            copied[row['path']]=row['sha256'];sizes[row['path']]=count
            remaining-=((row['bytes']+4095)//4096)*4096
            sync_directory(target.parent)
        files.verify(plan['bound_original_sha256'])
        assert run_inventory(files,plan)==plan['run_inventory_sha256'], 'Run changed during preservation'
        after=storage(files,METADATA_RESERVE)
        result={'schema':'continuation_recovery_capsule_complete_v1',
            'status':'preserved_only_not_resume_authorization','protocol_sha256':PROTOCOL_SHA,
            'label':plan['label'],'plan_sha256':digest(raw_plan),
            'started_sha256':files.sha(name+'/CAPTURE_STARTED.json'),
            'copied_file_sha256':copied,'copied_file_bytes':sizes,'completed_unix':time.time(),
            'resources_after_copy':after,'originals_unchanged_at_capture':True,
            'independent_byte_copies':True,'resume_authorized':False}
        publish_immutable(folder/'CAPTURE_COMPLETE.json',encoded(result));sync_directory(folder)
        verify_capsule(files,name)
        return {'capsule':name,'complete_sha256':files.sha(name+'/CAPTURE_COMPLETE.json'),
                'status':result['status'],'resume_authorized':False}
    except BaseException as error:
        # Retain partial bytes and all originals; never remove a failed capture.
        if not (folder/'CAPTURE_COMPLETE.json').exists():
            publish_immutable(folder/'CAPTURE_FAILURE.json',encoded({'error':repr(error),'created_unix':time.time(),
                'partial_files_retained':True,'resume_authorized':False}))
        raise


def verify_capsule(files,name):
    path=PurePosixPath(name);assert path.parent==CAPSULES
    folder=files.path(name);assert folder.is_dir() and not (folder/'CAPTURE_FAILURE.json').exists()
    complete=loads(files.read(name+'/CAPTURE_COMPLETE.json'))
    assert complete['schema']=='continuation_recovery_capsule_complete_v1'
    assert complete['status']=='preserved_only_not_resume_authorization' and complete['resume_authorized'] is False
    assert complete['protocol_sha256']==PROTOCOL_SHA
    assert complete['originals_unchanged_at_capture'] is True and complete['independent_byte_copies'] is True
    raw=files.read(name+'/plan.json',complete['plan_sha256']);plan=loads(raw)
    assert plan['label']==complete['label'] and plan['protocol_sha256']==PROTOCOL_SHA
    start=loads(files.read(name+'/CAPTURE_STARTED.json',complete['started_sha256']))
    assert start['plan_sha256']==digest(raw) and start['label']==plan['label']
    expected={r['path']:r['sha256'] for r in plan['files']};sizes={r['path']:r['bytes'] for r in plan['files']}
    assert len(expected)==len(plan['files']) and complete['copied_file_sha256']==expected
    assert complete['copied_file_bytes']==sizes
    actual={p.relative_to(folder/'original').as_posix() for p in (folder/'original').rglob('*') if p.is_file()}
    assert actual==set(expected)
    for n,h in expected.items():
        copy=files.path(name+'/original/'+n);assert copy.stat().st_size==sizes[n]
        assert copy.stat().st_nlink==1, 'Preserved payload must remain an independent copy'
        assert files.sha(name+'/original/'+n)==h
    assert {p.name for p in folder.iterdir()}=={'original','plan.json','CAPTURE_STARTED.json','CAPTURE_COMPLETE.json'}
    return complete


def collect_history(context,job):
    """Preserve related registered attempts, parents, logs and all stop causes."""
    f=context.files;records=read_records(f);label=job['label']
    selected={n:r for n,r in records.items() if r.get('label')==PREFIX+label or label in r.get('command',[])}
    assert selected
    parents={r['parent_pid'] for r in selected.values() if 'parent_pid' in r}
    selected.update({n:r for n,r in records.items() if r.get('pid') in parents})
    history={};unclosed=[]
    for name,row in selected.items():
        if 'pid' in row:assert process_command(row['pid']) is None, 'Related process still running'
        history[name]=f.sha(name)
        if 'ended_unix' not in row:unclosed.append(name)  # preserve; never invent a close time
        for key in ('log','stdout_artifact'):
            if key in row and f.path(row[key]).is_file():history[row[key]]=f.sha(row[key])
    for name in ('CONTINUATION_FAILURE.json','BUDGET_STOP.json','continuation_launch.json'):
        n=(ROOT/name).as_posix()
        if f.path(n).is_file():history[n]=f.sha(n)
    for path in sorted(f.path((ROOT/'production_failures').as_posix()).glob('*.json')):
        n=path.relative_to(f.project).as_posix();history[n]=f.sha(n)
    folder=f.path(PurePosixPath(evidence_paths(label)['admission']).parent)
    for path in sorted(folder.rglob('*')):
        n=path.relative_to(f.project).as_posix();f.path(n)
        if path.is_file():history[n]=f.sha(n)
    return history,unclosed


def capture(project,label,incident_name):
    assert os.environ.get('CUDA_VISIBLE_DEVICES')==''
    context=Context(project);f=context.files
    assert Path(__file__).resolve()==f.path(SELF.as_posix()).resolve()
    import continuation_recovery_audit as inspector
    import fcntl
    manifest=loads(f.read(inspector.MANIFEST.as_posix()))
    source_map={r['name']:r['sha256'] for r in manifest['files']}
    assert source_map[SELF.name]==f.sha(SELF.as_posix())
    assert Path(inspector.__file__).resolve()==f.path(inspector.SELF.as_posix()).resolve()
    job,_=job_for_label(context,label)
    assert PurePosixPath(incident_name).parent==ROOT/'recovery_investigations'
    incident_sha=f.sha(incident_name);incident=loads(f.read(incident_name,incident_sha))
    check_incident(incident,f,label)
    lock_path=f.path((ROOT/'recovery_capture.lock').as_posix())
    with lock_path.open('a') as capture_lock,f.path(job['run_directory']+'.lock').open('rb') as run_lock:
        fcntl.flock(capture_lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
        fcntl.flock(run_lock,fcntl.LOCK_SH|fcntl.LOCK_NB)
        # Inspector acquires another shared lock; the outer lock remains held
        # until all bytes have been independently copied and checked.
        report=inspector.inspect(project,label)
        history,unclosed=collect_history(context,job);history[incident_name]=incident_sha
        report['unclosed_registered_attempts_preserved_not_resolved']=unclosed
        plan=build_plan(f,job,report,incident,history)
        return write_capsule(f,plan)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--label',required=True)
    parser.add_argument('--incident',required=True);args=parser.parse_args()
    print(encoded(capture(Path.cwd(),args.label,args.incident)).decode(),end='')


if __name__=='__main__':main()
