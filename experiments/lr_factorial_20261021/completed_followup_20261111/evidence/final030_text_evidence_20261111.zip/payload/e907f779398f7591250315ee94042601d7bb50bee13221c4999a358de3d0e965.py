"""Fixed32 FP32 probes, with no optimizer or modification of saved states."""
import copy,json,os,sys
from pathlib import Path
from study_runtime import PROJECT,PHASE,HERE,source_check,publish,read,need,file_sha


def main(request_path,request_sha):
    need(file_sha(request_path)==request_sha,'Gradient request bytes')
    request=read(request_path);source_check(request['manifest_sha256'])
    need(os.environ.get('CUDA_VISIBLE_DEVICES')==str(request['device']),'Gradient physical device')
    for name,digest in request['bound_files'].items():need(file_sha(PROJECT/name)==digest,'Gradient input changed: '+name)
    output=PROJECT/request['output'];output.mkdir(parents=True,exist_ok=False)
    import torch
    import gradient_objectives_compatible as objectives
    import gradient_probe_core as core
    from gradient_input_loader import load_batch
    torch.set_num_threads(2);torch.manual_seed(20261021)
    torch.use_deterministic_algorithms(True,warn_only=True)
    torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
    torch.backends.cuda.matmul.allow_tf32=False;torch.backends.cudnn.allow_tf32=False
    device=torch.device('cuda:0');torch.cuda.set_device(device)
    uuid=str(torch.cuda.get_device_properties(device).uuid)
    need(uuid.removeprefix('GPU-')==request['GPU_uuid'].removeprefix('GPU-'),'Gradient GPU UUID')
    path=request['path'];config=read(PROJECT/path['config'])
    need(config['arm']==path['arm'] and config['lr']==path['lr'] and config['epochs']==40 and config['seed']==path['pair_seed']+1000,'Fixed gradient path conditions')
    raw=torch.load(PROJECT/path['raw_state'],map_location='cpu',weights_only=False)
    student_checkpoint=torch.load(PROJECT/path['source'],map_location='cpu',weights_only=False)
    teacher_checkpoint=torch.load(PROJECT/path['teacher'],map_location='cpu',weights_only=False)
    student_template=student_checkpoint.get('ema') or student_checkpoint['model']
    teacher_template=teacher_checkpoint.get('ema') or teacher_checkpoint['model']
    raw_before={key:{name:core.tensor_digest(tensor) for name,tensor in raw[key].items()} for key in ('student','adapters')}
    templates_before=[core.model_evidence(m) for m in (student_template,teacher_template)]
    def assemble(arm):
        cfg=copy.deepcopy(config);cfg['arm']=arm;cfg['kd_weight']=0. if arm=='control' else .3
        return objectives.assemble(student_template,teacher_template,raw,cfg,device)
    reports={}
    if request['mode']=='synthetic_correctness':
        # Fixed synthetic pixels/boxes; no validation/test image or result-based input choice.
        image=torch.arange(640,dtype=torch.float32,device=device).div(639).view(1,1,1,640).expand(32,3,640,640).contiguous()
        batch={'img':image,'cls':(torch.arange(32,device=device)%10).float().view(-1,1),
            'batch_idx':torch.arange(32,dtype=torch.float32,device=device),'bboxes':torch.tensor([.5,.5,.25,.25],device=device).repeat(32,1)}
        for arm in ('control','mse','cwd'):
            student,teacher,adapters,assembly=assemble(arm)
            report=objectives.diagnose_batch(student,teacher,adapters,batch,arm)
            need(report['status']=='computed' and report['teacher_no_grad'] and report['model_state_unchanged'],'Full640 GPU correctness fixture')
            need(report['objective_trace']['student_forwards']==1 and report['objective_trace']['teacher_forwards']==(0 if arm=='control' else 1),'Fixed forward trace')
            if arm=='control':need(report['groups']['all_student']['weighted_feature']['norm']==0 and report['feature_loss']==0,'Control gradient zero')
            reports[arm]=report
            del student,teacher,adapters;torch.cuda.empty_cache()
        value=dict(status='passed',mode=request['mode'],synthetic_full32x640_cases=3,actual_study_batch_probes=0,reports=reports)
    else:
        need(request['mode']=='fixed_two_batches' and path['batches']==[0,1],'Exactly two fixed batches')
        student,teacher,adapters,assembly=assemble(path['arm'])
        for index,record in enumerate(request['batches']):
            batch={key:value.to(device) for key,value in load_batch(record).items()}
            report=objectives.diagnose_batch(student,teacher,adapters,batch,path['arm'])
            need(report['model_state_unchanged'] and report['teacher_no_grad'] and report['input_tensors_unchanged'],'Gradient mutated fixed state/input')
            need(report['status'] in ('computed','nonfinite_objective','nonfinite_gradient'),'Undefined outcomes must remain explicit')
            report.update(label=path['label'],pair_seed=path['pair_seed'],learning_rate=path['lr'],batch_index=index,
                raw_state={'path':path['raw_state'],'sha256':request['bound_files'][path['raw_state']]},assembly=assembly)
            publish(output/('batch'+str(index)+'.json'),report);reports[str(index)]=file_sha(output/('batch'+str(index)+'.json'))
            del batch
        value=dict(status='two_fixed_gradient_probes_recorded',mode=request['mode'],label=path['label'],batches=reports,actual_study_batch_probes=2)
    need(raw_before=={key:{name:core.tensor_digest(tensor) for name,tensor in raw[key].items()} for key in ('student','adapters')},'Raw CPU tensors changed')
    need(templates_before==[core.model_evidence(m) for m in (student_template,teacher_template)],'Source templates changed')
    for name,digest in request['bound_files'].items():need(file_sha(PROJECT/name)==digest,'Saved gradient input changed during probe')
    value.update(request_sha256=request_sha,GPU_uuid=uuid,precision='FP32; TF32 disabled; no autocast/scaler/optimizer',saved_inputs_unchanged=True)
    publish(output/'COMPLETE.json',value)

if __name__=='__main__':main(Path(sys.argv[1]),sys.argv[2])
