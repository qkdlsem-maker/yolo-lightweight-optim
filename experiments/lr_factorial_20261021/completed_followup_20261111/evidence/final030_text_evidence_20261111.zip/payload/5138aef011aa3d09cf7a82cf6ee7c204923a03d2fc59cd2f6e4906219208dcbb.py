"""Targeted actual-filesystem admission; previous15 native cases remain bound."""
import os,resource,sys
from pathlib import Path
from study_runtime import Study,PROJECT,PHASE,HERE,source_check,read,publish,need,file_sha,identity,consume_previous_CPU
from metrics_run import create_output_tree as metric_tree
from analysis_run import create_output_tree as analysis_tree
from evaluation_monitor import evaluation_transient

CASES=('previous15_native_and36_raw_state_assemblies_retained','real_atomic_nested_metric_and_contrast_publication',
    'existing_destination_and_publication_preserved','fixed_metric_v7_atomic_path_matcher','completed_evaluation_and_gradient_not_dispatched_failure_latched')


def run(ctx):
    cases=[]
    previous=consume_previous_CPU(ctx.expected);publish(ctx.folder/'PREVIOUS_CPU_ADMISSION.json',previous);cases.append(CASES[0])
    roots={'metric':ctx.folder/'metric_publication_fixture','analysis':ctx.folder/'analysis_publication_fixture'}
    metric_tree(roots['metric']);analysis_tree(roots['analysis'])
    locations=read(PROJECT/PHASE/'factorial_endpoint_location_plan.json');endpoints=locations['metric_decomposition_final_endpoint_ids']
    need(len(endpoints)==48,'Fixed48 metric fixture destinations')
    paths=[]
    for eid in endpoints:
        path=roots['metric']/'requests'/(eid+'.json');value={'fixture_only':True,'endpoint_id':eid,'scoring_performed':False}
        publish(path,value);need(read(path)==value,'Actual metric request publication readback');paths.append(path)
    for index in range(18):
        path=roots['analysis']/'contrasts'/('metric_fixture_'+str(index)+'.json');value={'fixture_only':True,'index':index,'research_analysis_performed':False}
        publish(path,value);need(read(path)==value,'Actual nested contrast publication readback');paths.append(path)
    need((roots['metric']/'endpoints').is_dir(),'Metric scorer output parent');cases.append(CASES[1])
    before={p:file_sha(p) for p in paths}
    for function,root in ((metric_tree,roots['metric']),(analysis_tree,roots['analysis'])):
        try:function(root)
        except FileExistsError:pass
        else:raise RuntimeError('Existing output tree accepted')
    try:publish(paths[0],{'must_not_replace':True})
    except FileExistsError:pass
    else:raise RuntimeError('Existing publication replaced')
    need(before=={p:file_sha(p) for p in paths},'Existing published bytes changed');cases.append(CASES[2])
    eids={r['endpoint_id'] for r in locations['endpoints'] if r['action']=='new_evaluation_after_admission'};mids=set(endpoints)
    path='metric_decomposition_v7/endpoints/'+endpoints[0]+'.partial-'+('a'*32)+'/factorial.json'
    def line(value):return "du: cannot access '"+str(PROJECT/PHASE/value)+"': No such file or directory"
    need(evaluation_transient(line(path),PROJECT/PHASE,eids,mids),'New fixed metric atomic output rejected')
    for invalid in (path.replace(endpoints[0],'unplanned'),path.replace('factorial.json','other.bin'),path+'/../file'):
        need(not evaluation_transient(line(invalid),PROJECT/PHASE,eids,mids),'Unplanned transient accepted')
    cases.append(CASES[3])
    output=ctx.folder/'control_fixture'
    task={'endpoint_id':'control','device':None,'environment':{},'command':[sys.executable,'-B',str(HERE/'test_dispatch_control.py'),str(output)]}
    def verified(item):
        result=read(output/'COMPLETE.json')
        need(result['status']=='dispatch_control_test_passed' and result['scientific_children_spawned']==0 and result['model_loads']==0 and result['GPU_work'] is False,'New dispatcher fixture')
        return {(output/'COMPLETE.json').relative_to(PROJECT).as_posix():file_sha(output/'COMPLETE.json')}
    ctx.stage(ctx.folder.relative_to(PROJECT)/'control_stage','filesystem_continuation_control',[task],verified,120)
    cases.append(CASES[4])
    need(tuple(cases)==CASES and 'torch' not in sys.modules,'Targeted CPU-only admission scope')
    result=dict(status='all_native_operational_cases_passed',case_count=5,cases=cases,parent_model_loads=0,model_forwards=0,GPU_work=False,
        expected_failure_rows={},retained_previous_CPU=previous,actual_native_publications=66,old_published_bytes_preserved=True,
        scientific_scorers_run=0,existing_completed_gradients_and_evaluations_reexecuted=False)
    publish(ctx.folder/'CPU_RESULT.json',result);return result


if __name__=='__main__':
    expected=sys.argv[1];source_check(expected)
    affinity=sorted(os.sched_getaffinity(0));need(len(affinity)>=4,'Four CPU cores');os.sched_setaffinity(0,set(affinity[:4]))
    resource.setrlimit(resource.RLIMIT_CPU,(540,600));resource.setrlimit(resource.RLIMIT_FSIZE,(16*1024*1024,16*1024*1024))
    Study('CPU_integration',expected,600,0,validation=True,CPU_hours_limit=1/6).run(run)
