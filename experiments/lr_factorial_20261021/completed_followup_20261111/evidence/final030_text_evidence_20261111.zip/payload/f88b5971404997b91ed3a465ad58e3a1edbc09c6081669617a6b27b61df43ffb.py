"""Bounded disk sampling for atomic temporary-file disappearance.

Never accept partial du stdout or reuse an older disk measurement. Only the
observed ENOENT class for a continuation's known atomic temporary filename may
receive a fresh scan (three attempts total). All other errors fail closed.
Existing accounting, limits and the independent budget guard remain unchanged.
"""
import json, os, re, shutil, subprocess, time, uuid
from pathlib import Path
from continuation_artifact_receipts import ROOT
from continuation_preflight_runtime import account, read_records

MAX_SCANS = 3
SCAN_TIMEOUT_SECONDS = 5


def transient_missing_tmp(stderr, root):
    prefix = re.escape(str(root / 'continuations'))
    pattern = (r"du: cannot access '" + prefix +
        r"/pair[0-9]+_(?:control|mse|cwd)_w[0-9.]+_lr[0-9.]+/"
        r"(?:control|mse|cwd)_seed[0-9]+_e40/"
        r"(?:epoch_[0-9]+(?:_steps)?\.json|training_state\.pt)\.tmp': No such file or directory")
    lines = stderr.splitlines()
    return bool(lines) and all(re.fullmatch(pattern, line) for line in lines)


def scan_once(root):
    env = os.environ.copy(); env['LC_ALL'] = 'C'
    return subprocess.run(['du', '-s', '-B1', str(root)], text=True,
        stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env,
        timeout=SCAN_TIMEOUT_SECONDS, check=False)


def disk_bytes(root, record):
    root = Path(root)
    for attempt in range(1, MAX_SCANS + 1):
        try:
            result = scan_once(root)
        except BaseException as error:
            record({'scan': attempt, 'error': repr(error), 'fresh_retry': False})
            raise
        if result.returncode == 0 and not result.stderr:
            fields = result.stdout.rstrip('\n').split('\t')
            if len(fields) == 2 and fields[0].isdigit() and fields[1] == str(root):
                return int(fields[0])
            record({'scan': attempt, 'error': 'malformed_success_output',
                    'stdout': result.stdout, 'fresh_retry': False})
            raise RuntimeError('Invalid successful disk measurement')
        retry = (result.returncode == 1 and
                 transient_missing_tmp(result.stderr, root) and attempt < MAX_SCANS)
        record({'scan': attempt, 'returncode': result.returncode,
                'stdout_discarded': result.stdout, 'stderr': result.stderr,
                'fresh_retry': bool(retry)})
        if not retry:
            raise RuntimeError('Disk measurement failed closed: ' + result.stderr)
        time.sleep(.02)
    raise AssertionError('Unreachable bounded scan loop')


def resources(files):
    def record(value):
        folder = files.path(str(ROOT / 'resource_scan_incidents'))
        folder.mkdir(exist_ok=True)
        value = dict(value, unix=time.time(), pid=os.getpid(),
                     status='disk_measurement_only_no_experiment_retry')
        # Exclusive final filename: this diagnostic itself creates no rename race.
        with (folder / (uuid.uuid4().hex + '.json')).open('x', encoding='utf-8') as stream:
            json.dump(value, stream, sort_keys=True, indent=2)
            stream.flush(); os.fsync(stream.fileno())
    size = disk_bytes(files.path(str(ROOT)), record)
    # Read allocations after the possibly repeated scan, not before it.
    rows = read_records(files)
    return rows, account(rows, time.time(), size, shutil.disk_usage(files.project).free)
