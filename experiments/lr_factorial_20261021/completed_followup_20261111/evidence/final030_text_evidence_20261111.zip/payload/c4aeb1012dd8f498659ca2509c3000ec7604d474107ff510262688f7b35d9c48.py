"""CPU file authentication for one same-state, two-worker incident020 recovery."""
from pathlib import Path
from continuation_artifact_receipts import ROOT, PROTOCOL_SHA, Context, loads
from continuation_execution_runtime import job_for_label, arguments, source_bindings, untouched_destination
from continuation_preflight_runtime import no_latches, check_limits, process_command, verify_completed_bases
from continuation_production_gate import verify_gate
from continuation_recovery_capsule import verify_capsule, run_inventory
from continuation_wave_evidence import audit_report, closed_attempt
from incident020_resources import resources
import continuation_wave_evidence as original
import incident018_resume as historical

HERE = ROOT/'incident020_recovery'
REVIEW = ROOT/'recovery_investigations/020_review.json'
MANIFEST = ROOT/'incident020_sources.json'
LABELS = ('pair404_mse_w0.3_lr0.0001', 'pair404_cwd_w0.3_lr0.0001')
CAPSULE_HASHES = ('3fa66c0f7c0ed73586177f17ffaeba390dd3304a4dde1d969d599f9f3d1e1da7',
                  'b062d1970b4bdb189c045f708d0f9cb9d26a725a57ea04e3ae20f2d12d7a236c')
guard = historical.guard


def sources(files):
    value = loads(files.read(str(MANIFEST)))
    assert value['schema'] == 'incident020_sources_v1' and value['protocol_sha256'] == PROTOCOL_SHA
    bindings = {str(ROOT/r['name']):r['sha256'] for r in value['files']}
    required = {'incident020_runner.py','incident020_evidence.py','incident020_resources.py',
                'test_incident020_processes.py','test_incident020_resources.py',
                'incident020_CPU.json','recovery_investigations/020_review.json'}
    assert {str(ROOT/n) for n in required} <= bindings.keys() and len(bindings) == len(value['files'])
    files.verify(bindings)
    proof = loads(files.read(str(ROOT/'incident020_CPU.json')))
    assert proof['status'] == 'passed' and proof['processes']['real_subprocess_cases'] >= 13
    assert proof['resources']['status'] == 'passed' and proof['resources']['real_du_race_observed'] is True
    for n,h in proof['tested_sources_sha256'].items(): assert bindings[str(ROOT/n)] == h
    bindings[str(MANIFEST)] = files.sha(str(MANIFEST))
    return bindings


def failure_set(files):
    result = historical.failure_set(files)
    for p in [files.path(str(ROOT/'continuation_waves/FAILURE.json'))] + sorted(files.path(str(ROOT/'continuation_waves/failures')).glob('*.json')):
        n = p.relative_to(files.project).as_posix(); result[n] = files.sha(n)
    return result


def latches(files, review):
    no_latches(files)
    assert failure_set(files) == review['known_failure_sha256'], 'New or altered failure evidence'
    for n in (HERE/'FAILURE.json', historical.HERE/'FAILURE.json',
              ROOT/'CONTINUATION_TRAINING_COMPLETE.json', ROOT/'continuation_waves/TRAINING_RECEIPTS_COMPLETE.json'):
        assert not files.path(str(n)).exists(), str(n)


def plan_for(context):
    old,design = original.plan_for(context)
    wave = old['waves'][4]
    assert wave['wave'] == 5 and tuple(i['label'] for i in wave['jobs']) == LABELS
    jobs = [dict(i,args=dict(i['args'],resume=True)) for i in wave['jobs']]
    assert [i['device'] for i in jobs] == [0,1]
    return {'waves':[{'wave':5,'jobs':jobs}]},design


def capsule(files, label):
    review = loads(files.read(str(REVIEW))); index = LABELS.index(label)
    row = review['jobs'][label]; name = row['capsule']
    assert row['capsule_complete_sha256'] == CAPSULE_HASHES[index] == files.sha(name+'/CAPTURE_COMPLETE.json')
    complete = verify_capsule(files,name)
    plan = loads(files.read(name+'/plan.json',complete['plan_sha256']))
    inspection = plan['inspection']; epoch = (35,33)[index]
    assert plan['label'] == label and inspection['label'] == label
    assert inspection['status'] == 'saved_state_checked_not_recovery_authorization'
    assert inspection['committed_epoch'] == epoch and inspection['next_training_epoch'] == epoch+1
    assert inspection['remaining_training_epochs'] == 40-epoch
    assert inspection['actual_step_counts'] == ({'attempted':38220,'applied':38209,'skipped':11},
                                               {'attempted':36036,'applied':36027,'skipped':9})[index]
    assert inspection['unclosed_registered_attempts_preserved_not_resolved'] == []
    assert inspection['missing_latest_raw_sidecar_reconstructible_from_atomic_state'] == []
    return row,plan,complete


def resume_destination(context, job):
    f=context.files; row,plan,_=capsule(f,job['label'])
    assert job['run_directory'] == plan['run_directory']
    assert not f.path(job['run_directory']+'/COMPLETE.json').exists()
    assert run_inventory(f,job) == plan['run_inventory_sha256'], 'Original interrupted run changed'


def preserved_prior(files, label):
    row,plan,complete=capsule(files,label)
    prefix=plan['run_directory']+'/'
    # Only the mutable atomic state and the directly observed uncommitted
    # MSE epoch36 tail may change. Their independent capsule copies remain bound.
    excluded={prefix+'training_state.pt'}
    if label==LABELS[0]: excluded.update(prefix+n for n in ('training_state.pt.tmp','epoch_36.json','epoch_36_steps.json'))
    assert excluded <= plan['run_inventory_sha256'].keys()
    preserved={n:h for n,h in plan['run_inventory_sha256'].items() if n not in excluded}
    files.verify(preserved)
    copies={row['capsule']+'/original/'+n:h for n,h in complete['copied_file_sha256'].items()}
    for n in ('plan.json','CAPTURE_STARTED.json','CAPTURE_COMPLETE.json'):
        key=row['capsule']+'/'+n; copies[key]=files.sha(key)
    files.verify(copies)
    return preserved,copies


def authenticate(files):
    new=sources(files); review=loads(files.read(str(REVIEW)));latches(files,review);guard(files)
    assert review['schema']=='incident020_same_state_recovery_review_v1'
    assert review['protocol_sha256']==PROTOCOL_SHA and review['same_original_state_resume_only'] is True
    assert review['automatic_retry'] is False and review['maximum_recovery_launches']==1
    assert review['max_recovery_wall_seconds']==14400 and review['max_allocated_recovery_GPU_hours']==8
    assert review['scientific_sources_changed'] is False and review['independent_guard_unchanged'] is True
    files.verify(review['supporting_evidence_sha256'])
    for pid in (2678690,2944716,2944719,3003488): assert process_command(pid) is None
    # All original attempts must be terminal; only this new parent may be open.
    rows,usage=resources(files);check_limits(usage);assert not usage['active_GPU_attempts']
    assert all('ended_unix' in r for r in rows.values() if r.get('label')!='incident020_parent_CPU')
    for n in review['original_attempts']:
        row=rows[n];assert row['status']=='failed' and row['returncode'] in (1,-15)
        assert row['ended_unix']>=row['started_unix'] and process_command(row['pid']) is None
    context=Context(files.project);source=source_bindings(context);bases=verify_completed_bases(context)
    gate=verify_gate(files.project,context.manifest_hash);plan,design=plan_for(context)
    # Reauthenticate preserved completed receipts/audits as bytes, never redo them.
    reuse={};files.verify(review['completed_wave_proof_sha256'])
    for n,h in review['completed_wave_proof_sha256'].items():
        proof=loads(files.read(n,h));assert proof['all_worker_processes_exited'] is True
        assert proof['sequential_independent_audits'] is True and proof['new_GPU_work'] is False
        files.verify(proof['bound_sha256']);reuse.update(proof['bound_sha256']);reuse[n]=h
    reuse.update(original.recovered_receipt(context,bases,source,gate))
    from continuation_production_receipts import verify_receipt
    from continuation_execution_runtime import checkpoint_bindings
    control,_=job_for_label(context,historical.CONTROL)
    a={'execution_source_sha256':source,'completed_base_bindings':bases,'preflight_gate':gate,
       'checkpoint_bindings':checkpoint_bindings(context,control,design)}
    _,digest=verify_receipt(context,historical.CONTROL,a)
    reuse[str(ROOT/'production_receipts'/f'{historical.CONTROL}.json')]=digest
    for item in plan['waves'][0]['jobs']:
        job,_=job_for_label(context,item['label']);resume_destination(context,job)
        prior,copies=preserved_prior(files,item['label']);reuse.update(prior);reuse.update(copies)
    old,_=original.plan_for(context)
    for wave in old['waves'][5:]:
        assert not files.path(str(ROOT/'continuation_waves'/f'wave_{wave["wave"]:02d}')).exists()
        for item in wave['jobs']:
            job,_=job_for_label(context,item['label']);untouched_destination(context,job)
    reuse.update(review['supporting_evidence_sha256']);reuse.update(review['known_failure_sha256'])
    return context,plan,review,{'source':source,'bases':bases,'gate':gate,'new_sources':new,'reuse':reuse}
