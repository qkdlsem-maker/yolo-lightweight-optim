"""Fixed paired six-stage workflow, with unchanged single-endpoint auditors.

Library only. No production CLI, evidence admission, launch, wait or retry.
The owner must supply authenticated model-bound plan/current-input contract,
original guard/caps/latches and a registered CPU parent before invoking it.
"""
from pathlib import Path
import time

import factorial_evaluation_adapter as original_adapter
from factorial_evaluation_stage_runtime_v2 import run_stage
from continuation_artifact_receipts import loads
from continuation_wave_runner import put
from validation_journal import publish_immutable


def validate_plan(plan):
    jobs=plan['jobs']
    assert plan['schema']=='factorial_evaluation_execution_plan_v1'
    assert len(jobs)==60 and len(plan['reuse_only'])==24
    assert len({j['endpoint_id'] for j in jobs})==60
    assert [j['wave'] for j in jobs]==[n for n in range(1,31) for _ in range(2)]
    assert [j['lane'] for j in jobs]==[0,1]*30
    assert plan['global_resource_caps']=={'hard_allocated_GPU_hours':220,'hard_wall_days':10,
        'max_new_disk_GiB':200,'min_free_disk_GiB':150}
    assert plan['independent_auditor_sha256']==original_adapter.AUDITOR_SHA
    assert plan['unchanged_scientific_algorithms'] is True
    assert plan['output_root']==str(original_adapter.ROOT/'factorial_evaluation')
    for job in jobs:
        assert job['output']==plan['output_root']+'/endpoints/'+job['endpoint_id']


def run_all(files,plan,plan_ref,parent_attempt,parent_row,contract,monitor,idle_uuid,uuids,
            stage_wall_seconds=7200,adapter=original_adapter):
    """One new 60-endpoint workflow. Test-only adapter replacement is explicit.

    The plan/evidence admission is a caller responsibility. Stage process cleanup
    and reservation accounting use the frozen runtime even in fixture tests.
    """
    validate_plan(plan)
    assert loads(files.read(plan_ref['path'],plan_ref['sha256']))==plan
    monitor({})
    root=Path(plan['output_root']);workflow=root/'workflow'
    # No adoption, resume, overwrite or delayed launch of any existing run.
    files.path(str(root)).mkdir(parents=True,exist_ok=False)
    try:
        put(files,workflow/'authority.json',{'plan':plan_ref,'parent_attempt':parent_attempt,
            'parent_pid':parent_row['pid'],'started_unix':time.time(),'jobs':60,'waves':30,
            'admission_conferred_by_this_library':False})
        receipt_sha={};wave_sha={};stage_sha={}
        for wave in range(1,31):
            monitor({})
            jobs=plan['jobs'][(wave-1)*2:wave*2];wave_dir=workflow/('wave_%02d'%wave)
            if wave>1:files.verify(wave_sha)
            put(files,wave_dir/'authority.json',{'wave':wave,'plan':plan_ref,
                'jobs':[j['endpoint_id'] for j in jobs],'previous_seal_sha256':dict(wave_sha),
                'parent_attempt':parent_attempt,'started_unix':time.time()})
            outputs={j['endpoint_id']:{} for j in jobs}
            for step,_,gpu in adapter.STEPS:
                monitor({});request_shas={}
                for job in jobs:
                    q=adapter.request(files,plan,job,step)
                    rp=adapter.request_path(plan,job,step)
                    files.path(rp).parent.mkdir(parents=True,exist_ok=True)
                    publish_immutable(files.path(rp),adapter.canonical(q))
                    request_shas[job['endpoint_id']]=files.sha(rp)
                batches=[jobs] if gpu else [[j] for j in jobs]
                for batch in batches:
                    directory=wave_dir/(step if gpu else step+'_'+batch[0]['endpoint_id'])
                    def verify(task):
                        job=next(j for j in batch if j['endpoint_id']==task['endpoint_id'])
                        return adapter.verify_step(files,plan,job,step,request_shas[job['endpoint_id']],
                            uuids[str(job['lane'])],contract)
                    result=run_stage(files,directory,step,[adapter.task(files,plan,j,step) for j in batch],
                        parent_attempt,parent_row,monitor,idle_uuid,uuids,verify,stage_wall_seconds)
                    path=str(directory/'STAGE_COMPLETE.json');stage_sha[path]=files.sha(path)
                    for job in batch:
                        eid=job['endpoint_id'];bindings=result['artifacts'][eid]
                        base=job['output']+'/'+step
                        outputs[eid][step]={'request_sha256':request_shas[eid],
                            'manifest_sha256':bindings[base+'/MANIFEST.json'],
                            'complete_sha256':bindings[base+'/COMPLETE.json']}
            for job in jobs:
                assert set(outputs[job['endpoint_id']])=={s[0] for s in adapter.STEPS}
                put(files,Path(job['output'])/'ENDPOINT_COMPLETE.json',
                    {'endpoint_id':job['endpoint_id'],'outputs':outputs[job['endpoint_id']]})
            # A completed GPU output is still not an audited endpoint.
            pair_receipts={}
            for job in jobs:
                monitor({})
                eid=job['endpoint_id'];ep=job['output']+'/ENDPOINT_COMPLETE.json';eh=files.sha(ep)
                audit_path=plan['output_root']+'/audits/'+eid+'.json'
                assert not files.path(audit_path).exists()
                def verify_audit(task):
                    assert task['endpoint_id']==eid
                    audit=loads(files.read(audit_path))
                    assert audit['status']=='passed' and audit['endpoint_id']==eid
                    assert audit['plan_sha256']==plan_ref['sha256'] and audit['endpoint_complete_sha256']==eh
                    assert audit['audit_source_sha256']==plan['independent_auditor_sha256']
                    assert all(audit[n] for n in ('native_bdd','bdd_common','kitti_common','native_kitti','scope'))
                    assert files.sha(ep)==eh
                    return {audit_path:files.sha(audit_path),ep:eh}
                directory=wave_dir/('independent_audit_'+eid)
                result=run_stage(files,directory,'independent_audit',[adapter.audit_task(files,plan,job,plan_ref)],
                    parent_attempt,parent_row,monitor,idle_uuid,uuids,verify_audit,stage_wall_seconds)
                ap=str(directory/'STAGE_COMPLETE.json');stage_sha[ap]=files.sha(ap)
                monitor({})
                receipt_path=root/'receipts'/(eid+'.json')
                put(files,receipt_path,{'schema':'factorial_evaluation_endpoint_receipt_v1',
                    'status':'six_original_stages_and_independent_CPU_audit_passed',
                    'endpoint_id':eid,'plan':plan_ref,'wave':wave,'outputs':outputs[eid],
                    'endpoint_complete_sha256':eh,'audit':{'path':audit_path,'sha256':files.sha(audit_path)},
                    'audit_stage_receipt_sha256':files.sha(ap),'parent_attempt':parent_attempt,
                    'ended_unix':time.time(),'repeated_historical_evaluation':False})
                pair_receipts[str(receipt_path)]=files.sha(str(receipt_path))
            monitor({});files.verify(pair_receipts)
            seal=wave_dir/'SEALED.json'
            put(files,seal,{'wave':wave,'plan':plan_ref,'receipt_sha256':pair_receipts,
                'all_owned_sessions_exited':True,'two_independent_CPU_audits_passed':True,'sealed_unix':time.time()})
            wave_sha[str(seal)]=files.sha(str(seal));receipt_sha.update(pair_receipts)
        monitor({});files.verify(stage_sha);files.verify(wave_sha);files.verify(receipt_sha)
        marker={'schema':'factorial_evaluation_receipts_complete_v1','plan':plan_ref,
            'receipt_sha256':receipt_sha,'wave_seal_sha256':wave_sha,'stage_receipt_sha256':stage_sha,
            'new_endpoints':60,'reused_endpoints':24,'parent_attempt':parent_attempt,'ended_unix':time.time(),
            'parent_success_exit_still_required':True,'whole_research_complete':False}
        put(files,root/'EVALUATION_RECEIPTS_COMPLETE.json',marker)
        return marker
    except BaseException as error:
        # run_stage has already drained its own sessions even if evidence I/O
        # fails. Preserve this outer error; there is never an automatic retry.
        put(files,root/'FAILURE.json',{'error':repr(error),'parent_attempt':parent_attempt,
            'automatic_retry':False,'original_outputs_and_attempts_preserved':True})
        raise
