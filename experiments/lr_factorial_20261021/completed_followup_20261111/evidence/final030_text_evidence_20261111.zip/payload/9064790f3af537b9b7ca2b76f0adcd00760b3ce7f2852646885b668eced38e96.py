"""Fixed continuation roster and fail-closed argument/evidence gates.

This module does not initialize CUDA, train, evaluate, or modify an output.
CPU contract tests do not replace observational or interrupted-replay preflight.
"""
import hashlib
import itertools
import json
from pathlib import Path

PROTOCOL_SHA = '8dac98e36fee058726b9475487896c49f53f246e960cdfc0ba7e6acb895cdc9d'
INTERPRETATION_SHA = 'ffea92e15e8f0d7973e6ccc96083227124c3eb42de25d746f4611b76471f02b8'
REUSE_SHA = '2eb69016b83b3347ba5e79823d81d35cde13230818cd028445e5da213ac157fd'
ROOT = Path('review_20261021_lr_factorial')
ARMS = ('control', 'mse', 'cwd')
RATES = (.0001, .001)
ALL_SEEDS = (101, 202, 303, 404, 505, 606)
OLD_SEEDS = (101, 202, 303)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1048576), b''):
            digest.update(chunk)
    return digest.hexdigest()


def read(path):
    return json.loads(Path(path).read_bytes())


def build_design(protocol, reuse):
    assert protocol['root'] == ROOT.as_posix()
    assert protocol['all_pair_seeds'] == list(ALL_SEEDS)
    assert protocol['historical_pair_seeds'] == list(OLD_SEEDS)
    assert protocol['pair_seeds'] == [404, 505, 606]
    factorial = protocol['factorial']
    assert factorial['arms'] == list(ARMS) and factorial['learning_rates'] == list(RATES)
    assert factorial['kd_weight'] == .3 and factorial['control_weight'] == 0.
    assert factorial['epochs'] == 40 and factorial['new_continuation_runs'] == 27
    assert reuse['original_roster_sha256'] == protocol['historical_roster_sha256']
    old_endpoints = reuse['endpoints']
    assert len(old_endpoints) == 24 and len({x['endpoint_id'] for x in old_endpoints}) == 24
    old_base = [x for x in old_endpoints if x['stage'] == 'base']
    assert len(old_base) == 6
    assert {(x['architecture'], x['pair_seed'], x['epoch']) for x in old_base} == set(itertools.product(('nano', 'large'), OLD_SEEDS, (100,)))
    new_jobs, reused = [], []
    for seed, rate, arm in itertools.product(ALL_SEEDS, RATES, ARMS):
        weight = 0. if arm == 'control' else .3
        if seed in OLD_SEEDS and rate == .0001:
            rows = [x for x in old_endpoints if x['stage'] == 'continuation'
                    and x['pair_seed'] == seed and x['arm'] == arm and x['weight'] == weight]
            assert len(rows) == 2 and {x['epoch'] for x in rows} == {20, 40}
            reused.append({'pair_seed': seed, 'lr': rate, 'arm': arm, 'kd_weight': weight,
                           'action': 'reuse_only_never_retrain', 'endpoints': sorted(rows, key=lambda x: x['epoch'])})
            continue
        base_root = protocol['historical_root'] if seed in OLD_SEEDS else protocol['root']
        label = f'pair{seed}_{arm}_w{weight:g}_lr{rate:g}'
        out_root = f"{protocol['root']}/continuations/{label}"
        args = {'arm': arm, 'seed': seed + 1000, 'epochs': 40, 'batch': 64, 'workers': 4,
                'lr': rate, 'kd_weight': weight, 'temperature': 4.,
                'source': f'{base_root}/base/nano_seed{seed}/weights/last.pt',
                'teacher': f'{base_root}/base/large_seed{seed}/weights/last.pt',
                'data': protocol['data']['yaml'], 'out_root': out_root,
                'smoke_batches': 0, 'fixture_batches': 0, 'stop_after_epoch': 0,
                'stop_before_validation_epoch': 0, 'stop_after_validation_epoch': 0,
                'preflight_id': None}
        new_jobs.append({'label': label, 'pair_seed': seed, 'args': args,
                         'run_directory': f'{out_root}/{arm}_seed{seed + 1000}_e40'})
    assert len(new_jobs) == 27 and len(reused) == 9
    assert len({x['run_directory'] for x in new_jobs}) == 27
    return {'schema': 'continuation_design_v1', 'protocol_sha256': PROTOCOL_SHA,
            'interpretation_sha256': INTERPRETATION_SHA, 'historical_reuse_sha256': REUSE_SHA,
            'new_jobs': new_jobs, 'reused_paths': reused, 'reused_base_endpoints': old_base,
            'new_job_count': 27, 'reused_path_count': 9,
            'status': 'fixed_design_only_pending_checkpoint_bindings_and_GPU_preflight'}


PATH_KEYS = ('source', 'teacher', 'data', 'out_root')


def same_arguments(actual, expected):
    assert set(actual) == set(expected) | {'device', 'resume'}, 'Unexpected or missing argument'
    for key, value in expected.items():
        observed = actual[key]
        if key in PATH_KEYS:
            assert Path(observed).resolve() == Path(value).resolve(), ('wrong path', key)
        else:
            assert type(observed) is type(value) and observed == value, ('wrong argument', key)
    assert type(actual['device']) is int and actual['device'] in (0, 1)
    assert type(actual['resume']) is bool


def validate_production_args(actual, design):
    matches = [job for job in design['new_jobs'] if all(actual.get(k) == job['args'][k] for k in ('arm', 'seed', 'lr'))]
    assert len(matches) == 1, 'Not one of the27new paths; historical low-rate paths are reuse-only'
    same_arguments(actual, matches[0]['args'])
    return matches[0]


def validate_fixture_args(actual, plan):
    key = actual.get('preflight_id')
    assert isinstance(key, str) and key
    matches = [request for request in plan['requests'] if request['id'] == key]
    assert len(matches) == 1, 'Fixture must match one prespecified immutable request'
    request = matches[0]
    expected = request['args']
    assert expected['preflight_id'] == key
    out = Path(expected['out_root']).resolve()
    fixture_root = (ROOT / 'continuation_preflight').resolve()
    assert out != fixture_root and out.is_relative_to(fixture_root)
    assert expected['smoke_batches'] > 0 or expected['fixture_batches'] > 0
    assert expected['smoke_batches'] >= 0 and expected['fixture_batches'] >= 0
    assert not (expected['smoke_batches'] and expected['fixture_batches'])
    assert 1 <= expected['epochs'] <= 40
    # Only the exact prespecified interruption combinations may change on resume.
    stop_keys = ('stop_after_epoch', 'stop_before_validation_epoch', 'stop_after_validation_epoch')
    stops = {key: actual[key] for key in stop_keys}
    assert all(type(value) is int for value in stops.values()), 'Fixture stop epochs must be integers'
    assert stops in request['allowed_stop_points']
    for point in request['allowed_stop_points']:
        assert set(point) == set(stop_keys)
        assert all(type(e) is int and 0 <= e <= expected['epochs'] for e in point.values())
        assert sum(e > 0 for e in point.values()) <= 1
        for key in stop_keys[1:]:
            assert point[key] in (0, 10, 20, expected['epochs'])
    compare = dict(expected, **stops)
    same_arguments(actual, compare)
    return request


def verify_manifest(root):
    manifest_path = root / 'continuation_sources.json'
    manifest = read(manifest_path)
    names = [row['name'] for row in manifest['files']]
    assert len(names) == len(set(names))
    assert {'continuation.py', 'continuation_contract.py', 'continuation_design.json',
            'continuation_rng.py', 'validation_journal.py'} <= set(names)
    for row in manifest['files']:
        relative = Path(row['name'])
        assert not relative.is_absolute() and '..' not in relative.parts
        assert sha(root / relative) == row['sha256'], row['name']
    return manifest, sha(manifest_path)


def enforce_contract(args):
    """Required before output creation or CUDA selection; pending gates fail closed."""
    root = ROOT
    for latch in ('BUDGET_STOP.json', 'CONTINUATION_PREFLIGHT_BUDGET_STOP.json',
                  'CONTINUATION_PREFLIGHT_FAILURE.json'):
        assert not (root / latch).exists(), f'Stop/failure is latched: {latch}'
    assert sha(root / 'protocol.json') == PROTOCOL_SHA
    assert sha(root / 'protocol_interpretation.json') == INTERPRETATION_SHA
    assert sha(root / 'historical_reuse_manifest.json') == REUSE_SHA
    protocol = read(root / 'protocol.json')
    design = read(root / 'continuation_design.json')
    assert design == build_design(protocol, read(root / 'historical_reuse_manifest.json'))
    manifest, manifest_hash = verify_manifest(root)
    actual = vars(args)
    if actual.get('preflight_id') is not None:
        name = 'continuation_preflight_requests.json'
        assert name in {x['name'] for x in manifest['files']}
        plan = read(root / name)
        assert plan['protocol_sha256'] == PROTOCOL_SHA
        request = validate_fixture_args(actual, plan)
        for key in ('source', 'teacher', 'data'):
            assert sha(actual[key]) == request['input_sha256'][key], key
        label = request['id']
    else:
        request = validate_production_args(actual, design)
        assert 'continuation_production_gate.py' in {row['name'] for row in manifest['files']}
        from continuation_production_gate import verify_gate
        verify_gate(Path.cwd(), manifest_hash)
        seed = request['pair_seed']
        for key, model in (('source', 'nano'), ('teacher', 'large')):
            if seed in OLD_SEEDS:
                bindings = [e for e in design['reused_base_endpoints'] if e['architecture'] == model and e['pair_seed'] == seed]
                assert len(bindings) == 1
                digest = bindings[0]['checkpoint']['sha256']
            else:
                proof = read(root / 'completed_base_audits' / f'{model}_seed{seed}.json')
                digest = proof['run']['checkpoint_sha256']
            assert sha(actual[key]) == digest, key
        assert sha(actual['data']) == protocol['data']['yaml_sha256']
        label = request['label']
    return {'label': label, 'protocol_sha256': PROTOCOL_SHA,
            'contract_sha256': sha(__file__), 'design_sha256': sha(root / 'continuation_design.json'),
            'source_manifest_sha256': manifest_hash,
            'mode': 'preflight_fixture' if actual.get('preflight_id') is not None else 'production'}
