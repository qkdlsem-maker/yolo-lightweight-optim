"""Real Linux process bounds; evidence/model/guard boundaries are synthetic.

All overrides are memory-only in this test. The production wrapper has no
testing argument, duration override, alternative collector or retry option.
"""
import copy
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import run_factorial_current_inputs_auth as w
from continuation_artifact_receipts import encoded, loads, Files, ROOT, PROTOCOL_SHA


def synthetic_result():
    return {'schema': 'factorial_current_evaluation_inputs_v1',
        'status': 'current_input_bytes_authenticated_not_evaluation_admission',
        'protocol_sha256': PROTOCOL_SHA, 'preparation_sha256': w.SPEC_SHA,
        'reused24_authentication_sha256': w.evidence.REUSE_SHA,
        'image_counts': {'bdd':10000, 'kitti':7481},
        'BDD_labels': {'images':10000, 'boxes':185526}, 'KITTI_label_members':7481,
        'model_loaded':False, 'new_GPU_work':False, 'new_inference':False,
        'new_scoring':False, 'old_evaluation_audit_repeated':False,
        'evaluation_admitted':False, 'runtime':{'GPU_runtime_observed':False}}


def child(case, directory):
    root = Path(directory).resolve()
    f = Files(root)
    w.command = lambda files, expected: [sys.executable, '-B', '-u', str(Path(__file__).resolve()), '--child', case, str(root)]
    w.WALL_SECONDS = 1 if case == 'wall_timeout' else 12
    w.CPU_SECONDS = 2 if case == 'CPU_timeout' else 30
    w.POLL_SECONDS, w.JOIN_SECONDS = .03, 2
    binding = str(ROOT / 'synthetic_source.txt')
    original = f.sha(binding)
    counter = [0]

    def gate(files):
        counter[0] += 1
        if case == 'initial_gate_failure' or case == 'watchdog_failure' and counter[0] >= 2:
            raise RuntimeError('Synthetic gate rejects')
        return {'synthetic': True, 'active_GPU_attempts': []}

    def source(files, expected):
        assert expected == 'a' * 64
        if case == 'source_reject':
            raise AssertionError('Synthetic source rejection')
        return {binding: original}

    def collect(project, preparation_sha):
        if case == 'collector_failure':
            raise RuntimeError('Synthetic collector fails')
        if case in ('wall_timeout', 'watchdog_failure', 'external_SIGTERM', 'active_duplicate'):
            time.sleep(20)
        if case == 'CPU_timeout':
            while True:
                hashlib.sha256(b'CPU limit fixture').digest()
        if case == 'source_mutation':
            f.path(binding).write_text('mutated synthetic source')
        if case == 'guard_terminal':
            p = next(f.path(str(ROOT / 'attempts')).glob('*.json'))
            row = loads(p.read_bytes())
            p.write_bytes(encoded(dict(row, status='failed', returncode=1,
                ended_unix=time.time(), stop_reason='synthetic independent guard terminal')))
        value = synthetic_result()
        if case == 'invalid_result':
            value['evaluation_admitted'] = True
        return value

    w.gate, w.verify_sources, w.evidence.collect = gate, source, collect
    w.run(root, 'a' * 64)


def run_processes(folder):
    outcomes = []
    env = dict(os.environ, CUDA_VISIBLE_DEVICES='', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1')
    for case in ('success', 'initial_gate_failure', 'source_reject', 'collector_failure',
                 'invalid_result', 'source_mutation', 'guard_terminal', 'watchdog_failure',
                 'wall_timeout', 'CPU_timeout', 'external_SIGTERM', 'active_duplicate'):
        root = folder / case
        phase = root / ROOT
        phase.mkdir(parents=True)
        (phase / 'synthetic_source.txt').write_text('immutable synthetic source')
        cmd = [sys.executable, '-B', '-u', str(Path(__file__).resolve()), '--child', case, str(root)]
        log = (root / 'process.log').open('xb')
        proc = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT, env=env, start_new_session=True)
        prefix = phase / 'factorial_current_inputs_auth'
        execution = Path(str(prefix) + '_execution.json')
        deadline = time.monotonic() + 8
        while not execution.exists() and proc.poll() is None:
            assert time.monotonic() < deadline
            time.sleep(.01)
        assert execution.exists()
        if case == 'active_duplicate':
            duplicate = subprocess.run(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True, timeout=5)
            (root / 'duplicate.log').write_bytes(duplicate.stdout)
            assert duplicate.returncode != 0 and proc.poll() is None
            assert not Path(str(prefix) + '_FAILURE.json').exists()
            assert len(list((phase / 'attempts').glob('*.json'))) == 1
        if case in ('external_SIGTERM', 'active_duplicate'):
            os.kill(proc.pid, signal.SIGTERM)
        code = proc.wait(timeout=18)
        log.close()
        assert w.process_command(proc.pid) is None
        attempts = list((phase / 'attempts').glob('*.json'))
        assert len(attempts) == 1
        row = loads(attempts[0].read_bytes())
        assert row['GPU_job'] is False and row['device'] is None
        assert row['pid'] == proc.pid and row['command'] == cmd and row['ended_unix'] >= row['started_unix']
        success = case == 'success'
        assert (code == 0) == success and (row['status'] == 'completed') == success
        assert Path(str(prefix) + '.json').exists() == success
        assert Path(str(prefix) + '_FAILURE.json').exists() != success
        if case == 'guard_terminal':
            assert row['stop_reason'] == 'synthetic independent guard terminal'
        if success:
            value = loads(Path(str(prefix) + '.json').read_bytes())
            w.validate_result(value)
            assert value['attempt'] == str(attempts[0].relative_to(root))
            assert value['runtime_model_imported'] is False
        preserved = {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in phase.rglob('*') if p.is_file()}
        # Completed AND failed operations refuse any second execution, unchanged.
        duplicate = subprocess.run(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, start_new_session=True, timeout=5)
        (root / 'terminal_duplicate.log').write_bytes(duplicate.stdout)
        assert duplicate.returncode != 0
        assert preserved == {str(p.relative_to(root)): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in phase.rglob('*') if p.is_file()}
        outcomes.append({'case': case, 'returncode': code, 'duplicate_rejected_unchanged': True,
            'CPU_only_closed_attempt': True, 'process_exited': True})
    return outcomes


def test_gate(folder):
    from unittest.mock import patch
    f=Files(folder);f.path(str(ROOT)).mkdir(parents=True)
    p=f.path(str(w.guarded.REVIEW));p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(encoded({'synthetic':True}))
    usage={'allocated_GPU_hours':100,'preflight_GPU_hours':.7,'wall_days':3,
        'phase_disk_GiB':20,'free_disk_GiB':1000,'active_GPU_attempts':['synthetic_existing_training_reservation']}
    outcomes=[]
    with patch.object(w.guarded,'guard'),patch.object(w.guarded,'latches'),patch.object(w,'resources',return_value=({},usage)):
        assert w.gate(f)==usage  # ongoing training is expressly permitted
    for key,value in (('allocated_GPU_hours',220),('preflight_GPU_hours',3),('wall_days',10),('phase_disk_GiB',200),('free_disk_GiB',149)):
        u=dict(usage);u[key]=value
        with patch.object(w.guarded,'guard'),patch.object(w.guarded,'latches'),patch.object(w,'resources',return_value=({},u)):
            try:w.gate(f)
            except RuntimeError:outcomes.append(key)
            else:raise AssertionError('Accepted exceeded cap '+key)
    for name in ('guard','latches'):
        with patch.object(w.guarded,'guard'),patch.object(w.guarded,'latches'),patch.object(w,'resources',return_value=({},usage)):
            getattr(w.guarded,name).side_effect=RuntimeError('Synthetic failure')
            try:w.gate(f)
            except RuntimeError:outcomes.append(name)
            else:raise AssertionError('Accepted failed guard/latch')
    for name,flag in (('CUDA_VISIBLE_DEVICES','0'),):
        with patch.dict(os.environ,{name:flag}),patch.object(w.guarded,'guard'),patch.object(w.guarded,'latches'),patch.object(w,'resources',return_value=({},usage)):
            try:w.gate(f)
            except AssertionError:outcomes.append(name)
            else:raise AssertionError('Accepted visible CUDA')
    return outcomes


def main():
    if len(sys.argv) == 4 and sys.argv[1] == '--child':
        return child(sys.argv[2], sys.argv[3])
    assert len(sys.argv) == 2
    folder = Path(sys.argv[1]).resolve()
    folder.mkdir()  # exclusive run; failed attempts are retained
    os.environ['CUDA_VISIBLE_DEVICES'] = ''
    results = run_processes(folder)
    gates = test_gate(folder / 'gate_boundaries')
    assert 'torch' not in sys.modules
    result = {'status': 'passed', 'process_cases': results, 'gate_rejection_cases': gates,
        'real_Linux_process_cases': len(results), 'real_gate_rejection_cases': len(gates),
        'GPU_work': False, 'production_collect_executed': False,
        'source_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
            for p in (Path(__file__), Path(w.__file__))},
        'limits': 'Model, completed receipt, source admission and independent guard boundaries are synthetic; actual complete input data authentication is still pending.'}
    (folder / 'RESULT.json').write_bytes(encoded(result))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
