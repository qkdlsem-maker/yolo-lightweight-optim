"""One initial production path after all real gates; never auto-resume/retrain.

No import starts work. This worker remains undeployed until its parent driver,
execution freeze, completed audits and actual GPU preflight all exist and pass.
"""
import argparse
import os
from pathlib import Path
import runpy
import signal
import sys
import threading
import time
import traceback
import uuid
from continuation_artifact_receipts import ROOT,PROTOCOL_SHA,encoded
from continuation_fixture_roster import argument_vector
from continuation_preflight_runtime import BudgetExceeded,gpu_idle_uuid,watch_budget
from validation_journal import publish_immutable,sync_directory
from continuation_execution_runtime import (RUNNER,public_context,job_for_label,arguments,
    evidence_paths,untouched_destination,checkpoint_bindings,wait_for_registration,
    ownership,limits_now)


def execute_trainer(path,args,expected_sha,sha):
    """Run the unchanged gated trainer in this already registered GPU process."""
    assert sha(path)==expected_sha
    previous=list(sys.argv)
    try:
        sys.argv=[str(path)]+argument_vector(args)
        runpy.run_path(str(path),run_name='__main__')
    finally:
        sys.argv=previous
    assert sha(path)==expected_sha


def publish_failure(files,label,attempt,pid,error):
    record={'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'pid':pid,
        'label':label,'attempt':attempt,'error':repr(error),'traceback':traceback.format_exc(),
        'last_atomic_state_and_completed_results_preserved':True,'automatic_retry':False}
    marker='CONTINUATION_FAILURE.json'
    if isinstance(error,BudgetExceeded):
        marker='BUDGET_STOP.json';record.update(scope=error.scope,resources=error.snapshot)
    history=files.path((ROOT/'production_failures'/f'{label}_pid{pid}_{uuid.uuid4().hex}.json').as_posix())
    history.parent.mkdir(parents=True,exist_ok=True)
    publish_immutable(history,encoded(record))
    # Both GPU workers can fail together. Retain each cause, atomically claim
    # the first latch, and never replace an earlier guard or worker decision.
    target=files.path((ROOT/marker).as_posix())
    try:os.link(history,target)
    except FileExistsError:pass
    sync_directory(target.parent)
    return history.relative_to(files.project).as_posix()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--label',required=True)
    parser.add_argument('--device',type=int,choices=(0,1),required=True)
    options=parser.parse_args()
    assert os.name=='posix' and 'CUDA_VISIBLE_DEVICES' not in os.environ
    context,source_hashes,gate,base_hashes=public_context(Path.cwd())
    f=context.files
    assert Path(__file__).resolve()==f.path(RUNNER.as_posix()).resolve()
    pid,parent_pid=os.getpid(),os.getppid()
    assert os.getsid(pid)==os.getpgid(pid)==pid, 'Require owned new process session'
    job,design=job_for_label(context,options.label)
    args=arguments(job,design,options.device)
    attempt=wait_for_registration(context,options.label,options.device,pid,parent_pid)
    stopped=threading.Event();watcher=None;locks=[]

    def failure(error):
        publish_failure(f,options.label,attempt,pid,error)

    def sample():
        records,snapshot=limits_now(context)
        ownership(context,options.label,options.device,records,pid,parent_pid)
        return snapshot

    def stop_self(error):
        try:failure(error)
        finally:
            assert os.getpid()==pid and os.getpgid(pid)==pid
            os.killpg(pid,signal.SIGTERM)

    try:
        import fcntl
        for name in (f'continuation_production_gpu{options.device}.lock',f'production_job_locks/{options.label}.lock'):
            path=f.path((ROOT/name).as_posix());path.parent.mkdir(parents=True,exist_ok=True)
            handle=path.open('a');fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(handle)
        untouched_destination(context,job)
        input_hashes=checkpoint_bindings(context,job,design)
        snapshot=sample();gpu_uuid=gpu_idle_uuid(options.device)
        paths=evidence_paths(options.label)
        admission={'schema':'continuation_production_admission_v1','status':'registered_guards_passed_not_completed',
            'label':options.label,'pid':pid,'attempt':attempt,'device':options.device,'GPU_uuid':gpu_uuid,
            'protocol_sha256':PROTOCOL_SHA,'context':context.identifiers(),'args':args,
            'execution_source_sha256':source_hashes,'preflight_gate':gate,
            'completed_base_bindings':base_hashes,'checkpoint_bindings':input_hashes,'resources_before_Torch_import':snapshot}
        destination=f.path(paths['admission']);destination.parent.mkdir(parents=True,exist_ok=False)
        publish_immutable(destination,encoded(admission))
        watcher=threading.Thread(target=watch_budget,args=(sample,stopped,stop_self),daemon=True);watcher.start()
        # First trainer/Torch load is after actual gates, registration, locks and idle GPU.
        trainer=(ROOT/'continuation.py').as_posix()
        execute_trainer(f.path(trainer),args,context.bindings[trainer],lambda p:f.sha(Path(p).relative_to(f.project).as_posix()))
        context.verify();f.verify(source_hashes);f.verify(base_hashes);f.verify(input_hashes);sample()
        complete=(Path(job['run_directory'])/'COMPLETE.json').as_posix()
        execution={'schema':'continuation_production_execution_v1','status':'trainer_returned_requires_independent_CPU_audit',
            'label':options.label,'attempt':attempt,'pid':pid,'device':options.device,'GPU_uuid':gpu_uuid,
            'admission_sha256':f.sha(paths['admission']),'complete_sha256':f.sha(complete),
            'returned_unix':time.time(),
            'protocol_sha256':PROTOCOL_SHA,'context':context.identifiers()}
        publish_immutable(f.path(paths['execution']),encoded(execution))
        print('PRODUCTION_TRAINER_RETURNED_REQUIRES_CPU_AUDIT',options.label,flush=True)
    except BaseException as error:
        failure(error)
        raise
    finally:
        stopped.set()
        if watcher is not None:
            watcher.join(timeout=10);assert not watcher.is_alive()
        for handle in reversed(locks):handle.close()


if __name__=='__main__':main()
