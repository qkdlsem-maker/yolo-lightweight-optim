"""Join all fixed results and apply the previously frozen paired contrast kernel."""
import json,sys
from pathlib import Path
from study_runtime import Study,PROJECT,PHASE,HERE,source_check,publish,read,need,file_sha,stage_folder,GRADIENT_RESULTS
from completed_training_bridge import PulsedFiles
from metrics_run import endpoint_directories
from result_analysis_core import scores,metric_factor_effects
from continuation_artifact_receipts import loads
import factorial_contrasts as contrasts


def run(ctx):
    f=PulsedFiles(PROJECT,ctx.check);locations,directories=endpoint_directories(f)
    reused=loads(f.read(PHASE+'/factorial_reuse_auth_v2.json'))
    reused_by_id={x['endpoint_id']:x for x in reused['endpoints']}
    evaluation=loads(f.read(PHASE+'/factorial_evaluation/EVALUATION_RECEIPTS_COMPLETE.json'))
    metric_complete=loads(f.read(PHASE+'/metric_decomposition/COMPLETE.json'));f.verify(metric_complete['bound_result_sha256'])
    gradient_complete=loads(f.read(GRADIENT_RESULTS+'/COMPLETE.json'));f.verify(gradient_complete['bound_result_sha256'])
    root=PROJECT/PHASE/'analysis_final';root.mkdir(parents=True,exist_ok=False)
    from training_summary import collect as collect_training
    accepted=loads(f.read(PHASE+'/factorial_training_acceptance.json'))
    training=collect_training(f,accepted)
    publish(root/'TRAINING_36_PATHS_AND6_NEW_BASES.json',training)
    endpoints=[]
    for row in locations['endpoints']:
        eid=row['endpoint_id'];base=directories[eid]
        if eid in reused_by_id:
            audit_path='review_20261017_independent/final_evaluation_audits/'+reused_by_id[eid]['historical_endpoint_id']+'.json'
            audit=loads(f.read(audit_path,reused['bound_artifacts'][audit_path]))
        else:
            receipt_path=PHASE+'/factorial_evaluation/receipts/'+eid+'.json'
            receipt=loads(f.read(receipt_path,evaluation['receipt_sha256'][receipt_path]))
            audit_path=receipt['audit']['path'];audit=loads(f.read(audit_path,receipt['audit']['sha256']))
        need(audit['status']=='passed','Endpoint audit status')
        refs={
            'native_bdd':(base+'/native_bdd/score.json',audit['native_bdd']['score_sha256']),
            'bdd_common':(base+'/bdd_common/bdd_common.json',audit['bdd_common']['scores']['bdd_common']['score_sha256']),
            'kitti_source_ignore':(base+'/kitti_common/kitti_source_ignore.json',audit['kitti_common']['scores']['kitti_source_ignore']['score_sha256']),
            'kitti_no_ignore':(base+'/kitti_common/kitti_no_ignore_sensitivity.json',audit['kitti_common']['scores']['kitti_no_ignore_sensitivity']['score_sha256']),
            'native_kitti':(base+'/kitti_native/score.json',audit['native_kitti']['score_sha256'])}
        values={key:loads(f.read(path,digest)) for key,(path,digest) in refs.items()}
        extracted=scores(values['native_bdd'],values['bdd_common'],values['kitti_source_ignore'],values['kitti_no_ignore'],values['native_kitti'])
        endpoints.append(dict(roster=row,scores=extracted,evidence={key:{'artifact':path,'sha256':digest} for key,(path,digest) in refs.items()},audit={'path':audit_path,'sha256':f.sha(audit_path)}))
    need(len(endpoints)==84,'All84 endpoint results required')
    publish(root/'ALL_84_ENDPOINTS.json',endpoints)
    outputs={}
    for metric in endpoints[0]['scores']:
        key=('native_bdd' if metric.startswith('bdd_ten') else 'bdd_common' if metric.startswith('bdd_common') else
            'kitti_source_ignore' if metric.startswith('kitti_common_source_ignore') else 'kitti_no_ignore' if metric.startswith('kitti_common_no_ignore') else 'native_kitti')
        definition='run_native_bdd_validation.py' if key=='native_bdd' else 'common_ap_core.py' if 'common' in key or key.startswith('kitti_') and key!='native_kitti' else 'score_native_kitti_archive.py'
        source='review_20261017_independent/evaluation_tools/'+definition
        payload=dict(schema='factorial_metric_input_v1',protocol_sha256=contrasts.PROTOCOL_SHA,interpretation_sha256=contrasts.INTERPRETATION_SHA,
            unit='AP_fraction_0_to_1',metric_id=metric,population='BDD reconstructed legacy validation, 10000 images' if metric.startswith('bdd') else 'Previously examined KITTI public labeled training partition, all7481 images',
            metric_definition_sha256=f.sha(source),endpoint_roster_sha256=f.sha(PHASE+'/factorial_endpoint_location_plan.json'),rows=[])
        for endpoint in endpoints:
            row=endpoint['roster']
            if row['stage']=='base':continue
            payload['rows'].append(dict(pair_seed=row['pair_seed'],learning_rate=row['lr'],arm=row['arm'],epoch=row['epoch'],kd_weight=row['weight'],
                origin='historical_reuse' if row['action']=='reuse_completed_evaluation_only' else 'new',endpoint_id=row['endpoint_id'],
                status='completed',reason=None,score=endpoint['scores'][metric],evidence=endpoint['evidence'][key]))
        result=contrasts.analyze(payload);publish(root/'contrasts'/(metric+'.json'),result);outputs[metric]=result
    bases=[e for e in endpoints if e['roster']['stage']=='base'];need(len(bases)==12,'Twelve base references')
    publish(root/'BASE_REFERENCES_12.json',bases)
    factors=[]
    for eid in locations['metric_decomposition_final_endpoint_ids']:
        path=PHASE+'/metric_decomposition/endpoints/'+eid+'/factorial.json'
        value=loads(f.read(path,metric_complete['bound_result_sha256'][path]))
        factors.append(dict(endpoint_id=eid,cells=value['cells'],factor_effects=metric_factor_effects(value['cells']),evidence={'path':path,'sha256':f.sha(path)}))
    publish(root/'METRIC_384_CELLS_AND_EFFECTS.json',factors)
    gradient_rows=[]
    for path,digest in gradient_complete['bound_result_sha256'].items():
        if Path(path).name not in ('batch0.json','batch1.json'):continue
        value=loads(f.read(path,digest));gradient_rows.append(dict(label=value['label'],pair_seed=value['pair_seed'],learning_rate=value['learning_rate'],arm=value['arm'],
            batch_index=value['batch_index'],status=value['status'],detection_loss=value['detection_loss'],feature_loss=value['feature_loss'],groups=value['groups'],
            evidence={'path':path,'sha256':digest},teacher_no_grad=value['teacher_no_grad'],model_state_unchanged=value['model_state_unchanged']))
    need(len(gradient_rows)==72,'All72 gradients, including undefined outcomes')
    gradient_rows.sort(key=lambda r:(r['pair_seed'],r['learning_rate'],r['arm'],r['batch_index']))
    publish(root/'GRADIENT_72_SUMMARY.json',gradient_rows)
    # Preserve original strength-grid conclusions/data references as a separate, unchanged record.
    historical_plan='review_20261017_independent/final_evaluation_plan.json'
    publish(root/'HISTORICAL_STRENGTH_GRID_REFERENCE.json',dict(endpoint_count=48,plan={'path':historical_plan,'sha256':f.sha(historical_plan)},
        completion={'path':'review_20261017_independent/final_evaluation/EVALUATION_COMPLETE.json','sha256':f.sha('review_20261017_independent/final_evaluation/EVALUATION_COMPLETE.json')},
        scoring_repeated=False,selection_performed=False))
    primary=[c for c in outputs['bdd_ten_class_AP50_95']['contrasts'] if c['role']=='primary']
    environment=read(stage_folder('evaluation')/'CURRENT_INPUT_BYTES.json')['environment_transition']
    summary=dict(status='all_fixed_results_analyzed',new_bases=6,new_continuations=27,evaluation_endpoints=84,new_evaluations=60,reused_evaluations=24,
        gradient_batch_probes=72,metric_cells=384,paired_metrics=18,primary_interactions=primary,
        training_optimizer_totals={'new_bases':training['new_base_optimizer_totals'],'new_continuations':training['new27_optimizer_totals'],'historical_reused_continuations':training['historical9_optimizer_totals']},
        sampled_training_input_pairing=training['sampled_pairing'],
        environment_transition=environment,
        gradient_serialization_compatibility=read(HERE/'GRADIENT_RECOVERY.json'),
        limitations=outputs['bdd_ten_class_AP50_95']['notes']+[
            'The external partition was previously examined, not a new untouched or official hidden test.',
            'Common annotation/matching differences prevent a causal domain-shift interpretation.',
            'Metric decomposition is a controlled alternate scorer, not native KITTI equivalence.',
            'Gradient probes describe fixed raw final models on two fixed training batches, not historical stochastic AMP updates.',
            'Two pair606 high-rate paths were disclosed cold restarts to new destinations; original failed records remain preserved.',
            'An initial synthetic gradient preflight stopped before any model forward because its exact-dict check rejected authenticated OrderedDict states. A disclosed container compatibility correction preserves state metadata, tensors and objective mathematics; completed evaluation was retained.',
            environment['limitation']])
    publish(root/'SUMMARY.json',summary)
    refs={p.relative_to(PROJECT).as_posix():file_sha(p) for p in root.rglob('*.json')}
    publish(root/'COMPLETE.json',dict(status='all_fixed_results_analyzed',bound_result_sha256=refs))
    return {'summary':{'path':PHASE+'/analysis_final/SUMMARY.json','sha256':file_sha(root/'SUMMARY.json')},'bound_result_sha256':refs}

if __name__=='__main__':
    expected=sys.argv[1];source_check(expected);Study('analysis',expected,2*3600,0).run(run)
