"""Fixed-model FP32 gradient diagnostics; no data selection, training or launch.

Student-parameter gradients only (adapters excluded from the measured vector).
Autograd computes detection, unweighted feature, and the actual FP32 weighted
feature objectives separately. Reductions use float64 to avoid FP32 norm overflow.
This is not a reconstruction of historical stochastic/AMP training gradients.
"""
import hashlib
import math
import re
import torch
import torch.nn.functional as F

BATCH_SIZE = 32
TEMPERATURE = 4.
LAYERS = (15, 18, 21)
ARMS = ('control', 'mse', 'cwd')


def tensor_digest(value):
    v = value.detach().cpu().contiguous()
    h = hashlib.sha256()
    h.update(str(v.dtype).encode()); h.update(str(tuple(v.shape)).encode())
    h.update(v.reshape(-1).view(torch.uint8).numpy().tobytes())
    return h.hexdigest()


def model_evidence(module):
    return {'tensors': {k: tensor_digest(v) for k, v in module.state_dict().items()},
            'buffers_including_nonpersistent': {k: tensor_digest(v) for k, v in module.named_buffers()},
            'grads': {k: None if p.grad is None else tensor_digest(p.grad) for k, p in module.named_parameters()},
            'requires_grad': {k: p.requires_grad for k, p in module.named_parameters()},
            'training': {k: m.training for k, m in module.named_modules()}}


def feature_objective(arm, aligned, targets):
    """Same three feature-scale means as the frozen continuation; teacher detached."""
    assert arm in ('mse', 'cwd')
    assert len(aligned) == len(targets) == 3
    parts = []
    for student, teacher in zip(aligned, targets):
        assert student.shape == teacher.shape and student.ndim == 4
        assert student.shape[0] == BATCH_SIZE and student.numel() > 0
        assert student.dtype == teacher.dtype == torch.float32
        assert student.device == teacher.device
        if arm == 'mse':
            value = F.mse_loss(student.float(), teacher.detach().float())
        else:
            s = F.log_softmax(student.float().flatten(2) / TEMPERATURE, dim=-1)
            t = F.log_softmax(teacher.detach().float().flatten(2) / TEMPERATURE, dim=-1)
            value = (t.exp() * (t-s)).sum(-1).mean() * (TEMPERATURE**2)
        parts.append(value)
    return sum(parts)


def parameter_groups(named):
    assert named and len({name for name, _ in named}) == len(named)
    assert len({id(p) for _, p in named}) == len(named), 'Aliased parameters cannot be counted twice'
    groups = {'all_student': []}
    for i, (name, p) in enumerate(named):
        match = re.fullmatch(r'model\.(\d+)\..+', name)
        assert match and 'dfl.conv.weight' not in name, 'Only trainable student layer parameters'
        assert isinstance(p, torch.nn.Parameter) and p.requires_grad and p.dtype == torch.float32
        groups['all_student'].append(i)
        groups.setdefault(f'layer_{int(match[1]):02d}', []).append(i)
    return groups


def reduce_group(indices, named, gradients):
    stats = {}
    for kind, values in gradients.items():
        squares = []; nan = positive_inf = negative_inf = absent = 0
        for i in indices:
            g = values[i]
            if g is None:
                absent += 1
                continue
            assert g.dtype == torch.float32 and g.shape == named[i][1].shape
            v = g.detach()
            nan += int(torch.isnan(v).sum().item())
            positive_inf += int(torch.isposinf(v).sum().item())
            negative_inf += int(torch.isneginf(v).sum().item())
            if bool(torch.isfinite(v).all()):
                squares.append(float(v.double().square().sum().item()))
        nonfinite = nan + positive_inf + negative_inf
        stats[kind] = {'norm': None if nonfinite else math.sqrt(math.fsum(squares)),
                       'nan_elements': nan, 'positive_inf_elements': positive_inf,
                       'negative_inf_elements': negative_inf, 'unused_parameter_tensors': absent}
    det_norm, weighted_norm = stats['detection']['norm'], stats['weighted_feature']['norm']
    reasons = []
    if det_norm is None or weighted_norm is None:
        dot = cosine = ratio = None; reasons.append('nonfinite_detection_or_weighted_feature_gradient')
    else:
        dots = []
        for i in indices:
            d, w = gradients['detection'][i], gradients['weighted_feature'][i]
            if d is not None and w is not None:
                dots.append(float((d.detach().double() * w.detach().double()).sum().item()))
        dot = math.fsum(dots)
        ratio = weighted_norm / det_norm if det_norm > 0 else None
        cosine = dot / (det_norm * weighted_norm) if det_norm > 0 and weighted_norm > 0 else None
        if cosine is not None:
            assert -1.-1e-12 <= cosine <= 1.+1e-12
            cosine = max(-1., min(1., cosine))  # Only float64 final-rounding overshoot.
        if det_norm == 0: reasons.append('zero_detection_gradient')
        if weighted_norm == 0: reasons.append('zero_weighted_feature_gradient')
    return {'parameter_tensors': len(indices), 'parameter_elements': sum(named[i][1].numel() for i in indices),
            **stats, 'detection_weighted_feature_dot': dot,
            'detection_weighted_feature_cosine': cosine, 'weighted_feature_to_detection_norm_ratio': ratio,
            'undefined_reasons': reasons}


def diagnose_objectives(detection, feature, named_parameters, arm):
    """Value-level diagnostic. Caller owns immutable model/data provenance."""
    assert arm in ARMS
    assert not torch.is_autocast_enabled('cpu') and not torch.is_autocast_enabled('cuda')
    named = list(named_parameters); groups = parameter_groups(named)
    params = [p for _, p in named]
    assert len({p.device for p in params}) == 1
    for value in (detection, feature):
        assert isinstance(value, torch.Tensor) and value.ndim == 0 and value.dtype == torch.float32
        assert value.device == params[0].device
    assert detection.requires_grad
    before = [None if p.grad is None else tensor_digest(p.grad) for p in params]
    weight = 0. if arm == 'control' else .3
    gd = torch.autograd.grad(detection, params, retain_graph=arm != 'control', allow_unused=True)
    if arm == 'control':
        assert not feature.requires_grad and float(feature) == 0.
        gf = gw = (None,) * len(params)
    else:
        assert feature.requires_grad
        gf = torch.autograd.grad(feature, params, retain_graph=True, allow_unused=True)
        # Differentiate the actual FP32 weighted objective, rather than reporting
        # a float64-scaled unweighted norm as though it were an observed gradient.
        gw = torch.autograd.grad((BATCH_SIZE * weight) * feature, params, allow_unused=True)
    after = [None if p.grad is None else tensor_digest(p.grad) for p in params]
    assert before == after, 'Diagnostic modified parameter .grad fields'
    values = {'detection': gd, 'feature': gf, 'weighted_feature': gw}
    summaries = {name: reduce_group(indices, named, values) for name, indices in groups.items()}
    loss_values = [float(value.detach()) for value in (detection, feature)]
    finite_loss = all(math.isfinite(v) for v in loss_values)
    nonfinite = any(summaries['all_student'][kind]['norm'] is None for kind in values)
    return {'schema': 'fixed_student_gradient_diagnostic_v1', 'arm': arm, 'batch_size': BATCH_SIZE,
            'feature_weight': weight, 'feature_multiplier': BATCH_SIZE * weight,
            'autograd_precision': 'FP32; no autocast, scaler, clipping or optimizer',
            'reduction_precision': 'float64 sum of squares/dot; final scalar norm, ratio and cosine',
            'status': 'nonfinite_objective' if not finite_loss else 'nonfinite_gradient' if nonfinite else 'computed',
            'detection_loss': loss_values[0] if math.isfinite(loss_values[0]) else None,
            'feature_loss': loss_values[1] if math.isfinite(loss_values[1]) else None,
            'objective_finite': finite_loss, 'parameter_grad_fields_unchanged': True,
            'groups': summaries,
            'limits': 'Fixed-model, fixed-training-image diagnostic. Not historical stochastic AMP gradients or a causal explanation.'}


def diagnose_models(student, teacher, adapters, objective_builder, arm):
    """Check eval/FP32/frozen teacher and unchanged state around a single forward.

    objective_builder returns the batch-summed detection scalar and sum of the
    three feature means on the already fixed32-image batch. The future dataset
    runner must bind checkpoint/image hashes and record its exact input tensor.
    """
    assert torch.is_grad_enabled(), 'Autograd must be enabled before the probe forward'
    assert not torch.is_autocast_enabled('cpu') and not torch.is_autocast_enabled('cuda')
    models = {'student': student, 'teacher': teacher, 'adapters': adapters}
    for model in models.values():
        assert all(not m.training for m in model.modules()), 'Every module must be in eval mode'
        for value in list(model.state_dict().values()) + list(model.buffers()):
            assert not value.is_floating_point() or value.dtype == torch.float32
            assert bool(torch.isfinite(value).all()), 'Nonfinite input state'
    assert all(not p.requires_grad and p.grad is None for p in teacher.parameters())
    all_named = list(student.named_parameters())
    frozen = [name for name, p in all_named if not p.requires_grad]
    assert len(frozen) == 1 and 'dfl.conv.weight' in frozen[0]
    named = [(name, p) for name, p in all_named if p.requires_grad]
    before = {key: model_evidence(model) for key, model in models.items()}
    detection, feature = objective_builder()
    result = diagnose_objectives(detection, feature, named, arm)
    after = {key: model_evidence(model) for key, model in models.items()}
    assert before == after, 'Probe changed a parameter, buffer, gradient, trainability or training-mode flag'
    result.update(model_state_before=before, model_state_after=after,
                  model_state_unchanged=True, teacher_no_grad=True)
    return result
