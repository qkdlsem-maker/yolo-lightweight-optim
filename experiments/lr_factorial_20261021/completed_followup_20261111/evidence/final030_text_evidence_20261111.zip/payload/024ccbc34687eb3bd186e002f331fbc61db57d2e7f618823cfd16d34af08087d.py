"""Actual Linux lifecycle for the new orchestration; all scientific boundaries synthetic."""
import json,os,resource,sys,time
from pathlib import Path
from study_runtime import Study,PROJECT,PHASE,HERE,OLD,source_check,read,publish,need,file_sha,identity,members
from completed_training_bridge import routed_blueprint
from evaluation_monitor import evaluation_transient
from segmented_journal import SegmentedJournal,verify as verify_segments
from result_analysis_core import metric_factor_effects

CASES=('two_registered_CPU_workers_and_synthetic_devices','serial_CPU_stage','nonzero_worker_drained',
    'timeout_worker_drained','escaped_descendant_rejected_and_drained','journal_rotation_and_mutation_rejection',
    'exact_four_endpoint_restart_route','atomic_publication_matcher_boundaries','known_answer_metric_effects',
    'sequential_dispatch_failure_latch_and_no_retry','fixed_current_input_authentication',
    'historical24_actual_byte_authentication','actual60_completed_model_plan_assembly','cleanup_SIGTERM_deferred_until_drain_scope_ends',
    'authenticated36_raw_state_metadata_and_model_assembly_CPU_no_forwards')


def run(ctx):
    cases=[];expected_failed={};evidence={}
    need(len(os.sched_getaffinity(0))==4,'CPU validation and monitor affinity')
    publish(ctx.folder/'CPU_AFFINITY.json',dict(allowed_cores=sorted(os.sched_getaffinity(0)),aggregate_CPU_seconds_cap=1800,wall_seconds_cap=1800,monitor_du_timeout_seconds=5))
    from current_input_verification import authenticate
    current,proof=authenticate(ctx)
    need(proof['verified_files']==27530 and proof['approved_BDD_leaf_links']==10000 and not proof['GPU_work'],'Actual frozen input reader validation')
    publish(ctx.folder/'ACTUAL_INPUT_VERIFICATION.json',proof)
    del current
    cases.append(CASES[10])
    from evaluation_run import authenticate_reuse
    historical_path=authenticate_reuse(ctx);historical=read(historical_path)
    need(len(historical['endpoints'])==24 and historical['file_hash_operations']==1040191 and historical['bytes_hashed']==9842906612,'Actual24 historical byte authentication')
    need(not historical['new_inference'] and not historical['new_scoring'] and not historical['model_loaded'],'Historical replay forbidden')
    del historical
    cases.append(CASES[11])
    from completed_training_bridge import collect
    from retained_io import encode
    import factorial_evaluation_adapter as adapter
    from factorial_evaluation_workflow import validate_plan
    accepted,routed,_=collect(ctx);acceptance=PROJECT/PHASE/'factorial_training_acceptance.json'
    need(acceptance.read_bytes()==encode(accepted),'Actual completed acceptance changed')
    actual_plan=adapter.plan_from_bound(accepted,routed,{'path':acceptance.relative_to(PROJECT).as_posix(),'sha256':file_sha(acceptance)})
    validate_plan(actual_plan)
    publish(ctx.folder/'ACTUAL_60_ENDPOINT_PLAN.json',actual_plan)
    cases.append(CASES[12])
    original=json.loads((PROJECT/PHASE/'factorial_evaluation_request_blueprint.json').read_bytes())
    routed,changes=routed_blueprint(original)
    need(len(changes)==12 and len({x['endpoint_id'] for x in changes})==4,'Four endpoint route test')
    for before,after in zip(original['jobs'],routed['jobs']):
        if before['endpoint_id'] not in {x['endpoint_id'] for x in changes}:need(before==after,'Unrelated request changed')
    cases.append(CASES[6])
    locations=read(PROJECT/PHASE/'factorial_endpoint_location_plan.json')
    eids={r['endpoint_id'] for r in locations['endpoints'] if r['action']=='new_evaluation_after_admission'}
    mids=set(locations['metric_decomposition_final_endpoint_ids']);eid=sorted(eids)[0];mid=sorted(mids)[0]
    def line(path):return "du: cannot access '"+str(PROJECT/PHASE/path)+"': No such file or directory"
    valid=[f'factorial_evaluation/endpoints/{eid}/native_bdd.partial-'+('a'*32)+'/view/labels/val.cache.npy',
        f'factorial_evaluation/endpoints/{eid}/bdd_predictions/staging/000001-'+('b'*32)+'/00000001.json',
        f'metric_decomposition/endpoints/{mid}.partial-'+('c'*32)+'/factorial.json']
    for path in valid:need(evaluation_transient(line(path),PROJECT/PHASE,eids,mids),'Atomic publication path rejected')
    invalid=[valid[0].replace(eid,'unplanned'),valid[0].replace('.partial-'+('a'*32),''),valid[1]+'/../data.json',valid[1].replace('/staging/','/batches/'),valid[2].replace('factorial.json','other.bin')]
    for path in invalid:need(not evaluation_transient(line(path),PROJECT/PHASE,eids,mids),'Unrelated disk error accepted')
    need(not evaluation_transient(line(valid[0])+'\nPermission denied',PROJECT/PHASE,eids,mids),'Mixed error accepted')
    cases.append(CASES[7])
    path=ctx.folder/'journal_fixture.jsonl';journal=SegmentedJournal(path,8192,12)
    for number in range(45):journal.event('fixture',number=number)
    journal.close();index,last=verify_segments(path);need(len(index['parts'])>=4 and last['value']['number']==44,'Actual retained journal rotation')
    # Corrupt a separate copy so the original successful fixture remains intact.
    copy=ctx.folder/'mutated_journal';copy.mkdir()
    for item in [path.with_name(path.name+'.INDEX.json'),*[path.with_name(x['file']) for x in index['parts']]]:(copy/item.name).write_bytes(item.read_bytes())
    altered=copy/index['parts'][1]['file'];altered.write_bytes(altered.read_bytes().replace(b'fixture',b'fixturE',1))
    try:verify_segments(copy/path.name)
    except ValueError:pass
    else:raise RuntimeError('Mutated journal accepted')
    cases.append(CASES[5])
    import itertools
    cells=[]
    for a,b,c in itertools.product((0,1),repeat=3):
        v=.1+.02*a+.03*b+.04*c+.05*a*b+.06*a*c+.07*b*c+.08*a*b*c
        cells.append(dict(overlap_policy=('iou_grid','class_specific_iou')[a],recall_points=(101,40)[b],ignore_policy=('source_ignore','no_ignore')[c],mean_AP=v,class_AP={'person':v,'car':v}))
    results=metric_factor_effects(cells)
    need(all(abs(row['effect_pp']['mean_AP']-expected)<1e-12 for row,expected in zip(results['effects'],(9.5,11,12.5,9,10,11,8))),'Known-answer factorial effects')
    cases.append(CASES[8])
    outputs=ctx.folder/'fixture_outputs';outputs.mkdir()
    def task(label,device=None,kind='pass'):
        path=outputs/(label+'.json')
        code=f'''import os,sys,time,json,fcntl,subprocess
from pathlib import Path
sys.path.insert(0,{str(OLD)!r})
from retained_io import publish,read
from owned_runtime import identity,ROOT_LEASE_FD_NAME
assert os.environ.get('CUDA_VISIBLE_DEVICES')=='' and 'torch' not in sys.modules
fd=int(os.environ[ROOT_LEASE_FD_NAME]);held=os.fstat(fd)
lock=Path({str(PROJECT/AUX_PATH())!r})
linked=lock.stat();assert (held.st_dev,held.st_ino)==(linked.st_dev,linked.st_ino)
separate=os.open(lock,os.O_RDWR|os.O_NOFOLLOW)
try:
    locked=False
    try:fcntl.flock(separate,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:locked=True
    assert locked
finally:os.close(separate)
mode={kind!r}
if mode=='cleanup_signal':
    import signal
    sys.path.insert(0,{str(HERE)!r})
    from study_runtime import defer_cleanup_SIGTERM
    previous=signal.getsignal(signal.SIGTERM)
    def fail_on_signal(number,frame):raise RuntimeError('Unshielded fixture signal')
    signal.signal(signal.SIGTERM,fail_on_signal)
    with defer_cleanup_SIGTERM() as observed:
        os.kill(os.getpid(),signal.SIGTERM)
        assert observed==[signal.SIGTERM]
    assert signal.getsignal(signal.SIGTERM) is fail_on_signal
    signal.signal(signal.SIGTERM,previous)
if mode=='fail':raise SystemExit(7)
if mode=='timeout':time.sleep(60)
if mode=='orphan':
    child=subprocess.Popen([sys.executable,'-B','-c','import time;time.sleep(60)'],start_new_session=True,pass_fds=(fd,))
    publish(Path({str(path)!r}),{{'escaped_pid':child.pid,'parent':os.getpid()}})
else:
    time.sleep(1)
    publish(Path({str(path)!r}),{{'status':'passed','identity':identity(os.getpid()),'inherited_common_lock_verified':True,'GPU_work':False,'model_loads':0}})
'''
        return {'endpoint_id':label,'device':device,'environment':{},'command':[sys.executable,'-B','-c',code]}
    def verified(item):
        path=outputs/(item['endpoint_id']+'.json');value=read(path)
        need(value['status']=='passed' and value['inherited_common_lock_verified'] and identity(value['identity']['pid']) is None,'CPU fixture output or process absence')
        return {path.relative_to(PROJECT).as_posix():file_sha(path)}
    ctx.stage(ctx.folder.relative_to(PROJECT)/'paired_CPU','fixture_pair',[task('lane0',0),task('lane1',1)],verified,120,synthetic_devices=True);cases.append(CASES[0])
    ctx.stage(ctx.folder.relative_to(PROJECT)/'serial_CPU','fixture_serial',[task('serial')],verified,120);cases.append(CASES[1])
    ctx.stage(ctx.folder.relative_to(PROJECT)/'cleanup_signal_CPU','fixture_cleanup_signal',[task('cleanup_signal',kind='cleanup_signal')],verified,120);cases.append(CASES[13])
    for kind,case in (('fail',CASES[2]),('timeout',CASES[3]),('orphan',CASES[4])):
        directory=ctx.folder/(kind+'_fixture');before=set(ctx.additional)
        try:ctx.stage(directory.relative_to(PROJECT),'fixture_'+kind,[task(kind,kind=kind)],verified,12 if kind=='timeout' else 120)
        except RuntimeError as error:
            need((directory/'FAILURE.json').exists(),'Missing expected rejection evidence')
            new=set(ctx.additional)-before;need(len(new)==1,'Expected one fixture worker')
            for name in new:
                row=read(PROJECT/name);need(row.get('ended_unix') and identity(row['pid']) is None and not row['GPU_job'],'Rejected fixture not drained/closed')
                if row['status']!='completed' or row['returncode']!=0:expected_failed[name]=file_sha(PROJECT/name)
            if kind=='orphan':need(identity(read(outputs/'orphan.json')['escaped_pid']) is None,'Escaped descendant remains')
            evidence[kind]=dict(error=str(error),rows={name:file_sha(PROJECT/name) for name in new})
        else:raise RuntimeError('Expected controlled CPU rejection did not occur')
        cases.append(case);ctx.check()
    control_output=ctx.folder/'dispatch_fixture'
    control_task={'endpoint_id':'dispatch_control','device':None,'environment':{},'command':[sys.executable,'-B',str(HERE/'test_dispatch_control.py'),str(control_output)]}
    def verify_control(item):
        value=read(control_output/'COMPLETE.json')
        need(value['status']=='dispatch_control_test_passed' and value['scientific_children_spawned']==0 and value['model_loads']==0 and value['GPU_work'] is False,'Dispatch fixture scope')
        return {(control_output/'COMPLETE.json').relative_to(PROJECT).as_posix():file_sha(control_output/'COMPLETE.json')}
    ctx.stage(ctx.folder.relative_to(PROJECT)/'dispatch_control_stage','fixture_dispatch',[control_task],verify_control,120)
    cases.append(CASES[9])
    from gradient_run import fixed_inputs
    _,paths,batches=fixed_inputs(ctx)
    request=ctx.folder/'COMPATIBILITY_REQUEST.json';output=ctx.folder/'COMPATIBILITY_RESULT.json'
    publish(request,dict(manifest_sha256=ctx.expected,paths=paths,output=output.relative_to(PROJECT).as_posix()))
    item={'endpoint_id':'actual36_compatibility','device':None,'environment':{},'command':[sys.executable,'-B',str(HERE/'validate_gradient_compatibility.py'),str(request),file_sha(request)]}
    def verified_compatibility(task):
        value=read(output)
        need(value['status']=='all36_authenticated_CPU_assemblies_passed' and value['paths']==36 and value['model_forwards']==0 and value['GPU_work'] is False,'Actual36 raw-state CPU compatibility')
        return {output.relative_to(PROJECT).as_posix():file_sha(output)}
    ctx.stage(ctx.folder.relative_to(PROJECT)/'compatibility_CPU','fixture_compatibility',[item],verified_compatibility,900)
    cases.append(CASES[14])
    need(set(cases)==set(CASES) and len(cases)==15 and 'torch' not in sys.modules,'Native CPU integration scope')
    value={'status':'all_native_operational_cases_passed','case_count':15,'cases':cases,'expected_failure_rows':expected_failed,
        'rejection_evidence':evidence,'parent_model_loads':0,'model_forwards':0,'GPU_work':False,
        'CPU_affinity':sorted(os.sched_getaffinity(0)),'CPU_raw_state_loads':36,'CPU_model_template_loads':72,'actual36_compatibility_result':{'path':output.relative_to(PROJECT).as_posix(),'sha256':file_sha(output)},
        'scientific_boundaries_synthetic':True,
        'original_workflow_full60_assembly_tests_reused':True}
    publish(ctx.folder/'CPU_RESULT.json',value);return value


def AUX_PATH():return PHASE+'_auxiliary026/ownership/execution.lock'

if __name__=='__main__':
    expected=sys.argv[1];source_check(expected)
    affinity=sorted(os.sched_getaffinity(0));need(len(affinity)>=4,'Four available CPU cores for independent monitoring');os.sched_setaffinity(0,set(affinity[:4]))
    resource.setrlimit(resource.RLIMIT_CPU,(1740,1800));resource.setrlimit(resource.RLIMIT_FSIZE,(16*1024*1024,16*1024*1024))
    Study('CPU_integration',expected,1800,0,validation=True,CPU_hours_limit=.5).run(run)
