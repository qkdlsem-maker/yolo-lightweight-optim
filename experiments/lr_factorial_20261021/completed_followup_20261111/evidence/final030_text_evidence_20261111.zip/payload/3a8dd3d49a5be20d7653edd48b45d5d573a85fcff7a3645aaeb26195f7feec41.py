"""Immutable, independent copies of the prespecified 64 training images only."""
import hashlib
import json
from pathlib import Path
import yaml

PREFIX = 'gradient_probe_20261021'
COUNT = 64
BATCH = 32


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def select_names(names):
    assert len(names) == len(set(names)) >= COUNT
    assert all(Path(n).name == n and n.endswith('.jpg') and '\\' not in n for n in names)
    return sorted(names, key=lambda n: (hashlib.sha256((PREFIX+n).encode()).hexdigest(), n))[:COUNT]


def cache_hashes(source):
    return {str(p): sha(p) if p.exists() else None for p in
            (source/'labels/train.cache', source/'labels/val.cache')}


def expected_view(source_yaml, destination, expected_train=69863):
    source_yaml, destination = Path(source_yaml).absolute(), Path(destination).absolute()
    config = yaml.safe_load(source_yaml.read_bytes())
    source = Path(config['path'])
    names = config['names']
    if isinstance(names, dict):
        assert set(names) == set(range(len(names)))
        names = [names[i] for i in range(len(names))]
    assert isinstance(names, list) and len(names) == 10 and all(isinstance(n,str) for n in names)
    assert source.is_absolute() and config['train'] == 'images/train'
    assert config['val'] == 'images/val'
    assert destination != source and source not in destination.parents
    assert not destination.is_symlink()
    images = sorted((source/'images/train').glob('*.jpg'))
    assert len(images) == expected_train
    selected = select_names([p.name for p in images])
    entries = []
    for rank, name in enumerate(selected):
        original_image = source/'images/train'/name
        original_label = source/'labels/train'/(Path(name).stem+'.txt')
        assert original_image.is_file() and original_label.is_file()
        entries.append(dict(rank=rank, batch=rank//BATCH, position=rank%BATCH, name=name,
            selection_sha256=hashlib.sha256((PREFIX+name).encode()).hexdigest(),
            source_image=str(original_image), source_label=str(original_label),
            view_image=str(destination/'images/train'/name),
            view_label=str(destination/'labels/train'/original_label.name),
            image_sha256=sha(original_image), label_sha256=sha(original_label)))
    return dict(schema='fixed_gradient_training_view_v1', source_yaml=str(source_yaml),
        source_yaml_sha256=sha(source_yaml), source_train_images=expected_train,
        destination=str(destination), images=COUNT, batch_size=BATCH, batches=2,
        selection=PREFIX+' + filename UTF8, SHA256 ascending; retain rank order within two batches',
        pool='training only; no validation or KITTI images; no outcome selection',
        names=names, shared_cache_sha256=cache_hashes(source), entries=entries)


def verify_view(destination, expected):
    destination = Path(destination).absolute()
    assert not destination.is_symlink()
    path = destination/'view_manifest.json'
    assert not path.is_symlink() and json.loads(path.read_bytes()) == expected
    for kind in ('image', 'label'):
        directory = destination/('images/train' if kind == 'image' else 'labels/train')
        assert not directory.is_symlink() and not directory.parent.is_symlink()
        assert sorted(p.name for p in directory.iterdir()) == sorted(
            Path(e['view_'+kind]).name for e in expected['entries'])
        for row in expected['entries']:
            view, original = Path(row['view_'+kind]), Path(row['source_'+kind])
            assert view.is_file() and not view.is_symlink() and not view.samefile(original)
            assert sha(view) == sha(original) == row[kind+'_sha256']
    return dict(status='fixed_training_copies_verified_only',
        view_manifest_sha256=sha(path), images=COUNT, batches=2, batch_size=BATCH)


def create_view(source_yaml, destination, expected_train=69863):
    expected = expected_view(source_yaml, destination, expected_train)
    destination = Path(destination).absolute()
    if (destination/'view_manifest.json').exists():
        return verify_view(destination, expected)
    destination.mkdir(parents=True, exist_ok=False)
    for part in ('images/train', 'labels/train'):
        (destination/part).mkdir(parents=True)
    for row in expected['entries']:
        for kind in ('image', 'label'):
            raw = Path(row['source_'+kind]).read_bytes()
            assert hashlib.sha256(raw).hexdigest() == row[kind+'_sha256']
            with Path(row['view_'+kind]).open('xb') as stream:
                stream.write(raw)
    assert expected_view(source_yaml, destination, expected_train) == expected
    with (destination/'view_manifest.pending').open('x') as stream:
        stream.write(json.dumps(expected, indent=2)+'\n')
    (destination/'view_manifest.pending').rename(destination/'view_manifest.json')
    return verify_view(destination, expected)
