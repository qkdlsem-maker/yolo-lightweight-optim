"""Capture/restore the same four RNG components used by the original trainer."""
import io
import random
import numpy as np
import torch


def capture_rng_state(device):
    return {'rng_python': random.getstate(), 'rng_numpy': np.random.get_state(),
            'rng_torch': torch.get_rng_state(), 'rng_cuda': torch.cuda.get_rng_state(device)}


def restore_rng_state(state, device):
    random.setstate(state['rng_python'])
    np.random.set_state(state['rng_numpy'])
    torch.set_rng_state(state['rng_torch'].cpu())
    torch.cuda.set_rng_state(state['rng_cuda'].cpu(), device)


def capture_rng_bytes(device):
    stream = io.BytesIO()
    torch.save(capture_rng_state(device), stream)
    return stream.getvalue()


def restore_rng_bytes(data, device):
    state = torch.load(io.BytesIO(data), map_location='cpu', weights_only=False)
    restore_rng_state(state, device)
