"""Request/command/output metadata adapter for unchanged original evaluators.

No CLI, process launch, model load, scoring, admission or automatic wait.
Callers must authenticate the supplied completed-model/current-input evidence.
Metadata checks here do NOT replace the original independent numerical audit.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path

from continuation_artifact_receipts import ROOT, PROTOCOL_SHA, loads
from gradient_path_roster import relative, valid_sha

STEPS = (
    ('native_bdd', 'run_native_bdd_validation.py', True),
    ('bdd_predictions', 'run_prediction_archive.py', True),
    ('bdd_common', 'score_common_archive.py', False),
    ('kitti_predictions', 'run_prediction_archive.py', True),
    ('kitti_common', 'score_common_archive.py', False),
    ('kitti_native', 'score_native_kitti_archive.py', False))
AUDITOR_SHA = 'abf66b83332814f890d58f18c4962e886e8e26625295820fbb136aa9fb3141e6'
BLUEPRINT_SHA = '58e7707eaa846e82514827c488e87fc14f03843bae2a7f9979d2f05367939f27'
ISOLATED = 'review_20261017_independent/evaluation_deps'
PREDICT_MODULES = ('ultralytics.engine.predictor', 'ultralytics.nn.autobackend',
    'ultralytics.models.yolo.detect.predict', 'ultralytics.data.augment',
    'ultralytics.utils.ops', 'ultralytics.nn.tasks')
NATIVE_MODULES = ('ultralytics.engine.validator', 'ultralytics.models.yolo.detect.val',
    'ultralytics.data.dataset', 'ultralytics.data.base', 'ultralytics.data.build',
    'ultralytics.data.utils', 'ultralytics.utils.metrics', 'ultralytics.cfg')
NATIVE_CORE = {
    'executable':'4524fb43a3b39662140f1f41a749d3cf42e395e18cd23420260fa796d89b64c9',
    'original_source':'b16410ba8914a732405ec937a16d1cd039b6e3bf7d9e8edb6dd3ec79c15892b4',
    'adapted_source':'20c521ef2b30b37f34b52cdbfee3c6e7daa0d3650a603c2b209a5dd39f91c45e',
    'build_manifest':'427e55b18221e0c67788c0b81240d1b31f20d0e77eb6b3f3c6eba7339ee28a33',
    'prior_synthetic_proof':'444b92667b3656ccba487678ffbf088d03978fb3354fcd1a01ea88eff7ec3527'}


def canonical(value):
    return (json.dumps(value, sort_keys=True, separators=(',', ':'), allow_nan=False)+'\n').encode()


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def plan_from_bound(accepted, blueprint, acceptance_ref):
    """Pure plan assembly, never proof of authenticity or permission to run."""
    assert set(acceptance_ref) == {'path','sha256'}
    assert acceptance_ref['path'] == str(ROOT/'factorial_training_acceptance.json')
    valid_sha(acceptance_ref['sha256'])
    assert accepted['schema'] == 'factorial_training_model_bindings_v1'
    assert accepted['status'] == 'completed_training_model_bytes_bound_not_evaluation_admission'
    assert accepted['protocol_sha256'] == blueprint['protocol_sha256'] == PROTOCOL_SHA
    assert accepted['completed_new_bases'] == 6 and accepted['completed_new_continuations'] == 27
    assert accepted['evaluation_admitted'] is accepted['new_GPU_work'] is accepted['model_loaded'] is accepted['model_audit_repeated'] is False
    assert blueprint['status'] == 'prepared_unbound_requests_not_execution_admission'
    assert blueprint['execution_admitted'] is False
    original = blueprint['jobs']; endpoints = accepted['new_evaluation_endpoints']
    assert len(original) == len(endpoints) == 60 and len(blueprint['reuse_only']) == 24
    assert len({v['endpoint_id'] for v in endpoints}) == 60
    prepared = accepted['model_bound_request_blueprint']
    assert prepared['execution_admitted'] is prepared['new_inference_performed'] is False
    expected = deepcopy(blueprint)
    expected['status'] = 'completed_model_hashes_bound_current_data_and_execution_admission_pending'
    for job, endpoint in zip(expected['jobs'], endpoints):
        assert job['endpoint_id'] == endpoint['endpoint_id'] and job['role'] == endpoint['role']
        cp = endpoint['checkpoint']; valid_sha(cp['sha256']); relative(cp['path'])
        assert set(cp)=={'path','sha256'}
        for q in (job['native_bdd_request'], *job['prediction_requests'].values()):
            assert q['checkpoint'] == {'path':cp['path'],'sha256':None}
            q['checkpoint'] = deepcopy(cp)
        job['completion_evidence_required'] = deepcopy(endpoint['completion_evidence'])
    assert prepared == expected, 'Bound requests changed beyond authenticated model/proof binding'
    jobs = deepcopy(prepared['jobs'])
    for index, job in enumerate(jobs):
        assert job['output'] == blueprint['output_root']+'/endpoints/'+job['endpoint_id']
        relative(job['output'])
        job.update(lane=index%2, wave=index//2+1)
    return {'schema':'factorial_evaluation_execution_plan_v1',
        'status':'assembled_model_bound_plan_not_execution_admission', 'execution_admitted':False,
        'protocol':{'path':str(ROOT/'protocol.json'),'sha256':PROTOCOL_SHA},
        'roster':deepcopy(acceptance_ref), 'roster_scope':'Authenticated60-model acceptance, not the old48 roster',
        'output_root':blueprint['output_root'],'jobs':jobs,'reuse_only':deepcopy(blueprint['reuse_only']),
        **deepcopy(blueprint['unchanged_evaluator_bindings']),
        'global_resource_caps':deepcopy(blueprint['global_resource_caps']),
        'independent_auditor_sha256':AUDITOR_SHA,'unchanged_scientific_algorithms':True}


def runtime_contract(inputs):
    assert inputs['schema'] == 'factorial_current_evaluation_inputs_v1'
    assert inputs['status'] == 'current_input_bytes_authenticated_not_evaluation_admission'
    assert inputs['protocol_sha256'] == PROTOCOL_SHA and inputs['evaluation_admitted'] is False
    rt=deepcopy(inputs['runtime']); bound=inputs['bound_artifacts']
    native={}
    for module in PREDICT_MODULES+NATIVE_MODULES:
        suffix=module.replace('.', '/')
        candidates=[(n,h) for n,h in bound.items() if n.startswith('venv/') and
                    (n.endswith('/'+suffix+'.py') or n.endswith('/'+suffix+'/__init__.py'))]
        assert len(candidates)==1, 'Missing/ambiguous authenticated native source: '+module
        native[module]=candidates[0][1]
    cfg=[h for n,h in bound.items() if n.startswith('venv/') and n.endswith('/ultralytics/cfg/default.yaml')]
    assert len(cfg)==1
    rt['prediction_sources']={n:native[n] for n in PREDICT_MODULES}
    rt['validation_sources']={**{n:native[n] for n in NATIVE_MODULES},'default_cfg_yaml':cfg[0]}
    return rt


def spec(stage):
    matches=[s for s in STEPS if s[0]==stage]; assert len(matches)==1
    return matches[0]


def request_path(plan,job,stage):
    spec(stage)
    assert job in plan['jobs']
    return plan['output_root']+'/requests/'+job['endpoint_id']+'/'+stage+'.json'


def request(files,plan,job,stage):
    spec(stage); assert job in plan['jobs']
    if stage=='native_bdd':return deepcopy(job['native_bdd_request'])
    if stage in ('bdd_predictions','kitti_predictions'):
        return deepcopy(job['prediction_requests'][stage.split('_')[0]])
    dataset=stage.split('_')[0];native=stage=='kitti_native'
    archive=job['output']+'/'+dataset+'_predictions'
    # No early or partial archive may be bound into a scoring request.
    manifest=loads(files.read(archive+'/MANIFEST.json'))
    complete=loads(files.read(archive+'/COMPLETE.json'))
    assert manifest['schema']=='prediction_archive_v1' and complete['schema']=='prediction_archive_complete_v1'
    assert complete['manifest_sha256']==files.sha(archive+'/MANIFEST.json')
    b=manifest['bindings'];q=job['prediction_requests'][dataset]
    assert b['endpoint_id']==job['endpoint_id'] and b['dataset_id']==dataset
    assert b['checkpoint_sha256']==q['checkpoint']['sha256'] and b['protocol_sha256']==PROTOCOL_SHA
    assert b['source_sha256']==dict(q['source_sha256'],frozen_request=digest(canonical(q)))
    value={'schema':'native_kitti_archive_scoring_request_v1' if native else 'common_archive_scoring_request_v1',
        'archive_path':archive,'archive_manifest_sha256':files.sha(archive+'/MANIFEST.json'),
        'archive_complete_sha256':files.sha(archive+'/COMPLETE.json')}
    if native:
        value.update(source_sha256=deepcopy(plan['kitti_source_sha256']),
            native_core_paths=deepcopy(plan['native_core_paths']),label_zip=deepcopy(plan['label_zip']))
    else:
        names=['bdd_common'] if dataset=='bdd' else ['kitti_source_ignore','kitti_no_ignore_sensitivity']
        value.update(dataset=dataset,source_sha256=deepcopy(plan['common_source_sha256']),
            annotation_views={n:deepcopy(plan['annotation_views'][n]) for n in names})
    return value


def task(files,plan,job,stage):
    assert job in plan['jobs']
    _,script,gpu=spec(stage)
    cmd=[str(files.project/'venv/bin/python'),str(Path(plan['evaluation_tools'])/script),
         '--request',request_path(plan,job,stage),'--output',job['output']+'/'+stage]
    device=job['lane'] if gpu else None
    assert type(job['lane']) is int and job['lane'] in (0,1)
    if gpu:cmd+=['--device',str(device)]
    return {'endpoint_id':job['endpoint_id'],'command':cmd,'device':device,
        'environment':{'PYTHONPATH':str(files.project/ISOLATED)}}


def audit_task(files,plan,job,plan_ref):
    assert job in plan['jobs'];valid_sha(plan_ref['sha256']);relative(plan_ref['path'])
    cmd=[str(files.project/'venv/bin/python'),str(Path(plan['evaluation_tools'])/'audit_final_evaluation.py'),
        '--plan',plan_ref['path'],'--plan-sha256',plan_ref['sha256'],
        '--output',plan['output_root']+'/audits','--endpoint',job['endpoint_id']]
    # --endpoint explicitly avoids the original CLI's48-endpoint batch mode.
    return {'endpoint_id':job['endpoint_id'],'command':cmd,'device':None,
        'environment':{'PYTHONPATH':str(files.project/ISOLATED)}}


def check_gpu_runtime(manifest,stage,device,uuid,contract):
    assert type(device) is int and device in (0,1)
    rt=manifest['runtime'] if stage=='native_bdd' else manifest['bindings']['runtime']
    assert rt['requested_device']==rt['CUDA_VISIBLE_DEVICES']==str(device)
    assert rt['selected_device']=='cuda:0' and rt['gpu']['uuid'].removeprefix('GPU-')==uuid.removeprefix('GPU-')
    for n in ('python','platform','packages'):assert rt[n]==contract[n]
    assert rt['native_source_sha256']==contract['prediction_sources']
    assert rt['torch_cuda_build']=='12.1' and rt['torch_num_threads']==2 and rt['evaluation_seed']==0
    for n in ('deterministic_algorithms','deterministic_warn_only','cudnn_deterministic'):assert rt[n] is True
    assert rt['cudnn_benchmark'] is False
    if stage=='native_bdd':assert manifest['native_validation_source_sha256']==contract['validation_sources']


def verify_step(files,plan,job,stage,frozen_request_sha,uuid,contract):
    """Bind new output metadata; full saved-array/hash/numerical audit is later."""
    qpath=request_path(plan,job,stage);q=loads(files.read(qpath,frozen_request_sha))
    assert q==request(files,plan,job,stage)
    out=job['output']+'/'+stage
    raw=files.read(out+'/MANIFEST.json');m=loads(raw);c=loads(files.read(out+'/COMPLETE.json'))
    assert raw==canonical(m) and c['manifest_sha256']==digest(raw)
    _,_,gpu=spec(stage)
    if stage=='native_bdd':
        assert m['schema']=='native_bdd_validation_manifest_v1' and m['request']==q
        assert c['schema']=='native_bdd_validation_complete_v1'
    elif stage in ('bdd_predictions','kitti_predictions'):
        assert m['schema']=='prediction_archive_v1' and c['schema']=='prediction_archive_complete_v1'
        b=m['bindings'];assert b['endpoint_id']==q['endpoint_id'] and b['dataset_id']==q['dataset_id']
        assert b['checkpoint_sha256']==q['checkpoint']['sha256'] and b['protocol_sha256']==q['protocol']['sha256']
        assert b['source_sha256']==dict(q['source_sha256'],frozen_request=digest(canonical(q)))
        assert b['inference']=={'imgsz':640,'batch':32,'conf':.001,'nms_iou':.7,'max_det':300,'half':False,'rect':False}
        count=10000 if q['dataset_id']=='bdd' else 7481
        assert len(m['images'])==c['images']==count and m['batch_size']==32
        assert m['images']==loads(files.read(q['image_manifest']['path'],q['image_manifest']['sha256']))
        assert c['batches']==len(c['batch_commit_sha256'])==(count+31)//32
        for h in c['batch_commit_sha256']:valid_sha(h)
    else:
        prefix='native_kitti' if stage=='kitti_native' else 'common'
        assert m['schema']==prefix+'_archive_scoring_manifest_v1' and m['request']==q
        assert c['schema']==prefix+'_archive_scores_complete_v1'
        archive=loads(files.read(q['archive_path']+'/MANIFEST.json',q['archive_manifest_sha256']))
        assert m['prediction_bindings']==archive['bindings']
        if stage!='kitti_native':
            assert m['runtime']=={'pycocotools_version':contract['isolated_pycocotools'],
                'numpy_version':contract['packages']['numpy'],
                'cocoeval_python_sha256':contract['isolated_dependency_files']['pycocotools/cocoeval.py']}
            assert set(c['outputs'])=={n+'.json' for n in q['annotation_views']}
        else:
            assert m['images']==7481 and len(m['label_member_sha256'])==7481
            assert m['core_sha256']==NATIVE_CORE
            assert m['runtime']['python'].split()[0]==contract['python'] and m['runtime']['platform']==contract['platform']
    if gpu:check_gpu_runtime(m,stage,job['lane'],uuid,contract)
    return {qpath:frozen_request_sha,out+'/MANIFEST.json':digest(raw),out+'/COMPLETE.json':files.sha(out+'/COMPLETE.json')}
