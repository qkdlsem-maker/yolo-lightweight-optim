"""Read authenticated diagnostics; do not reconstruct missing historical counters."""
import json,math
from pathlib import Path
from study_runtime import PHASE,need
from completed_training_bridge import reroute_checkpoint,merge
from continuation_artifact_receipts import loads


def epoch_record(raw,historical):
    def unique(pairs):
        value={}
        for key,item in pairs:
            need(key not in value,'Duplicate epoch diagnostic key');value[key]=item
        return value
    marker_key='_original_nonfinite_literal'
    record=json.loads(raw,object_pairs_hook=unique,parse_constant=lambda x:{marker_key:x})
    median=record.get('median_unclipped_grad_norm');reason=None
    if isinstance(median,dict) and set(median)=={marker_key}:
        need(historical,'Unexpected new nonfinite diagnostic literal')
        reason='historical_'+median[marker_key]+'_median_does_not_identify_nonfinite_backward_count'
        record['median_unclipped_grad_norm']=None
    def no_other_markers(value):
        if isinstance(value,dict):
            need(marker_key not in value,'Nonfinite value outside the documented historical median')
            for x in value.values():no_other_markers(x)
        elif isinstance(value,list):
            for x in value:no_other_markers(x)
        elif isinstance(value,float):need(math.isfinite(value),'Nonfinite epoch number')
    no_other_markers(record)
    return record,reason


def collect(files,accepted):
    archive=PHASE+'/prepared_history/gradient_path_roster_preparation_20261022_0636/'
    roster=loads(files.read(archive+'gradient_path_roster.json','1d217fea0e74b269101d56dcbc1efcf1acd67719966eadcec1ac3fc6af742b63'))
    bound=dict(accepted['bound_file_sha256']);proofs={};bases=[]
    for endpoint in accepted['new_evaluation_endpoints']:
        if endpoint['stage']=='continuation':
            label=endpoint['endpoint_id'].rsplit('_e',1)[0]
            proofs[label]=endpoint['completion_evidence']['independent_audit']
        else:
            name=endpoint['completion_evidence']['independent_audit'];report=loads(files.read(name,bound[name]));run=report['run']
            bases.append({key:run[key] for key in ('model','seed','epochs','actual_step_counts','native_EMA_updates',
                'initial_parameter_digest','raw_final_parameter_digest','EMA_parameter_digest','raw_changed_parameter_tensors',
                'fixed_dfl_preserved','checkpoint_matches_raw_EMA_at_saved_precision','finite_saved_tensors')}|
                {'audit':{'path':name,'sha256':bound[name]},'historical_base_counters_reconstructed':False})
    need(len(bases)==6 and len(proofs)==27,'Training diagnostic roster')
    trajectories=[];references={};initial={};paired_comparisons=0
    for row in roster['paths']:
        historical=row['origin']=='historical_reuse'
        if historical:
            proof=row['historical_audit'];report=loads(files.read(proof['path'],proof['sha256']))
            need(report['status']=='passed' and report['epochs']==40,'Historical training audit')
            merge(bound,report['bound_sha256'])
            counts=dict(applied=report['optimizer_applied_updates'],skipped=report['optimizer_skipped_updates'])
            counts['attempted']=counts['applied']+counts['skipped']
            finite=report['finite_final_student_adapter_ema_optimizer_tensors'];nonfinite=None
        else:
            name=proofs[row['label']];proof={'path':name,'sha256':bound[name]};report=loads(files.read(name,proof['sha256']))
            need(report['status']=='completed_evidence_passed','New training audit')
            counts=report['actual_step_counts'];finite=report['finite_saved_states'];nonfinite=report['native_gradient_nonfinite_batches']
        config_name=reroute_checkpoint(row['config'],row['label']);config=loads(files.read(config_name,bound[config_name]));directory=Path(config_name).parent
        need(config['arm']==row['arm'] and config['lr']==row['lr'] and config['kd_weight']==row['kd_weight'],'Training diagnostic identity')
        initial.setdefault(row['pair_seed'],{'source':set(),'teacher':set(),'new_student':set(),'new_adapter':set()})
        group=initial[row['pair_seed']];group['source'].add(config['student_sha256']);group['teacher'].add(config['teacher_sha256'])
        if not historical:
            group['new_student'].add(config['initial_raw_student_digest']);group['new_adapter'].add(config['initial_adapter_digest'])
        epochs=[]
        for epoch in range(1,41):
            name=(directory/('epoch_%02d.json'%epoch)).as_posix();record,reason=epoch_record(files.read(name,bound[name]),historical)
            need(record['epoch']==epoch and record['batches']==1092,'Fixed training epoch diagnostic')
            key=(row['pair_seed'],epoch);value=record['first_two_input_sha256']
            need(len(value)==2 and all(isinstance(x,str) and len(x)==64 for x in value),'Sampled training input digest shape')
            if key not in references:references[key]=value
            else:
                need(references[key]==value,'Paired training input mismatch');paired_comparisons+=1
            epochs.append({k:record[k] for k in ('epoch','lr','det_loss','feature_loss','batches','optimizer_steps_skipped','median_unclipped_grad_norm','first_two_input_sha256')}|
                {'gradient_median_unavailable_reason':reason,'gradient_norm_nonfinite_batches':record.get('gradient_norm_nonfinite_batches'),
                 'finite_gradient_clipped_batches':record.get('finite_gradient_clipped_batches'),
                 'source':{'path':name,'sha256':bound[name]}})
        need(counts['attempted']==sum(x['batches'] for x in epochs)==43680 and counts['skipped']==sum(x['optimizer_steps_skipped'] for x in epochs),'Audited optimizer counters disagree with epoch records')
        trajectories.append({'label':row['label'],'pair_seed':row['pair_seed'],'arm':row['arm'],'learning_rate':row['lr'],
            'origin':'historical_reuse' if historical else 'new','actual_step_counts':counts,'finite_saved_states':finite,
            'observed_nonfinite_gradient_batches':nonfinite,'nonfinite_batch_count_unavailable_reason':'historical_per_batch_counters_not_recorded' if historical else None,
            'initial_adapter_digest':config.get('initial_adapter_digest'),'historical_initial_adapter_digest_reconstructed':False,
            'epochs':epochs,'audit':proof})
    need(paired_comparisons==1200 and len(trajectories)==36,'Full36 trajectory pairing')
    for seed,values in initial.items():
        need(all(len(v)==1 for v in values.values()),'Starting source or recorded new initial conditions differ within pair')
    def total(items):return {k:sum(row['actual_step_counts'][k] for row in items) for k in ('attempted','applied','skipped')}
    return {'status':'all36_training_diagnostics_and_sampled_pairing_verified','new_bases':bases,'trajectories':trajectories,
        'new_base_optimizer_totals':total(bases),'new27_optimizer_totals':total([r for r in trajectories if r['origin']=='new']),
        'historical9_optimizer_totals':total([r for r in trajectories if r['origin']=='historical_reuse']),
        'sampled_pairing':{'pairs':6,'paths_per_pair':6,'epochs_per_path':40,'sampled_batches_per_epoch':2,
            'comparisons_to_within_pair_reference':1200,'all_compared_hashes_equal':True,'all_training_batches_archived':False},
        'starting_conditions':{str(seed):{key:next(iter(value)) for key,value in groups.items()} for seed,groups in initial.items()},
        'historical_instrumentation_reconstructed':False,
        'limits':['Historical9 trajectories lack per-batch gradient counts and recorded initial adapter hashes.',
            'Historical undefined gradient medians remain null with their original literal identified; they do not count nonfinite backward passes.',
            'New base instrumentation does not reconstruct old base counters. Source checkpoints share the same COCO pretraining.',
            'Epoch loss and gradient summaries are training diagnostics, not the standalone evaluation or the fixed FP32 probes.']}
