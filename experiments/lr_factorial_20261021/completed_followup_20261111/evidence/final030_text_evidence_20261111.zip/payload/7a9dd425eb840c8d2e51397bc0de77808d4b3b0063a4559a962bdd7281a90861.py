"""Read-only audit of one completed NEW40-epoch continuation, never a launcher.

Public entry requires the real frozen study Context and six completed base
audits. The lower-level value/file functions are test seams, not authorization.
No forward pass, validation, RNG restoration, optimizer step or file repair.
An audit may still read completed evidence after a budget stop. It cannot admit
new work or substitute for the separately required GPU parity/replay gate.
"""
import argparse
import hashlib
import math
import os
from pathlib import Path, PurePosixPath
import numpy as np
import torch
import continuation_artifact_receipts as artifacts
import continuation_contract as contract
import continuation_evidence_checks as core
import continuation_observer as observer
import continuation_preflight_reader as reader
from continuation_preflight_runtime import verify_completed_bases

ROOT = contract.ROOT
ENDPOINTS = (10, 20, 40)
AUDITOR = 'continuation_completion_audit.py'
MANIFEST = ROOT / 'continuation_completion_sources.json'


def check_rng(value):
    assert value.keys() == set(core.RNG_KEYS)
    observer.assert_exact(value, value)
    py, np_state = value['rng_python'], value['rng_numpy']
    assert type(py) is tuple and len(py) == 3 and py[0] == 3
    assert type(py[1]) is tuple and len(py[1]) == 625
    assert all(type(x) is int and 0 <= x <= 2**32 - 1 for x in py[1][:-1])
    assert type(py[1][-1]) is int and 0 <= py[1][-1] <= 624
    assert py[2] is None or type(py[2]) is float and math.isfinite(py[2])
    assert type(np_state) is tuple and len(np_state) == 5 and np_state[0] == 'MT19937'
    assert np_state[1].dtype == np.uint32 and np_state[1].shape == (624,)
    assert type(np_state[2]) is int and 0 <= np_state[2] <= 624
    assert type(np_state[3]) is int and np_state[3] in (0, 1)
    assert type(np_state[4]) is float and math.isfinite(np_state[4])
    for name in ('rng_torch', 'rng_cuda'):
        v = value[name]
        assert isinstance(v, torch.Tensor) and v.device.type == 'cpu'
        assert v.dtype == torch.uint8 and v.ndim == 1 and v.numel() > 0


def check_raw(state, record, source, config, ledger):
    assert state.keys() == set(core.STATE_KEYS) | set(core.RNG_KEYS) | {'epoch', 'actual_step_counts', 'elapsed'}
    observer.assert_exact(state, state)  # Includes finite optimizer/scaler, not historical gradients.
    core.integer(state['epoch'], 1); assert state['epoch'] == record['epoch']
    core.finite(state['elapsed'], 0.)
    observer.assert_exact(state['actual_step_counts'], record['actual_step_counts'])
    core.check_snapshot_record(state, record)
    check_rng({k: state[k] for k in core.RNG_KEYS})
    initial = reader.as_loaded_float(source.state_dict())
    parameters = reader.as_loaded_float(dict(source.named_parameters()))
    assert state['student'].keys() == state['ema'].keys() == initial.keys()
    for key, original in initial.items():
        for name in ('student', 'ema'):
            observed = state[name][key]
            assert observed.shape == original.shape and observed.dtype == original.dtype
    fixed = [k for k in parameters if 'dfl.conv.weight' in k]
    assert len(fixed) == 1
    observer.assert_exact(state['student'][fixed[0]], parameters[fixed[0]], 'fixed_DFL')
    deltas = [float((state['student'][k] - v).abs().max()) for k, v in parameters.items()]
    assert max(deltas) > 0
    assert state['adapters'].keys() == {f'{i}.{kind}' for i in range(3) for kind in ('weight', 'bias')}
    for i, (sc, tc) in enumerate(zip(config['student_channels'], config['teacher_channels'])):
        for kind, shape in [('weight', (tc, sc, 1, 1)), ('bias', (tc,))]:
            value = state['adapters'][f'{i}.{kind}']
            assert value.dtype == torch.float32 and tuple(value.shape) == shape
    unchanged = core.training_digest(state['adapters']) == config['initial_adapter_digest']
    assert unchanged == (config['arm'] == 'control'), 'Unexpected adapter update/preservation'
    optimizer = state['optimizer']; assert optimizer.keys() == {'state', 'param_groups'}
    assert len(optimizer['param_groups']) == 1
    group = optimizer['param_groups'][0]
    for key, value in {'lr': record['lr'], 'momentum': .937, 'weight_decay': .0005,
                       'dampening': 0, 'nesterov': False, 'maximize': False,
                       'differentiable': False}.items():
        observer.assert_exact(group[key], value, 'optimizer/' + key)
    assert group.get('foreach') in (None, False) and group.get('fused') in (None, False)
    trainable = [v for k, v in parameters.items() if k not in fixed]
    adapter_values = [state['adapters'][f'{i}.{kind}'] for i in range(3) for kind in ('weight', 'bias')]
    expected = trainable + adapter_values
    assert group['params'] == list(range(len(expected)))
    assert all(type(x) is int for x in group['params'])
    active = len(trainable) if config['arm'] == 'control' else len(expected)
    assert optimizer['state'].keys() == set(range(active))
    for index, values in optimizer['state'].items():
        assert type(index) is int and values.keys() == {'momentum_buffer'}
        assert values['momentum_buffer'].shape == expected[index].shape
        assert values['momentum_buffer'].dtype == expected[index].dtype
    scaler = state['scaler']
    assert scaler.keys() == {'scale', 'growth_factor', 'backoff_factor', 'growth_interval', '_growth_tracker'}
    observer.assert_exact(scaler['scale'], ledger[-1]['AMP_scale_after'])
    observer.assert_exact(scaler['growth_factor'], 2.)
    observer.assert_exact(scaler['backoff_factor'], .5)
    assert type(scaler['growth_interval']) is int and scaler['growth_interval'] == 2000
    assert type(scaler['_growth_tracker']) is int and 0 <= scaler['_growth_tracker'] < 2000
    return {'changed_parameter_tensors': sum(x > 0 for x in deltas), 'max_abs_parameter_delta': max(deltas),
            'raw_parameter_digest': observer.state_digest({k: state['student'][k] for k in parameters}),
            'raw_EMA_digest': observer.state_digest(state['ema'])}


def check_metrics(metrics, classes):
    assert metrics.keys() == core.METRIC_KEYS
    assert metrics['classes'] == {str(k): v for k, v in classes.items()}
    assert len(classes) == 10
    for name in ('map50', 'map50_95', 'precision', 'recall'):
        core.finite(metrics[name], 0.); assert metrics[name] <= 1.
    for name in ('ap50', 'ap50_95'):
        assert type(metrics[name]) is list and len(metrics[name]) == 10
        for value in metrics[name]:
            core.finite(value, 0.); assert value <= 1.
    core.sha(metrics['checkpoint_sha256']); core.sha(metrics['state_sha256'])


class BoundRun:
    """Take content hashes before reading; recheck every used byte at the end."""
    def __init__(self, context, job):
        self.context, self.job = context, job
        self.files = context.files
        self.out = PurePosixPath(job['run_directory'])
        self.bindings = {}

    def raw_path(self, path, expected=None):
        key = str(path)
        value = self.files.sha(key)
        if expected is not None: assert value == expected, ('Unexpected input', key)
        if key in self.bindings: assert self.bindings[key] == value, ('Changed during audit', key)
        self.bindings[key] = value
        return self.files.read(key, value)

    def raw(self, name): return self.raw_path(self.out / name)
    def json(self, name): return artifacts.loads(self.raw(name))
    def tensor(self, name): return reader.tensor_bytes(self.raw(name))

    def finish(self):
        self.context.verify()
        self.files.verify(self.bindings)


def check_config(run, source_hash, teacher_hash):
    c = run.json('config.json'); context = run.context; job = run.job
    args = {key: c[key] for key in set(job['args']) | {'device', 'resume'}}
    contract.same_arguments(args, job['args'])
    # Initial config is retained unchanged on resume; a first-run --resume has no state.
    assert c['resume'] is False
    expected_contract = {'label': job['label'], 'protocol_sha256': contract.PROTOCOL_SHA,
        'contract_sha256': context.bindings[(ROOT / 'continuation_contract.py').as_posix()],
        'design_sha256': context.bindings[(ROOT / 'continuation_design.json').as_posix()],
        'source_manifest_sha256': context.manifest_hash, 'mode': 'production'}
    observer.assert_exact(c['contract'], expected_contract)
    assert c['student_sha256'] == source_hash and c['teacher_sha256'] == teacher_hash
    assert c['protocol_sha256'] == contract.PROTOCOL_SHA
    assert c['script_sha256'] == context.bindings[(ROOT / 'continuation.py').as_posix()]
    assert type(c['train_images']) is int and c['train_images'] == 69863
    for key, expected in {'feature_layers': [15, 18, 21], 'mosaic': 0., 'mixup': 0.,
                          'copy_paste': 0., 'clip_grad_norm': 10., 'AMP_initial_scale': 128.,
                          'evaluation_epochs': [10, 20, 40]}.items():
        observer.assert_exact(c[key], expected)
    for key in ('student_channels', 'teacher_channels'):
        assert type(c[key]) is list and len(c[key]) == 3
        assert all(type(v) is int and v > 0 for v in c[key])
    for key, expected in {'imgsz': 640, 'seed': job['args']['seed'], 'deterministic': True,
                          'mosaic': 0., 'mixup': 0., 'copy_paste': 0.}.items():
        observer.assert_exact(c['hyp'][key], expected)
    core.sha(c['initial_raw_student_digest']); core.sha(c['initial_adapter_digest'])
    return c


def audit_bound_run(context, job, input_hashes):
    """Internal test seam: caller authenticates Context, job and input_hashes."""
    assert not torch.cuda.is_initialized()
    run = BoundRun(context, job)
    # A completion marker alone is insufficient and must never trigger retraining.
    complete = run.json('COMPLETE.json')
    config = check_config(run, input_hashes['source'], input_hashes['teacher'])
    initial = {}
    for key in ('source', 'teacher', 'data'):
        raw = run.raw_path(job['args'][key], input_hashes[key])
        if key != 'data': initial[key] = reader.checkpoint_module(reader.tensor_bytes(raw))
    source = initial['source']
    assert core.training_digest(reader.as_loaded_float(source.state_dict())) == config['initial_raw_student_digest']
    assert source.names == initial['teacher'].names and len(source.names) == 10
    out = run.files.path(str(run.out))
    assert {p.name for p in out.glob('epoch_*.json')} == {
        f'epoch_{i:02d}{suffix}.json' for i in range(1, 41) for suffix in ('', '_steps')}
    assert {p.name for p in out.glob('raw_state_epoch*.pt')} == {f'raw_state_epoch{i:02d}.pt' for i in ENDPOINTS}
    assert {p.name for p in out.glob('ema_epoch*_metrics.json')} == {f'ema_epoch{i:02d}_metrics.json' for i in ENDPOINTS}
    records = [run.json(f'epoch_{i:02d}.json') for i in range(1, 41)]
    ledgers = [run.json(f'epoch_{i:02d}_steps.json') for i in range(1, 41)]
    for i, record in enumerate(records, 1):
        assert record['batch_step_ledger_sha256'] == run.bindings[str(run.out / f'epoch_{i:02d}_steps.json')]
    counts = core.check_epoch_chain(records, ledgers, config['lr'], math.ceil(69863 / 64), 40)
    if config['arm'] == 'control':
        assert all(row['feature_loss'] == 0. for row in records)
    gradient = run.json('gradient_check.json')
    assert gradient['channel_probe_preserved_buffers'] is True
    core.integer(gradient['student_nonzero_grad_tensors'], 1)
    core.integer(gradient['student_grad_tensors'], 1)
    trainable = [v for k, v in source.named_parameters() if 'dfl.conv.weight' not in k]
    assert gradient['student_grad_tensors'] == len(trainable)
    assert gradient['student_nonzero_grad_tensors'] <= gradient['student_grad_tensors']
    assert gradient['student_trainable_numel'] == sum(v.numel() for v in trainable)
    assert type(gradient['adapter_grad_tensors']) is int
    assert gradient['adapter_grad_tensors'] == (0 if config['arm'] == 'control' else 6)
    for key in ('detection_loss', 'feature_loss', 'weighted_KD_to_detection_loss'):
        core.finite(gradient[key])
    endpoints = {}; raw40 = None
    for epoch in ENDPOINTS:
        name = f'ema_epoch{epoch:02d}'
        state = run.tensor(f'raw_state_epoch{epoch:02d}.pt')
        raw_check = check_raw(state, records[epoch-1], source, config, ledgers[epoch-1])
        saved = run.tensor(name + '.pt')
        expected = {k: v.half() if v.is_floating_point() else v for k, v in state['ema'].items()}
        assert isinstance(saved, dict) and isinstance(saved.get('model'), torch.nn.Module)
        observer.assert_exact(saved['model'].state_dict(), expected, 'saved_precision_EMA')
        assert all(p.grad is None for p in saved['model'].parameters())
        if saved.get('ema') is not None:
            assert isinstance(saved['ema'], torch.nn.Module)
            observer.assert_exact(saved['ema'].state_dict(), expected, 'alternate_saved_EMA')
        commit = out / (name + '_validation_commit')
        assert {p.name for p in commit.iterdir()} == {'manifest.json', 'result.json', 'post_rng.bin'}
        manifest = run.json(name + '_validation_commit/manifest.json')
        result_bytes = run.raw(name + '_validation_commit/result.json')
        rng_bytes = run.raw(name + '_validation_commit/post_rng.bin')
        result = artifacts.loads(result_bytes); check_metrics(result, source.names)
        expected_bindings = {'source_sha256': input_hashes['source'], 'data_yaml_sha256': input_hashes['data'],
            'state_sha256': records[epoch-1]['EMA_state_sha256'],
            'config_sha256': run.bindings[str(run.out / 'config.json')],
            'trainer_sha256': config['script_sha256'], 'endpoint': name}
        assert manifest == {'schema': 'validation_rng_commit_v1', 'bindings': expected_bindings,
            'result_sha256': artifacts.digest(result_bytes), 'post_rng_sha256': artifacts.digest(rng_bytes),
            'checkpoint_sha256': run.bindings[str(run.out / (name + '.pt'))]}
        assert result['checkpoint_sha256'] == manifest['checkpoint_sha256']
        assert result['state_sha256'] == expected_bindings['state_sha256']
        assert run.raw(name + '_metrics.json') == result_bytes
        check_rng(reader.tensor_bytes(rng_bytes))  # Never restores the recorded state.
        endpoints[str(epoch)] = {'role': 'primary' if epoch == 40 else 'secondary' if epoch == 20 else 'diagnostic',
            'metrics': result, 'actual_step_counts': state['actual_step_counts'], **raw_check}
        if epoch == 40: raw40 = state
    observer.assert_exact(run.tensor('training_state.pt'), raw40, 'atomic_latest_vs_raw40')
    observer.assert_exact(complete, endpoints['40']['metrics'], 'COMPLETE_vs_committed_epoch40')
    delta = run.json('parameter_delta.json')
    assert delta.keys() == {'changed_tensors', 'max_abs_delta', 'fixed_dfl_preserved', 'actual_step_counts', 'elapsed_seconds'}
    observer.assert_exact(delta['changed_tensors'], endpoints['40']['changed_parameter_tensors'])
    observer.assert_exact(delta['max_abs_delta'], endpoints['40']['max_abs_parameter_delta'])
    observer.assert_exact(delta['actual_step_counts'], counts)
    assert delta['fixed_dfl_preserved'] is True
    core.finite(delta['elapsed_seconds'], 0.)
    run.finish(); assert not torch.cuda.is_initialized()
    return {'schema': 'completed_continuation_file_audit_v1', 'status': 'completed_evidence_passed',
        'protocol_sha256': contract.PROTOCOL_SHA, 'label': job['label'], 'pair_seed': job['pair_seed'],
        'arm': config['arm'], 'lr': config['lr'], 'epochs': 40, 'actual_step_counts': counts,
        'initial_raw_student_digest': config['initial_raw_student_digest'],
        'first_two_input_sha256_by_epoch': {str(r['epoch']): r['first_two_input_sha256'] for r in records},
        'endpoints': endpoints, 'finite_saved_states': True, 'fixed_DFL_preserved': True,
        'native_gradient_nonfinite_batches': sum(r['gradient_norm_nonfinite_batches'] for r in records),
        'bound_input_sha256': dict(sorted(run.bindings.items())),
        'limits': ['File/tensor audit only; no launch authorization or fresh inference.',
                   'Teacher no-grad during training is a frozen-trainer assertion, not an independent saved teacher trajectory.',
                   'Raw states checked at10/20/40; other epochs have recorded digests and runtime finite checks.',
                   'Device/attempt supervision and cross-path pairing require separate execution and aggregate audits.']}


def audit(project, label):
    assert os.environ.get('CUDA_VISIBLE_DEVICES') == '' and not torch.cuda.is_initialized()
    context = artifacts.Context(project)
    base_bindings = verify_completed_bases(context)
    manifest_hash = context.files.sha(MANIFEST.as_posix())
    manifest = artifacts.loads(context.files.read(MANIFEST.as_posix(), manifest_hash))
    assert manifest['schema'] == 'continuation_completion_sources_v1'
    assert manifest['protocol_sha256'] == contract.PROTOCOL_SHA
    rows = manifest['files']; assert len({r['name'] for r in rows}) == len(rows)
    bindings = {(ROOT / r['name']).as_posix(): r['sha256'] for r in rows}
    assert (ROOT / AUDITOR).as_posix() in bindings
    assert Path(__file__).resolve() == context.files.path((ROOT / AUDITOR).as_posix()).resolve()
    context.files.verify(bindings)
    for module in (core, observer, reader, artifacts, contract):
        path = (ROOT / Path(module.__file__).name).as_posix()
        assert context.files.path(path).resolve() == Path(module.__file__).resolve()
        assert context.files.sha(path) == context.bindings[path]
    design = artifacts.loads(context.files.read((ROOT / 'continuation_design.json').as_posix()))
    protocol = artifacts.loads(context.files.read((ROOT / 'protocol.json').as_posix()))
    reuse = artifacts.loads(context.files.read((ROOT / 'historical_reuse_manifest.json').as_posix()))
    assert design == contract.build_design(protocol, reuse)
    jobs = [j for j in design['new_jobs'] if j['label'] == label]
    assert len(jobs) == 1, 'Only27new jobs; historical low-rate runs are reuse-only'
    job = jobs[0]; hashes = {'data': protocol['data']['yaml_sha256']}
    for key, model in (('source', 'nano'), ('teacher', 'large')):
        if job['pair_seed'] in contract.OLD_SEEDS:
            matches = [e for e in design['reused_base_endpoints'] if e['architecture'] == model and e['pair_seed'] == job['pair_seed']]
            assert len(matches) == 1; hashes[key] = matches[0]['checkpoint']['sha256']
        else:
            proof = artifacts.loads(context.files.read((ROOT / 'completed_base_audits' / f"{model}_seed{job['pair_seed']}.json").as_posix()))
            hashes[key] = proof['run']['checkpoint_sha256']
    import fcntl
    lock = PurePosixPath(job['run_directory'] + '.lock')
    with context.files.path(str(lock)).open('rb') as handle:
        fcntl.flock(handle, fcntl.LOCK_SH | fcntl.LOCK_NB)
        report = audit_bound_run(context, job, hashes)
        context.files.verify(base_bindings); context.files.verify(bindings)
        assert context.files.sha(MANIFEST.as_posix()) == manifest_hash
    report['audit_sources_sha256'] = manifest_hash
    report['bound_input_sha256'].update(context.bindings)
    report['bound_input_sha256'].update(base_bindings)
    report['bound_input_sha256'].update(bindings)
    report['bound_input_sha256'][MANIFEST.as_posix()] = manifest_hash
    return report


def main():
    parser = argparse.ArgumentParser(); parser.add_argument('--label', required=True)
    args = parser.parse_args(); torch.set_num_threads(1)
    print(artifacts.encoded(audit(Path.cwd(), args.label)).decode(), end='')


if __name__ == '__main__': main()
