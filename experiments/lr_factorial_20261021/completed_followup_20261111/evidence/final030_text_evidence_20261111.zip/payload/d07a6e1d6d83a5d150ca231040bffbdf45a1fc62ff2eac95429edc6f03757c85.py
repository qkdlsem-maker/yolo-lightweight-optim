"""Consumer tests against existing real Linux lifecycle fixtures; no replay.

The prior successful process tests already wrote15 jobs and8waves. Read them
without changing their bytes. Only the test's model/source/auditor boundaries
are substituted; the new completion consumer and file/attempt checks are real.
"""
import copy
import hashlib
import json
import sys
from pathlib import Path
from types import SimpleNamespace

from continuation_artifact_receipts import Files, encoded, loads
import factorial_after020_completion as e
from test_continuation_after020_processes import synthetic_plan


class Overlay(Files):
    def __init__(self, project):
        super().__init__(project)
        self.overrides = {}

    def read(self, name, expected=None):
        data = self.overrides.get(str(name), ...)
        if data is ...:
            data = super().read(name)
        assert data is not None, 'Synthetic missing file: ' + str(name)
        if expected is not None:
            assert hashlib.sha256(data).hexdigest() == expected
        return data

    def sha(self, name):
        return hashlib.sha256(self.read(name)).hexdigest()


def main(root):
    f = Overlay(root)
    context = SimpleNamespace(files=f)
    plan = synthetic_plan()
    authority = loads(f.read(str(e.HERE/'authority.json')))
    review = loads(f.read(str(e.ROOT/'recovery_investigations/020_review.json')))
    rows = {p.relative_to(f.project).as_posix(): loads(p.read_bytes())
            for p in f.path(str(e.ROOT/'attempts')).glob('*.json')}
    parent_name = next(n for n, r in rows.items() if r['label'] == 'continuation_after020_parent_CPU')
    parent_cmd = rows[parent_name]['command']
    e.command = lambda files, number=None, label=None: parent_cmd + ([] if number is None else ['--wave', str(number), '--label', label])

    def job(context, label):
        item = next(i for w in plan['waves'] for i in w['jobs'] if i['label'] == label)
        return {'label': label, 'args': item['args'], 'run_directory': str(e.ROOT/'runs'/label)}, {}

    e.job_for_label = job
    e.checkpoint_bindings = lambda *unused: {}

    def audit(context, job, report, *unused):
        assert report['status'] == 'synthetic_independent_audit_passed' and report['label'] == job['label']
        name = job['run_directory']+'/COMPLETE.json'
        return {name: context.files.sha(name)}

    e.audit_report = audit

    def run():
        return e.completed_remaining15(context, plan, authority, parent_name, review)

    accepted = run()
    assert len(accepted['receipt_sha256']) == 15 and accepted['evaluation_admitted'] is False
    before = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in f.project.rglob('*') if p.is_file() and not p.is_symlink()}
    folder = e.HERE/'wave_06'
    receipt_path = str(e.HERE/'receipts/first.json')
    receipt = loads(f.read(receipt_path))
    complete_path = str(e.HERE/'TRAINING_RECEIPTS_COMPLETE.json')
    cases = []

    def changed(name, path, mutate):
        value = copy.deepcopy(loads(f.read(str(path))))
        mutate(value)
        cases.append((name, str(path), encoded(value)))

    for key, value in [('status', 'wrong'), ('schema', 'wrong'), ('protocol_sha256', '0'*64),
                       ('label', 'second'), ('device', 1), ('wave', 7), ('bound_file_sha256', {}),
                       ('reservation_attempts', []), ('worker_attempt', receipt['audit_attempt'])]:
        changed('receipt_'+key, receipt_path, lambda x, k=key, v=value: x.__setitem__(k, v))
    changed('resume_instead_of_initial', receipt_path, lambda x: x['args'].__setitem__('resume', True))
    changed('step_counts_changed', receipt_path, lambda x: x['actual_step_counts'].__setitem__('attempted', 1))
    changed('parent_unclosed', parent_name, lambda x: x.pop('ended_unix'))
    changed('parent_failed', parent_name, lambda x: x.__setitem__('returncode', 1))
    changed('parent_charge_as_GPU', parent_name, lambda x: x.__setitem__('GPU_job', True))
    changed('parent_wrong_PID', parent_name, lambda x: x.__setitem__('pid', x['pid']+1))
    changed('parent_exited_before_seal', parent_name, lambda x: x.__setitem__('ended_unix', x['started_unix']))
    changed('parent_command_changed', parent_name, lambda x: x['command'].append('--resume'))
    changed('worker_double_charge', receipt['worker_attempt'], lambda x: x.__setitem__('GPU_job', True))
    changed('worker_failed', receipt['worker_attempt'], lambda x: x.__setitem__('returncode', -15))
    changed('worker_unclosed', receipt['worker_attempt'], lambda x: x.pop('ended_unix'))
    changed('worker_wrong_parent', receipt['worker_attempt'], lambda x: x.__setitem__('parent_pid', 1))
    changed('audit_failed', receipt['audit_attempt'], lambda x: x.__setitem__('returncode', 1))
    changed('audit_before_GPU_exit', receipt['audit_attempt'], lambda x: x.__setitem__('started_unix', 1))
    changed('reservation_not_charged', receipt['reservation_attempts'][0], lambda x: x.__setitem__('GPU_job', False))
    changed('reservation_failed', receipt['reservation_attempts'][0], lambda x: x.__setitem__('returncode', 1))
    changed('reservation_closed_early', receipt['reservation_attempts'][0], lambda x: x.__setitem__('ended_unix', x['started_unix']))
    changed('reservation_wrong_peers', receipt['reservation_attempts'][0], lambda x: x.__setitem__('worker_PIDs', [1, 2]))
    changed('readiness_contract_wrong', folder/'first/ready.json', lambda x: x['contract'].__setitem__('mode', 'fixture'))
    changed('release_wrong_GPU', folder/'release.json', lambda x: x.__setitem__('GPU_uuid', {}))
    changed('release_before_readiness', folder/'release.json', lambda x: x.__setitem__('released_unix', 1))
    changed('return_wrong_complete', folder/'first/returned.json', lambda x: x.__setitem__('complete_sha256', '0'*64))
    changed('unsealed_peer', folder/'SEALED.json', lambda x: x.__setitem__('all_worker_processes_exited', False))
    changed('seal_before_audits', folder/'SEALED.json', lambda x: x.__setitem__('sealed_unix', 1))
    changed('seal_missing_receipt', folder/'SEALED.json', lambda x: x.__setitem__('receipt_sha256', {}))
    changed('seal_claims_full_phase', folder/'SEALED.json', lambda x: x.__setitem__('not_full_phase_completion', False))
    changed('completion_missing_receipt', complete_path, lambda x: x['receipt_sha256'].pop(receipt_path))
    changed('completion_prior_evidence_changed', complete_path, lambda x: x.__setitem__('prior_reuse_sha256', {'wrong': '0'*64}))
    changed('completion_claims_whole_phase', complete_path, lambda x: x.__setitem__('whole_phase_complete', True))
    changed('completion_claims_documents', complete_path, lambda x: x.__setitem__('new_evaluation_diagnostics_and_documents_complete', True))
    changed('completion_bad_receipt_digest', complete_path, lambda x: x['receipt_sha256'].__setitem__(receipt_path, '0'*64))
    cases.append(('final_single_GPU_seal_absent', str(e.HERE/'wave_13/SEALED.json'), None))
    cases.append(('malformed_duplicate_JSON', receipt_path, b'{"schema":"a","schema":"b"}'))
    cases.append(('nonfinite_JSON', receipt_path, b'{"v":NaN}'))
    for name, path, data in cases:
        f.overrides = {path: data}
        try:
            run()
        except (AssertionError, KeyError, TypeError):
            pass
        else:
            raise AssertionError('Invalid completion accepted: '+name)
    f.overrides = {}
    assert run() == accepted
    after = {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in f.project.rglob('*') if p.is_file() and not p.is_symlink()}
    assert after == before, 'Prior fixture was modified'
    assert 'torch' not in sys.modules
    return {'status': 'passed', 'positive_completed_jobs': 15, 'positive_waves': 8,
            'final_single_GPU_wave_checked': True, 'rejection_cases': len(cases),
            'cases': [c[0] for c in cases], 'bound_files': len(accepted['bound_file_sha256']),
            'fixture': str(f.project), 'preserved_fixture_files': len(before), 'original_fixture_modified': False,
            'new_process_experiments': False, 'new_GPU_work': False,
            'tested_sources_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                                      for p in (Path(e.__file__), Path(__file__))},
            'limits': ['Uses completed actual Linux process/session/receipt fixtures from the prior13-case suite without rerunning it.',
                       'Model, source, plan and independent-auditor boundaries are synthetic here.',
                       'Not actual production15 completion acceptance, tensor audit, or GPU numerical validation.']}


if __name__ == '__main__':
    print(json.dumps(main(Path(sys.argv[1]).resolve()), indent=2))
