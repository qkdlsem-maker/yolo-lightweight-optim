"""Read current evaluation bytes, without models, CUDA, scoring or dispatch.

Historical evidence supplies expected hashes; the data themselves are read now.
Only known BDD image leaf links may be followed, to their fixed in-project raw
image targets. A future bounded CPU wrapper must call collect after source
freeze. This library alone does not admit an evaluation or start a process.
"""
import hashlib
import importlib.metadata as metadata
import io
import os
from pathlib import Path, PurePosixPath
import platform
import stat
import sys
import time
import zipfile

from continuation_artifact_receipts import ROOT, PROTOCOL_SHA, Files, loads, valid_sha

BLUEPRINT_SHA = '58e7707eaa846e82514827c488e87fc14f03843bae2a7f9979d2f05367939f27'
REUSE_SHA = 'ae0ab01d3f746a68664c582655c6b70c0eb035bed1c205a51bc3a93d21e60b85'
OLD = Path('review_20261017_independent')
ISOLATED = OLD / 'evaluation_deps'
RAW_BDD = Path('data/raw/val/images')
MAX_IMAGE_BYTES = 64 * 1024 * 1024


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def basename(value):
    assert isinstance(value, str) and value and '\\' not in value and ':' not in value
    assert PurePosixPath(value).parts == (value,) and value not in ('.', '..')
    return value


def identity(s):
    return [s.st_dev, s.st_ino, s.st_mode, s.st_size, s.st_mtime_ns, s.st_ctime_ns]


class CurrentBytes:
    def __init__(self, project):
        self.files = Files(project)
        self.bound = {}
        self.observations = {}
        self.bytes_read = 0

    def target(self, name, allowed_link_target=None):
        # Strict parent path; a controlled exception applies only to the leaf.
        name = str(name)
        rel = PurePosixPath(name)
        basename(rel.name)
        parent = self.files.path(rel.parent.as_posix())
        p = parent / rel.name
        before = identity(p.lstat())
        link = None
        if p.is_symlink():
            assert allowed_link_target is not None, 'Unexpected leaf symlink'
            link = os.readlink(p)
            target = self.files.path(str(allowed_link_target))
            assert p.resolve(strict=True) == target.resolve(strict=True), 'Unexpected link target'
        else:
            target = self.files.path(name)
        assert target.is_file() and not target.is_symlink()
        return p, target, {'leaf_identity': before, 'target_identity': identity(target.stat()),
            'link_target': link, 'resolved_path': target.relative_to(self.files.project).as_posix()}

    def read(self, name, expected=None, allowed_link_target=None, max_bytes=None):
        name = str(name)
        p, target, before = self.target(name, allowed_link_target)
        if max_bytes is not None:
            assert 0 < before['target_identity'][3] <= max_bytes, 'Invalid payload size'
        fd = os.open(target, os.O_RDONLY | os.O_NOFOLLOW)
        with os.fdopen(fd, 'rb') as stream:
            assert identity(os.fstat(stream.fileno())) == before['target_identity']
            assert stat.S_ISREG(os.fstat(stream.fileno()).st_mode)
            raw = stream.read()
            assert identity(os.fstat(stream.fileno())) == before['target_identity'], 'Changed during read'
        _, _, after = self.target(name, allowed_link_target)
        assert before == after, 'Path changed during read'
        h = digest(raw)
        if expected is not None:
            valid_sha(expected)
            assert h == expected, 'Changed input: ' + name
        if name in self.bound:
            assert self.bound[name] == h and self.observations[name] == before, 'Input changed within authentication'
        self.bound[name] = h
        self.observations[name] = before
        self.bytes_read += len(raw)
        return raw

    def json(self, binding):
        return loads(self.read(binding['path'], binding['sha256']))

    def final_identity_check(self):
        # Not a filesystem snapshot: runtime must still recheck data per request.
        for name, before in self.observations.items():
            _, _, after = self.target(name, before['resolved_path'] if before['link_target'] is not None else None)
            assert before == after, 'Input changed after authentication: ' + name


def image_population(reader, request, count, allow_bdd_links):
    from PIL import Image
    images = reader.json(request['image_manifest'])
    assert len(images) == count and len({v['file_name'] for v in images}) == count
    assert [v['id'] for v in images] == list(range(1, count + 1))
    assert [v['file_name'] for v in images] == sorted(v['file_name'] for v in images)
    directory = reader.files.path(request['image_dir'])
    names = {basename(v['file_name']) for v in images}
    assert {p.name for p in directory.iterdir()} == names, 'Image population mismatch'
    for row in images:
        allowed = str(RAW_BDD / row['file_name']) if allow_bdd_links else None
        raw = reader.read(str(Path(request['image_dir']) / row['file_name']), row['sha256'], allowed, MAX_IMAGE_BYTES)
        with Image.open(io.BytesIO(raw)) as im:
            assert im.size == (row['width'], row['height']), 'Image dimensions differ'
    assert {p.name for p in directory.iterdir()} == names
    return images


def label_population(reader, request, images):
    data = reader.json(request['dataset_manifest'])
    reader.read(request['data_yaml']['path'], request['data_yaml']['sha256'])
    expected = data['splits']['val']
    assert expected['images'] == len(images)
    names = sorted(Path(v['file_name']).stem + '.txt' for v in images)
    assert len(set(names)) == len(images)
    directory = reader.files.path(request['label_dir'])
    assert {p.name for p in directory.iterdir()} == set(names), 'Label population mismatch'
    ordered = hashlib.sha256()
    boxes = 0
    for name in names:
        raw = reader.read(str(Path(request['label_dir']) / name))
        ordered.update(name.encode() + b'\0' + raw)
        boxes += sum(bool(line.strip()) for line in raw.splitlines())
    assert ordered.hexdigest() == expected['ordered_label_content_sha256'], 'Label contents differ'
    assert boxes == expected['boxes']
    assert {p.name for p in directory.iterdir()} == set(names)
    return {'images': len(images), 'boxes': boxes, 'ordered_label_content_sha256': ordered.hexdigest()}


def annotation_views(reader, bindings, images):
    result = {}
    for variant, binding in bindings['annotation_views'].items():
        view = reader.json(binding)
        population = images['bdd' if variant == 'bdd_common' else 'kitti']
        assert view['images'] == [{k: v[k] for k in ('id', 'file_name', 'width', 'height')} for v in population]
        assert view['info']['annotation_variant'] == variant
        assert view['info']['policy_sha256'] == bindings['common_source_sha256']['common_annotation_policy.json']
        assert view['categories'] == [{'id': 0, 'name': 'person'}, {'id': 2, 'name': 'car'}]
        result[variant] = {'sha256': binding['sha256'], 'images': len(population), 'annotations': len(view['annotations'])}
    return result


def kitti_labels(reader, binding, expected):
    raw = reader.read(binding['path'], binding['sha256'])
    with zipfile.ZipFile(io.BytesIO(raw)) as archive:
        members = [v.filename for v in archive.infolist() if not v.is_dir()]
        assert len(members) == len(set(members)) == len(expected)
        assert set(expected) == {f'{i:06d}.txt' for i in range(len(expected))}
        assert set(members) == {'training/label_2/' + v for v in expected}
        for name in members:
            assert digest(archive.read(name)) == expected[Path(name).name], 'KITTI member changed'
    return len(members)


def runtime_sources(reader, native, common, isolated_expected):
    runtime = native['runtime']
    assert platform.python_version() == runtime['python']
    assert platform.platform() == runtime['platform']
    packages = {}
    for name, version in runtime['packages'].items():
        dist = metadata.distribution(name)
        assert dist.version == version, 'Runtime package changed: ' + name
        root = Path(dist.locate_file('')).resolve()
        assert root.is_relative_to(reader.files.project / 'venv')
        packages[name] = version
    ultralytics = Path(metadata.distribution('ultralytics').locate_file('')).resolve()
    expected = dict(runtime['native_source_sha256'])
    for name, h in native['native_validation_source_sha256'].items():
        assert name not in expected or expected[name] == h
        expected[name] = h
    for name, h in expected.items():
        if name == 'default_cfg_yaml':
            p = ultralytics / 'ultralytics/cfg/default.yaml'
        else:
            parts = name.split('.')
            assert all(v.isidentifier() for v in parts) and parts[0] == 'ultralytics'
            module = ultralytics.joinpath(*parts)
            candidates = [module.with_suffix('.py'), module / '__init__.py']
            available = [v for v in candidates if v.is_file()]
            assert len(available) == 1, 'Ambiguous runtime module'
            p = available[0]
        reader.read(p.relative_to(reader.files.project).as_posix(), h)
    isolated = reader.files.path(str(ISOLATED))
    distributions = [d for d in metadata.distributions(path=[str(isolated)]) if d.metadata['Name'] == 'pycocotools']
    assert len(distributions) == 1
    dist = distributions[0]
    assert dist.version == common['runtime']['pycocotools_version'] == '2.0.11'
    assert packages['numpy'] == common['runtime']['numpy_version']
    assert isolated_expected['pycocotools/cocoeval.py'] == common['runtime']['cocoeval_python_sha256']
    installed = {str(v) for v in dist.files if str(v).startswith('pycocotools/') and not str(v).endswith('.pyc')}
    assert installed == set(isolated_expected)
    for name, h in isolated_expected.items():
        reader.read(str(ISOLATED / name), h)
    assert 'torch' not in sys.modules
    return {'packages': packages, 'python': platform.python_version(), 'platform': platform.platform(),
        'native_python_source_files': len(expected), 'isolated_pycocotools': dist.version,
        'isolated_dependency_files': isolated_expected, 'GPU_runtime_observed': False,
        'limits': 'Package versions and recorded Python sources match historical runs. Isolated extension bytes are frozen from the current inspection; full historical binary identity and current GPU numerical behavior are not established.'}


def collect(project, preparation_sha):
    assert os.name == 'posix' and 'torch' not in sys.modules and os.environ.get('CUDA_VISIBLE_DEVICES') == ''
    started = time.time()
    reader = CurrentBytes(project)
    spec = reader.json({'path': str(ROOT / 'factorial_current_inputs_spec.json'), 'sha256': preparation_sha})
    assert spec['schema'] == 'factorial_current_inputs_spec_v1' and spec['protocol_sha256'] == PROTOCOL_SHA
    assert spec['evaluation_admitted'] is False
    reader.read(str(ROOT / 'protocol.json'), PROTOCOL_SHA)
    blueprint = reader.json({'path': str(ROOT / 'factorial_evaluation_request_blueprint.json'), 'sha256': BLUEPRINT_SHA})
    reuse = reader.json({'path': str(ROOT / 'factorial_reuse_auth_v2.json'), 'sha256': REUSE_SHA})
    assert reuse['status'] == '24_historical_evaluations_authenticated_without_replay'
    assert len(reuse['endpoints']) == 24 and blueprint['execution_admitted'] is False
    ref = blueprint['reuse_only'][0]
    assert ref['directory'] == spec['historical_reference_directory']
    manifests = {}
    for step, h in spec['reference_manifests'].items():
        name = ref['directory'] + '/' + step + '/MANIFEST.json'
        assert reuse['bound_artifacts'][name] == h
        manifests[step] = reader.json({'path': name, 'sha256': h})
    shared = blueprint['unchanged_evaluator_bindings']
    for key in ('source_sha256', 'common_source_sha256', 'kitti_source_sha256'):
        for name, h in shared[key].items():
            basename(name)
            reader.read(shared['evaluation_tools'] + '/' + name, h)
    for key, name in shared['native_core_paths'].items():
        assert manifests['kitti_native']['core_sha256'][key] == reuse['bound_artifacts'][name]
        reader.read(name, reuse['bound_artifacts'][name])
    runtime = runtime_sources(reader, manifests['native_bdd'], manifests['bdd_common'], spec['isolated_dependency_files'])
    job = blueprint['jobs'][0]
    populations = {d: image_population(reader, job['prediction_requests'][d], spec['image_counts'][d], d == 'bdd') for d in ('bdd', 'kitti')}
    labels = label_population(reader, job['native_bdd_request'], populations['bdd'])
    views = annotation_views(reader, shared, populations)
    members = kitti_labels(reader, shared['label_zip'], manifests['kitti_native']['label_member_sha256'])
    assert members == len(populations['kitti'])
    reader.final_identity_check()
    assert 'torch' not in sys.modules
    return {'schema': 'factorial_current_evaluation_inputs_v1', 'status': 'current_input_bytes_authenticated_not_evaluation_admission',
        'protocol_sha256': PROTOCOL_SHA, 'preparation_sha256': preparation_sha, 'blueprint_sha256': BLUEPRINT_SHA,
        'reused24_authentication_sha256': REUSE_SHA, 'started_unix': started, 'ended_unix': time.time(),
        'image_counts': {k: len(v) for k, v in populations.items()}, 'BDD_labels': labels,
        'annotation_views': views, 'KITTI_label_members': members, 'runtime': runtime,
        'bound_artifacts': reader.bound, 'path_observations': reader.observations, 'bytes_read': reader.bytes_read,
        'model_loaded': False, 'new_GPU_work': False, 'new_inference': False, 'new_scoring': False,
        'old_evaluation_audit_repeated': False, 'evaluation_admitted': False,
        'limits': ['Hashes and image-header dimensions authenticate current inputs; no images are inferred or scores recomputed.',
            'File identities are checked again at the end; this is not a transactional snapshot. Each actual evaluator must retain its own input and runtime checks.',
            'Full model completion, final requests, guarded dispatcher tests and source freeze remain separate prerequisites.']}
