"""All48 fixed final endpoints, eight metric cells from each saved KITTI archive."""
import itertools,sys
from pathlib import Path
from study_runtime import Study,PROJECT,PHASE,HERE,source_check,publish,read,need,file_sha
from completed_training_bridge import PulsedFiles,merge
from continuation_artifact_receipts import loads


def endpoint_directories(files):
    locations=loads(files.read(PHASE+'/factorial_endpoint_location_plan.json'))
    reused=loads(files.read(PHASE+'/factorial_reuse_auth_v2.json'))
    mapping={row['endpoint_id']:row['directory'] for row in reused['endpoints']}
    for row in locations['endpoints']:
        if row['action']=='new_evaluation_after_admission':mapping[row['endpoint_id']]=PHASE+'/factorial_evaluation/endpoints/'+row['endpoint_id']
    need(len(mapping)==84,'All fixed evaluation endpoints')
    return locations,mapping


def run(ctx):
    f=PulsedFiles(PROJECT,ctx.check);locations,directories=endpoint_directories(f)
    roster=locations['metric_decomposition_final_endpoint_ids'];need(len(roster)==len(set(roster))==48,'Fixed metric endpoints')
    manifest=loads(f.read(PHASE+'/metric_decomposition_sources.json'))
    sources={x['name']:x['sha256'] for x in manifest['files'] if x['name'] in ('metric_factor_core.py','score_metric_factor_archive.py','prediction_archive.py','prediction_io.py','common_annotation_policy.json')}
    need(len(sources)==5,'Frozen metric sources');f.verify({PHASE+'/'+name:digest for name,digest in sources.items()})
    plan=loads(f.read(PHASE+'/factorial_evaluation_execution_plan.json'))
    root=PROJECT/PHASE/'metric_decomposition';root.mkdir(parents=True,exist_ok=False)
    requests=[];results={}
    for eid in roster:
        base=directories[eid];archive=base+'/kitti_predictions'
        request={'schema':'metric_factor_archive_request_v1','dataset':'kitti','archive_path':archive,
            'archive_manifest_sha256':f.sha(archive+'/MANIFEST.json'),'archive_complete_sha256':f.sha(archive+'/COMPLETE.json'),
            'source_sha256':sources,'annotation_views':{n:plan['annotation_views'][n] for n in ('kitti_source_ignore','kitti_no_ignore_sensitivity')},
            'reference_common_scores':{n:{'path':base+'/kitti_common/'+n+'.json','sha256':f.sha(base+'/kitti_common/'+n+'.json')} for n in ('kitti_source_ignore','kitti_no_ignore_sensitivity')}}
        request_path=root/'requests'/(eid+'.json');publish(request_path,request);requests.append((eid,request_path))
    publish(root/'FIXED_REQUEST_ROSTER.json',{'endpoints':roster,'cells':384,'requests':{p.relative_to(PROJECT).as_posix():file_sha(p) for eid,p in requests}})
    for index,(eid,path) in enumerate(requests):
        output=root/'endpoints'/eid
        task={'endpoint_id':eid,'device':None,'environment':{'PYTHONPATH':str(PROJECT/'review_20261017_independent/evaluation_deps')},
            'command':[sys.executable,'-B',str(PROJECT/PHASE/'score_metric_factor_archive.py'),'--request',str(path),'--output',str(output)]}
        def verify(task):
            complete=read(output/'COMPLETE.json');report=loads((output/'factorial.json').read_bytes())
            need(complete['cells']==8 and complete['manifest_sha256']==file_sha(output/'MANIFEST.json') and complete['factorial_sha256']==file_sha(output/'factorial.json'),'Metric output bytes')
            need(len(report['cells'])==8 and {(c['ignore_policy'],c['recall_points'],c['overlap_policy']) for c in report['cells']}==set(itertools.product(('source_ignore','no_ignore'),(101,40),('iou_grid','class_specific_iou'))),'Fixed eight metric cells')
            need(report['native_KITTI_equivalence_claimed'] is False and set(report['common_reference_cells_exactly_reproduced'])=={'kitti_source_ignore','kitti_no_ignore_sensitivity'},'Metric common references not reproduced')
            return {p.relative_to(PROJECT).as_posix():file_sha(p) for p in (output/'MANIFEST.json',output/'COMPLETE.json',output/'factorial.json')}
        result=ctx.stage(ctx.folder.relative_to(PROJECT)/('endpoint_%02d'%(index+1)),'metric_factor',[task],verify,3600)
        merge(results,result['artifacts'][eid])
    f.verify(results);value={'status':'all384_fixed_metric_cells_verified','endpoints':48,'cells':384,'bound_result_sha256':results,'new_inference':False,'common_reference_cells_exactly_reproduced':96,'native_KITTI_equivalence_claimed':False}
    publish(root/'COMPLETE.json',value);return value

if __name__=='__main__':
    expected=sys.argv[1];source_check(expected);Study('metrics',expected,24*3600,0,CPU_hours_limit=23.5).run(run)
