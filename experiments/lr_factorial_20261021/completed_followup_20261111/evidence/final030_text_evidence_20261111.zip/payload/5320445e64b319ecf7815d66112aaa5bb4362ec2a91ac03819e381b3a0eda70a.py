"""Sole parent for the fixed84-invocation technical preflight, never production.

All six real base audits, frozen inputs/sources, a live independent budget guard
and the separately implemented numerical reader are mandatory. No training is
started by import. Successful collection is NOT a numerical/production gate.
"""
import argparse
import importlib
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback
import uuid
from continuation_artifact_receipts import (
    ROOT, PROTOCOL_SHA, Context, encoded, loads, expected_command,
    invocation_spec, receipt_path, verify_receipt, seal_invocation,
    verify_complete_request, check_attempt,
)
from continuation_preflight_runtime import (
    DISPATCHER, RUNNER, PREFIX, GUARD_SHA, BudgetExceeded, resources,
    read_records, no_latches, check_limits, process_command, gpu_idle_uuid,
    verify_completed_bases, verify_runner_sources,
)
from run_continuation_fixture import prior_state_and_destination
from validation_journal import publish_immutable, sync_directory

SELF_LABEL = 'continuation_preflight_dispatcher_CPU'
READER = ROOT / 'continuation_preflight_reader.py'
FINALIZER = ROOT / 'finalize_continuation_preflight.py'
COLLECTED = ROOT / 'CONTINUATION_PREFLIGHT_COLLECTED.json'


def utc():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())


def self_command(context, device):
    assert type(device) is int and device in (0, 1)
    return [str(context.files.project / 'venv/bin/python'), '-u',
            DISPATCHER.as_posix(), '--device', str(device)]


def supervision(context, records, own_pid=None, command_reader=process_command):
    """Do not repair stale ledgers or signal any pre-existing process."""
    f = context.files
    guard = loads(f.read((ROOT / 'budget_guard_launch.json').as_posix()))
    command = ['venv/bin/python', '-u', (ROOT / 'budget_guard.py').as_posix()]
    assert guard['command'] == command and guard['source_sha256'] == GUARD_SHA
    assert f.sha((ROOT / 'budget_guard.py').as_posix()) == GUARD_SHA
    assert command_reader(guard['pid']) == command, 'Independent budget guard is absent'
    for launch in ('launch.json', 'base_recovery_launch.json'):
        value = loads(f.read((ROOT / launch).as_posix()))
        assert command_reader(value['pid']) is None, 'Base coordinator has not exited'
    for row in records.values():
        if 'ended_unix' not in row and (row.get('label') == SELF_LABEL or
                                       DISPATCHER.as_posix() in row.get('command', [])):
            assert own_pid is not None and row.get('pid') == own_pid, 'Another/stale dispatcher attempt'


def matching_attempts(context, invocation_id, rows):
    # Recognize the fixed command even if a damaged record lost its label.
    commands = [expected_command(context, invocation_id, device) for device in (0, 1)]
    return [(name, row) for name, row in rows.items()
            if row.get('label') == PREFIX + invocation_id or row.get('command') in commands]


def classify(context, invocation_id, device, rows):
    """Reuse a valid receipt, seal one successful child, or admit a new child.

    Failed/unclosed/duplicate attempts are never rerun automatically. Sealing
    after a parent interruption performs only file verification and state copy.
    """
    matches = matching_attempts(context, invocation_id, rows)
    assert len(matches) <= 1, 'Multiple attempts for a fixed fixture; investigate'
    if context.files.path(receipt_path(invocation_id)).exists():
        receipt, _ = verify_receipt(context, invocation_id)
        assert receipt['device'] == device
        assert len(matches) == 1 and matches[0][0] == receipt['attempt']['path']
        return 'reuse', matches[0][0]
    if matches:
        name, _ = matches[0]
        check_attempt(context, name, invocation_id, device)
        return 'seal_only', name
    prior_state_and_destination(context, invocation_spec(context, invocation_id, device))
    return 'launch', None


def receipt_prefix(context):
    """No later completed work may be hidden behind a missing earlier receipt."""
    gap = False
    for item in context.roster['invocations']:
        exists = context.files.path(receipt_path(item['id'])).exists()
        assert not (gap and exists), 'Non-prefix fixture receipts; preserve and investigate'
        gap |= not exists
    expected = {Path(receipt_path(i['id'])).name for i in context.roster['invocations']}
    folder = context.files.path((ROOT / 'continuation_preflight/receipts').as_posix())
    assert {p.name for p in folder.glob('*.json')} <= expected, 'Unexpected fixture receipt'


def new_attempt(files, label, command, device, pid=None):
    token = f'{label}_{time.strftime("%Y%m%dT%H%M%SZ", time.gmtime())}_{uuid.uuid4().hex}'
    path = (ROOT / 'attempts' / (token + '.json')).as_posix()
    log = (ROOT / 'logs' / (token + '.log')).as_posix()
    row = {'label': label, 'command': command, 'GPU_job': device is not None,
           'device': device, 'started_utc': utc(), 'started_unix': time.time(),
           'status': 'starting' if pid is None else 'running', 'log': log}
    if pid is not None:
        row['pid'] = pid
    files.path(path).parent.mkdir(parents=True, exist_ok=True)
    files.path(log).parent.mkdir(parents=True, exist_ok=True)
    publish_immutable(files.path(path), encoded(row))
    return path, row


def update_owned(files, name, previous, current):
    """Only this owned attempt changes. A guard's terminal decision is retained."""
    path = files.path(name)
    observed = loads(path.read_bytes())
    if encoded(observed) != encoded(previous):
        assert observed.get('status') == 'budget_stopped' and 'ended_unix' in observed, 'Owned attempt changed unexpectedly'
        return False
    pending = path.with_name(path.name + '.' + uuid.uuid4().hex + '.updating')
    with pending.open('xb') as stream:
        stream.write(encoded(current)); stream.flush(); os.fsync(stream.fileno())
    # The independent guard may stop this process at any moment. Never rewrite
    # a terminal record that is already visible. An interrupted temp is retained.
    assert path.read_bytes() == encoded(previous), 'Attempt changed during update'
    os.replace(pending, path); sync_directory(path.parent)
    return True


def stop_owned_child(proc, command, command_reader=process_command,
                     getpgid=os.getpgid if hasattr(os, 'getpgid') else None,
                     killpg=os.killpg if hasattr(os, 'killpg') else None):
    if proc.poll() is not None:
        return
    assert command_reader(proc.pid) == command, 'Refuse to signal an unrecognized process'
    assert getpgid(proc.pid) == proc.pid, 'Child no longer owns its process group'
    killpg(proc.pid, signal.SIGTERM)
    try:
        proc.wait(timeout=10.)
    except subprocess.TimeoutExpired:
        # Recheck identity before escalation, never act on a reused PID.
        assert command_reader(proc.pid) == command and getpgid(proc.pid) == proc.pid
        killpg(proc.pid, signal.SIGKILL)
        proc.wait(timeout=10.)


def execute_child(context, invocation_id, device, check, popen=subprocess.Popen):
    """Register before launch; close the exact attempt before allowing sealing."""
    check()
    command = expected_command(context, invocation_id, device)
    name, previous = new_attempt(context.files, PREFIX + invocation_id, command, device)
    proc, error = None, None
    env = os.environ.copy()
    env.pop('CUDA_VISIBLE_DEVICES', None)
    env['YOLO_CONFIG_DIR'] = str(context.files.path((ROOT / 'config').as_posix()))
    try:
        with context.files.path(previous['log']).open('xb') as log:
            proc = popen(command, stdout=log, stderr=subprocess.STDOUT,
                         stdin=subprocess.DEVNULL, start_new_session=True, env=env,
                         cwd=context.files.project)
            running = dict(previous, pid=proc.pid, status='running')
            assert update_owned(context.files, name, previous, running), 'Guard stopped the attempt'
            previous = running
            while proc.poll() is None:
                check()
                try:
                    proc.wait(timeout=1.)
                except subprocess.TimeoutExpired:
                    pass
            check()
            assert proc.returncode == 0, f'Fixture failed: {name}; preserve outputs'
    except BaseException as caught:
        error = caught
        raise
    finally:
        try:
            if proc is not None and proc.poll() is None:
                stop_owned_child(proc, command)
        finally:
            # An unreaped live process stays unclosed and conservatively charged.
            # Never manufacture an end timestamp for an unknown live allocation.
            ended = proc is None or proc.poll() is not None
            if ended:
                code = None if proc is None else proc.returncode
                terminal = dict(previous, ended_unix=time.time(), ended_utc=utc(),
                    returncode=code, status='completed' if code == 0 and error is None else 'failed')
                if error is not None:
                    terminal['stop_reason'] = repr(error)
                update_owned(context.files, name, previous, terminal)
    check_attempt(context, name, invocation_id, device)
    return name


def publish_failure(context, error, attempt=None, invocation=None):
    payload = {'utc': utc(), 'stage': 'continuation_preflight_dispatcher',
        'pid': os.getpid(), 'attempt': attempt, 'invocation_id': invocation,
        'error': repr(error), 'traceback': traceback.format_exc(),
        'prior_raw_artifacts_preserved': True, 'automatic_training_retry': False}
    if isinstance(error, BudgetExceeded):
        payload.update(scope=error.scope, resource_snapshot=error.snapshot)
        marker = 'CONTINUATION_PREFLIGHT_BUDGET_STOP.json' if error.scope == 'preflight_GPU_hours' else 'BUDGET_STOP.json'
    else:
        marker = 'CONTINUATION_PREFLIGHT_FAILURE.json'
    path = context.files.path((ROOT / marker).as_posix())
    if not path.exists():
        publish_immutable(path, encoded(payload))
    archive = context.files.path((ROOT / 'continuation_preflight/dispatcher_failures' / (uuid.uuid4().hex + '.json')).as_posix())
    archive.parent.mkdir(parents=True, exist_ok=True)
    publish_immutable(archive, encoded(payload))


def numerical_reader(context):
    """Missing/unfrozen reader blocks even the first GPU invocation."""
    assert READER.as_posix() in context.bindings, 'Numerical artifact reader is not frozen'
    assert context.files.sha(READER.as_posix()) == context.bindings[READER.as_posix()]
    module = importlib.import_module('continuation_preflight_reader')
    assert Path(module.__file__).resolve() == context.files.path(READER.as_posix()).resolve()
    assert callable(module.verify_observation) and callable(module.verify_case)
    return module


def readiness_finalizer(context):
    assert FINALIZER.as_posix() in context.bindings, 'Final numerical gate implementation is not frozen'
    assert context.files.sha(FINALIZER.as_posix()) == context.bindings[FINALIZER.as_posix()]
    module = importlib.import_module('finalize_continuation_preflight')
    assert Path(module.__file__).resolve() == context.files.path(FINALIZER.as_posix()).resolve()
    assert callable(module.publish_gate)
    return module


def validate_numeric_result(context, result, case, kind):
    expected_status = 'observational_parity_passed' if kind == 'observation' else 'observational_and_replay_parity_passed'
    assert result['schema'] == 'continuation_preflight_numerical_case_v1'
    assert result['status'] == expected_status and result['kind'] == kind
    assert result['case_id'] == case['id'] and result['protocol_sha256'] == PROTOCOL_SHA
    assert result['context'] == context.identifiers()
    assert result['reader_sha256'] == context.bindings[READER.as_posix()]
    requested = [case['requests'][name] for name in (
        ('reference_observation', 'candidate_observation') if kind == 'observation' else
        ('reference_observation', 'candidate_observation', 'candidate_uninterrupted', 'candidate_interrupted'))]
    expected = {i['id'] for i in context.roster['invocations'] if i['request_id'] in requested}
    assert set(result['receipt_sha256']) == expected
    for ident, value in result['receipt_sha256'].items():
        assert verify_receipt(context, ident)[1] == value
    for request in requested:
        verify_complete_request(context, request)


def numeric_checkpoint(context, reader, case, kind):
    result = (reader.verify_observation if kind == 'observation' else reader.verify_case)(context, case['id'])
    validate_numeric_result(context, result, case, kind)
    name = (ROOT / 'continuation_preflight/numerical_cases' / f'{case["id"]}__{kind}.json').as_posix()
    path = context.files.path(name); path.parent.mkdir(parents=True, exist_ok=True)
    publish_immutable(path, encoded(result))
    return name


def collect(context, device, gpu_uuid, reader, check, event, execute=execute_child):
    receipt_prefix(context)
    case_by_request = {request: case for case in context.roster['cases'] for request in case['requests'].values()}
    numerical = {}
    for invocation in context.roster['invocations']:
        ident = invocation['id']
        resource_snapshot = check()
        action, attempt = classify(context, ident, device, read_records(context.files))
        event('fixture', invocation_id=ident, action=action)
        if action == 'launch':
            assert not resource_snapshot['active_GPU_attempts'], 'Existing/unclosed GPU allocation blocks dispatch'
            assert gpu_idle_uuid(device) == gpu_uuid, 'Selected physical GPU changed'
            attempt = execute(context, ident, device, check)
        if action != 'reuse':
            # No next segment may start until its predecessor is sealed.
            seal_invocation(context, ident, device, attempt)
        receipt, _ = verify_receipt(context, ident)
        assert receipt['device'] == device and receipt['GPU_uuid'] == gpu_uuid
        request = context.requests[invocation['request_id']]
        case = case_by_request[request['id']]
        if request['kind'] == 'candidate_observation':
            numerical[numeric_checkpoint(context, reader, case, 'observation')] = None
        if request['kind'] == 'candidate_interrupted' and invocation['stop']['stop_after_epoch'] == 12:
            numerical[numeric_checkpoint(context, reader, case, 'complete_case')] = None
        check()
    assert len(numerical) == 24
    receipt_hashes = {i['id']: verify_receipt(context, i['id'])[1] for i in context.roster['invocations']}
    closures = {name: verify_complete_request(context, name)[1] for name in context.requests}
    assert len(receipt_hashes) == 84 and len(closures) == 48
    return {'schema': 'continuation_preflight_collection_v1',
        'status': '84_receipts_48_closed_requests_12_case_checks_complete_not_production_gate',
        'protocol_sha256': PROTOCOL_SHA, 'context': context.identifiers(),
        'device': device, 'GPU_uuid': gpu_uuid, 'receipt_sha256': receipt_hashes,
        'closed_request_sha256': closures,
        'numerical_case_file_sha256': {name: context.files.sha(name) for name in numerical}}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--device', type=int, choices=(0, 1), required=True)
    args = parser.parse_args()
    assert os.name == 'posix', 'Actual dispatcher is Linux-only'
    context = Context(Path.cwd())
    verify_runner_sources(context)
    assert Path(__file__).resolve() == context.files.path(DISPATCHER.as_posix()).resolve()
    pid = os.getpid()
    assert os.getsid(pid) == os.getpgid(pid) == pid, 'Dispatcher requires its own process session'
    command = self_command(context, args.device)
    assert process_command(pid) == command
    import fcntl
    # Never hold the child's worker/base locks in this parent.
    lock = context.files.path((ROOT / 'continuation_preflight_dispatcher.lock').as_posix()).open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    no_latches(context.files)
    rows, snapshot = resources(context.files)
    check_limits(snapshot)
    supervision(context, rows)
    assert not snapshot['active_GPU_attempts'], 'Another/unclosed GPU allocation exists'
    # Register the CPU dispatcher so the unchanged independent guard can stop it.
    attempt, previous = new_attempt(context.files, SELF_LABEL, command, None, pid)
    own_log = context.files.path(previous['log']).open('xb')
    error = None
    def event(kind, **details):
        own_log.write(encoded({'utc': utc(), 'event': kind, **details})); own_log.flush()
    def check():
        no_latches(context.files)
        current_rows, current_snapshot = resources(context.files)
        check_limits(current_snapshot)
        supervision(context, current_rows, pid)
        # A child is the only allowed active GPU; its own runner validates exact
        # registration before CUDA. No new unrelated allocation is admitted.
        assert len(current_snapshot['active_GPU_attempts']) <= 1
        for name in current_snapshot['active_GPU_attempts']:
            row = current_rows[name]
            assert row['label'].startswith(PREFIX) and RUNNER.as_posix() in row['command']
        return current_snapshot
    def interrupted(signum, frame):
        raise RuntimeError(f'Dispatcher received signal {signum}; preserve and stop owned child')
    original = {s: signal.signal(s, interrupted) for s in (signal.SIGTERM, signal.SIGINT)}
    try:
        bases = verify_completed_bases(context)
        gpu_uuid = gpu_idle_uuid(args.device)
        # Reader uses authenticated CPU deserialization only. Children receive
        # a clean physical-device environment from execute_child.
        os.environ['CUDA_VISIBLE_DEVICES'] = ''
        reader = numerical_reader(context)
        finalizer = readiness_finalizer(context)
        event('admitted', device=args.device, GPU_uuid=gpu_uuid,
              resources=check(), base_audit_bound_sha256=bases)
        result = collect(context, args.device, gpu_uuid, reader, check, event)
        context.verify(); context.files.verify(bases); check()
        publish_immutable(context.files.path(COLLECTED.as_posix()), encoded(result))
        event('collection_complete_not_production_gate')
        finalizer.publish_gate(context, result)
        event('actual_numerical_preflight_gate_published_no_production_launch')
    except BaseException as caught:
        error = caught
        publish_failure(context, caught, attempt)
        raise
    finally:
        terminal = dict(previous, ended_unix=time.time(), ended_utc=utc(),
            status='completed' if error is None else 'failed', returncode=0 if error is None else 1)
        if error is not None:
            terminal['stop_reason'] = repr(error)
        update_owned(context.files, attempt, previous, terminal)
        own_log.close()
        for s, handler in original.items():
            signal.signal(s, handler)
        lock.close()


if __name__ == '__main__':
    main()
