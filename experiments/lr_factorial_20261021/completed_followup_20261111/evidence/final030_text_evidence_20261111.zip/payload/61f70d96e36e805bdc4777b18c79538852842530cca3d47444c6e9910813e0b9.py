"""Assemble the fixed FP32 diagnostic from raw student/adapter tensors.

No checkpoint discovery, image selection, optimizer, inference export or launch.
The future guarded runner must authenticate templates, raw state, configuration,
fixed batch archives and source hashes before calling these functions.
"""
import copy
import hashlib
import inspect
import math
from pathlib import Path
import torch
from ultralytics.cfg import get_cfg
from ultralytics.nn.tasks import DetectionModel
from ultralytics.nn.modules.head import Detect
from ultralytics.utils.loss import v8DetectionLoss
import gradient_probe_core as core

NATIVE_SHA256 = {
    'tasks.py': 'e444854e6d4262deee482c96916eebb0b01d30b3c748195af791968f8dfd4ab0',
    'head.py': '0bfb68614db2bc3b3da42361230877cabd03ebcffe57be4be81701c1920f4245',
    'loss.py': '9831c6985fa08e0800515848d5d9029bb4ed7d91c2c33db95ca9b8336c4928bb',
}
GAINS = {'box': 7.5, 'cls': .5, 'dfl': 1.5}


def native_bindings():
    result = {}
    for cls in (DetectionModel, Detect, v8DetectionLoss):
        path = Path(inspect.getfile(cls)); value = hashlib.sha256(path.read_bytes()).hexdigest()
        assert value == NATIVE_SHA256[path.name], 'Unreviewed native model/loss source: '+str(path)
        result[str(path)] = value
    return result


def raw_tensors(state):
    assert type(state) is dict and state
    for name, tensor in state.items():
        assert type(name) is str and isinstance(tensor, torch.Tensor)
        assert tensor.device.type == 'cpu', 'Load authenticated raw state on CPU before assembly'
        assert not tensor.is_floating_point() or tensor.dtype == torch.float32, 'Raw state must retain FP32'
        assert bool(torch.isfinite(tensor).all()), 'Nonfinite saved input state'


def assemble(student_template, teacher_template, raw, config, device):
    """Copy supplied models and load raw tensors exactly; never choose a checkpoint.

    Native model templates may originate from serialized FP16 EMA checkpoints,
    but the student's weights/buffers come exclusively from the supplied FP32 raw
    epoch40 state. The matching teacher retains its fixed base endpoint weights.
    """
    native = native_bindings()
    assert type(raw['epoch']) is int and raw['epoch'] == 40
    assert config['arm'] in core.ARMS and type(config['epochs']) is int and config['epochs'] == 40
    assert type(config['temperature']) is float and config['temperature'] == core.TEMPERATURE
    assert type(config['kd_weight']) is float and config['kd_weight'] == (0. if config['arm'] == 'control' else .3)
    assert config['feature_layers'] == list(core.LAYERS)
    for key, expected in GAINS.items():
        assert type(config['hyp'][key]) in (int, float) and config['hyp'][key] == expected
    channels = [config[k] for k in ('student_channels', 'teacher_channels')]
    assert all(type(c) is list and len(c) == 3 and all(type(x) is int and x > 0 for x in c) for c in channels)
    raw_tensors(raw['student']); raw_tensors(raw['adapters'])
    assert set(raw['adapters']) == {f'{i}.{kind}' for i in range(3) for kind in ('weight', 'bias')}
    for i, (sc, tc) in enumerate(zip(*channels)):
        assert tuple(raw['adapters'][f'{i}.weight'].shape) == (tc, sc, 1, 1)
        assert tuple(raw['adapters'][f'{i}.bias'].shape) == (tc,)
    for model in (student_template, teacher_template):
        assert type(model) is DetectionModel and len(model.model) == 23
        assert type(model.model[-1]) is Detect and model.model[-1].nc == 10
        assert model.model[-1].reg_max == 16 and not model.model[-1].end2end
        assert not model.model[-1].export and not model.model[-1].dynamic
        assert type(model.names) is dict and set(model.names) == set(range(10))
    assert student_template.names == teacher_template.names
    template_state = student_template.state_dict()
    assert set(raw['student']) == set(template_state)
    for name, tensor in template_state.items(): assert raw['student'][name].shape == tensor.shape
    dfl = [name for name in template_state if 'dfl.conv.weight' in name]; assert len(dfl) == 1
    assert torch.equal(raw['student'][dfl[0]], template_state[dfl[0]].detach().cpu().float()), 'Frozen DFL changed'
    student = copy.deepcopy(student_template).float().cpu()
    teacher = copy.deepcopy(teacher_template).float().cpu()
    # Adapter constructor randomness must not consume caller RNG. All initialized
    # values are replaced by the exact saved tensors before any diagnostic.
    with torch.random.fork_rng(devices=[]):
        adapters = torch.nn.ModuleList([torch.nn.Conv2d(sc, tc, 1) for sc, tc in zip(*channels)])
    student.load_state_dict(raw['student'], strict=True); adapters.load_state_dict(raw['adapters'], strict=True)
    hyp = get_cfg(); hyp.imgsz = 640; hyp.mosaic = hyp.mixup = hyp.copy_paste = 0.
    for key, value in GAINS.items(): setattr(hyp, key, value)
    student.args = hyp; teacher.args = copy.deepcopy(hyp)
    for name, p in student.named_parameters(): p.requires_grad_('dfl.conv.weight' not in name); p.grad = None
    for p in teacher.parameters(): p.requires_grad_(False); p.grad = None
    for p in adapters.parameters(): p.requires_grad_(True); p.grad = None
    device = torch.device(device); assert device.type in ('cpu', 'cuda')
    for model in (student, teacher, adapters): model.eval().to(device)
    # Replace any deserialized criterion after moving: its device/stride fields
    # must refer to this separate student. No training or model forward is needed.
    student.criterion = student.init_criterion(); assert type(student.criterion) is v8DetectionLoss
    for key, value in GAINS.items(): assert getattr(student.criterion.hyp, key) == value
    assert student.criterion.assigner.topk == 10
    for name, tensor in student.state_dict().items(): assert torch.equal(tensor.cpu(), raw['student'][name])
    for name, tensor in adapters.state_dict().items(): assert torch.equal(tensor.cpu(), raw['adapters'][name])
    return student, teacher, adapters, {'native_sources_sha256': native, 'detection_loss_gains': GAINS.copy(),
        'student_state': 'raw epoch40 FP32, not EMA', 'teacher_state': 'supplied matching base endpoint cast to FP32',
        'adapter_state': 'raw epoch40 FP32', 'model_precision': 'FP32 eval-mode; student DFL fixed, teacher detached',
        'provenance_authenticated_by_this_function': False}


def validate_batch(batch, device, size):
    assert set(batch) == {'img', 'cls', 'bboxes', 'batch_idx'}
    assert all(isinstance(t, torch.Tensor) and t.dtype == torch.float32 and t.device == device for t in batch.values())
    assert all(not t.requires_grad and bool(torch.isfinite(t).all()) for t in batch.values())
    assert tuple(batch['img'].shape) == (core.BATCH_SIZE, 3, size, size)
    n = batch['cls'].shape[0]
    assert tuple(batch['cls'].shape) == (n, 1) and tuple(batch['batch_idx'].shape) == (n,)
    assert tuple(batch['bboxes'].shape) == (n, 4)
    for key in ('img', 'bboxes'): assert bool(((batch[key] >= 0) & (batch[key] <= 1)).all())
    for key, upper in (('cls', 10), ('batch_idx', core.BATCH_SIZE)):
        t = batch[key]; assert bool(((t >= 0) & (t < upper) & (t == t.floor())).all())


def objectives_for_batch(student, teacher, adapters, batch, arm, *, fixture_size=None):
    """Return a single-forward builder and trace; CPU64 seam is fixtures only."""
    assert arm in core.ARMS
    device = next(student.parameters()).device
    if fixture_size is not None: assert device.type == 'cpu' and fixture_size == 64
    validate_batch(batch, device, 640 if fixture_size is None else fixture_size)
    assert len(adapters) == 3
    trace = {'student_forwards': 0, 'teacher_forwards': 0, 'feature_layers': list(core.LAYERS),
        'batch_size': core.BATCH_SIZE, 'fixture_only': fixture_size is not None}
    def build():
        assert trace['student_forwards'] == 0, 'One diagnostic forward per fixed batch'
        fs = {}; ft = {}; handles = []
        try:
            for model, store in ((student, fs), (teacher, ft)):
                for layer in core.LAYERS:
                    handles.append(model.model[layer].register_forward_hook(lambda m, a, o, i=layer, s=store: s.__setitem__(i, o)))
            prediction = student(batch['img']); trace['student_forwards'] += 1
            assert isinstance(prediction, tuple) and len(prediction) == 2 and len(prediction[1]) == 3
            det, components = student.loss(batch, prediction); det = det.sum()
            assert tuple(components.shape) == (3,) and det.dtype == torch.float32
            feature = det.new_zeros(())
            if arm != 'control':
                with torch.no_grad(): teacher(batch['img'])
                trace['teacher_forwards'] += 1
                aligned = [adapter(fs[layer]) for adapter, layer in zip(adapters, core.LAYERS)]
                targets = [ft[layer] for layer in core.LAYERS]
                assert all(not t.requires_grad for t in targets)
                feature = core.feature_objective(arm, aligned, targets)
            values = components.detach().cpu().tolist()
            trace['detection_components'] = [v if math.isfinite(v) else None for v in values]
            trace['detection_component_nonfinite'] = [None if math.isfinite(v) else
                'nan' if math.isnan(v) else 'positive_inf' if v > 0 else 'negative_inf' for v in values]
            trace['detection_normalization'] = 'native batch-summed scalar; no extra batch multiplier'
            trace['feature_normalization'] = 'sum of three per-scale means; core applies32*weight'
            return det, feature
        finally:
            for handle in handles: handle.remove()
    return build, trace


def diagnose_batch(student, teacher, adapters, batch, arm):
    """Production diagnostic is fixed32x640 only; caller supplies verified inputs."""
    before = {key: core.tensor_digest(value) for key, value in batch.items()}
    build, trace = objectives_for_batch(student, teacher, adapters, batch, arm)
    result = core.diagnose_models(student, teacher, adapters, build, arm)
    assert before == {key: core.tensor_digest(value) for key, value in batch.items()}
    result.update(input_tensor_sha256=before, objective_trace=trace, input_tensors_unchanged=True)
    return result
