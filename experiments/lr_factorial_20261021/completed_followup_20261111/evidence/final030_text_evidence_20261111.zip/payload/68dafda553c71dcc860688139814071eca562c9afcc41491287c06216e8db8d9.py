"""Authenticate the fixed 24 historical evaluations without replay or inference.

Only the standard library and the existing strict file reader are imported.
Prediction payloads are hashed, never scored. Existing numerical audit reports
are authenticated, not rerun. This does not admit any of the 60 new evaluations.
"""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import sys
import time

from continuation_artifact_receipts import Files, loads, valid_sha
from continuation_contract import ROOT, PROTOCOL_SHA, INTERPRETATION_SHA
from factorial_evaluation_requests import OLD, OLD_PLAN_SHA, LOCATION_SHA

BLUEPRINT_SHA='58e7707eaa846e82514827c488e87fc14f03843bae2a7f9979d2f05367939f27'
OLD_COMPLETE_SHA='342ade71474a15489bcc85809b07f58a58104673cd5c20b122a6bc01418bcfd4'
OLD_AUDITS_SHA='13359b2a0abd4781a55fde0724b443fd7cd61f35720f9a385cf56d6d7a310c69'
OLD_AUDITOR_SHA='abf66b83332814f890d58f18c4962e886e8e26625295820fbb136aa9fb3141e6'
OLD_RECOVERY_SHA='ed70a9b694f941bf34dbbceb41e02a97ce35286662a9145643f4f15bc17e496d'
STEPS={'native_bdd','bdd_predictions','bdd_common','kitti_predictions','kitti_common','kitti_native'}
GPU_UUID={'0':'41d83c61-12b9-c217-8efb-88f629f90acf','1':'f3dd6535-4b0a-a608-2aaa-cb487f6b3bfc'}
CORE={
 'executable':'4524fb43a3b39662140f1f41a749d3cf42e395e18cd23420260fa796d89b64c9',
 'original_source':'b16410ba8914a732405ec937a16d1cd039b6e3bf7d9e8edb6dd3ec79c15892b4',
 'adapted_source':'20c521ef2b30b37f34b52cdbfee3c6e7daa0d3650a603c2b209a5dd39f91c45e',
 'build_manifest':'427e55b18221e0c67788c0b81240d1b31f20d0e77eb6b3f3c6eba7339ee28a33',
 'prior_synthetic_proof':'444b92667b3656ccba487678ffbf088d03978fb3354fcd1a01ea88eff7ec3527'}

def canonical(v):return (json.dumps(v,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def digest(raw):return hashlib.sha256(raw).hexdigest()
def pathtext(name):return name.as_posix() if isinstance(name,Path) else str(name)

def child_name(name):
    p=PurePosixPath(name)
    assert isinstance(name,str) and name and '\\' not in name and ':' not in name
    assert not p.is_absolute() and p.as_posix()==name and all(x not in ('.','..') for x in p.parts)
    return p

class Reader:
    def __init__(self,project):
        self.files=Files(project);self.bound={};self.bytes_hashed=0;self.file_reads=0
    def check(self,name,expected):
        name=pathtext(name);valid_sha(expected)
        if name in self.bound:
            assert self.bound[name]==expected,'Conflicting expected bytes: '+name
            return
        p=self.files.path(name)
        assert self.files.sha(name)==expected,'Changed artifact: '+name
        self.bytes_hashed+=p.stat().st_size;self.file_reads+=1;self.bound[name]=expected
    def json(self,name,expected):
        self.check(name,expected)
        return loads(self.files.read(pathtext(name),expected))
    def leaf(self,name,expected):
        """Hash payloads without retaining a second copy of huge archive manifests."""
        valid_sha(expected);name=pathtext(name);p=self.files.path(name)
        assert self.files.sha(name)==expected,'Changed payload: '+name
        self.bytes_hashed+=p.stat().st_size;self.file_reads+=1

def inventory(reader,folder,expected,symlinks=False):
    """Match the original sealed inventory, including recorded native-BDD links."""
    folder=reader.files.path(pathtext(folder));actual={}
    for p in sorted(folder.rglob('*')):
        key=p.relative_to(folder).as_posix()
        if key=='COMPLETE.json':continue
        if p.is_symlink():
            assert symlinks,'Unexpected symlink'
            actual[key]={'symlink_target':os.readlink(p)}
        elif p.is_file():actual[key]=None
        else:assert p.is_dir(),'Unexpected filesystem object'
    assert set(actual)==set(expected),'Missing or extra sealed artifact'
    for name,row in expected.items():
        child_name(name)
        if symlinks:
            assert isinstance(row,dict) and len(row)==1
            if 'symlink_target' in row:
                assert actual[name]==row
                continue
            assert set(row)=={'sha256'};h=row['sha256']
        else:h=row
        assert actual[name] is None,'Expected regular file'
        reader.leaf((folder/name).relative_to(reader.files.project),h)
    return {'entries':len(expected),'inventory_sha256':digest(canonical(expected))}

def prediction_archive(reader,folder,manifest,complete,request,inference):
    folder=Path(folder);images=reader.json(request['image_manifest']['path'],request['image_manifest']['sha256'])
    assert manifest['schema']=='prediction_archive_v1' and manifest['batch_size']==32
    assert manifest['images']==images and len({i['id'] for i in images})==len(images)>0
    b=manifest['bindings']
    assert b['endpoint_id']==request['endpoint_id'] and b['dataset_id']==request['dataset_id']
    assert b['checkpoint_sha256']==request['checkpoint']['sha256'] and b['protocol_sha256']==request['protocol']['sha256']
    assert b['source_sha256']==dict(request['source_sha256'],frozen_request=digest(canonical(request)))
    assert b['inference']==inference
    mh=digest(canonical(manifest));count=(len(images)+31)//32
    assert set(complete)=={'schema','manifest_sha256','images','batches','batch_commit_sha256'}
    assert complete['schema']=='prediction_archive_complete_v1' and complete['manifest_sha256']==mh
    assert complete['images']==len(images) and complete['batches']==count and len(complete['batch_commit_sha256'])==count
    base=reader.files.path(pathtext(folder));allowed={'.lock','MANIFEST.json','batches','staging','COMPLETE.json'}
    assert {p.name for p in base.iterdir()}<=allowed and {'MANIFEST.json','batches','staging','COMPLETE.json'}<={p.name for p in base.iterdir()}
    assert not any(p.is_symlink() for p in base.iterdir())
    batches=sorted((base/'batches').iterdir());assert [p.name for p in batches]==['%06d'%i for i in range(count)]
    payload_count=0
    for i,p in enumerate(batches):
        assert p.is_dir() and not p.is_symlink()
        name=folder/'batches'/p.name/'COMMIT.json';commit=reader.json(name,complete['batch_commit_sha256'][i]);batch=images[32*i:32*(i+1)]
        assert set(commit)=={'schema','archive_manifest_sha256','batch_index','records','actual_forward_inputs'}
        assert commit['schema']=='prediction_batch_v1' and commit['archive_manifest_sha256']==mh and commit['batch_index']==i
        assert commit['actual_forward_inputs']==[{'shape':[len(batch),3,640,640],'dtype':'torch.float32','device':'cuda:0'}]
        assert len(commit['records'])==len(batch)
        names={'COMMIT.json'}|{'%08d.json'%im['id'] for im in batch}
        assert {q.name for q in p.iterdir()}==names and not any(q.is_symlink() for q in p.iterdir())
        for entry,im in zip(commit['records'],batch):
            assert set(entry)=={'file','sha256','image_sha256'} and entry['file']=='%08d.json'%im['id'] and entry['image_sha256']==im['sha256']
            reader.leaf(folder/'batches'/p.name/entry['file'],entry['sha256']);payload_count+=1
    return {'images':payload_count,'batches':count,'batch_commit_chain_sha256':digest(canonical(complete['batch_commit_sha256'])),
            'staging_entries_preserved_not_counted':sorted(p.name for p in (base/'staging').iterdir())}

def runtime(manifest,device,uuid):
    r=manifest.get('runtime',manifest.get('bindings',{}).get('runtime'))
    assert r and r['requested_device']==r['CUDA_VISIBLE_DEVICES']==device
    assert r['gpu']['uuid'].removeprefix('GPU-')==uuid

def endpoint(reader,row,job,plan,proof,marker,recovery):
    eid=row['historical_endpoint_id'];folder=Path(row['directory'])
    assert job['endpoint_id']==proof['endpoint_id']==marker['endpoint_id']==eid
    assert job['output']==folder.as_posix() and row['checkpoint']==job['native_bdd_request']['checkpoint']
    assert proof['status']=='passed' and proof['plan_sha256']==OLD_PLAN_SHA and proof['audit_source_sha256']==OLD_AUDITOR_SHA
    assert set(marker['outputs'])==STEPS
    reader.check(row['checkpoint']['path'],row['checkpoint']['sha256'])
    summary={};manifests={};completes={};reqs={}
    for step in sorted(STEPS):
        hashes=marker['outputs'][step];assert set(hashes)=={'request_sha256','manifest_sha256','complete_sha256'}
        req=reader.json(Path(plan['output_root'])/'requests'/eid/(step+'.json'),hashes['request_sha256'])
        m=reader.json(folder/step/'MANIFEST.json',hashes['manifest_sha256']);c=reader.json(folder/step/'COMPLETE.json',hashes['complete_sha256'])
        assert digest(canonical(m))==hashes['manifest_sha256'] and c['manifest_sha256']==hashes['manifest_sha256']
        if step=='native_bdd' or step.endswith('_predictions'):
            expected=job['native_bdd_request'] if step=='native_bdd' else job['prediction_requests'][step.split('_')[0]]
            assert req==expected
            d=str(job['lane']);uuid=GPU_UUID[d]
            override=recovery['completed_device_overrides'].get(eid+'/'+step)
            if override:
                assert override['manifest_sha256']==hashes['manifest_sha256'] and override['complete_sha256']==hashes['complete_sha256']
                d=override['requested_device'];uuid=override['gpu_uuid']
            runtime(m,d,uuid)
        else:assert m['request']==req
        if step=='native_bdd':
            assert m['schema']=='native_bdd_validation_manifest_v1' and m['request']==req
            assert c['schema']=='native_bdd_validation_complete_v1' and set(c)=={'schema','manifest_sha256','files'}
            summary[step]=inventory(reader,folder/step,c['files'],True)
        elif step.endswith('_predictions'):
            summary[step]=prediction_archive(reader,folder/step,m,c,req,plan['_inference'])
        elif step.endswith('_common'):
            variants={'bdd_common'} if step=='bdd_common' else {'kitti_source_ignore','kitti_no_ignore_sensitivity'}
            assert c['schema']=='common_archive_scores_complete_v1' and set(c)=={'schema','manifest_sha256','outputs'}
            assert set(c['outputs'])=={v+'.json' for v in variants}
            assert {p.name for p in reader.files.path(pathtext(folder/step)).iterdir()}=={'MANIFEST.json','COMPLETE.json'}|set(c['outputs'])
            for name,h in c['outputs'].items():reader.check(folder/step/name,h)
            summary[step]={'score_variants':sorted(variants)}
        else:
            assert c['schema']=='native_kitti_archive_scores_complete_v1' and set(c)=={'schema','manifest_sha256','files'}
            summary[step]=inventory(reader,folder/step,c['files'])
        manifests[step]=m;completes[step]=c;reqs[step]=req
    for step,dataset in [('bdd_common','bdd'),('kitti_common','kitti'),('kitti_native','kitti')]:
        q=reqs[step];archive=dataset+'_predictions'
        assert q['archive_path']==(folder/archive).as_posix()
        assert q['archive_manifest_sha256']==marker['outputs'][archive]['manifest_sha256'] and q['archive_complete_sha256']==marker['outputs'][archive]['complete_sha256']
        assert manifests[step]['prediction_bindings']==manifests[archive]['bindings']
        if step.endswith('common'):
            variants=['bdd_common'] if dataset=='bdd' else ['kitti_source_ignore','kitti_no_ignore_sensitivity']
            assert q['schema']=='common_archive_scoring_request_v1' and q['dataset']==dataset
            assert q['source_sha256']==plan['common_source_sha256'] and q['annotation_views']=={k:plan['annotation_views'][k] for k in variants}
        else:
            assert q['schema']=='native_kitti_archive_scoring_request_v1'
            assert q['source_sha256']==plan['kitti_source_sha256'] and q['native_core_paths']==plan['native_core_paths'] and q['label_zip']==plan['label_zip']
            assert manifests[step]['core_sha256']==CORE
    for step,key in [('native_bdd','native_bdd'),('kitti_native','native_kitti')]:reader.check(folder/step/'score.json',proof[key]['score_sha256'])
    for step in ('bdd_common','kitti_common'):
        assert set(proof[step]['scores'])==set(summary[step]['score_variants'])
        for variant,score in proof[step]['scores'].items():
            assert score['all_numeric_fields_replayed_exactly'] is True
            reader.check(folder/step/(variant+'.json'),score['score_sha256'])
    assert proof['native_bdd']['saved_statistics_exactly_reproduce_all_results_and_class_AP'] is True
    assert proof['native_kitti']['AP_R40_reconstructed_exactly_from_saved_curves'] is True
    return {'endpoint_id':row['endpoint_id'],'historical_endpoint_id':eid,'checkpoint':row['checkpoint'],'directory':folder.as_posix(),'artifact_checks':summary,
            'audit_repeated':False,'new_inference':False,'new_scores':False}

def collect(project,progress=None):
    reader=Reader(project);r=ROOT;old=Path(OLD)
    anchors={str(r/'protocol.json'):PROTOCOL_SHA,str(r/'protocol_interpretation.json'):INTERPRETATION_SHA,
      str(r/'factorial_evaluation_request_blueprint.json'):BLUEPRINT_SHA,str(r/'factorial_endpoint_location_plan.json'):LOCATION_SHA,
      str(old/'final_evaluation_plan.json'):OLD_PLAN_SHA,str(old/'final_evaluation/EVALUATION_COMPLETE.json'):OLD_COMPLETE_SHA,
      str(old/'final_evaluation_audits/AUDITS_COMPLETE.json'):OLD_AUDITS_SHA,str(old/'evaluation_tools/audit_final_evaluation.py'):OLD_AUDITOR_SHA,
      str(old/'final_evaluation_recovery.json'):OLD_RECOVERY_SHA}
    values={p:reader.json(p,h) for p,h in anchors.items() if p.endswith('.json')}
    reader.check(old/'evaluation_tools/audit_final_evaluation.py',OLD_AUDITOR_SHA)
    bp=values[str(r/'factorial_evaluation_request_blueprint.json')];plan=values[str(old/'final_evaluation_plan.json')]
    complete=values[str(old/'final_evaluation/EVALUATION_COMPLETE.json')];audits=values[str(old/'final_evaluation_audits/AUDITS_COMPLETE.json')]
    recovery=values[str(old/'final_evaluation_recovery.json')]
    assert bp['schema']=='factorial_evaluation_request_blueprint_v1' and bp['execution_admitted'] is False
    assert bp['original_evaluation_plan_sha256']==complete['plan_sha256']==audits['plan_sha256']==recovery['plan_sha256']==OLD_PLAN_SHA
    assert complete['schema']=='fixed_evaluation_complete_v1' and audits['status']=='passed' and audits['audit_source_sha256']==OLD_AUDITOR_SHA
    jobs={j['endpoint_id']:j for j in plan['jobs']}
    assert len(jobs)==48 and set(jobs)==set(complete['endpoint_complete_sha256'])==set(audits['proof_sha256'])
    rows=bp['reuse_only'];assert len(rows)==len({x['endpoint_id'] for x in rows})==len({x['historical_endpoint_id'] for x in rows})==24
    for key,value in bp['unchanged_evaluator_bindings'].items():assert plan[key]==value
    for name,h in plan['source_sha256'].items():reader.check(Path(plan['evaluation_tools'])/name,h)
    for ref in [plan['protocol'],plan['roster'],plan['label_zip'],*plan['annotation_views'].values()]:reader.check(ref['path'],ref['sha256'])
    assert set(plan['native_core_paths'])==set(CORE)
    for name,h in CORE.items():reader.check(plan['native_core_paths'][name],h)
    plan=dict(plan,_inference=bp['inference']);results=[]
    for row in rows:
        assert row['action']=='authenticate_existing_outputs_only_no_inference_or_rescoring'
        eid=row['historical_endpoint_id'];job=jobs[eid]
        proof=reader.json(old/'final_evaluation_audits'/(eid+'.json'),audits['proof_sha256'][eid])
        marker=reader.json(Path(row['directory'])/'ENDPOINT_COMPLETE.json',complete['endpoint_complete_sha256'][eid])
        assert proof['endpoint_complete_sha256']==complete['endpoint_complete_sha256'][eid]
        results.append(endpoint(reader,row,job,plan,proof,marker,recovery))
        if progress:progress(eid)
    reader.files.verify(anchors)
    assert 'torch' not in sys.modules
    return {'schema':'factorial_reused_evaluation_evidence_v1','status':'24_historical_evaluations_authenticated_without_replay',
      'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'pid':os.getpid(),'protocol_sha256':PROTOCOL_SHA,
      'endpoints':results,'bound_artifacts':reader.bound,'file_hash_operations':reader.file_reads,'bytes_hashed':reader.bytes_hashed,
      'new_inference':False,'new_scoring':False,'model_loaded':False,'numerical_audits_repeated':False,'new60_evaluation_admitted':False,
      'limits':['Reuses original passed numerical audits; this run only authenticates recorded bytes and request/runtime chains.',
        'Native BDD symlink targets are compared to their sealed paths; current underlying image/label bytes require separate new-evaluation data admission.',
        'No independent metric implementation, new untouched data or final current-phase completion is claimed.']}
