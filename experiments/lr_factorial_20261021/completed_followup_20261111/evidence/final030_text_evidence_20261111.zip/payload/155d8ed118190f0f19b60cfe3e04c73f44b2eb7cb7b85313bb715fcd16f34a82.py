"""Read-only acceptance for remaining25 initial paths after incident018.

The original sources, failures and receipts are never changed. No tensor load,
CUDA, training, automatic recovery or replacement of completed evidence.
"""
from pathlib import Path
from continuation_artifact_receipts import ROOT, PROTOCOL_SHA, Context, loads, encoded, valid_sha
from continuation_execution_runtime import (job_for_label, arguments, source_bindings,
    checkpoint_bindings, untouched_destination)
from continuation_preflight_runtime import (verify_completed_bases, process_command,
    no_latches, resources, check_limits)
from continuation_production_gate import verify_gate
from continuation_production_receipts import (verify_receipt, canonical_bindings,
    required_run_files)
from continuation_recovery_capsule import verify_capsule
import incident018_resume as recovery

HERE = ROOT/'continuation_waves'
PLAN = ROOT/'continuation_remaining_wave_execution_plan.json'
PLAN_SHA = '5e8f1fc50b9d55bd7a691b04629d453aeafaeace32e1716b0e66cfb2d8287a22'
MANIFEST = ROOT/'continuation_wave_sources.json'


def plan_for(context):
    f=context.files;plan=loads(f.read(PLAN.as_posix(),PLAN_SHA))
    assert plan['schema']=='continuation_remaining_wave_execution_plan_v1'
    assert plan['protocol_sha256']==PROTOCOL_SHA
    assert plan['original_design_sha256']==f.sha((ROOT/'continuation_design.json').as_posix())
    assert plan['unchanged_scientific_sources_sha256']==context.manifest_hash
    _,design=job_for_label(context,recovery.CONTROL)
    pending=[j for j in design['new_jobs'] if j['label'] not in (recovery.CONTROL,recovery.LABEL)]
    expected=[{'wave':i//2+1,'jobs':[{'label':j['label'],'device':d,'args':arguments(j,design,d)}
        for d,j in enumerate(pending[i:i+2])]} for i in range(0,len(pending),2)]
    assert len(pending)==25 and len(expected)==13 and plan['waves']==expected
    assert plan['new_trajectories_remaining']==25
    return plan,design


def sources(files):
    assert Path(__file__).resolve()==files.path(str(ROOT/'continuation_wave_evidence.py')).resolve()
    value=loads(files.read(MANIFEST.as_posix()))
    assert value['schema']=='continuation_wave_sources_v1'
    assert value['status']=='frozen_after_CPU_integration_and_source_review'
    assert value['protocol_sha256']==PROTOCOL_SHA and value['plan_sha256']==PLAN_SHA
    bindings={(ROOT/r['name']).as_posix():r['sha256'] for r in value['files']}
    required={'continuation_wave_runner.py','continuation_wave_evidence.py',
              'test_continuation_waves.py','continuation_wave_CPU.json',
              'continuation_wave_review.json','incident018_resume_sources.json'}
    assert len(bindings)==len(value['files']) and {(ROOT/n).as_posix() for n in required}<=set(bindings)
    files.verify(bindings);bindings[MANIFEST.as_posix()]=files.sha(MANIFEST.as_posix())
    proof=loads(files.read((ROOT/'continuation_wave_CPU.json').as_posix()))
    assert proof['status']=='passed' and proof['real_subprocess_cases']>=10
    for n,h in proof['tested_sources_sha256'].items():assert bindings[(ROOT/n).as_posix()]==h
    review=loads(files.read((ROOT/'continuation_wave_review.json').as_posix()))
    assert review['status']=='reviewed_for_initial_only_wave_execution'
    assert review['scientific_sources_changed'] is False and review['automatic_retry'] is False
    assert review['both_readiness_and_completion_barriers'] is True
    assert review['separate_worker_and_reservation_no_double_count'] is True
    assert review['CPU_proof_sha256']==files.sha((ROOT/'continuation_wave_CPU.json').as_posix())
    return bindings


def latches(files,review):
    no_latches(files)
    assert recovery.failure_set(files)==review['known_failure_sha256'],'Unreviewed production failure'
    for name in (recovery.HERE/'FAILURE.json', HERE/'FAILURE.json',ROOT/'CONTINUATION_TRAINING_COMPLETE.json'):
        assert not files.path(name.as_posix()).exists(), 'Stop/completion marker: '+str(name)


def audit_report(context,job,report,base_bindings,input_bindings):
    f=context.files
    assert report['schema']=='completed_continuation_file_audit_v1'
    assert report['status']=='completed_evidence_passed' and report['protocol_sha256']==PROTOCOL_SHA
    for key,value in [('label',job['label']),('pair_seed',job['pair_seed']),
                      ('arm',job['args']['arm']),('lr',job['args']['lr']),('epochs',40)]:
        assert report[key]==value and type(report[key]) is type(value)
    assert report['finite_saved_states'] is True and report['fixed_DFL_preserved'] is True
    counts=report['actual_step_counts']
    assert set(counts)=={'attempted','applied','skipped'}
    assert all(type(v) is int and v>=0 for v in counts.values())
    assert counts['attempted']==43680 and counts['applied']>0
    assert counts['attempted']==counts['applied']+counts['skipped']
    assert set(report['endpoints'])=={'10','20','40'}
    for epoch,role in [('10','diagnostic'),('20','secondary'),('40','primary')]:
        assert report['endpoints'][epoch]['role']==role
    assert encoded(report['endpoints']['40']['metrics'])==encoded(loads(f.read(job['run_directory']+'/COMPLETE.json')))
    assert set(report['first_two_input_sha256_by_epoch'])=={str(i) for i in range(1,41)}
    for pair in report['first_two_input_sha256_by_epoch'].values():
        assert type(pair) is list and len(pair)==2
        for h in pair:valid_sha(h)
    valid_sha(report['initial_raw_student_digest'])
    path=(ROOT/'continuation_completion_sources.json').as_posix()
    assert report['audit_sources_sha256']==f.sha(path)
    required=dict(context.bindings);required.update(base_bindings);required.update(input_bindings)
    required.update({(ROOT/r['name']).as_posix():r['sha256'] for r in loads(f.read(path))['files']})
    required[path]=f.sha(path)
    bound=canonical_bindings(f,report['bound_input_sha256'])
    assert required_run_files(job)<=set(bound)
    for n,h in required.items():assert bound.get(n)==h, 'Missing audit binding: '+n
    f.verify(bound)
    return bound


def closed_attempt(files,name,command=None):
    assert Path(name).parent==ROOT/'attempts'
    row=loads(files.read(name))
    assert row['status']=='completed' and type(row['returncode']) is int and row['returncode']==0
    assert 'stop_reason' not in row and row['ended_unix']>=row['started_unix']>0
    if command is not None:assert row['command']==command
    assert process_command(row['pid']) is None, 'Successful attempt still running'
    return row


def recovered_receipt(context,bases,source,gate):
    """Revalidate the separate recovery chain without repeating its tensor audit."""
    f=context.files;review=loads(f.read(recovery.REVIEW.as_posix()))
    f.verify(review['supporting_evidence_sha256']);recovery.manifest(f)
    recovery.validate_original_attempts(loads(f.read(review['original_parent_attempt'])),loads(f.read(review['original_child_attempt'])))
    path=(recovery.HERE/'RECEIPT.json').as_posix();receipt=loads(f.read(path))
    assert receipt['schema']=='incident018_recovered_continuation_receipt_v1'
    assert receipt['status']=='same_state_recovery_and_independent_completed_audit_passed'
    assert receipt['protocol_sha256']==PROTOCOL_SHA and receipt['label']==recovery.LABEL
    assert receipt['source_manifest_sha256']==f.sha(recovery.MANIFEST.as_posix())
    assert receipt['review_sha256']==f.sha(recovery.REVIEW.as_posix())
    assert receipt['capsule']==review['capsule'] and receipt['capsule_complete_sha256']==review['capsule_complete_sha256']
    assert receipt['original_attempt']==review['original_child_attempt']
    complete=verify_capsule(f,review['capsule'])
    plan=loads(f.read(review['capsule']+'/plan.json',complete['plan_sha256']))
    preserved={n:h for n,h in plan['run_inventory_sha256'].items() if Path(n).name!='training_state.pt'}
    assert receipt['unchanged_prior_run_sha256']==preserved;f.verify(preserved)
    ticket=loads(f.read((recovery.HERE/'worker_ticket.json').as_posix(),receipt['worker_ticket_sha256']))
    returned=loads(f.read((recovery.HERE/'worker_returned.json').as_posix(),receipt['worker_returned_sha256']))
    authority=loads(f.read((recovery.HERE/'authority.json').as_posix(),ticket['authority_sha256']))
    job,design=job_for_label(context,recovery.LABEL);inputs=checkpoint_bindings(context,job,design)
    assert authority['args']==dict(arguments(job,design,1),resume=True)
    assert authority['evidence']['pre_resume_inventory_sha256']==plan['run_inventory_sha256']
    for key,value in [('source',source),('bases',bases),('inputs',inputs)]:assert authority['evidence'][key]==value
    assert authority['evidence']['gate']==gate
    assert authority['parent_pid']==ticket['parent_pid'] and returned['status']=='trainer_returned_independent_audit_pending'
    assert returned['pid']==ticket['pid'] and returned['authority_sha256']==ticket['authority_sha256']
    assert returned['complete_sha256']==f.sha(job['run_directory']+'/COMPLETE.json')
    assert len(ticket['attempts'])==2 and {r['device'] for r in ticket['attempts'].values()}=={0,1}
    f.verify(receipt['closed_recovery_and_audit_attempt_sha256'])
    assert set(receipt['closed_recovery_and_audit_attempt_sha256'])==set(ticket['attempts'])|{receipt['audit_attempt']}
    ends=[]
    for n,initial in ticket['attempts'].items():
        row=closed_attempt(f,n,recovery.command(f,True));ends.append(row['ended_unix'])
        assert {k:row[k] for k in initial if k!='status'}=={k:v for k,v in initial.items() if k!='status'}
        assert row['GPU_job'] is True and row['pid']==ticket['pid'] and row['parent_pid']==ticket['parent_pid']
        assert row['started_unix']<=returned['returned_unix']<=row['ended_unix']
    cpu=closed_attempt(f,receipt['audit_attempt'],[str(f.project/'venv/bin/python'),'-u',(ROOT/'continuation_completion_audit.py').as_posix(),'--label',recovery.LABEL])
    assert cpu['GPU_job'] is False and cpu['started_unix']>=max(ends)
    report=loads(f.read((recovery.HERE/'completed_audit.json').as_posix(),receipt['audit_sha256']))
    bound=audit_report(context,job,report,bases,inputs)
    assert receipt['bound_file_sha256']==bound and receipt['actual_step_counts']==report['actual_step_counts']
    rows,_=resources(f)
    parents=[(n,r) for n,r in rows.items() if r.get('label')=='incident018_recovery_parent_CPU']
    assert len(parents)==1
    parent=closed_attempt(f,parents[0][0],recovery.command(f))
    assert parent['pid']==ticket['parent_pid'] and parent['ended_unix']>=cpu['ended_unix']
    f.verify(authority['evidence']['new_sources'])
    return {path:f.sha(path),parents[0][0]:f.sha(parents[0][0])}


def authenticate(files):
    new=sources(files);review=loads(files.read(recovery.REVIEW.as_posix()));latches(files,review);recovery.guard(files)
    context=Context(files.project);source=source_bindings(context);bases=verify_completed_bases(context)
    gate=verify_gate(files.project,context.manifest_hash);plan,design=plan_for(context)
    recovered=recovered_receipt(context,bases,source,gate)
    job,_=job_for_label(context,recovery.CONTROL)
    authority={'execution_source_sha256':source,'completed_base_bindings':bases,'preflight_gate':gate,
               'checkpoint_bindings':checkpoint_bindings(context,job,design)}
    _,digest=verify_receipt(context,recovery.CONTROL,authority)
    assert digest==review['completed_control_receipt_sha256']
    reuse=dict(recovered);reuse[(ROOT/'production_receipts'/f'{recovery.CONTROL}.json').as_posix()]=digest
    rows,usage=resources(files);check_limits(usage);assert not usage['active_GPU_attempts']
    assert all('ended_unix' in r for r in rows.values() if r.get('label')!='continuation_wave_parent_CPU')
    for wave in plan['waves']:
        for item in wave['jobs']:
            job,_=job_for_label(context,item['label']);untouched_destination(context,job)
            assert not files.path((HERE/'receipts'/f'{item["label"]}.json').as_posix()).exists()
    return context,plan,review,{'source':source,'bases':bases,'gate':gate,'new_sources':new,'reuse':reuse}
