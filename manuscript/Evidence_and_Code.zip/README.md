# Evidence for the completed YOLOv8 reassessment

Prepared 2026-10-01. Article: **Reassessing Pruning and Feature Distillation for Lightweight YOLOv8**. Authors: Hyerim Choi and Tae-Kook Kim.

## Completed scope

The archive separates historical artifact audits, the earlier nine-run objective study, and a fresh source-reconstructed phase. The latter trains new nano/large models for 100 epochs on 69,863 images excluding the 137 unverified cases, then completes control/MSE/CWD by three data seeds for 20 epochs. All 25 fixed external KITTI evaluations and all 11 new class/illumination evaluations are complete. No model is tuned or selected by KITTI outcomes.

Fresh primary ten-class AP50:95 means are control 0.2591236363, MSE 0.2588043595 and CWD 0.2583395409. Mean paired differences are -0.03192768 and -0.07840954 percentage points. External two-class moderate AP_R40 means are 0.7016589328, 0.7020294180 and 0.7030743041, giving positive paired differences of +0.03704852 and +0.14153713 points. Every fresh continuation remains below fresh nano externally. Both directions are retained; data distribution, categories and scoring rules change together. The earlier phase is reported separately, not pooled as additional independent base-model initializations.

## Package map

- `results/`: original checkpoint/state/data audits, exact artifact evaluations, measured runtime and earlier fixed-data implementation probe.
- `followup/`: every earlier nine-run record, primary/secondary analysis, label correspondence and annotation-sensitivity evidence.
- `clean_followup/`: two fresh bases, all nine new runs, all 25 external outcomes/precision curves, all 11 new secondary evaluations, frozen hashes and independent verification records.
- `clean_followup/scripts/`: published executed scientific scripts and analysis verifiers. Private server transport and credential helpers are excluded.
- `clean_followup/publication.json`: verified results commit and public artifact URLs, bytes and SHA-256 values.
- `clean_followup/public_record_manifest.json`: hashes relative to the published evidence directory; package-added scripts/publication notes are additional entries covered by the top-level SHA256SUMS.txt.
- `reference_verification.json`, `DATA_PROVENANCE.md`, figures and tables: source metadata and directly derived numerical artifacts.

The larger archives are intentionally linked instead of duplicated inside this ZIP: 25 inference checkpoints, all 187,025 KITTI prediction files, and 27 BDD per-image statistics sets. They were uploaded to the versioned GitHub release and publicly downloaded with exact hash verification. Exported checkpoint hashes differ from source-file hashes because training-location/history metadata is omitted, but every tensor/dtype/module/class name matches and deterministic CPU FP32 raw outputs are bitwise equal. Upstream model notices remain applicable. Obtain original images and full source labels separately under dataset terms.

## Reproduction and limits

Use Python 3.12.3, PyTorch 2.5.1+cu121, Ultralytics 8.2.103 and Torch-Pruning 1.6.0. The scientific scripts retain project-relative paths and reproduce the published configuration; choose new run directories for intentional replication, and never overwrite completed originals. Check every artifact hash before loading. Use the repository's c2f_v2_utils.py for archived pruned model modules.

Within each phase, three continuation seeds share one trained student/teacher pair. Primary FP32 batch32 differs from reconstructed-label group evaluation at batch8. Actual AMP skips and raw nonfinite gradient diagnostics are retained; all final saved tensors and objective means are finite. Earlier fixed-data control reruns are not independent repetitions. Historical pruning budgets differ, and runtime is model-only on a shared RTX4090 environment.

The 137 labels remain unidentified; only new-model exposure is removed. Reconstructed annotations correspond to a public legacy2018 mirror, not authenticated Detection2020 data. BDD validation is reused. KITTI is this study's external use of a publicly labeled training partition, not an official hidden-test result, and covers Car/Pedestrian only. Sequence correlation and COCO pretraining overlap are not fully audited. Unknown local test labels are excluded. No general KD ranking, target-device acceleration, safety certification, journal acceptance or completed submission is claimed.
