"""Initial, fixed27-job production dispatcher after the actual numerical gate.

At most two unsealed trajectories and two GPU allocations, one CPU file audit.
All children have owned sessions and pre-registered shared-ledger records.
Completed receipts are reused; a returned GPU job is audited, never retrained.
Failed/unclosed attempts and existing parent launches require an investigated,
separately validated recovery procedure. Import never starts work.
"""
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass
import os
from pathlib import Path
import signal
import subprocess
import time
import uuid
from continuation_artifact_receipts import ROOT,PROTOCOL_SHA,encoded,loads
from continuation_preflight_runtime import resources,check_limits,read_records,process_command,gpu_idle_uuid
from continuation_execution_runtime import (DISPATCHER,PARENT_LABEL,PREFIX,public_context,dispatcher_command,
    expected_command,source_bindings,job_for_label,checkpoint_bindings,supervision,production_latches)
import continuation_production_receipts as receipts
from run_continuation_preflight import update_owned,stop_owned_child,utc,supervision as prerequisite_supervision
from run_continuation_production_job import publish_failure
from validation_journal import publish_immutable


def register_attempt(files,label,command,device,parent_pid=None,pid=None,audit=False):
    """Publish all ownership/environment fields before another worker can read it."""
    token=f'{label}_{time.strftime("%Y%m%dT%H%M%SZ",time.gmtime())}_{uuid.uuid4().hex}'
    name=(ROOT/'attempts'/(token+'.json')).as_posix()
    log=(ROOT/'logs'/(token+'.log')).as_posix()
    row={'label':label,'command':command,'GPU_job':device is not None,'device':device,
        'started_utc':utc(),'started_unix':time.time(),'status':'starting' if pid is None else 'running','log':log}
    if parent_pid is not None:row['parent_pid']=parent_pid
    if pid is not None:row['pid']=pid
    if audit:
        assert device is None and label.startswith(receipts.AUDIT_PREFIX)
        row.update(environment_contract=receipts.CPU_ENVIRONMENT,
            stdout_artifact=receipts.audit_path(label[len(receipts.AUDIT_PREFIX):]))
    files.path(name).parent.mkdir(parents=True,exist_ok=True)
    files.path(log).parent.mkdir(parents=True,exist_ok=True)
    publish_immutable(files.path(name),encoded(row))
    return name,row


@dataclass
class Child:
    label:str
    audit:bool
    device:object
    command:list
    attempt:str
    row:dict
    proc:object=None
    log:object=None
    stdout:object=None
    closed:bool=False


def close_child(context,child,error=None,stop=stop_owned_child):
    """No end time for an unreaped live/unknown process; retain guard terminal."""
    if child.closed:return
    try:
        if child.proc is not None and child.proc.poll() is None:
            assert error is not None, 'Never close or interrupt a healthy running child'
            stop(child.proc,child.command)
    finally:
        if child.proc is None or child.proc.poll() is not None:
            for handle in (child.stdout,child.log):
                if handle is not None:handle.close()
            code=None if child.proc is None else child.proc.returncode
            terminal=dict(child.row,ended_unix=time.time(),ended_utc=utc(),returncode=code,
                status='completed' if code==0 and error is None else 'failed')
            if error is not None:terminal['stop_reason']=repr(error)
            retained=update_owned(context.files,child.attempt,child.row,terminal)
            child.closed=True
            if retained:child.row=terminal
            else:child.row=loads(context.files.read(child.attempt))


def start_child(context,label,device,parent_pid,audit=False,popen=subprocess.Popen):
    assert type(parent_pid) is int and parent_pid>0
    if audit:assert device is None
    else:assert type(device) is int and device in (0,1)
    command=receipts.audit_command(context,label) if audit else expected_command(context,label,device)
    name,row=register_attempt(context.files,(receipts.AUDIT_PREFIX if audit else PREFIX)+label,
        command,device,parent_pid=parent_pid,audit=audit)
    child=Child(label,audit,device,command,name,row)
    env=os.environ.copy();env['YOLO_CONFIG_DIR']=str(context.files.path((ROOT/'config').as_posix()))
    if audit:env.update(receipts.CPU_ENVIRONMENT)
    else:env.pop('CUDA_VISIBLE_DEVICES',None)
    try:
        child.log=context.files.path(row['log']).open('xb')
        if audit:
            target=context.files.path(row['stdout_artifact']);target.parent.mkdir(parents=True,exist_ok=True)
            child.stdout=target.open('xb')
        child.proc=popen(command,stdout=child.stdout if audit else child.log,
            stderr=child.log if audit else subprocess.STDOUT,stdin=subprocess.DEVNULL,
            start_new_session=True,env=env,cwd=context.files.project)
        running=dict(row,pid=child.proc.pid,status='running')
        assert update_owned(context.files,name,row,running), 'Guard stopped child admission'
        child.row=running
        return child
    except BaseException as error:
        close_child(context,child,error)
        raise


def validate_children(context,children,records,parent_pid,command_reader=process_command):
    """CPU audit children are also supervised; GPU peers have stricter runtime checks."""
    owned={c.attempt:c for c in children if not c.closed}
    for name,child in owned.items():
        assert records[name]==child.row and child.row['parent_pid']==parent_pid
        assert child.row['status']=='running' and child.row['pid']==child.proc.pid
        if child.proc.poll() is None:
            observed=command_reader(child.proc.pid)
            # The process can exit between poll and /proc lookup.
            if observed is None:assert child.proc.poll() is not None
            else:assert observed==child.command
    for name,row in records.items():
        if 'ended_unix' not in row and (row.get('label','').startswith(receipts.AUDIT_PREFIX) or receipts.AUDITOR.as_posix() in row.get('command',[])):
            assert name in owned and owned[name].audit, 'Unowned/stale completed-file audit process'
            assert row['GPU_job'] is False and row['device'] is None
            assert row['environment_contract']==receipts.CPU_ENVIRONMENT


def authority_for(context,label,source_hashes,gate,base_hashes):
    job,design=job_for_label(context,label)
    return {'execution_source_sha256':source_hashes,'preflight_gate':gate,
        'completed_base_bindings':base_hashes,'checkpoint_bindings':checkpoint_bindings(context,job,design)}


def check_output_inventory(context,design):
    f=context.files;labels={j['label'] for j in design['new_jobs']}
    for folder,allowed in [('production_receipts',{n+'.json' for n in labels}),
                           ('production_audits',{n+'.json' for n in labels}),
                           ('production_execution',labels),('continuations',labels)]:
        path=f.path((ROOT/folder).as_posix())
        if path.exists():
            assert {p.name for p in path.iterdir()}<=allowed, 'Unexpected/partial production artifact: '+folder
            for p in path.iterdir():f.path(p.relative_to(f.project).as_posix())


def build_schedule(context,design,records,authorities):
    check_output_inventory(context,design)
    pending=deque();audits=deque();done={}
    for job in design['new_jobs']:
        label=job['label'];authority=authorities[label]
        action,gpu,cpu=receipts.classify(context,label,records,authority)
        if action=='launch':pending.append(label)
        elif action=='audit_only':audits.append((label,gpu))
        elif action=='seal_only':done[label]=receipts.seal_receipt(context,label,gpu,cpu,authority)[1]
        else:done[label]=receipts.verify_receipt(context,label,authority)[1]
    return pending,audits,done


def collect(context,design,authorities,check,event,parent_pid,children,
            start=start_child,close=close_child,sleep=time.sleep,idle=gpu_idle_uuid,
            executor_factory=ThreadPoolExecutor):
    """Poll both GPU exits before CPU verification so ledger closure is prompt."""
    pending,audits,done=build_schedule(context,design,read_records(context.files),authorities)
    audit_gpu={};gpu_uuids={device:idle(device) for device in (0,1)}
    # Large file hashing must not stall ledger closure past the worker's bounded
    # exit handoff. This one read/hash thread launches no processes and imports
    # no tensors. Only completed, closed GPU/CPU attempts are passed to it.
    pool=executor_factory(max_workers=1);seals={}
    try:
        while pending or audits or children or seals:
            returned=[c for c in children if c.proc.poll() is not None]
            for child in returned:close(context,child)
            for child in returned:
                children.remove(child)
                assert child.row['status']=='completed' and child.row['returncode']==0, 'Child failed; retain evidence and stop'
                label=child.label
                if child.audit:
                    gpu=audit_gpu.pop(label)
                    seals[label]=pool.submit(receipts.seal_receipt,context,label,gpu,child.attempt,authorities[label])
                else:
                    # The independent auditor only reads. Full execution proof
                    # is required by seal_receipt before any result is accepted.
                    audits.append((label,child.attempt));event('GPU_returned_requires_CPU_audit',label=label)
            for label,future in list(seals.items()):
                if future.done():
                    done[label]=future.result()[1];del seals[label]
                    event('completed_file_audit_sealed',label=label,receipt_sha256=done[label])
            check()
            if audits and not any(c.audit for c in children):
                label,gpu=audits.popleft();audit_gpu[label]=gpu
                child=start(context,label,None,parent_pid,audit=True);children.append(child)
                event('CPU_audit_started',label=label,attempt=child.attempt)
            # Bound unsealed work to two trajectories, including audit/hash work.
            occupied={c.device for c in children if not c.audit}
            for device in (0,1):
                if not pending or len(children)+len(audits)+len(seals)>=2:break
                if device in occupied:continue
                check();assert idle(device)==gpu_uuids[device], 'Physical GPU changed'
                label=pending.popleft()
                assert receipts.classify(context,label,read_records(context.files),authorities[label])==('launch',None,None)
                child=start(context,label,device,parent_pid);children.append(child);occupied.add(device)
                event('GPU_started',label=label,device=device,attempt=child.attempt)
            if children or seals:sleep(.5)
    finally:
        # A failure first returns control to main, which stops owned GPU children.
        # A hash task may finish authenticating completed evidence; it cannot
        # train, change raw data, clear latches, or authorize further dispatch.
        pool.shutdown(wait=False,cancel_futures=True)
    assert set(done)=={j['label'] for j in design['new_jobs']} and len(done)==27
    # Recheck after every job has finished; never regenerate the audit or model.
    for label,value in done.items():
        check();assert receipts.verify_receipt(context,label,authorities[label])[1]==value
    reused={}
    for item in design['reused_paths']:
        assert item['action']=='reuse_only_never_retrain'
        for endpoint in item['endpoints']:
            name,value=endpoint['checkpoint']['path'],endpoint['checkpoint']['sha256']
            context.files.verify({name:value});reused[name]=value
    assert len(design['reused_paths'])==9 and len(reused)==18
    return {'schema':'continuation_training_collection_v1','status':'27_new_completed_audited_9_historical_paths_reused',
        'protocol_sha256':PROTOCOL_SHA,'context':context.identifiers(),'new_receipt_sha256':dict(sorted(done.items())),
        'reused_20_40_checkpoint_sha256':dict(sorted(reused.items())),
        'remaining':['Cross-path pairing and all84 endpoint analysis, including60new evaluation endpoints.',
                     '72fixed-batch gradient diagnostics and384metric decomposition cells.',
                     'Manuscript/supplement/review/GitHub revision and all-page visual verification.']}


def main():
    import argparse
    argparse.ArgumentParser().parse_args()  # no hidden queue/device/resume overrides
    assert os.name=='posix'
    os.environ.update(receipts.CPU_ENVIRONMENT)
    context,source_hashes,gate,base_hashes=public_context(Path.cwd());f=context.files
    assert Path(__file__).resolve()==f.path(DISPATCHER.as_posix()).resolve()
    assert f.sha(receipts.SELF.as_posix())==source_hashes[receipts.SELF.as_posix()]
    assert Path(receipts.__file__).resolve()==f.path(receipts.SELF.as_posix()).resolve()
    pid=os.getpid();command=dispatcher_command(context)
    assert os.getsid(pid)==os.getpgid(pid)==pid and process_command(pid)==command
    import fcntl
    lock=f.path((ROOT/'continuation_dispatcher.lock').as_posix()).open('a')
    fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    production_latches(f);rows,snapshot=resources(f);check_limits(snapshot)
    prerequisite_supervision(context,rows)
    assert not snapshot['active_GPU_attempts']
    assert not any('ended_unix' not in row and (row.get('label')==PARENT_LABEL or
        DISPATCHER.as_posix() in row.get('command',[])) for row in rows.values())
    launch=f.path((ROOT/'continuation_launch.json').as_posix())
    assert not launch.exists(), 'Existing dispatcher launch needs investigated recovery, never silent replacement'
    attempt,previous=register_attempt(f,PARENT_LABEL,command,None,pid=pid)
    own_log=f.path(previous['log']).open('xb');children=[];error=None
    def event(kind,**details):
        own_log.write(encoded({'utc':utc(),'event':kind,**details}));own_log.flush()
    def check():
        production_latches(f);current_rows,current=resources(f);check_limits(current)
        supervision(context,current_rows)
        validate_children(context,children,current_rows,pid)
        return current
    def interrupted(signum,frame):
        raise RuntimeError(f'Production dispatcher received signal {signum}; preserve and stop owned children')
    handlers={s:signal.signal(s,interrupted) for s in (signal.SIGTERM,signal.SIGINT)}
    try:
        publish_immutable(launch,encoded({'utc':utc(),'pid':pid,'command':command,'attempt':attempt,
            'source_sha256':f.sha(DISPATCHER.as_posix()),'execution_sources_sha256':source_hashes[(ROOT/'continuation_execution_sources.json').as_posix()]}))
        _,design=job_for_label(context,loads(f.read((ROOT/'continuation_design.json').as_posix()))['new_jobs'][0]['label'])
        authorities={job['label']:authority_for(context,job['label'],source_hashes,gate,base_hashes) for job in design['new_jobs']}
        event('admitted',resources=check(),new_jobs=27,reuse_only_paths=9)
        result=collect(context,design,authorities,check,event,pid,children)
        context.verify();f.verify(source_hashes);f.verify(base_hashes);check()
        result['dispatcher_attempt']=attempt
        result['execution_sources_sha256']=source_hashes[(ROOT/'continuation_execution_sources.json').as_posix()]
        result['resources_at_collection']=check()
        assert not result['resources_at_collection']['active_GPU_attempts']
        publish_immutable(f.path((ROOT/'CONTINUATION_TRAINING_COMPLETE.json').as_posix()),encoded(result))
        event('training_only_complete_evaluation_and_documents_still_pending')
    except BaseException as caught:
        error=caught
        publish_failure(f,'dispatcher',attempt,pid,caught)
        raise
    finally:
        # Each live child is identity checked before signalling; every failure
        # is retained. Never signal a process discovered merely by a broad name.
        for child in list(children):
            try:close_child(context,child,error or RuntimeError('Parent leaving with unfinished child'))
            except BaseException as child_error:
                error=error or child_error;publish_failure(f,child.label,child.attempt,pid,child_error)
        terminal=dict(previous,ended_unix=time.time(),ended_utc=utc(),returncode=0 if error is None else 1,
            status='completed' if error is None else 'failed')
        if error is not None:terminal['stop_reason']=repr(error)
        update_owned(f,attempt,previous,terminal)
        own_log.close()
        for signum,handler in handlers.items():signal.signal(signum,handler)
        lock.close()


if __name__=='__main__':main()
