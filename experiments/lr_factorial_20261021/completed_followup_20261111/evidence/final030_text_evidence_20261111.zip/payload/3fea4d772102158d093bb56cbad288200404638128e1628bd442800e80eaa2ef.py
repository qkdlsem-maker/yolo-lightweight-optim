"""Owned process/accounting primitive for future evaluation orchestration.

Library only: no CLI, admission, delayed launch or scientific request builder.
The caller must authenticate all training, inputs and final requests first, and
provide the global guard/cap/latch monitor. Tests replace only those boundaries.
GPU reservations cover both stage peers until BOTH sessions exit. CPU scoring
and independent audit stages are serial and have no GPU reservations.
"""
import os
from pathlib import Path
import signal
import subprocess
import time

from continuation_artifact_receipts import ROOT, loads, encoded
from continuation_preflight_runtime import process_command
from continuation_wave_runner import add_fields, finish, put
from run_continuations import register_attempt

GPU_STAGES = ('native_bdd', 'bdd_predictions', 'kitti_predictions')
CPU_STAGES = ('bdd_common', 'kitti_common', 'kitti_native', 'independent_audit')


def proc_identity(pid):
    try:
        raw = Path('/proc/%d/stat' % pid).read_text()
    except FileNotFoundError:
        return None
    fields = raw[raw.rfind(')') + 2:].split()
    return {'pid': pid, 'state': fields[0], 'group': int(fields[2]),
            'session': int(fields[3]), 'start_ticks': int(fields[19])}


def owned_members(child):
    """Only the newly created session, with a retained kernel start identity."""
    proc = child.get('proc')
    if proc is None:
        return []
    anchor = child['identity']
    leader = proc_identity(proc.pid)
    if leader is not None:
        assert leader['start_ticks'] == anchor['start_ticks'], 'PID reused'
        assert leader['session'] == leader['group'] == proc.pid
    members = []
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        item = proc_identity(int(path.name))
        if item is not None and item['session'] == proc.pid and item['state'] != 'Z':
            assert item['start_ticks'] >= anchor['start_ticks']
            members.append(item)
    return members


def drain(child, error):
    proc = child.get('proc')
    if proc is None:
        return
    if proc.poll() is None or owned_members(child):
        assert error is not None, 'Process or descendant outlived successful stage'
        for sig, duration in ((signal.SIGTERM, 2.), (signal.SIGKILL, 3.)):
            members = owned_members(child)
            for group in {m['group'] for m in members}:
                # Group IDs are selected only from this exact owned session.
                try:
                    os.killpg(group, sig)
                except ProcessLookupError:
                    pass
            deadline = time.monotonic() + duration
            while time.monotonic() < deadline:
                proc.poll()
                if proc.poll() is not None and not owned_members(child):
                    return
                time.sleep(.02)
        raise RuntimeError('Owned session did not exit; allocation remains open')
    assert proc.poll() is not None and not owned_members(child)


def validate(stage, tasks, folder, wall_seconds):
    assert stage in GPU_STAGES + CPU_STAGES
    assert type(wall_seconds) in (int, float) and 0 < wall_seconds <= 86400
    assert 1 <= len(tasks) <= (2 if stage in GPU_STAGES else 1)
    assert len({t['endpoint_id'] for t in tasks}) == len(tasks)
    for task in tasks:
        assert set(task) == {'endpoint_id', 'command', 'device', 'environment'}
        eid = task['endpoint_id']
        assert type(eid) is str and eid and Path(eid).name == eid and '/' not in eid and '\\' not in eid and ':' not in eid and eid not in ('.', '..')
        assert type(task['command']) is list and task['command'] and all(type(x) is str and x and '\0' not in x for x in task['command'])
        assert set(task['environment']) <= {'PYTHONPATH', 'YOLO_CONFIG_DIR'}
        assert all(type(v) is str for v in task['environment'].values())
        if stage in GPU_STAGES:
            assert type(task['device']) is int and task['device'] in (0, 1)
        else:
            assert task['device'] is None
    if stage in GPU_STAGES:
        assert len({t['device'] for t in tasks}) == len(tasks)
    assert Path(folder).parts[:len(ROOT.parts)] == ROOT.parts


def run_stage(files, folder, stage, tasks, parent_attempt, parent_row,
              monitor, idle_uuid, expected_uuids, verify, wall_seconds):
    """Run one stage exactly once. Callbacks confer no production admission.

    monitor(reservations) must enforce original global caps/guard/latches,
    absent training and exact active allocations. verify(task) returns newly
    produced artifact byte bindings. A stage receipt is NOT an endpoint audit.
    """
    validate(stage, tasks, folder, wall_seconds)
    folder = Path(folder)
    pid = os.getpid()
    command = process_command(pid)
    assert parent_row['pid'] == pid and parent_row['command'] == command
    assert parent_row['GPU_job'] is False and 'ended_unix' not in parent_row
    assert loads(files.read(parent_attempt)) == parent_row
    destination = files.path(str(folder))
    # This exclusive create happens before handlers or shared-ledger mutation.
    destination.mkdir(parents=True, exist_ok=False)
    reservations, children = {}, []
    interrupted = []
    previous = {sig: signal.getsignal(sig) for sig in (signal.SIGTERM, signal.SIGINT)}
    for sig in previous:
        signal.signal(sig, lambda number, _frame: interrupted.append(number))
    started = time.monotonic()

    def check():
        assert not interrupted, 'Evaluation stage interrupted'
        assert time.monotonic() - started < wall_seconds, 'Evaluation stage wall limit'
        assert process_command(pid) == command
        assert loads(files.read(parent_attempt)) == parent_row, 'Parent attempt changed/terminated'
        monitor(reservations)
        for child in children:
            assert loads(files.read(child['attempt'])) == child['row'], 'Child attempt changed/terminated'

    def close(error):
        # Refuse to close any charged reservation until all owned sessions drain.
        for child in children:
            drain(child, error)
        for child in children:
            if child.get('log') is not None:
                child['log'].close()
            code = child['proc'].returncode if child.get('proc') is not None else 1
            terminal = finish(files, child['attempt'], child['row'], code, error)
            child['terminal'] = terminal
            if error is None:
                assert terminal['status'] == 'completed' and terminal['returncode'] == 0
        for name, row in reservations.items():
            terminal = finish(files, name, row, 0 if error is None else 1, error)
            if error is None:
                assert terminal['status'] == 'completed' and terminal['returncode'] == 0

    try:
        check()
        put(files, folder/'intent.json', {'stage': stage, 'tasks': tasks, 'parent_pid': pid,
            'parent_attempt': parent_attempt, 'parent_command': command,
            'started_unix': time.time(), 'wall_seconds': wall_seconds,
            'whole_evaluation_admitted_by_this_library': False})
        if stage in GPU_STAGES:
            observed = {str(t['device']): idle_uuid(t['device']) for t in tasks}
            assert observed == {d: expected_uuids[d] for d in observed}, 'GPU identity/idle check'
            for task in tasks:
                n, row = register_attempt(files, 'factorial_eval_stage_GPU%d_reservation' % task['device'],
                    command, task['device'], pid=pid)
                reservations[n] = row
                reservations[n] = add_fields(files, n, row, reservation=True, stage=stage,
                    stage_directory=str(folder), endpoint_id=task['endpoint_id'])
            check()
        put(files, folder/'allocation.json', {'reservations': reservations,
            'CPU_only': stage in CPU_STAGES, 'allocated_unix': time.time()})
        for task in tasks:
            check()
            n, row = register_attempt(files, 'factorial_eval_stage_%s__%s' % (stage, task['endpoint_id']),
                task['command'], None, parent_pid=pid)
            child = {'attempt': n, 'row': row, 'task': task}
            children.append(child)
            child['row'] = add_fields(files, n, row, stage=stage, stage_directory=str(folder),
                physical_device=task['device'], GPU_accounting='parent_stage_reservations' if reservations else 'CPU_only',
                reservation_attempts=sorted(reservations))
            child['log'] = files.path(str(folder/(task['endpoint_id']+'.log'))).open('xb')
            env = dict(os.environ, CUDA_VISIBLE_DEVICES='' if task['device'] is None else str(task['device']),
                       OMP_NUM_THREADS='2', MKL_NUM_THREADS='2', PYTHONUNBUFFERED='1')
            env.update(task['environment'])
            proc = subprocess.Popen(task['command'], cwd=files.project, env=env,
                stdin=subprocess.DEVNULL, stdout=child['log'], stderr=subprocess.STDOUT, start_new_session=True)
            child['proc'] = proc
            child['identity'] = proc_identity(proc.pid)
            assert child['identity'] is not None and child['identity']['session'] == child['identity']['group'] == proc.pid
            child['row'] = add_fields(files, n, child['row'], pid=proc.pid, status='running',
                kernel_start_ticks=child['identity']['start_ticks'])
            put(files, folder/(task['endpoint_id']+'_ticket.json'), {'pid': proc.pid,
                'attempt': n, 'registered': child['row'], 'parent_pid': pid, 'command': task['command']})
        while True:
            check()
            codes = [c['proc'].poll() for c in children]
            assert all(code in (None, 0) for code in codes), 'Evaluation worker failed; no retry'
            for c, code in zip(children, codes):
                if code is not None:
                    assert not owned_members(c), 'Worker left a live descendant'
            if all(code == 0 for code in codes):
                break
            time.sleep(.2)
        close(None)
        closed_reservations = dict(reservations)
        reservations.clear()
        # All GPU sessions have exited before artifact checks or CPU scoring.
        monitor({})
        assert not interrupted and loads(files.read(parent_attempt)) == parent_row
        artifacts = {}
        for task in tasks:
            bindings = verify(task)
            assert type(bindings) is dict and bindings
            files.verify(bindings)
            artifacts[task['endpoint_id']] = bindings
        assert time.monotonic() - started < wall_seconds
        monitor({})
        assert not interrupted and loads(files.read(parent_attempt)) == parent_row
        receipt = {'status': 'stage_processes_exited_and_artifact_bytes_verified', 'stage': stage,
            'parent_attempt': parent_attempt, 'parent_pid': pid, 'ended_unix': time.time(),
            'worker_attempt_sha256': {c['attempt']: files.sha(c['attempt']) for c in children},
            'reservation_attempt_sha256': {n: files.sha(n) for n in closed_reservations},
            'artifacts': artifacts, 'sessions_drained': True,
            'endpoint_independent_audit_and_seal_complete': False}
        put(files, folder/'STAGE_COMPLETE.json', receipt)
        return receipt
    except BaseException as error:
        put(files, folder/'FAILURE.json', {'error': repr(error), 'pid': pid,
            'automatic_retry': False, 'original_outputs_and_attempts_preserved': True})
        close(error)
        raise
    finally:
        for sig, handler in previous.items():
            signal.signal(sig, handler)
