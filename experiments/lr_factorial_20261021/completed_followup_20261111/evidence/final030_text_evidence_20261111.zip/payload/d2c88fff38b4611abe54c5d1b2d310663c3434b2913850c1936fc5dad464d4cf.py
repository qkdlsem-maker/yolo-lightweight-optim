"""Strict numerical checks for fixed preflight evidence already bound by a caller.

No file loading, dispatch or readiness-marker publication. This module cannot
establish source/file authenticity: the future artifact reader must verify all
immutable input, source, receipt and output hashes before calling these checks.
Only wall-clock seconds and serialized checkpoint-file hashes differ legitimately
between separate runs. Raw tensors and RNG always use exact typed byte equality.
"""
import hashlib
import math
import numpy as np
import torch
from continuation_observer import assert_exact

COMMON_EPOCH = {'epoch', 'lr', 'det_loss', 'feature_loss', 'seconds', 'batches',
                'optimizer_steps_skipped', 'median_unclipped_grad_norm', 'first_two_input_sha256'}
EXTRA_EPOCH = {'gradient_norm_finite_batches', 'gradient_norm_nonfinite_batches',
               'finite_gradient_clipped_batches', 'actual_step_counts', 'student_state_sha256',
               'adapter_state_sha256', 'EMA_state_sha256', 'batch_step_ledger_sha256'}
STEP_KEYS = {'batch', 'applied', 'AMP_scale_before', 'AMP_scale_after', 'unclipped_gradient_norm',
             'gradient_norm_finite', 'clipping_invoked', 'finite_norm_above_clip'}
STATE_KEYS = ('student', 'adapters', 'ema', 'ema_updates', 'optimizer', 'scaler')
RNG_KEYS = ('rng_python', 'rng_numpy', 'rng_torch', 'rng_cuda')
SNAPSHOT_KEYS = set(STATE_KEYS) | {'rng', 'initial_student_parameters', 'teacher_state_sha256',
                                 'teacher_no_grad_and_unchanged'}
METRIC_KEYS = {'map50', 'map50_95', 'precision', 'recall', 'classes', 'ap50', 'ap50_95',
               'checkpoint_sha256', 'state_sha256'}


def sha(value):
    assert type(value) is str and len(value) == 64 and all(c in '0123456789abcdef' for c in value)


def integer(value, minimum=0):
    assert type(value) is int and value >= minimum


def finite(value, minimum=None):
    assert type(value) is float and math.isfinite(value)
    assert minimum is None or value >= minimum


def training_digest(state):
    """Exact legacy digest representation used in the frozen candidate records."""
    h = hashlib.sha256()
    for key, value in sorted(state.items()):
        h.update(key.encode())
        h.update(value.detach().cpu().contiguous().numpy().tobytes())
    return h.hexdigest()


def check_snapshot(snapshot, initial_adapter_digest=None, arm=None):
    assert snapshot.keys() == SNAPSHOT_KEYS
    assert_exact(snapshot, snapshot)  # Reject any nonfinite tensor/scalar in raw saved state.
    assert snapshot['rng'].keys() == set(RNG_KEYS)
    assert snapshot['teacher_no_grad_and_unchanged'] is True
    sha(snapshot['teacher_state_sha256'])
    integer(snapshot['ema_updates'], 1)
    initial = snapshot['initial_student_parameters']
    assert initial and initial.keys() <= snapshot['student'].keys()
    fixed = [k for k in initial if 'dfl.conv.weight' in k]
    assert len(fixed) == 1
    assert_exact(initial[fixed[0]], snapshot['student'][fixed[0]], 'fixed_DFL')
    changed = 0
    for key, before in initial.items():
        after = snapshot['student'][key]
        assert before.dtype == after.dtype and before.shape == after.shape
        changed += not torch.equal(before, after)
    assert changed > 0, 'No raw parameter update'
    if initial_adapter_digest is not None:
        sha(initial_adapter_digest)
        assert arm in ('control', 'mse', 'cwd')
        unchanged = training_digest(snapshot['adapters']) == initial_adapter_digest
        assert unchanged == (arm == 'control'), 'Unexpected adapter update/preservation'
    return changed


def check_epoch_chain(records, steps, lr, batches, final_epoch):
    assert type(lr) is float and lr in (.0001, .001)
    assert len(records) == len(steps) == final_epoch
    cumulative = {'attempted': 0, 'applied': 0, 'skipped': 0}
    prior_scale = 128.
    for epoch, (record, ledger) in enumerate(zip(records, steps), 1):
        assert record.keys() == COMMON_EPOCH | EXTRA_EPOCH
        integer(record['epoch'], 1); assert record['epoch'] == epoch
        integer(record['batches'], 1); assert record['batches'] == batches == len(ledger)
        expected_lr = lr * (.1 + .9 * (1 + math.cos(math.pi * (epoch - 1) / 39)) / 2)
        assert_exact(record['lr'], expected_lr, 'fixed_cosine_schedule')
        finite(record['det_loss'], 0.); finite(record['feature_loss']); finite(record['seconds'], 0.)
        assert len(record['first_two_input_sha256']) == 2
        for value in record['first_two_input_sha256']:
            sha(value)
        for key in ('student_state_sha256', 'adapter_state_sha256', 'EMA_state_sha256', 'batch_step_ledger_sha256'):
            sha(record[key])
        applied, nonfinite, clipped = 0, 0, 0
        for index, item in enumerate(ledger):
            assert item.keys() == STEP_KEYS
            integer(item['batch']); assert item['batch'] == index
            integer(item['applied']); assert item['applied'] in (0, 1)
            finite(item['AMP_scale_before'], 0.); finite(item['AMP_scale_after'], 0.)
            assert item['AMP_scale_before'] > 0 and item['AMP_scale_after'] > 0
            assert_exact(item['AMP_scale_before'], prior_scale, 'continuous_AMP_scale')
            assert bool(item['applied']) == (item['AMP_scale_after'] >= prior_scale)
            prior_scale = item['AMP_scale_after']
            assert type(item['gradient_norm_finite']) is bool and item['clipping_invoked'] is True
            norm = item['unclipped_gradient_norm']
            if item['gradient_norm_finite']:
                finite(norm, 0.)
                assert type(item['finite_norm_above_clip']) is bool
                assert item['finite_norm_above_clip'] == (norm > 10.)
            else:
                assert norm is None and item['finite_norm_above_clip'] is None
                assert item['applied'] == 0, 'Nonfinite gradient produced a raw optimizer step'
            applied += item['applied']; nonfinite += not item['gradient_norm_finite']
            clipped += item['finite_norm_above_clip'] is True
        cumulative['attempted'] += batches
        cumulative['applied'] += applied; cumulative['skipped'] += batches - applied
        assert_exact(record['actual_step_counts'], cumulative, 'actual_step_counts')
        for key, expected in [('optimizer_steps_skipped', batches - applied),
                              ('gradient_norm_finite_batches', batches - nonfinite),
                              ('gradient_norm_nonfinite_batches', nonfinite),
                              ('finite_gradient_clipped_batches', clipped)]:
            integer(record[key]); assert record[key] == expected
        median = record['median_unclipped_grad_norm']
        if median is None:
            assert nonfinite > 0, 'Undefined median without any nonfinite batch'
        else:
            finite(median, 0.)
        if nonfinite == 0:
            assert_exact(median, float(np.median([x['unclipped_gradient_norm'] for x in ledger])))
    assert cumulative['applied'] > 0
    return cumulative


def check_snapshot_record(snapshot, record):
    for snapshot_key, record_key in [('student', 'student_state_sha256'),
                                     ('adapters', 'adapter_state_sha256'), ('ema', 'EMA_state_sha256')]:
        assert training_digest(snapshot[snapshot_key]) == record[record_key]
    assert_exact(snapshot['ema_updates'], record['actual_step_counts']['applied'], 'EMA_applied_count')


def check_training_state(state, snapshot, record):
    assert state.keys() == set(STATE_KEYS) | set(RNG_KEYS) | {'epoch', 'actual_step_counts', 'elapsed'}
    integer(state['epoch'], 1); assert state['epoch'] == record['epoch']
    finite(state['elapsed'], 0.)
    assert_exact(state['actual_step_counts'], record['actual_step_counts'])
    for key in STATE_KEYS:
        assert_exact(state[key], snapshot[key], 'training_checkpoint/' + key)
    assert_exact({k: state[k] for k in RNG_KEYS}, snapshot['rng'], 'training_checkpoint/RNG')
    check_snapshot_record(snapshot, record)


def compare_observation(reference, candidate, lr, arm):
    """One original/candidate32-batch case. Original missing AMP ledger is not invented."""
    for bundle in (reference, candidate):
        check_snapshot(bundle['snapshot'])
        assert len(bundle['epochs']) == 1
    assert_exact(reference['snapshot'], candidate['snapshot'], 'observational_raw_and_RNG')
    counts = check_epoch_chain(candidate['epochs'], candidate['steps'], lr, 32, 1)
    check_snapshot(candidate['snapshot'], candidate['initial_adapter_digest'], arm)
    check_snapshot_record(candidate['snapshot'], candidate['epochs'][0])
    original, added = reference['epochs'][0], candidate['epochs'][0]
    assert original.keys() == COMMON_EPOCH
    for key in COMMON_EPOCH - {'seconds', 'median_unclipped_grad_norm'}:
        assert_exact(original[key], added[key], 'observation/' + key)
    finite(original['seconds'], 0.)
    median = original['median_unclipped_grad_norm']
    if type(median) is float and not math.isfinite(median):
        assert added['median_unclipped_grad_norm'] is None
        assert added['gradient_norm_nonfinite_batches'] > 0
    else:
        assert_exact(median, added['median_unclipped_grad_norm'])
    assert_exact(reference['gradient_check'], candidate['gradient_check'], 'initial_gradient_observation')
    assert candidate['gradient_check']['channel_probe_preserved_buffers'] is True
    integer(candidate['gradient_check']['student_nonzero_grad_tensors'], 1)
    assert candidate['gradient_check']['adapter_grad_tensors'] == (0 if arm == 'control' else 6)
    assert counts['applied'] == reference['snapshot']['ema_updates']
    return {'status': 'numerical_case_passed_only', 'actual_step_counts': counts,
            'original_applied_count_evidence': 'Original EMA updates and skipped steps, not retrospective optimizer hooks.'}


def compare_replay(uninterrupted, interrupted, captures, validation_artifacts, post_rng, lr, arm):
    """One8-batch/12-epoch case with four captures at2,10before,10after,12.

    validation_artifacts are per-segment hash inventories from the future runner.
    Their stability proves preservation; inference-call semantics additionally
    depend on the frozen validation journal and its separately recorded tests.
    """
    assert len(captures) == 4 and len(validation_artifacts) == 4
    for bundle in (uninterrupted, interrupted):
        counts = check_epoch_chain(bundle['epochs'], bundle['steps'], lr, 8, 12)
        check_snapshot(bundle['snapshot'], bundle['initial_adapter_digest'], arm)
        check_training_state(bundle['training_state'], bundle['snapshot'], bundle['epochs'][-1])
        assert counts == bundle['epochs'][-1]['actual_step_counts']
    assert_exact(uninterrupted['initial_adapter_digest'], interrupted['initial_adapter_digest'])
    for index, (left, right) in enumerate(zip(uninterrupted['epochs'], interrupted['epochs']), 1):
        assert_exact({k: v for k, v in left.items() if k != 'seconds'},
                     {k: v for k, v in right.items() if k != 'seconds'}, 'replay_epoch/' + str(index))
    assert_exact(uninterrupted['steps'], interrupted['steps'], 'all_batch_steps')
    assert_exact(uninterrupted['snapshot'], interrupted['snapshot'], 'replay_final_raw_and_RNG')
    assert_exact(interrupted['snapshot'], captures[-1], 'last_segment_snapshot')
    for snapshot, epoch in zip(captures, (2, 10, 10, 12)):
        check_snapshot(snapshot, interrupted['initial_adapter_digest'], arm)
        check_snapshot_record(snapshot, interrupted['epochs'][epoch - 1])
        for key in ('initial_student_parameters', 'teacher_state_sha256', 'teacher_no_grad_and_unchanged'):
            assert_exact(snapshot[key], interrupted['snapshot'][key], 'segment_invariant/' + key)
    assert_exact({k: v for k, v in captures[1].items() if k != 'rng'},
                 {k: v for k, v in captures[2].items() if k != 'rng'}, 'validation_no_parameter_change')
    check_training_state(interrupted['raw_epoch10'], captures[1], interrupted['epochs'][9])
    # The uninterrupted raw sidecar is also saved before validation.
    check_training_state(uninterrupted['raw_epoch10'], captures[1], uninterrupted['epochs'][9])
    assert_exact(post_rng, captures[2]['rng'], 'committed_post_validation_RNG')
    assert validation_artifacts[:2] == [{}, {}]
    keys = {'result.json', 'post_rng.bin', 'manifest.json', 'metrics.json', 'checkpoint.pt'}
    assert validation_artifacts[2].keys() == keys and validation_artifacts[3].keys() == keys
    for value in validation_artifacts[2].values():
        sha(value)
    assert_exact(validation_artifacts[2], validation_artifacts[3], 'committed_validation_bytes_preserved')
    assert validation_artifacts[2]['result.json'] == validation_artifacts[2]['metrics.json']
    for bundle in (uninterrupted, interrupted):
        assert bundle['validation_metrics'].keys() == METRIC_KEYS
        sha(bundle['validation_metrics']['checkpoint_sha256'])
        assert bundle['validation_metrics']['state_sha256'] == bundle['epochs'][9]['EMA_state_sha256']
    assert_exact({k: v for k, v in uninterrupted['validation_metrics'].items() if k != 'checkpoint_sha256'},
                 {k: v for k, v in interrupted['validation_metrics'].items() if k != 'checkpoint_sha256'},
                 'diagnostic_validation_values')
    assert_exact(uninterrupted['post_validation_rng'], post_rng, 'uninterrupted_validation_RNG')
    return {'status': 'numerical_case_passed_only', 'epochs_compared': 12, 'batches_per_trajectory': 96,
            'actual_step_counts': interrupted['epochs'][-1]['actual_step_counts'],
            'validation_commit_bytes_preserved_across_final_resume': True}
