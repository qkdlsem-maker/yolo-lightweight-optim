"""Passive call/return observer for the fixed continuation preflight only.

No source rewriting, optimizer hooks or per-batch code injection. Teacher state
is read after its existing channel probe; the complete comparison snapshot is
read only when main returns. The caller must apply the fixed fixture and budget
gates before executing a program. Importing this module launches nothing.
"""
import hashlib
import math
import os
import runpy
import struct
import sys
from pathlib import Path

import numpy as np
import torch
from continuation_rng import capture_rng_state


def freeze(value):
    if isinstance(value, torch.Tensor):
        return value.detach().cpu().clone()
    if isinstance(value, np.ndarray):
        return value.copy()
    if isinstance(value, dict):
        return {key: freeze(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return tuple(freeze(item) for item in value)
    if isinstance(value, list):
        return [freeze(item) for item in value]
    assert value is None or type(value) in (str, int, float, bool), type(value)
    return value


def state_digest(state):
    h = hashlib.sha256()
    for key, tensor in sorted(state.items()):
        value = tensor.detach().cpu().contiguous()
        h.update(key.encode())
        h.update(str(value.dtype).encode())
        h.update(str(tuple(value.shape)).encode())
        h.update(value.reshape(-1).view(torch.uint8).numpy().tobytes())
    return h.hexdigest()


def assert_exact(left, right, path='state'):
    """Typed, bitwise equality; no tolerance or NaN equivalence for raw states."""
    if isinstance(left, torch.Tensor):
        assert isinstance(right, torch.Tensor), (path, 'tensor type')
        assert left.dtype == right.dtype and left.shape == right.shape, (path, 'tensor shape/dtype')
        assert bool(torch.isfinite(left).all()) and bool(torch.isfinite(right).all()), (path, 'nonfinite tensor')
        a, b = left.cpu().contiguous(), right.cpu().contiguous()
        assert torch.equal(a.reshape(-1).view(torch.uint8), b.reshape(-1).view(torch.uint8)), (path, 'tensor bytes')
    elif isinstance(left, np.ndarray):
        assert isinstance(right, np.ndarray) and left.dtype == right.dtype and left.shape == right.shape, (path, 'array shape/dtype')
        assert np.isfinite(left).all() and np.isfinite(right).all(), (path, 'nonfinite array')
        assert left.tobytes() == right.tobytes(), (path, 'array bytes')
    elif isinstance(left, dict):
        assert isinstance(right, dict) and left.keys() == right.keys(), (path, 'mapping keys')
        for key in left:
            assert_exact(left[key], right[key], path + '/' + str(key))
    elif isinstance(left, (tuple, list)):
        assert type(left) is type(right) and len(left) == len(right), (path, 'sequence')
        for index, (a, b) in enumerate(zip(left, right)):
            assert_exact(a, b, path + '/' + str(index))
    elif type(left) is float:
        assert type(right) is float and math.isfinite(left) and math.isfinite(right), (path, 'finite float')
        assert struct.pack('!d', left) == struct.pack('!d', right), (path, 'float bits')
    else:
        assert type(left) is type(right) and left == right, (path, 'scalar')


def capture_main(local, teacher_initial_digest, capture_rng=capture_rng_state):
    required = {'student', 'teacher', 'adapters', 'ema', 'optimizer', 'scaler', 'args', 'before', 'out'}
    assert required <= local.keys(), 'Main did not reach a completed fixture return'
    assert teacher_initial_digest is not None, 'Teacher channel probe was not observed'
    # Snapshot RNG first. Subsequent CPU copies and hashing must not consume it.
    rng = freeze(capture_rng(local['args'].device))
    teacher = local['teacher']
    assert all(p.grad is None for p in teacher.parameters()), 'Teacher received gradients'
    assert state_digest(teacher.state_dict()) == teacher_initial_digest, 'Frozen teacher changed'
    result = {'student': freeze(local['student'].state_dict()),
              'adapters': freeze(local['adapters'].state_dict()),
              'ema': freeze(local['ema'].ema.state_dict()),
              'ema_updates': int(local['ema'].updates),
              'optimizer': freeze(local['optimizer'].state_dict()),
              'scaler': freeze(local['scaler'].state_dict()),
              'rng': rng, 'initial_student_parameters': freeze(local['before']),
              'teacher_state_sha256': teacher_initial_digest, 'teacher_no_grad_and_unchanged': True}
    assert_exact(result, result)  # Finite saved values, not finite historical gradients.
    assert_exact(rng, freeze(capture_rng(local['args'].device)), 'observer_RNG_noninterference')
    return result


def observe_program(target, argv, output, expected_sha256, capture_rng=capture_rng_state):
    """Execute one already-admitted fixture, retain an immutable raw CPU snapshot.

    capture_rng is injectable solely for CPU observer tests with fake CUDA state.
    The production GPU fixture runner must use the default implementation.
    """
    target, output = Path(target).resolve(), Path(output)
    assert hashlib.sha256(target.read_bytes()).hexdigest() == expected_sha256
    assert not output.exists() and not output.with_suffix(output.suffix + '.pending').exists()
    assert sys.getprofile() is None, 'Do not replace another profiler'
    main_snapshot = None
    teacher_initial = None
    observer_errors = []

    def inspect_return(frame):
        nonlocal main_snapshot, teacher_initial
        if frame.f_code.co_name == 'features' and frame.f_back is not None:
            parent = frame.f_back
            if parent.f_code.co_name == 'main' and parent.f_code.co_filename == str(target):
                model = frame.f_locals.get('model')
                if model is not None and model is parent.f_locals.get('teacher'):
                    assert teacher_initial is None, 'Unexpected repeated teacher channel probe'
                    teacher_initial = state_digest(model.state_dict())
        elif frame.f_code.co_name == 'main':
            assert main_snapshot is None, 'Unexpected repeated main return'
            # Exceptions can also cause a return event. If any exception escapes,
            # runpy below fails and this in-memory snapshot is never published.
            main_snapshot = capture_main(frame.f_locals, teacher_initial, capture_rng)

    def observer(frame, event, value):
        if event != 'return' or frame.f_code.co_filename != str(target) or observer_errors:
            return
        try:
            inspect_return(frame)
        except Exception as error:
            # Never replace the trainer's original exception during unwinding.
            observer_errors.append(error)

    saved_argv, saved_path = sys.argv, list(sys.path)
    try:
        sys.argv = [str(target), *argv]
        sys.setprofile(observer)
        runpy.run_path(str(target), run_name='__main__')
    finally:
        sys.setprofile(None)
        sys.argv = saved_argv
        sys.path[:] = saved_path
    if observer_errors:
        raise RuntimeError('Passive observer failed; no snapshot published') from observer_errors[0]
    assert main_snapshot is not None
    assert hashlib.sha256(target.read_bytes()).hexdigest() == expected_sha256
    output.parent.mkdir(parents=True, exist_ok=True)
    pending = output.with_suffix(output.suffix + '.pending')
    with pending.open('xb') as stream:
        torch.save(main_snapshot, stream)
        stream.flush()
        os.fsync(stream.fileno())
    os.link(pending, output)  # Atomic create; never replace a completed snapshot.
    pending.unlink()
    return {'target_sha256': expected_sha256, 'snapshot_sha256': hashlib.sha256(output.read_bytes()).hexdigest(),
            'observer_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            'teacher_state_sha256': teacher_initial, 'EMA_updates': main_snapshot['ema_updates']}
