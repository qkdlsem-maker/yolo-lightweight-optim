"""One registered, bounded fixture only; no dispatcher or production admission.

The caller must use the shared attempts ledger, a new process session and the
fixed command. Missing full source/input freeze or completed base audits causes
rejection before Torch/CUDA import. Importing this file does not run a fixture.
"""
import argparse
import hashlib
import os
from pathlib import Path
import signal
import threading
import time
import traceback
from continuation_artifact_receipts import (
    ROOT, PROTOCOL_SHA, Context, encoded, invocation_spec, verify_receipt,
    check_output_boundary, receipt_path,
)
from continuation_fixture_roster import argument_vector
from continuation_preflight_runtime import (
    BudgetExceeded, RUNNER, no_latches, read_records, resources, check_limits,
    verify_completed_bases, check_process_ownership, gpu_idle_uuid,
    verify_runner_sources, watch_budget,
)
from validation_journal import publish_immutable


def prior_state_and_destination(context, spec):
    """Before any output creation, reject a repeat or an unreceipted continuation."""
    f = context.files
    capture = Path(spec['artifacts']['snapshot'])
    for name in (capture, capture.with_suffix('.pt.pending'), capture.with_suffix('.execution.json'),
                 capture.with_suffix('.admission.json'), Path(receipt_path(spec['invocation']['id']))):
        assert not f.path(name.as_posix()).exists(), 'Completed/partial fixture already exists; preserve and investigate'
    out = f.path(spec['out'])
    if spec['previous'] is None:
        assert not out.exists(), 'First fixture must have a new isolated output'
        return None
    previous, previous_hash = verify_receipt(context, spec['previous'])
    assert previous['device'] == spec['args']['device']
    prior_spec = invocation_spec(context, spec['previous'], previous['device'])
    check_output_boundary(context, prior_spec)
    assert f.sha((Path(spec['out']) / 'training_state.pt').as_posix()) == previous['artifacts']['training_state']['sha256']
    return previous_hash


def wait_for_attempt(context, invocation_id, device, pid):
    # Popen and the parent's atomic running-record publication have a short race.
    # Waiting creates no files and cannot admit a process without the final record.
    deadline = time.monotonic() + 10.
    while True:
        rows = read_records(context.files)
        matches = [row for row in rows.values() if row.get('pid') == pid]
        if matches:
            return rows, check_process_ownership(context, invocation_id, device, rows, pid)
        assert time.monotonic() < deadline, 'No registered shared-ledger attempt'
        time.sleep(.1)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--invocation-id', required=True)
    parser.add_argument('--device', type=int, choices=(0, 1), required=True)
    args = parser.parse_args()
    assert os.name == 'posix', 'Actual GPU runner is Linux-only'
    assert 'CUDA_VISIBLE_DEVICES' not in os.environ, 'Use fixed physical device indices without remapping'
    context = Context(Path.cwd())
    verify_runner_sources(context)
    assert Path(__file__).resolve() == context.files.path(RUNNER.as_posix()).resolve()
    no_latches(context.files)
    spec = invocation_spec(context, args.invocation_id, args.device)
    pid = os.getpid()
    assert os.getsid(pid) == os.getpgid(pid) == pid, 'Require an independently owned process session'
    _, attempt_name = wait_for_attempt(context, args.invocation_id, args.device, pid)
    registered = True
    stopped = threading.Event()
    watcher = None
    held_locks = []

    def latch(error):
        evidence = {'utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                    'invocation_id': args.invocation_id, 'pid': pid, 'attempt': attempt_name,
                    'error': repr(error), 'traceback': traceback.format_exc(),
                    'completed_artifacts_and_last_atomic_state_preserved': True}
        if isinstance(error, BudgetExceeded):
            evidence.update(scope=error.scope, resource_snapshot=error.snapshot)
            name = 'CONTINUATION_PREFLIGHT_BUDGET_STOP.json' if error.scope == 'preflight_GPU_hours' else 'BUDGET_STOP.json'
        else:
            name = 'CONTINUATION_PREFLIGHT_FAILURE.json'
        path = context.files.path((ROOT / name).as_posix())
        # Do not overwrite an earlier cause (e.g. the independent budget guard).
        if not path.exists():
            publish_immutable(path, encoded(evidence))
        failure = context.files.path((ROOT / 'continuation_preflight/runner_failures' / f'{args.invocation_id}_pid{pid}.json').as_posix())
        failure.parent.mkdir(parents=True, exist_ok=True)
        if not failure.exists():
            publish_immutable(failure, encoded(evidence))

    def sample():
        no_latches(context.files)
        return resources(context.files)[1]

    def stop_own_group(error):
        try:
            latch(error)
        finally:
            # Verified own session/ledger at entry. Never signal a different PID.
            assert os.getpid() == pid and os.getpgid(pid) == pid
            os.killpg(pid, signal.SIGTERM)

    try:
        import fcntl
        # These locks are held by the child, not by the future parent dispatcher.
        # Waiting for all six completed/audited bases avoids racing the base queue.
        for name in ('continuation_preflight_worker.lock', 'base_pipeline.lock', 'base_recovery.lock'):
            lock = context.files.path((ROOT / name).as_posix()).open('a')
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            held_locks.append(lock)
        base_bindings = verify_completed_bases(context)
        prior_hash = prior_state_and_destination(context, spec)
        _, snapshot = resources(context.files)
        check_limits(snapshot); no_latches(context.files)
        gpu_uuid = gpu_idle_uuid(args.device)
        if spec['previous']:
            previous, _ = verify_receipt(context, spec['previous'])
            assert previous['GPU_uuid'] == gpu_uuid, 'Physical GPU changed between replay segments'
        admission = {'schema': 'continuation_fixture_admission_v1',
            'status': 'registered_input_and_budget_checks_only_not_numerical_pass',
            'invocation_id': args.invocation_id, 'device': args.device, 'GPU_uuid': gpu_uuid,
            'protocol_sha256': PROTOCOL_SHA, 'context': context.identifiers(),
            'attempt': attempt_name, 'pid': pid, 'previous_receipt_sha256': prior_hash,
            'base_audit_bound_sha256': base_bindings, 'resources_before_import': snapshot}
        admission_path = context.files.path(Path(spec['artifacts']['snapshot']).with_suffix('.admission.json').as_posix())
        admission_path.parent.mkdir(parents=True, exist_ok=True)
        publish_immutable(admission_path, encoded(admission))
        watcher = threading.Thread(target=watch_budget, args=(sample, stopped, stop_own_group), daemon=True)
        watcher.start()
        # First Torch import occurs only after every guard above passes.
        from continuation_observer import observe_program
        result = observe_program(context.files.path(spec['request']['target']), argument_vector(spec['args']),
            context.files.path(spec['artifacts']['snapshot']), context.bindings[spec['request']['target']])
        context.verify()
        context.files.verify(base_bindings)
        check_limits(sample())
        execution = {'schema': 'continuation_fixture_execution_v1', 'status': 'observer_completed_only',
            'invocation_id': args.invocation_id, 'device': args.device, 'GPU_uuid': gpu_uuid,
            'protocol_sha256': PROTOCOL_SHA, **context.identifiers(),
            'target_sha256': result['target_sha256'], 'observer_sha256': result['observer_sha256'],
            'snapshot_sha256': result['snapshot_sha256']}
        publish_immutable(context.files.path(spec['artifacts']['execution']), encoded(execution))
        print('FIXTURE_OBSERVER_RETURNED', args.invocation_id, flush=True)
    except BaseException as error:
        if registered:
            latch(error)
        raise
    finally:
        stopped.set()
        if watcher is not None:
            watcher.join(timeout=10.)
            assert not watcher.is_alive(), 'Budget watcher did not exit; do not admit a completed receipt'
        for lock in reversed(held_locks):
            lock.close()


if __name__ == '__main__':
    main()
