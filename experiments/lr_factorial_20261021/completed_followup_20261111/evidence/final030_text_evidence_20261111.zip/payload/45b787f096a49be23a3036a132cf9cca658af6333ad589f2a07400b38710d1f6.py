"""Known-answer CPU gradient fixtures; never actual72diagnostics or GPU proof."""
import ast
import copy
import hashlib
import json
import math
import os
from pathlib import Path
from datetime import datetime, timezone
os.environ['CUDA_VISIBLE_DEVICES'] = ''
import numpy as np
import torch
import torch.nn.functional as F
import gradient_probe_core as core


def close(actual, expected, tol=1e-12):
    if expected is None: assert actual is None
    else: assert math.isclose(actual, expected, rel_tol=tol, abs_tol=tol), (actual, expected)


def reject(call):
    try: call()
    except (AssertionError, ValueError, RuntimeError): return
    raise AssertionError('Invalid diagnostic accepted')


def linear(det, feat, arm='mse', existing_grad=False):
    p = torch.nn.Parameter(torch.tensor([1.,2.]))
    if existing_grad: p.grad = torch.tensor([7.,8.])
    det = torch.tensor(det, dtype=torch.float32)
    feat = torch.tensor(feat, dtype=torch.float32)
    before = None if p.grad is None else p.grad.clone()
    result = core.diagnose_objectives((p*det).sum(), torch.tensor(0.) if arm=='control' else (p*feat).sum(), [('model.0.weight',p)], arm)
    weighted = np.zeros(2) if arm=='control' else (feat.numpy()*np.float32(9.6)).astype(np.float64)
    d = det.numpy().astype(np.float64); f = np.zeros(2) if arm=='control' else feat.numpy().astype(np.float64)
    dn, fn, wn = np.linalg.norm(d), np.linalg.norm(f), np.linalg.norm(weighted)
    row = result['groups']['all_student']
    close(row['detection']['norm'], dn); close(row['feature']['norm'], fn); close(row['weighted_feature']['norm'], wn)
    dot = float(np.dot(d,weighted)); close(row['detection_weighted_feature_dot'],dot)
    close(row['detection_weighted_feature_cosine'],dot/(dn*wn) if dn>0 and wn>0 else None)
    close(row['weighted_feature_to_detection_norm_ratio'],wn/dn if dn>0 else None)
    if before is None: assert p.grad is None
    else: assert torch.equal(before,p.grad)
    assert result['status']=='computed'
    json.dumps(result,allow_nan=False)
    return result


class NonfiniteBackward(torch.autograd.Function):
    @staticmethod
    def forward(ctx, value): return value.new_zeros(())
    @staticmethod
    def backward(ctx, gradient): return gradient*gradient.new_tensor([float('nan'),float('inf'),float('-inf')])


def models():
    student = torch.nn.Module(); student.model = torch.nn.ModuleList()
    student.register_buffer('probe_nonpersistent',torch.ones(1),persistent=False)
    student.model.append(torch.nn.Sequential(torch.nn.Linear(2,2),torch.nn.BatchNorm1d(2)))
    dfl = torch.nn.Module(); dfl.dfl=torch.nn.Module();dfl.dfl.conv=torch.nn.Conv2d(1,1,1,bias=False)
    dfl.dfl.conv.weight.requires_grad_(False);student.model.append(dfl)
    teacher=torch.nn.Linear(2,2);teacher.requires_grad_(False)
    adapters=torch.nn.ModuleList([torch.nn.Linear(2,2) for _ in range(3)])
    for module in (student,teacher,adapters):module.eval()
    x=torch.arange(64,dtype=torch.float32).reshape(32,2)/64
    def objectives():
        y=student.model[0](x)
        target=teacher(x).detach()
        return y.square().sum(),sum((a(y)-target).square().mean() for a in adapters)
    return student,teacher,adapters,objectives


def main():
    torch.set_num_threads(1); torch.manual_seed(314159)
    cases=[]
    for title,d,f in [('parallel',[3.,4.],[6.,8.]),('opposed',[3.,4.],[-6.,-8.]),
                      ('orthogonal',[1.,0.],[0.,1.]),('zero_detection',[0.,0.],[1.,2.]),
                      ('zero_feature',[1.,2.],[0.,0.]),('both_zero',[0.,0.],[0.,0.]),
                      ('large_finite_FP32_gradient_float64_reduction',[1e30,-2e30],[1e29,2e29])]:
        for arm in ('mse','cwd'):
            linear(d,f,arm);cases.append(title+'_'+arm)
    linear([3.,4.],[0.,0.],'control');cases.append('control_structural_zero_cosine_undefined_ratio_zero')
    linear([3.,4.],[1.,2.],'mse',True);cases.append('existing_grad_fields_preserved')
    p=torch.nn.Parameter(torch.tensor([1.,2.]));q=torch.nn.Parameter(torch.tensor([3.,4.]))
    result=core.diagnose_objectives(p.sum(),q.sum(),[('model.0.weight',p),('model.1.weight',q)],'mse')
    groups=result['groups'];assert groups['all_student']['detection_weighted_feature_cosine']==0.
    assert groups['layer_00']['feature']['unused_parameter_tensors']==1
    assert groups['layer_01']['detection']['unused_parameter_tensors']==1
    for kind in ('detection','feature','weighted_feature'):
        close(groups['all_student'][kind]['norm']**2,sum(groups[k][kind]['norm']**2 for k in ('layer_00','layer_01')))
    cases.append('unused_parameters_zero_components_and_layer_partition')
    p=torch.nn.Parameter(torch.ones(3));result=core.diagnose_objectives(p.sum(),NonfiniteBackward.apply(p),[('model.0.weight',p)],'cwd')
    assert result['status']=='nonfinite_gradient'
    for kind in ('feature','weighted_feature'):
        row=result['groups']['all_student'][kind]
        assert row['norm'] is None and row['nan_elements']==row['positive_inf_elements']==row['negative_inf_elements']==1
    assert result['groups']['all_student']['detection_weighted_feature_cosine'] is None
    json.dumps(result,allow_nan=False);cases.append('finite_objective_nonfinite_backward_explicit_null_counts')
    p=torch.nn.Parameter(torch.ones(2));result=core.diagnose_objectives(p.sum()+float('nan'),p.sum(),[('model.0.weight',p)],'mse')
    assert result['status']=='nonfinite_objective' and result['detection_loss'] is None
    assert result['groups']['all_student']['detection']['norm'] is not None
    json.dumps(result,allow_nan=False);cases.append('nonfinite_objective_with_finite_derivative_reported')
    # Analytic known answers for the actual three-scale feature kernels.
    ss=[torch.full((32,2,2,2),2.,requires_grad=True) for _ in range(3)]
    tt=[torch.ones((32,2,2,2),requires_grad=True) for _ in range(3)]
    loss=core.feature_objective('mse',ss,tt);close(float(loss.detach()),3.)
    grads=torch.autograd.grad(loss,ss+tt,allow_unused=True)
    for g in grads[:3]:assert torch.equal(g,torch.full_like(g,2./256))
    assert grads[3:]==(None,None,None);cases.append('MSE_three_scale_means_analytic_gradient_teacher_detached')
    ss=[torch.zeros((32,1,1,2),requires_grad=True) for _ in range(3)]
    tt=[torch.tensor([0.,4*math.log(2)],dtype=torch.float32).reshape(1,1,1,2).expand(32,1,1,2).clone().requires_grad_() for _ in range(3)]
    loss=core.feature_objective('cwd',ss,tt)
    expected=48*((1/3)*math.log(2/3)+(2/3)*math.log(4/3))
    close(float(loss.detach()),expected,2e-6)
    grads=torch.autograd.grad(loss,ss+tt,allow_unused=True)
    for g in grads[:3]:
        assert torch.allclose(g,torch.tensor([1/48,-1/48]).reshape(1,1,1,2).expand_as(g),rtol=2e-6,atol=1e-8)
    assert grads[3:]==(None,None,None);cases.append('CWD_T4_three_scale_KL_and_analytic_gradient_teacher_detached')
    same=[torch.randn(32,2,2,3,requires_grad=True) for _ in range(3)]
    close(float(core.feature_objective('cwd',same,[s.detach().clone() for s in same]).detach()),0.)
    cases.append('CWD_identical_features_exact_zero')
    # Extract only the frozen original CWD function; never import its trainer/main.
    here=Path(__file__).resolve().parent; raw=(here/'continuation.py').read_bytes()
    assert hashlib.sha256(raw).hexdigest()=='7f720b53fbbadcd51aeb5e722ca84cbc37f3c86ae5b12217063a58c819d7c51f'
    tree=ast.parse(raw);node=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='cwd_loss')
    namespace={'torch':torch,'F':F};exec(compile(ast.Module(body=[node],type_ignores=[]),'frozen_CWD_function','exec'),namespace)
    ss=[torch.randn(32,2,3,3,requires_grad=True) for _ in range(3)];tt=[torch.randn_like(s) for s in ss]
    ours=core.feature_objective('cwd',ss,tt);ref=sum(namespace['cwd_loss'](s,t,4.) for s,t in zip(ss,tt))
    assert torch.equal(ours,ref)
    our_g=torch.autograd.grad(ours,ss);ref_g=torch.autograd.grad(ref,ss)
    assert all(torch.equal(x,y) for x,y in zip(our_g,ref_g));cases.append('exact_frozen_CWD_function_value_and_gradient_parity')
    student,teacher,adapters,objectives=models();before=[core.model_evidence(m) for m in (student,teacher,adapters)]
    rng=torch.get_rng_state().clone();result=core.diagnose_models(student,teacher,adapters,objectives,'mse')
    assert before==[core.model_evidence(m) for m in (student,teacher,adapters)]
    assert torch.equal(rng,torch.get_rng_state()) and result['model_state_unchanged']
    cases.append('eval_model_parameters_buffers_modes_grads_and_CPU_RNG_unchanged')
    student,teacher,adapters,objectives=models()
    def mutate_buffer():
        student.model[0][1].running_mean.add_(1)
        return objectives()
    reject(lambda:core.diagnose_models(student,teacher,adapters,mutate_buffer,'mse'));cases.append('forward_buffer_mutation_rejected')
    student,teacher,adapters,objectives=models()
    def mutate_nonpersistent():
        student.probe_nonpersistent.add_(1)
        return objectives()
    reject(lambda:core.diagnose_models(student,teacher,adapters,mutate_nonpersistent,'mse'));cases.append('nonpersistent_buffer_mutation_rejected')
    student,teacher,adapters,objectives=models();called=[]
    def no_forward():
        called.append(True)
        return objectives()
    with torch.autocast('cpu',dtype=torch.bfloat16):
        reject(lambda:core.diagnose_models(student,teacher,adapters,no_forward,'mse'))
    assert not called;cases.append('autocast_rejected_before_any_model_forward')
    with torch.no_grad():
        reject(lambda:core.diagnose_models(student,teacher,adapters,no_forward,'mse'))
    assert not called;cases.append('disabled_autograd_rejected_before_any_model_forward')
    student,teacher,adapters,objectives=models();teacher.requires_grad_(True)
    reject(lambda:core.diagnose_models(student,teacher,adapters,objectives,'mse'));cases.append('trainable_teacher_rejected')
    student,teacher,adapters,objectives=models();student.model[0].train()
    reject(lambda:core.diagnose_models(student,teacher,adapters,objectives,'mse'));cases.append('training_mode_rejected')
    student,teacher,adapters,objectives=models();student.half()
    reject(lambda:core.diagnose_models(student,teacher,adapters,objectives,'mse'));cases.append('FP16_input_state_rejected')
    student,teacher,adapters,objectives=models();student.model[1].dfl.conv.weight.requires_grad_(True)
    reject(lambda:core.diagnose_models(student,teacher,adapters,objectives,'mse'));cases.append('unfrozen_DFL_rejected')
    p=torch.nn.Parameter(torch.ones(2))
    reject(lambda:core.parameter_groups([('model.0.weight',p),('model.1.weight',p)]));cases.append('aliased_parameter_double_count_rejected')
    reject(lambda:core.parameter_groups([('adapter.0.weight',p)]));cases.append('adapter_excluded_from_student_vector')
    reject(lambda:core.parameter_groups([('model.22.dfl.conv.weight',p)]));cases.append('DFL_excluded_from_student_vector')
    reject(lambda:core.feature_objective('mse',[torch.zeros(16,2,2,2)]*3,[torch.zeros(16,2,2,2)]*3));cases.append('wrong_feature_batch_size_rejected')
    reject(lambda:core.feature_objective('cwd',[torch.zeros(32,2,2,2)]*2,[torch.zeros(32,2,2,2)]*2));cases.append('missing_feature_scale_rejected')
    reject(lambda:core.feature_objective('mse',[torch.zeros(32,2,2,2)]*3,[torch.zeros(32,2,2,3)]*3));cases.append('feature_shape_mismatch_rejected')
    with torch.autocast('cpu',dtype=torch.bfloat16):
        reject(lambda:core.diagnose_objectives(p.sum(),p.sum(),[('model.0.weight',p)],'mse'))
    cases.append('autocast_diagnostic_rejected')
    assert not torch.cuda.is_initialized()
    proof={'status':'passed','utc':datetime.now(timezone.utc).isoformat(),'count':len(cases),'cases':cases,
        'CUDA_initialized':False,'frozen_trainer_sha256':hashlib.sha256(raw).hexdigest(),
        'source_sha256':{n:hashlib.sha256((here/n).read_bytes()).hexdigest() for n in ('gradient_probe_core.py','test_gradient_probe_core.py')},
        'limits':'Synthetic CPU autograd and toy modules only; no research checkpoint/data, actual72fixed-batch probes, GPU runtime or launch authorization. Analytic float64 scalar comparisons use stated1e-12 or2e-6 formula-rounding tolerances; frozen CWD function tensor parity is exact.'}
    print(json.dumps(proof,indent=2,allow_nan=False))


if __name__=='__main__':main()
