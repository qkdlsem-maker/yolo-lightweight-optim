"""Known-answer and independent numerical-oracle tests; synthetic scores only."""
import copy
import datetime
import hashlib
import math
from pathlib import Path
import random
import scipy
from scipy.stats import t
import factorial_contrasts as f


def fixture():
    rows = []
    for i, seed in enumerate(f.SEEDS):
        for rate in f.RATES:
            for arm in f.ARMS:
                for epoch in f.EPOCHS:
                    baseline = .2+i*.01 + (0 if rate == .0001 else .05)
                    score = baseline
                    if arm != 'control':
                        score += .01 if arm == 'mse' else .02
                        if rate == .001:
                            interaction = [-3, -1, 1, 3, 5, 7][i] if arm == 'mse' else -2
                            score += interaction / 100 * (1 if epoch == 40 else .5)
                    label = f'{seed}_{rate}_{arm}_epoch{epoch}'
                    rows.append({'pair_seed': seed, 'learning_rate': rate, 'arm': arm, 'epoch': epoch,
                                 'kd_weight': 0 if arm == 'control' else .3,
                                 'origin': 'historical_reuse' if i < 3 and rate == .0001 else 'new',
                                 'endpoint_id': label, 'status': 'completed', 'reason': None,
                                 'score': round(score, 8),
                                 'evidence': {'artifact': 'synthetic/'+label, 'sha256': 'a'*64}})
    return {'schema': 'factorial_metric_input_v1', 'protocol_sha256': f.PROTOCOL_SHA,
            'interpretation_sha256': f.INTERPRETATION_SHA, 'unit': 'AP_fraction_0_to_1',
            'metric_id': f.PRIMARY_METRIC, 'population': 'Synthetic fixtures; no research scores',
            'metric_definition_sha256': 'b'*64, 'endpoint_roster_sha256': 'c'*64, 'rows': rows}


def select(result, kind, arm, epoch=40, rate=None):
    return next(r for r in result['contrasts'] if
                (r['kind'], r['arm'], r['epoch'], r['learning_rate']) == (kind, arm, epoch, rate))


def main():
    cases = []
    def passed(name): cases.append(name)
    def close(a, b): assert math.isclose(a, b, rel_tol=2e-12, abs_tol=2e-12), (a, b)
    def reject(name, change):
        x = fixture(); change(x)
        try: f.analyze(x)
        except ValueError: passed(name); return
        raise AssertionError('Accepted invalid fixture: '+name)
    x = fixture(); original = f.encoded(x); result = f.analyze(x)
    assert len(result['endpoint_rows']) == 72 and len(result['contrasts']) == 18
    assert sum(r['role'] == 'primary' for r in result['contrasts']) == 2
    assert sum(r['origin'] == 'historical_reuse' for r in result['endpoint_rows']) == 18
    assert f.encoded(x) == original
    passed('72slots_18contrasts_two_primary_reuse18_endpoints_input_unchanged')
    m = select(result, 'interaction', 'mse')
    assert [p['value_pp'] for p in m['pairs']] == [-3, -1, 1, 3, 5, 7]
    close(m['all_six_pairs']['mean_pp'], 2)
    close(m['all_six_pairs']['sample_sd_pp'], math.sqrt(14))
    assert (m['all_six_pairs']['minimum_pp'], m['all_six_pairs']['maximum_pp']) == (-3, 7)
    assert [p['pair_seed'] for p in m['pairs']] == list(f.SEEDS)
    passed('known_answer_signed_interactions_six_pair_mean_sample_sd_range')
    close(m['historical_three_pairs']['mean_pp'], -1)
    close(m['new_three_pairs']['mean_pp'], 5)
    close(m['historical_three_pairs']['sample_sd_pp'], 2)
    close(m['new_three_pairs']['sample_sd_pp'], 2)
    assert m['historical_three_pairs']['t_interval_95_pp'] is None
    passed('old_new_three_pair_strata_not_pooled_as12_or72_replicates')
    expected = t.interval(.95, df=5, loc=2, scale=math.sqrt(14)/math.sqrt(6))
    interval = m['all_six_pairs']['t_interval_95_pp']
    close(interval['lower'], expected[0]); close(interval['upper'], expected[1])
    close(f.T975_DF5, t.ppf(.975, 5))
    assert interval['df'] == 5 and 'No multiplicity-adjusted' in interval['interpretation']
    passed('independent_scipy_df5_two_sided_interval_oracle')
    c = select(result, 'interaction', 'cwd')['all_six_pairs']
    assert c['mean_pp'] == -2 and c['sample_sd_pp'] == 0
    assert c['t_interval_95_pp']['lower'] == c['t_interval_95_pp']['upper'] == -2
    passed('constant_negative_effect_retained_zero_variance_not_dropped')
    secondary = select(result, 'interaction', 'mse', epoch=20)
    assert [p['value_pp'] for p in secondary['pairs']] == [-1.5, -.5, .5, 1.5, 2.5, 3.5]
    assert secondary['role'] == 'secondary'
    passed('epoch20_separate_nested_secondary_no_pooling')
    for arm, low in [('mse', 1), ('cwd', 2)]:
        block = select(result, 'kd_minus_control', arm, rate=.0001)
        assert [p['value_pp'] for p in block['pairs']] == [low]*6
        assert block['role'] == 'secondary' and block['all_six_pairs']['t_interval_95_pp'] is None
    assert [p['value_pp'] for p in select(result, 'high_minus_low', 'control')['pairs']] == [5]*6
    assert [p['value_pp'] for p in select(result, 'high_minus_low', 'cwd')['pairs']] == [3]*6
    passed('simple_method_and_rate_effects_correct_percentage_point_units')
    y = copy.deepcopy(x); random.Random(20261021).shuffle(y['rows'])
    shuffled = f.analyze(y)
    assert shuffled['endpoint_rows'] == result['endpoint_rows'] and shuffled['contrasts'] == result['contrasts']
    passed('row_order_does_not_change_pairing_or_outputs')
    y = copy.deepcopy(x)
    for row in y['rows']:
        row['score'] = round(row['score']+.1, 8)
    assert f.analyze(y)['contrasts'] == result['contrasts']
    passed('common_additive_score_offset_cancels_in_all_contrasts')
    y = copy.deepcopy(x); y['metric_id'] = 'kitti_common_AP50_95'
    assert all(r['role'] == 'secondary' for r in f.analyze(y)['contrasts'])
    passed('external_metric_cannot_become_primary_by_epoch40')
    y = copy.deepcopy(x)
    missing = next(r for r in y['rows'] if (r['pair_seed'], r['learning_rate'], r['arm'], r['epoch']) == (606, .001, 'cwd', 40))
    missing.update(status='unavailable', score=None, reason='Hard budget reached; fixed cell not completed')
    missing['evidence'] = {'artifact': 'synthetic/BUDGET_STOP.json', 'sha256': 'd'*64}
    incomplete = f.analyze(y); c = select(incomplete, 'interaction', 'cwd')
    assert c['all_six_pairs']['available_pairs'] == 5 and not c['all_six_pairs']['complete']
    assert all(c['all_six_pairs'][k] is None for k in ('mean_pp', 'sample_sd_pp', 'minimum_pp', 'maximum_pp', 't_interval_95_pp'))
    assert c['pairs'][-1]['value_pp'] is None and len(c['pairs'][-1]['missing']) == 1
    assert c['historical_three_pairs']['complete'] and not c['new_three_pairs']['complete']
    assert select(incomplete, 'interaction', 'mse') == m
    assert select(incomplete, 'interaction', 'cwd', epoch=20)['all_six_pairs']['complete']
    passed('budget_missing_cell_visible_no_imputation_or_complete_case_aggregate')
    y = copy.deepcopy(x)
    for row in y['rows']:
        row.update(status='unavailable', score=None, reason='Pending or stopped; synthetic fixture')
    empty = f.analyze(y)
    assert all(r['all_six_pairs']['available_pairs'] == 0 for r in empty['contrasts'])
    passed('all_unavailable_schema_is_reportable_without_inventing_results')
    assert result['source_bytes_authenticated_by_this_module'] is False
    assert result['status'] == 'numerical_calculation_only'
    assert result['endpoint_rows'][0]['evidence'] == x['rows'][0]['evidence']
    passed('evidence_references_preserved_no_file_authentication_or_readiness_claim')
    result['endpoint_rows'][0]['evidence']['artifact'] = 'changed-output-only'
    assert f.encoded(x) == original
    passed('output_mutation_does_not_alias_input_rows')
    for name, change in [
        ('missing_row', lambda d: d['rows'].pop()),
        ('extra_row', lambda d: d['rows'].append(copy.deepcopy(d['rows'][0]))),
        ('duplicate_slot', lambda d: d['rows'].__setitem__(0, copy.deepcopy(d['rows'][1]))),
        ('wrong_seed', lambda d: d['rows'][0].update(pair_seed=42)),
        ('boolean_seed', lambda d: d['rows'][0].update(pair_seed=True)),
        ('epoch10_not_endpoint', lambda d: d['rows'][0].update(epoch=10)),
        ('float_epoch', lambda d: d['rows'][0].update(epoch=20.0)),
        ('selected_weight', lambda d: d['rows'][2].update(kd_weight=.03)),
        ('control_nonzero_weight', lambda d: d['rows'][0].update(kd_weight=.3)),
        ('boolean_weight', lambda d: d['rows'][0].update(kd_weight=False)),
        ('unplanned_rate', lambda d: d['rows'][0].update(learning_rate=.01)),
        ('unknown_arm', lambda d: d['rows'][0].update(arm='best')),
        ('rerun_historical_low_rate', lambda d: d['rows'][0].update(origin='new')),
        ('duplicate_endpoint_name', lambda d: d['rows'][0].update(endpoint_id=d['rows'][1]['endpoint_id'])),
        ('wrong_protocol', lambda d: d.update(protocol_sha256='a'*64)),
        ('wrong_interpretation', lambda d: d.update(interpretation_sha256='a'*64)),
        ('mixed_percent_unit', lambda d: d.update(unit='percent')),
        ('out_of_range_score', lambda d: d['rows'][0].update(score=20)),
        ('negative_score', lambda d: d['rows'][0].update(score=-.1)),
        ('nan_score', lambda d: d['rows'][0].update(score=float('nan'))),
        ('infinite_score', lambda d: d['rows'][0].update(score=float('inf'))),
        ('boolean_score', lambda d: d['rows'][0].update(score=True)),
        ('score_string', lambda d: d['rows'][0].update(score='0.2')),
        ('completed_null_score', lambda d: d['rows'][0].update(score=None)),
        ('unavailable_nonnull_score', lambda d: d['rows'][0].update(status='unavailable', reason='budget')),
        ('unavailable_missing_reason', lambda d: d['rows'][0].update(status='unavailable', score=None)),
        ('incomplete_not_silently_completed', lambda d: d['rows'][0].update(status='in_progress')),
        ('no_metric_definition', lambda d: d.update(metric_definition_sha256=None)),
        ('bad_roster_digest', lambda d: d.update(endpoint_roster_sha256='unknown')),
        ('no_evidence', lambda d: d['rows'][0].update(evidence=None)),
        ('bad_evidence_digest', lambda d: d['rows'][0]['evidence'].update(sha256='short')),
        ('blank_population', lambda d: d.update(population=' ')),
    ]: reject(name, change)
    for data in ['{"a":1,"a":2}', '{"a":NaN}', '{"a":Infinity}']:
        try: f.loads(data)
        except ValueError: passed('reject_JSON_'+str(len(cases))); continue
        raise AssertionError('Invalid JSON accepted')
    before = f.loads(original); before['rows'][0]['score'] = 0; before['rows'][1]['score'] = 1
    assert len(f.analyze(before)['endpoint_rows']) == 72
    passed('valid_zero_and_one_AP_retained')
    report = {'status': 'passed', 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'cases': cases, 'case_count': len(cases), 'synthetic_scores_only': True,
              'actual_new_scientific_results_read': 0, 'scipy_version': scipy.__version__,
              'source_sha256': {n: hashlib.sha256((Path(__file__).parent/n).read_bytes()).hexdigest()
                                for n in ('factorial_contrasts.py', 'test_factorial_contrasts.py')},
              'scope': 'Numerical kernel only; no actual evaluation-file authentication, training or GPU operation.'}
    print(f.encoded(report).decode(), end='')


if __name__ == '__main__':
    main()
