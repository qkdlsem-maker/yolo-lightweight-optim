"""Prepare60 evaluation model hashes from authenticated completed training.

No evaluation is launched or admitted by this library. Public collect() refuses
unfinished training before expensive reads. Data bytes, evaluator runtime and a
separately tested budgeted execution plan remain required after this evidence.
"""
from copy import deepcopy
from pathlib import Path
import sys

from continuation_artifact_receipts import ROOT, PROTOCOL_SHA, Files, Context, loads
from continuation_execution_runtime import job_for_label, checkpoint_bindings
from continuation_preflight_runtime import process_command, check_limits
from incident020_resources import resources
from continuation_wave_evidence import audit_report, closed_attempt
from factorial_after020_completion import completed_remaining15, command, merge, HERE
import continuation_after020_evidence as after

ACCEPTANCE_SHA = '2891030d1eed8fb073ad68aafaf0528a5e90b64ae151c5b0b2fc97c164c2c232'
AUTHORITY_SHA = '80df0d28bcbb8cf869ab57d00647a3f14653821b516e742737db1458baeadde3'
ROUTES_SHA = '3685719808d28fc61ada76f8ebb359577c63dc06ae59021eb40e5509cc67041e'
LOCATIONS_SHA = '602bce8810c004387b6642ba597bce12fd05118f81d4aca8c6421684b81c4382'
BLUEPRINT_SHA = '58e7707eaa846e82514827c488e87fc14f03843bae2a7f9979d2f05367939f27'
REUSE24_SHA = 'ae0ab01d3f746a68664c582655c6b70c0eb035bed1c205a51bc3a93d21e60b85'


def anchor(files, name, sha, bound):
    path = str(ROOT/name)
    value = loads(files.read(path, sha))
    merge(bound, {path: sha})
    return value


def bind_endpoints(files, locations, routes, authenticated):
    """Map all60 fixed endpoints to hashes already certified in receipt chains.

    This is deliberately separate from chain authentication so tests can cover
    the complete fixed roster with harmless synthetic model/audit bytes.
    """
    assert locations['protocol_sha256'] == routes['protocol_sha256'] == PROTOCOL_SHA
    assert len(locations['endpoints']) == 84
    assert len({r['endpoint_id'] for r in locations['endpoints']}) == 84
    route_by_label = {r['label']: r for r in routes['routes']}
    assert len(route_by_label) == len(routes['routes']) == 27
    assert routes['route_counts'] == {'original_production': 1, 'incident018_recovery': 1,
                                    'original_wave': 8, 'incident020_recovery': 2, 'after020_initial_wave': 15}
    result, labels, base_ids = [], set(), set()
    for row in locations['endpoints']:
        if row['action'] == 'reuse_completed_evaluation_only':
            continue
        assert row['action'] == 'new_evaluation_after_admission'
        cp = row['checkpoint']
        assert cp['sha256'] is None
        assert cp['path'] in authenticated, 'Checkpoint absent from completed evidence'
        h = authenticated[cp['path']]
        files.verify({cp['path']: h})
        if row['stage'] == 'base':
            assert row['epoch'] == 100 and row['role'] == 'base_reference'
            proof = row['completion_evidence_required']
            assert proof['kind'] == 'completed_base'
            for name in (proof['aggregate_gate'], proof['independent_audit']):
                files.read(name, authenticated[name])
            gate = loads(files.read(proof['aggregate_gate']))
            assert gate['status'] == 'all_six_completed_bases_passed' and gate['protocol_sha256'] == PROTOCOL_SHA
            audit = loads(files.read(proof['independent_audit']))
            assert audit['status'] == 'passed' and audit['protocol_sha256'] == PROTOCOL_SHA
            run = audit['run']
            assert (run['model'], run['seed'], run['epochs']) == (row['architecture'], row['pair_seed'], 100)
            assert run['checkpoint_sha256'] == h
            assert cp['path'] == str(ROOT/'base'/f'{row["architecture"]}_seed{row["pair_seed"]}'/'weights/last.pt')
            base_ids.add((row['architecture'], row['pair_seed']))
        else:
            assert row['stage'] == 'continuation' and row['epoch'] in (20, 40)
            assert row['role'] == ('secondary' if row['epoch'] == 20 else 'primary')
            route = route_by_label[row['path_label']]
            assert route['completion_claim'] is False  # prepared lookup remains a lookup
            assert route['EMA_endpoints'][str(row['epoch'])] == cp['path']
            receipt_path = route['receipt']
            receipt = loads(files.read(receipt_path, authenticated[receipt_path]))
            assert receipt['label'] == row['path_label'] and receipt['protocol_sha256'] == PROTOCOL_SHA
            assert receipt['bound_file_sha256'][cp['path']] == h
            raw = route['raw_epoch40']
            assert receipt['bound_file_sha256'][raw] == authenticated[raw]
            files.verify({raw: authenticated[raw]})
            audit_path = route['independent_audit']
            audit = loads(files.read(audit_path, authenticated[audit_path]))
            assert audit['schema'] == 'completed_continuation_file_audit_v1'
            assert audit['status'] == 'completed_evidence_passed' and audit['protocol_sha256'] == PROTOCOL_SHA
            assert audit['label'] == row['path_label'] and audit['epochs'] == 40
            assert (audit['pair_seed'], audit['arm'], audit['lr']) == (row['pair_seed'], row['arm'], row['lr'])
            assert audit['bound_input_sha256'][cp['path']] == h
            assert audit['bound_input_sha256'][raw] == authenticated[raw]
            assert audit['endpoints'][str(row['epoch'])]['role'] == row['role']
            if route['required_wave_seal'] is not None:
                seal_path = route['required_wave_seal']
                seal = loads(files.read(seal_path, authenticated[seal_path]))
                assert seal['receipt_sha256'][receipt_path] == authenticated[receipt_path]
                assert seal['wave'] == route['wave'] and seal['all_worker_processes_exited'] is True
            proof = {k: route[k] for k in ('kind', 'receipt', 'independent_audit', 'required_wave_seal', 'wave')}
            labels.add(row['path_label'])
        result.append({'endpoint_id': row['endpoint_id'], 'role': row['role'],
                       'stage': row['stage'], 'epoch': row['epoch'],
                       'checkpoint': {'path': cp['path'], 'sha256': h},
                       'completion_evidence': proof})
    assert labels == set(route_by_label)
    assert base_ids == {(a, s) for a in ('nano', 'large') for s in (404, 505, 606)}
    assert len(result) == 60 and len({v['checkpoint']['path'] for v in result}) == 60
    assert sum(v['role'] == 'primary' for v in result) == sum(v['role'] == 'secondary' for v in result) == 27
    return result


def collect(project):
    """Future actual read-only acceptance, after every training session closes.

    No command-line entry point or automatic wait/retry is provided. A bounded,
    source-frozen CPU launcher must be supplied before running this on production.
    """
    assert 'torch' not in sys.modules
    f = Files(project)
    # Refuse current running/incomplete training before any model-byte scans.
    complete_path = str(HERE/'TRAINING_RECEIPTS_COMPLETE.json')
    complete = loads(f.read(complete_path))
    assert len(complete['receipt_sha256']) == 15
    review = loads(f.read(str(after.REVIEW)))
    after.latches(f, review)
    after.guard(f)
    rows, usage = resources(f)
    check_limits(usage)
    assert not usage['active_GPU_attempts']
    parents = [n for n, r in rows.items() if r['label'] == 'continuation_after020_parent_CPU']
    assert len(parents) == 1
    parent = closed_attempt(f, parents[0], command(f))
    bound = {}
    acceptance = anchor(f, 'continuation_after020_actual_acceptance.json', ACCEPTANCE_SHA, bound)
    assert acceptance['status'] == 'actual_twelve_completed_paths_and_fifteen_untouched_paths_authenticated'
    assert acceptance['protocol_sha256'] == PROTOCOL_SHA
    assert process_command(acceptance['pid']) is None
    authority = anchor(f, 'continuation_after020/authority.json', AUTHORITY_SHA, bound)
    assert authority == acceptance['authority']
    assert acceptance['unix'] < parent['started_unix']
    for key in ('source', 'bases', 'new_sources', 'reuse'):
        f.verify(authority[key])
        merge(bound, authority[key])
    context = Context(project)
    plan, _ = after.plan_for(context)
    assert plan == acceptance['plan']
    remaining = completed_remaining15(context, plan, authority, parents[0], review)
    merge(bound, remaining['bound_file_sha256'])
    routes = anchor(f, 'continuation_result_evidence_routes_after020.json', ROUTES_SHA, bound)
    locations = anchor(f, 'factorial_endpoint_location_plan.json', LOCATIONS_SHA, bound)
    blueprint = anchor(f, 'factorial_evaluation_request_blueprint.json', BLUEPRINT_SHA, bound)
    # The pinned actual12 acceptance already checked lifecycle/capsules/seals.
    # Expand those authenticated receipts, and authenticate their saved audits;
    # the original numerical/tensor audits are never executed again.
    for route in routes['routes']:
        rp = route['receipt']
        receipt = loads(f.read(rp, bound[rp]))
        f.verify(receipt['bound_file_sha256'])
        merge(bound, receipt['bound_file_sha256'])
        ap = route['independent_audit']
        if route['kind'] == 'incident018_recovery':
            merge(bound, {ap: receipt['audit_sha256']})
        report = loads(f.read(ap, bound[ap]))
        if route['kind'] != 'after020_initial_wave':
            job, design = job_for_label(context, route['label'])
            inputs = checkpoint_bindings(context, job, design)
            merge(bound, audit_report(context, job, report, authority['bases'], inputs))
    endpoints = bind_endpoints(f, locations, routes, bound)
    reuse = anchor(f, 'factorial_reuse_auth_v2.json', REUSE24_SHA, bound)
    assert reuse['status'] == '24_historical_evaluations_authenticated_without_replay'
    assert reuse['protocol_sha256'] == PROTOCOL_SHA and len(reuse['endpoints']) == 24
    auth_row = closed_attempt(f, reuse['attempt'], reuse['command'])
    assert auth_row['pid'] == reuse['pid'] and auth_row['GPU_job'] is False
    assert auth_row['started_unix'] <= reuse['started_unix'] <= reuse['ended_unix'] <= auth_row['ended_unix']
    merge(bound, {reuse['attempt']: f.sha(reuse['attempt'])})
    assert [r['endpoint_id'] for r in reuse['endpoints']] == [r['endpoint_id'] for r in blueprint['reuse_only']]
    assert [r['endpoint_id'] for r in endpoints] == [r['endpoint_id'] for r in blueprint['jobs']]
    prepared = deepcopy(blueprint)
    for job, endpoint in zip(prepared['jobs'], endpoints):
        for request in (job['native_bdd_request'], *job['prediction_requests'].values()):
            assert request['checkpoint']['path'] == endpoint['checkpoint']['path']
            request['checkpoint'] = deepcopy(endpoint['checkpoint'])
        job['completion_evidence_required'] = deepcopy(endpoint['completion_evidence'])
    prepared['status'] = 'completed_model_hashes_bound_current_data_and_execution_admission_pending'
    prepared['execution_admitted'] = prepared['new_inference_performed'] = False
    after.latches(f, review)
    after.guard(f)
    _, final_usage = resources(f)
    check_limits(final_usage)
    assert not final_usage['active_GPU_attempts']
    assert 'torch' not in sys.modules
    return {'schema': 'factorial_training_model_bindings_v1',
            'status': 'completed_training_model_bytes_bound_not_evaluation_admission',
            'protocol_sha256': PROTOCOL_SHA, 'completed_new_bases': 6, 'completed_new_continuations': 27,
            'new_evaluation_endpoints': endpoints, 'model_bound_request_blueprint': prepared,
            'bound_file_sha256': dict(sorted(bound.items())), 'reused24_authentication_sha256': REUSE24_SHA,
            'initial_usage': usage, 'final_usage': final_usage,
            'model_loaded': False, 'model_audit_repeated': False, 'new_GPU_work': False, 'evaluation_admitted': False,
            'limits': ['Current actual validation image/label bytes and unchanged evaluator/runtime still need separate authentication.',
                       'Reuses the completed24 byte-authentication result; no repeated historical inference, scoring or numerical audit.',
                       'Model binding alone cannot admit60 evaluations; a frozen tested budgeted runner and final requests are still required.']}
