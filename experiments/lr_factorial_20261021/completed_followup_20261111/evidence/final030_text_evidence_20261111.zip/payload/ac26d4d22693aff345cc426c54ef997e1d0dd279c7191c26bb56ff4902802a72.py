"""Random YOLOv8n/l, synthetic32x64 inputs, CPU only; not actual72probes."""
import ast
import copy
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
os.environ['CUDA_VISIBLE_DEVICES'] = ''
import torch
import ultralytics
import yaml
from ultralytics.cfg import get_cfg
from ultralytics.nn.tasks import DetectionModel
import gradient_probe_core as core
import gradient_probe_objectives as obj


def reject(fn):
    try: fn()
    except (AssertionError, KeyError, ValueError, TypeError, RuntimeError): return
    raise AssertionError('Invalid diagnostic assembly accepted')


def main():
    torch.set_num_threads(1); torch.manual_seed(777)
    assert not torch.cuda.is_initialized()
    here = Path(__file__).resolve().parent; cases = []
    yaml_path = Path(ultralytics.__file__).resolve().parent/'cfg/models/v8/yolov8.yaml'
    spec = yaml.safe_load(yaml_path.read_text())
    def model(scale):
        cfg = copy.deepcopy(spec); cfg['scale'] = scale
        m = DetectionModel(cfg, nc=10, verbose=False).float().eval()
        m.names = {i: 'class_'+str(i) for i in range(10)}
        return m
    student_template, teacher_template = model('n'), model('l')
    def channels(m):
        features = {}; handles = []
        try:
            for i in core.LAYERS:
                handles.append(m.model[i].register_forward_hook(lambda mod, inp, out, i=i: features.__setitem__(i, out)))
            with torch.no_grad(): m(torch.zeros(1, 3, 64, 64))
        finally:
            for handle in handles: handle.remove()
        return [features[i].shape[1] for i in core.LAYERS]
    sc, tc = channels(student_template), channels(teacher_template)
    adapters = torch.nn.ModuleList([torch.nn.Conv2d(s, t, 1) for s, t in zip(sc, tc)])
    raw = {'epoch': 40, 'student': {k: v.detach().clone() for k, v in student_template.state_dict().items()},
        'adapters': {k: v.detach().clone() for k, v in adapters.state_dict().items()}}
    first = next(iter(dict(student_template.named_parameters())))
    raw['student'][first].add_(.001)  # ensure assembled student is raw, not its template endpoint
    raw['ema'] = {first: torch.zeros_like(raw['student'][first])}  # deliberately unusable EMA is never selected
    config = {'arm': 'mse', 'epochs': 40, 'temperature': 4., 'kd_weight': .3, 'feature_layers': [15,18,21],
        'student_channels': sc, 'teacher_channels': tc, 'hyp': vars(get_cfg())}
    batch = {'img': torch.rand(32,3,64,64), 'cls': (torch.arange(32)%10).float().reshape(-1,1),
        'batch_idx': torch.arange(32).float(), 'bboxes': torch.tensor([.5,.5,.25,.25]).repeat(32,1)}
    templates_before = [core.model_evidence(m) for m in (student_template, teacher_template)]
    raw_before = {key: {n: core.tensor_digest(v) for n,v in raw[key].items()} for key in ('student','adapters')}
    rng_before = torch.random.get_rng_state().clone()
    student, teacher, loaded_adapters, assembly = obj.assemble(student_template, teacher_template, raw, config, 'cpu')
    assert torch.equal(rng_before, torch.random.get_rng_state())
    assert templates_before == [core.model_evidence(m) for m in (student_template, teacher_template)]
    assert raw_before == {key: {n: core.tensor_digest(v) for n,v in raw[key].items()} for key in ('student','adapters')}
    assert torch.equal(student.state_dict()[first], raw['student'][first])
    assert not torch.equal(student.state_dict()[first], student_template.state_dict()[first])
    cases += ['actual_nano_large_native_model_raw_adapter_assembly', 'raw_not_template_or_EMA_selected',
              'source_templates_and_raw_tensors_unchanged', 'adapter_initialization_preserves_CPU_RNG']
    # Use the unchanged continuation's feature extraction and loss as reference,
    # without importing its executable training module or calling its main.
    source = (here/'continuation.py').read_bytes()
    assert hashlib.sha256(source).hexdigest() == '7f720b53fbbadcd51aeb5e722ca84cbc37f3c86ae5b12217063a58c819d7c51f'
    tree = ast.parse(source); functions = [n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('features','cwd_loss')]
    oracle = {'torch': torch, 'F': torch.nn.functional, 'LAYERS': [15,18,21]}
    exec(compile(ast.Module(body=functions,type_ignores=[]), 'frozen_continuation_oracle', 'exec'), oracle)
    def reference(arm):
        prediction = student(batch['img']); det, _ = student.loss(batch, prediction)
        feature = det.new_zeros(())
        if arm != 'control':
            sf = oracle['features'](student, batch['img'])
            with torch.no_grad(): tf = oracle['features'](teacher, batch['img'])
            aligned = [a(s) for a,s in zip(loaded_adapters,sf)]
            feature = sum(torch.nn.functional.mse_loss(s,t.detach()) for s,t in zip(aligned,tf)) if arm == 'mse' else sum(oracle['cwd_loss'](s,t,4.) for s,t in zip(aligned,tf))
        return det.sum(), feature
    summaries = {}
    for arm in ('control','mse','cwd'):
        before_hooks = [len(m._forward_hooks) for m in list(student.modules())+list(teacher.modules())]
        build, trace = obj.objectives_for_batch(student,teacher,loaded_adapters,batch,arm,fixture_size=64)
        report = core.diagnose_models(student,teacher,loaded_adapters,build,arm)
        assert report['status'] == 'computed' and report['teacher_no_grad'] and report['model_state_unchanged']
        assert trace['student_forwards'] == 1 and trace['teacher_forwards'] == (0 if arm == 'control' else 1)
        assert before_hooks == [len(m._forward_hooks) for m in list(student.modules())+list(teacher.modules())]
        assert all(p.grad is None for m in (student,teacher,loaded_adapters) for p in m.parameters())
        with torch.no_grad(): det_ref, feature_ref = reference(arm)
        assert report['detection_loss'] == float(det_ref) and report['feature_loss'] == float(feature_ref)
        assert abs(sum(trace['detection_components'])*32-report['detection_loss']) < 1e-3
        # Different graphs (one shared student forward vs separate original
        # feature/detection forwards) must yield the same selected parameter gradient.
        fresh_build, _ = obj.objectives_for_batch(student,teacher,loaded_adapters,batch,arm,fixture_size=64)
        det, feat = fresh_build(); parameter = dict(student.named_parameters())[first]
        actual = torch.autograd.grad(det + (0. if arm=='control' else 9.6)*feat, parameter)[0]
        det_ref, feat_ref = reference(arm)
        expected = torch.autograd.grad(det_ref + (0. if arm=='control' else 9.6)*feat_ref, parameter)[0]
        torch.testing.assert_close(actual, expected, rtol=2e-5, atol=1e-6)
        reject(build)
        summaries[arm] = {'detection_loss':report['detection_loss'],'feature_loss':report['feature_loss'],
            'student_parameter_tensors':report['groups']['all_student']['parameter_tensors'],
            'single_forward_trace':trace,'all_registered_states_and_grads_unchanged':report['model_state_unchanged']}
        cases += ['native_scalar_and_frozen_feature_oracle_'+arm, 'selected_gradient_matches_separate_oracle_graph_'+arm,
                  'single_student_forward_teacher_detached_hooks_removed_'+arm, 'duplicate_builder_call_rejected_'+arm]
    for key,value in [('epoch',20),('epoch',True)]:
        changed=dict(raw);changed[key]=value;reject(lambda:obj.assemble(student_template,teacher_template,changed,config,'cpu'));cases.append('reject_raw_epoch_'+str(value))
    for key,value in [('arm','other'),('epochs',20),('temperature',1.),('kd_weight',3.),('feature_layers',[15,18]),('student_channels',[1,2,3])]:
        cfg=copy.deepcopy(config);cfg[key]=value;reject(lambda:obj.assemble(student_template,teacher_template,raw,cfg,'cpu'));cases.append('reject_config_'+key)
    cfg=copy.deepcopy(config);cfg['hyp']['box']=1.;reject(lambda:obj.assemble(student_template,teacher_template,raw,cfg,'cpu'));cases.append('reject_changed_detection_gain')
    for title,mutate in [('half_raw',lambda r:r['student'].__setitem__(first,r['student'][first].half())),
                         ('nonfinite_raw',lambda r:r['student'].__setitem__(first,torch.full_like(r['student'][first],float('nan')))),
                         ('missing_adapter',lambda r:r['adapters'].pop('0.bias')),
                         ('changed_DFL',lambda r:r['student'].__setitem__('model.22.dfl.conv.weight',torch.zeros_like(r['student']['model.22.dfl.conv.weight'])))]:
        changed={'epoch':40,'student':dict(raw['student']),'adapters':dict(raw['adapters'])};mutate(changed)
        reject(lambda:obj.assemble(student_template,teacher_template,changed,config,'cpu'));cases.append('reject_'+title)
    for key,value in [('img',batch['img'][:31]),('img',batch['img'].half()),('cls',torch.full_like(batch['cls'],10)),
                      ('batch_idx',torch.full_like(batch['batch_idx'],32)),('bboxes',torch.full_like(batch['bboxes'],2)),
                      ('img',torch.full_like(batch['img'],float('nan')))]:
        altered=dict(batch);altered[key]=value
        reject(lambda:obj.objectives_for_batch(student,teacher,loaded_adapters,altered,'mse',fixture_size=64));cases.append('reject_batch_'+key+'_'+str(len(cases)))
    reject(lambda:obj.diagnose_batch(student,teacher,loaded_adapters,batch,'mse'));cases.append('production_entry_rejects64geometry')
    # A failing forward must still release only hooks it installed.
    lengths=[len(m._forward_hooks) for m in student.modules()]
    hook=student.model[15].register_forward_hook(lambda *unused:(_ for _ in ()).throw(RuntimeError('fixture forward error')))
    try:
        failing,_=obj.objectives_for_batch(student,teacher,loaded_adapters,batch,'mse',fixture_size=64);reject(failing)
    finally:hook.remove()
    assert lengths==[len(m._forward_hooks) for m in student.modules()];cases.append('hook_cleanup_on_forward_failure')
    native_loss = student.loss
    def injected_nonfinite(b, predictions):
        det, _ = native_loss(b, predictions)
        return det+float('nan'), det.new_tensor([float('nan'),float('inf'),float('-inf')])
    student.loss = injected_nonfinite
    try:
        build, trace = obj.objectives_for_batch(student,teacher,loaded_adapters,batch,'control',fixture_size=64)
        nonfinite = core.diagnose_models(student,teacher,loaded_adapters,build,'control')
        assert nonfinite['status'] == 'nonfinite_objective' and nonfinite['detection_loss'] is None
        assert trace['detection_components'] == [None,None,None]
        assert trace['detection_component_nonfinite'] == ['nan','positive_inf','negative_inf']
        json.dumps({'diagnostic':nonfinite,'trace':trace},allow_nan=False)
    finally: del student.loss
    cases.append('nonfinite_native_loss_components_retained_as_explicit_null_and_type_without_invalid_JSON')
    assert not torch.cuda.is_initialized()
    out={'schema':'gradient_objective_CPU_fixture_v1','status':'passed','utc':datetime.now(timezone.utc).isoformat(),
         'case_count':len(cases),'cases':cases,'fixture_geometry':[32,3,64,64],'random_models_only':True,
         'actual72probes_completed':0,'actual_GPU_validation':False,'summaries':summaries,'assembly':assembly,
         'source_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [here/'gradient_probe_objectives.py',Path(__file__),here/'gradient_probe_core.py']},
         'limits':['Random YOLOv8n/l CPU fixture, not trained endpoints or fixed64training images.',
                   'No proof of full640 GPU memory/runtime or provenance; a guarded runner and all completed raw inputs are still required.']}
    print('GRADIENT_OBJECTIVE_CPU_RESULT\n'+json.dumps(out,indent=2,allow_nan=False))


if __name__=='__main__':main()
