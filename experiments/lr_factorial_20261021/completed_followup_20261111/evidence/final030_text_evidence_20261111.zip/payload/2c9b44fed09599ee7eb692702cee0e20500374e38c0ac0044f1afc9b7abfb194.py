"""Read authenticated fixture bytes on CPU and compare actual saved values.

No execution, inference, RNG restoration, file mutation or readiness publication.
Only the fixed artifact paths in verified receipts may be deserialized. Hashes
authenticate this study's retained files, not arbitrary external pickle inputs.
"""
import hashlib
import io
import json
import math
from pathlib import Path
import numpy as np
import torch
from continuation_artifact_receipts import (
    ROOT, PROTOCOL_SHA, loads, encoded, invocation_spec, verify_receipt,
    verify_complete_request,
)
import continuation_evidence_checks as core
import continuation_observer as observer
from continuation_observer import assert_exact, state_digest

READER = ROOT / 'continuation_preflight_reader.py'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def cpu_only(value):
    if isinstance(value, torch.Tensor):
        assert value.device.type == 'cpu', 'Deserialized tensor is not on CPU'
    elif isinstance(value, torch.nn.Module):
        cpu_only(value.state_dict())
    elif isinstance(value, dict):
        for item in value.values(): cpu_only(item)
    elif isinstance(value, (tuple, list)):
        for item in value: cpu_only(item)


def tensor_bytes(data):
    assert not torch.cuda.is_initialized(), 'Numerical reader must run in a CPU-only process'
    value = torch.load(io.BytesIO(data), map_location='cpu', weights_only=False)
    cpu_only(value)
    assert not torch.cuda.is_initialized()
    return value


def legacy_json(data, smoke=False):
    """Permit only the historical undefined median diagnostic, not raw NaNs."""
    def unique(pairs):
        result = {}
        for key, value in pairs:
            assert key not in result, 'Duplicate JSON key'
            result[key] = value
        return result
    result = json.loads(data, object_pairs_hook=unique)
    allowed = ('epoch', 'median_unclipped_grad_norm') if smoke else ('median_unclipped_grad_norm',)
    def walk(value, path=()):
        if isinstance(value, dict):
            for key, item in value.items(): walk(item, path+(key,))
        elif isinstance(value, list):
            for i, item in enumerate(value): walk(item, path+(i,))
        elif type(value) is float and not math.isfinite(value):
            assert path == allowed, ('Unexpected nonfinite legacy JSON', path)
    walk(result)
    return result


def authorize(context):
    assert not torch.cuda.is_initialized()
    context.verify()
    for name, file in [('continuation_preflight_reader.py', __file__),
                       ('continuation_evidence_checks.py', core.__file__),
                       ('continuation_observer.py', observer.__file__)]:
        key = (ROOT / name).as_posix()
        assert key in context.bindings and sha(Path(file).read_bytes()) == context.bindings[key], 'Imported numerical source differs from freeze'
    return context.bindings[READER.as_posix()]


class Evidence:
    def __init__(self, context, invocation_id):
        self.context = context
        self.receipt, self.receipt_hash = verify_receipt(context, invocation_id)
        self.spec = invocation_spec(context, invocation_id, self.receipt['device'])

    def raw(self, key):
        item = self.receipt['artifacts'][key]
        # Recheck these exact bytes before any JSON or pickle deserialization.
        return self.context.files.read(item['path'], item['sha256'])

    def json(self, key):
        data = self.raw(key)
        if self.spec['reference'] and (key.startswith('epoch_') or key == 'smoke_complete'):
            return legacy_json(data, key == 'smoke_complete')
        return loads(data)

    def tensor(self, key):
        return tensor_bytes(self.raw(key))

    def finish(self):
        checked, value = verify_receipt(self.context, self.receipt['invocation_id'])
        assert value == self.receipt_hash and encoded(checked) == encoded(self.receipt)


def checkpoint_module(checkpoint):
    assert isinstance(checkpoint, dict) and isinstance(checkpoint.get('model'), torch.nn.Module)
    selected = checkpoint.get('ema') if checkpoint.get('ema') is not None else checkpoint['model']
    assert isinstance(selected, torch.nn.Module)
    cpu_only(selected); assert_exact(selected.state_dict(), selected.state_dict())
    return selected


def as_loaded_float(state):
    # The fixed YOLO loader converts checkpoint modules to float32. Integral
    # buffers retain their type. No forward pass or model mutation is needed.
    return {k: v.float() if v.is_floating_point() else v for k, v in state.items()}


def check_initial_models(context, snapshot, request, config):
    source_name, teacher_name = (request['args'][k] for k in ('source', 'teacher'))
    source = checkpoint_module(tensor_bytes(context.files.read(source_name, request['input_sha256']['source'])))
    initial = as_loaded_float(dict(source.named_parameters()))
    assert_exact(snapshot['initial_student_parameters'], initial, 'actual_starting_checkpoint_parameters')
    if not request['kind'].startswith('reference'):
        assert config['initial_raw_student_digest'] == core.training_digest(as_loaded_float(source.state_dict()))
    teacher = checkpoint_module(tensor_bytes(context.files.read(teacher_name, request['input_sha256']['teacher'])))
    assert state_digest(as_loaded_float(teacher.state_dict())) == snapshot['teacher_state_sha256'], 'Teacher snapshot does not match fixed checkpoint'


def check_smoke(evidence, snapshot, epoch):
    smoke = evidence.json('smoke_complete')
    assert smoke.keys() == {'epoch', 'changed_parameter_tensors', 'max_delta'}
    # The only legacy nonfinite diagnostic is kept in its original representation.
    assert json.dumps(smoke['epoch'],sort_keys=True,allow_nan=True) == json.dumps(epoch,sort_keys=True,allow_nan=True)
    changed, maximum = 0, 0.
    for key, before in snapshot['initial_student_parameters'].items():
        delta = float((snapshot['student'][key] - before).abs().max())
        changed += delta > 0; maximum = max(maximum, delta)
    assert type(smoke['changed_parameter_tensors']) is int and smoke['changed_parameter_tensors'] == changed > 0
    assert_exact(smoke['max_delta'], maximum, 'smoke_raw_parameter_delta')


def check_validation_model(evidence, raw_state):
    saved = evidence.tensor('validation/checkpoint.pt')
    assert isinstance(saved, dict) and isinstance(saved.get('model'), torch.nn.Module)
    expected = {key: value.half() if value.is_floating_point() else value
                for key, value in raw_state['ema'].items()}
    # Model.save writes model.half(). Exact equality is at that saved precision;
    # raw full-precision equality is independently checked by the replay core.
    assert_exact(saved['model'].state_dict(), expected, 'serialized_validation_model_vs_raw_EMA_at_saved_precision')
    assert all(p.grad is None for p in saved['model'].parameters())
    if saved.get('ema') is not None:
        assert isinstance(saved['ema'], torch.nn.Module)
        assert_exact(saved['ema'].state_dict(), expected, 'alternate_saved_EMA_must_not_select_stale_model')
    metrics = evidence.json('validation/result.json')
    assert metrics['checkpoint_sha256'] == evidence.receipt['artifacts']['validation/checkpoint.pt']['sha256']
    assert metrics['state_sha256'] == core.training_digest(raw_state['ema'])
    return state_digest(expected)


def read_bundle(evidence):
    spec = evidence.spec; n = spec['invocation']['expected_committed_epoch']
    config = evidence.json('config')
    snapshot = evidence.tensor('snapshot')
    core.check_snapshot(snapshot)
    check_initial_models(evidence.context, snapshot, spec['request'], config)
    bundle = {'snapshot': snapshot, 'epochs': [evidence.json(f'epoch_{i:02d}') for i in range(1,n+1)],
              'gradient_check': evidence.json('gradient_check')}
    if not spec['reference']:
        bundle.update(steps=[evidence.json(f'steps_{i:02d}') for i in range(1,n+1)],
                      initial_adapter_digest=config['initial_adapter_digest'])
    if spec['observation']:
        check_smoke(evidence,snapshot,bundle['epochs'][-1])
    else:
        bundle['training_state'] = evidence.tensor('training_state')
        if n >= 10:
            bundle['raw_epoch10'] = evidence.tensor('raw_epoch10')
    if spec['validation']:
        bundle['validation_metrics'] = evidence.json('validation/result.json')
        bundle['post_validation_rng'] = evidence.tensor('validation/post_rng.bin')
        bundle['serialized_validation_model_state_sha256'] = check_validation_model(evidence,bundle['raw_epoch10'])
    return bundle


def case_info(context, case_id):
    matches = [c for c in context.roster['cases'] if c['id'] == case_id]
    assert len(matches) == 1
    return matches[0]


def request_evidence(context, request_id):
    verify_complete_request(context,request_id)
    invocations = [i for i in context.roster['invocations'] if i['request_id'] == request_id]
    assert len(invocations) in (1,4)
    return [Evidence(context,i['id']) for i in invocations]


def observation(context, case):
    items = [request_evidence(context,case['requests'][k])[0] for k in ('reference_observation','candidate_observation')]
    reference,candidate = [read_bundle(e) for e in items]
    check = core.compare_observation(reference,candidate,case['lr'],case['arm'])
    return items, check


def result(context, case, kind, evidence, checks):
    assert len({(e.receipt['device'],e.receipt['GPU_uuid']) for e in evidence}) == 1, 'Compared fixtures used different physical GPUs'
    for e in evidence:e.finish()
    for request_id in {e.spec['request']['id'] for e in evidence}:verify_complete_request(context,request_id)
    source = authorize(context)
    return {'schema':'continuation_preflight_numerical_case_v1','kind':kind,
        'status':'observational_parity_passed' if kind=='observation' else 'observational_and_replay_parity_passed',
        'case_id':case['id'],'protocol_sha256':PROTOCOL_SHA,'context':context.identifiers(),
        'reader_sha256':source,'receipt_sha256':{e.receipt['invocation_id']:e.receipt_hash for e in evidence},
        'checks':checks}


def verify_observation(context, case_id):
    authorize(context)
    case=case_info(context,case_id)
    evidence,check=observation(context,case)
    return result(context,case,'observation',evidence,{'observation':check})


def verify_case(context, case_id):
    authorize(context)
    case=case_info(context,case_id)
    observations,obs_check=observation(context,case)
    un=request_evidence(context,case['requests']['candidate_uninterrupted'])[0]
    segments=request_evidence(context,case['requests']['candidate_interrupted'])
    assert len(segments)==4
    uninterrupted=read_bundle(un)
    bundles=[read_bundle(e) for e in segments]
    captures=[b['snapshot'] for b in bundles]
    for index,bundle in enumerate(bundles):
        # The state after the validation-only segment is still the prevalidation
        # atomic training state. Its separate observer snapshot has postval RNG.
        state_snapshot=captures[1] if index==2 else captures[index]
        core.check_training_state(bundle['training_state'],state_snapshot,bundle['epochs'][-1])
    assert_exact(bundles[1]['training_state'],bundles[2]['training_state'],'validation_only_segment_preserves_atomic_training_state')
    inventories=[{k.split('/',1)[1]:v['sha256'] for k,v in e.receipt['artifacts'].items() if k.startswith('validation/')} for e in segments]
    inventories=[{k:v for k,v in inv.items() if k in {'result.json','post_rng.bin','manifest.json','metrics.json','checkpoint.pt'}} for inv in inventories]
    replay=core.compare_replay(uninterrupted,bundles[-1],captures,inventories,bundles[2]['post_validation_rng'],case['lr'],case['arm'])
    assert_exact(uninterrupted['serialized_validation_model_state_sha256'],bundles[-1]['serialized_validation_model_state_sha256'])
    return result(context,case,'complete_case',[*observations,un,*segments],
        {'observation':obs_check,'replay':replay,'serialized_validation_model_matches_raw_EMA_at_saved_FP16_precision':True,
         'all_four_atomic_segment_states_checked':True,'actual_starting_checkpoint_parameters_and_teacher_hash_checked':True})


def verify_all(context):
    """Complete12-case numerical report only; caller owns final admission gate."""
    authorize(context)
    assert len(context.roster['cases'])==12 and len(context.roster['invocations'])==84 and len(context.requests)==48
    cases={c['id']:verify_case(context,c['id']) for c in context.roster['cases']}
    receipts={key:value for c in cases.values() for key,value in c['receipt_sha256'].items()}
    assert set(receipts)==set(context.invocations) and len(receipts)==84
    closures={key:verify_complete_request(context,key)[1] for key in context.requests}
    assert len(closures)==48
    authorize(context)
    return {'schema':'continuation_preflight_numerical_report_v1',
        'status':'all12_numerical_cases_passed_only_not_production_admission',
        'protocol_sha256':PROTOCOL_SHA,'context':context.identifiers(),
        'reader_sha256':context.bindings[READER.as_posix()],
        'observational_parity_all_rates_arms':True,'interrupted_replay_exact':True,
        'cases':cases,'receipt_sha256':receipts,'closed_request_sha256':closures,
        'scope':'Bound artifact bytes and exact saved values. CPU readback is not additional training/inference. No missing historical AMP counts reconstructed.'}
