"""Bind a successful GPU execution to an independent completed-file CPU audit.

No tensor library, deserialization, inference or process launch. These receipts
are integrity/provenance records, not scientific significance or GPU admission.
Only the already authenticated parent may call the lower-level file functions.
An existing receipt is verified, never replaced; a missing receipt never means
that a completed or partially completed trajectory may be trained again.
"""
import math
from pathlib import Path, PurePosixPath
from continuation_artifact_receipts import ROOT, PROTOCOL_SHA, encoded, loads, valid_sha
from continuation_execution_runtime import (PREFIX, job_for_label, arguments,
    expected_command, evidence_paths, untouched_destination)
from validation_journal import publish_immutable

SELF = ROOT/'continuation_production_receipts.py'
AUDITOR = ROOT/'continuation_completion_audit.py'
AUDIT_PREFIX = 'continuation_completed_audit__'
CPU_ENVIRONMENT = {'CUDA_VISIBLE_DEVICES':'', 'OMP_NUM_THREADS':'1',
                   'MKL_NUM_THREADS':'1', 'OPENBLAS_NUM_THREADS':'1'}


def audit_command(context, label):
    job_for_label(context,label)
    return [str(context.files.project/'venv/bin/python'),'-u',AUDITOR.as_posix(),'--label',label]


def audit_path(label):
    evidence_paths(label)  # validate a plain label
    return (ROOT/'production_audits'/(label+'.json')).as_posix()


def successful_attempt(context, name, label, device, audit=False):
    f=context.files
    assert PurePosixPath(name).parent==ROOT/'attempts'
    row=loads(f.read(name));expected=audit_command(context,label) if audit else expected_command(context,label,device)
    assert row['command']==expected and row['label']==(AUDIT_PREFIX if audit else PREFIX)+label
    assert row['status']=='completed' and type(row['returncode']) is int and row['returncode']==0
    assert 'stop_reason' not in row
    for key in ('pid','parent_pid'):
        assert type(row[key]) is int and row[key]>0
    for key in ('started_unix','ended_unix'):
        assert type(row[key]) in (int,float) and math.isfinite(row[key])
    assert row['ended_unix']>=row['started_unix']>0
    assert row['GPU_job'] is (not audit)
    if audit:
        assert row['device'] is None and row['environment_contract']==CPU_ENVIRONMENT
        assert row['stdout_artifact']==audit_path(label)
    else:
        assert type(row['device']) is int and row['device']==device
    assert PurePosixPath(row['log']).parent==ROOT/'logs'
    f.sha(row['log'])
    return row


def canonical_bindings(files, supplied):
    """The auditor emits absolute run paths and relative frozen-source paths."""
    assert type(supplied) is dict and supplied
    result={}
    for name,value in supplied.items():
        valid_sha(value)
        assert type(name) is str and '\\' not in name
        path=PurePosixPath(name)
        if path.is_absolute():
            assert name==path.as_posix()
            name=path.relative_to(PurePosixPath(files.project.as_posix())).as_posix()
        files.path(name)  # traversal/symlink/alias rejection before filesystem access
        assert name not in result, 'Duplicate absolute/relative evidence alias'
        result[name]=value
    return result


def required_run_files(job):
    out=PurePosixPath(job['run_directory'])
    names={'config.json','gradient_check.json','parameter_delta.json','training_state.pt','COMPLETE.json'}
    for epoch in range(1,41):
        names.update({f'epoch_{epoch:02d}.json',f'epoch_{epoch:02d}_steps.json'})
    for epoch in (10,20,40):
        prefix=f'ema_epoch{epoch:02d}'
        names.update({f'raw_state_epoch{epoch:02d}.pt',prefix+'.pt',prefix+'_metrics.json'})
        names.update({prefix+'_validation_commit/'+n for n in ('manifest.json','result.json','post_rng.bin')})
    return {(out/name).as_posix() for name in names}


def execution_proof(context, label, attempt, authority):
    """authority comes from public_context and immutable checkpoint bindings."""
    f=context.files;job,design=job_for_label(context,label);paths=evidence_paths(label)
    for key in ('execution_source_sha256','completed_base_bindings','checkpoint_bindings'):
        f.verify(authority[key])
    admission=loads(f.read(paths['admission']));execution=loads(f.read(paths['execution']))
    assert admission['schema']=='continuation_production_admission_v1'
    assert admission['status']=='registered_guards_passed_not_completed'
    assert execution['schema']=='continuation_production_execution_v1'
    assert execution['status']=='trainer_returned_requires_independent_CPU_audit'
    device=admission['device'];assert type(device) is int and device in (0,1)
    row=successful_attempt(context,attempt,label,device)
    for value in (admission,execution):
        assert value['label']==label and value['attempt']==attempt and value['pid']==row['pid']
        assert type(value['device']) is int and value['device']==device
        assert value['protocol_sha256']==PROTOCOL_SHA and value['context']==context.identifiers()
        assert type(value['GPU_uuid']) is str and value['GPU_uuid'].startswith('GPU-')
    assert execution['GPU_uuid']==admission['GPU_uuid']
    assert admission['args']==arguments(job,design,device)
    for key in ('execution_source_sha256','preflight_gate','completed_base_bindings','checkpoint_bindings'):
        assert admission[key]==authority[key], 'Admission differs from current frozen authority: '+key
    assert execution['admission_sha256']==f.sha(paths['admission'])
    complete=(PurePosixPath(job['run_directory'])/'COMPLETE.json').as_posix()
    assert execution['complete_sha256']==f.sha(complete)
    returned=execution['returned_unix']
    assert type(returned) in (int,float) and math.isfinite(returned)
    assert row['started_unix']<=returned<=row['ended_unix']
    bindings={name:f.sha(name) for name in (paths['admission'],paths['execution'],attempt,row['log'],complete)}
    return row,admission,execution,bindings


def audit_proof(context, label, attempt, execution_attempt, authority):
    f=context.files;job,_=job_for_label(context,label)
    gpu,admission,execution,bindings=execution_proof(context,label,execution_attempt,authority)
    cpu=successful_attempt(context,attempt,label,None,audit=True)
    assert cpu['started_unix']>=gpu['ended_unix'], 'CPU audit must follow closed GPU attempt'
    report=loads(f.read(audit_path(label)))
    assert report['schema']=='completed_continuation_file_audit_v1'
    assert report['status']=='completed_evidence_passed' and report['protocol_sha256']==PROTOCOL_SHA
    for key,value in [('label',label),('pair_seed',job['pair_seed']),('arm',job['args']['arm']),('lr',job['args']['lr'])]:
        assert report[key]==value and type(report[key]) is type(value)
    assert type(report['epochs']) is int and report['epochs']==40
    assert report['finite_saved_states'] is True and report['fixed_DFL_preserved'] is True
    counts=report['actual_step_counts']
    assert set(counts)=={'attempted','applied','skipped'}
    assert all(type(v) is int and v>=0 for v in counts.values())
    assert counts['attempted']==43680 and counts['applied']>0 and counts['attempted']==counts['applied']+counts['skipped']
    assert set(report['endpoints'])=={'10','20','40'}
    for epoch,role in [('10','diagnostic'),('20','secondary'),('40','primary')]:
        assert report['endpoints'][epoch]['role']==role
    complete=loads(f.read((PurePosixPath(job['run_directory'])/'COMPLETE.json').as_posix()))
    assert encoded(report['endpoints']['40']['metrics'])==encoded(complete)
    inputs=report['first_two_input_sha256_by_epoch']
    assert set(inputs)=={str(i) for i in range(1,41)}
    for pair in inputs.values():
        assert type(pair) is list and len(pair)==2
        for value in pair:valid_sha(value)
    valid_sha(report['initial_raw_student_digest'])
    completion_manifest=(ROOT/'continuation_completion_sources.json').as_posix()
    assert report['audit_sources_sha256']==f.sha(completion_manifest)
    audit_bindings=canonical_bindings(f,report['bound_input_sha256'])
    required=dict(context.bindings)
    required.update(authority['completed_base_bindings'])
    required.update(authority['checkpoint_bindings'])
    completion=loads(f.read(completion_manifest))
    required.update({(ROOT/r['name']).as_posix():r['sha256'] for r in completion['files']})
    required[completion_manifest]=report['audit_sources_sha256']
    assert required_run_files(job)<=set(audit_bindings), 'Incomplete raw/epoch/validation evidence coverage'
    for name,value in required.items():assert audit_bindings.get(name)==value, 'Missing frozen audit binding: '+name
    f.verify(audit_bindings)
    for name,value in audit_bindings.items():
        assert name not in bindings or bindings[name]==value
        bindings[name]=value
    for name in (attempt,cpu['log'],audit_path(label)):
        bindings[name]=f.sha(name)
    return gpu,cpu,admission,report,dict(sorted(bindings.items()))


def receipt_value(context,label,execution_attempt,audit_attempt,authority):
    gpu,cpu,admission,report,bindings=audit_proof(context,label,audit_attempt,execution_attempt,authority)
    return {'schema':'completed_continuation_production_receipt_v1',
        'status':'execution_and_independent_CPU_file_audit_passed',
        'protocol_sha256':PROTOCOL_SHA,'context':context.identifiers(),'label':label,
        'execution_attempt':execution_attempt,'audit_attempt':audit_attempt,
        'device':gpu['device'],'GPU_uuid':admission['GPU_uuid'],
        'authority':authority,'bound_file_sha256':bindings,
        'actual_step_counts':report['actual_step_counts'],
        'limits':['Integrity and recorded execution/file audit only, not hardware attestation.',
                  'No new inference or independent replication is performed by sealing/reusing this receipt.',
                  'Cross-path pairing and statistical analysis remain separate.']}


def verify_receipt(context,label,authority):
    path=evidence_paths(label)['receipt'];f=context.files
    value=loads(f.read(path))
    expected=receipt_value(context,label,value['execution_attempt'],value['audit_attempt'],authority)
    assert encoded(value)==encoded(expected), 'Receipt no longer matches authenticated completed artifacts'
    return value,f.sha(path)


def seal_receipt(context,label,execution_attempt,audit_attempt,authority):
    value=receipt_value(context,label,execution_attempt,audit_attempt,authority)
    path=context.files.path(evidence_paths(label)['receipt']);path.parent.mkdir(parents=True,exist_ok=True)
    publish_immutable(path,encoded(value))
    return value,context.files.sha(evidence_paths(label)['receipt'])


def classify(context,label,records,authority):
    """No automatic trajectory retry; completed output can only be audited/sealed."""
    job,_=job_for_label(context,label);f=context.files
    gpu_commands=[expected_command(context,label,device) for device in (0,1)]
    gpu=[(n,r) for n,r in records.items() if r.get('label')==PREFIX+label or r.get('command') in gpu_commands]
    cpu=[(n,r) for n,r in records.items() if r.get('label')==AUDIT_PREFIX+label or r.get('command')==audit_command(context,label)]
    assert len(gpu)<=1 and len(cpu)<=1, 'Duplicate attempts require investigation, never automatic retry'
    if f.path(evidence_paths(label)['receipt']).exists():
        receipt,_=verify_receipt(context,label,authority)
        assert len(gpu)==len(cpu)==1 and gpu[0][0]==receipt['execution_attempt'] and cpu[0][0]==receipt['audit_attempt']
        return 'reuse',gpu[0][0],cpu[0][0]
    if gpu:
        execution_proof(context,label,gpu[0][0],authority)
        if cpu:
            audit_proof(context,label,cpu[0][0],gpu[0][0],authority)
            return 'seal_only',gpu[0][0],cpu[0][0]
        assert not f.path(audit_path(label)).exists(), 'Unregistered/partial audit output; investigate'
        return 'audit_only',gpu[0][0],None
    assert not cpu and not f.path(audit_path(label)).exists()
    untouched_destination(context,job)
    return 'launch',None,None
