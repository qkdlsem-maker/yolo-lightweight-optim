"""Fixed score extraction and within-archive metric-definition differences."""
import itertools,math
from decimal import Decimal,localcontext


def scores(native_bdd,bdd,kitti_ignore,kitti_no_ignore,native_kitti):
    output={
        'bdd_ten_class_AP50_95':native_bdd['results']['metrics/mAP50-95(B)'],
        'bdd_ten_class_AP50':native_bdd['results']['metrics/mAP50(B)'],
        'kitti_native_mean_moderate_R40':native_kitti['mean_moderate_AP_R40']}
    for prefix,artifact in (('bdd_common',bdd),('kitti_common_source_ignore',kitti_ignore),('kitti_common_no_ignore',kitti_no_ignore)):
        output[prefix+'_AP50_95']=artifact['score']['mean_AP50_95']
        for cls in ('person','car'):output[prefix+'_'+cls+'_AP50_95']=artifact['score']['class_AP50_95'][cls]
    for cls in ('car','pedestrian'):
        for difficulty in ('easy','moderate','hard'):
            output['kitti_native_'+cls+'_'+difficulty+'_R40']=native_kitti['classes'][cls][difficulty]['AP_R40']
    assert len(output)==18 and all(type(v) in (int,float) and math.isfinite(v) and 0<=v<=1 for v in output.values())
    return output


def metric_factor_effects(cells):
    assert len(cells)==8
    indexed={((0 if c['overlap_policy']=='iou_grid' else 1),
        (0 if c['recall_points']==101 else 1),(0 if c['ignore_policy']=='source_ignore' else 1)):c for c in cells}
    assert set(indexed)==set(itertools.product((0,1),repeat=3))
    for key,c in indexed.items():
        assert c['overlap_policy'] in ('iou_grid','class_specific_iou') and c['recall_points'] in (101,40) and c['ignore_policy'] in ('source_ignore','no_ignore')
    factors=('overlap','recall_grid','ignore');output=[]
    for size in (1,2,3):
        for selected in itertools.combinations(range(3),size):
            effects={}
            for metric in ('mean_AP','person','car'):
                with localcontext() as context:
                    context.prec=50;total=Decimal(0)
                    for key,c in indexed.items():
                        value=c['mean_AP'] if metric=='mean_AP' else c['class_AP'][metric]
                        assert math.isfinite(value) and 0<=value<=1
                        sign=math.prod(1 if key[index] else -1 for index in selected)
                        total+=Decimal(str(value))*sign
                    effects[metric]=float(100*total/Decimal(2**(3-size)))
            output.append({'factors':[factors[index] for index in selected],'order':size,'effect_pp':effects})
    return {'effects':output,'contrast_definition':'High-minus-low difference, averaged over unselected factors; interactions are differences of differences.',
        'high_levels':{'overlap':'class_specific_iou','recall_grid':40,'ignore':'no_ignore'},
        'low_levels':{'overlap':'iou_grid','recall_grid':101,'ignore':'source_ignore'},
        'unit':'AP_percentage_points','independent_replications_claimed':False,'native_KITTI_equivalence_claimed':False}
