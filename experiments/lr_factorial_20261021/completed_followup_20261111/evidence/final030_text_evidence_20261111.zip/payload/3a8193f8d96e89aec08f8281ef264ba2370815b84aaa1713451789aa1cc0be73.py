"""Atomic validation result plus post-validation RNG, with no inference on recovery.

The trainer owns the exclusive run lock. Callbacks own inference and RNG formats;
this module imports no tensor library and never samples an RNG. A committed result
is immutable. Uncommitted attempts are retained before retrying that validation.
"""
import hashlib
import json
import os
from pathlib import Path


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    # Normalize JSON object keys before sorting (class names may use integer keys).
    canonical = json.loads(json.dumps(value, allow_nan=False))
    return (json.dumps(canonical, indent=2, sort_keys=True, allow_nan=False) + '\n').encode('utf-8')


def durable_write(path, data):
    with path.open('xb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())


def sync_directory(path):
    if os.name != 'nt':
        fd = os.open(path, os.O_RDONLY | getattr(os, 'O_DIRECTORY', 0))
        try:
            os.fsync(fd)
        finally:
            os.close(fd)


def publish_immutable(path, data):
    if path.exists():
        assert path.read_bytes() == data, f'Existing result differs: {path}'
        return
    pending = path.with_name(path.name + '.publishing')
    if pending.exists():
        assert pending.read_bytes() == data, f'Unexpected partial publication: {pending}'
    else:
        durable_write(pending, data)
    # Atomic creation with no replacement, even if a caller violated the run lock.
    try:
        os.link(pending, path)
    except FileExistsError:
        assert path.read_bytes() == data, f'Concurrent result differs: {path}'
    sync_directory(path.parent)
    pending.unlink()
    sync_directory(path.parent)


def paths(out, name):
    assert name.startswith('ema_epoch') and name[len('ema_epoch'):].isdigit()
    out = Path(out)
    return out, out / (name + '_validation_commit'), out / (name + '_metrics.json'), out / (name + '.pt')


def recover_validation(out, name, bindings, restore_rng):
    out, commit, metrics, checkpoint = paths(out, name)
    if not commit.exists():
        assert not metrics.exists(), 'Visible metrics lack a validation/RNG commit'
        return None
    assert commit.is_dir()
    assert {p.name for p in commit.iterdir()} == {'result.json', 'post_rng.bin', 'manifest.json'}
    manifest = json.loads((commit / 'manifest.json').read_bytes())
    assert manifest['schema'] == 'validation_rng_commit_v1'
    assert manifest['bindings'] == bindings, 'Validation inputs/configuration changed'
    result_bytes = (commit / 'result.json').read_bytes()
    rng_bytes = (commit / 'post_rng.bin').read_bytes()
    assert digest(result_bytes) == manifest['result_sha256'], 'Committed metric bytes changed'
    assert digest(rng_bytes) == manifest['post_rng_sha256'], 'Committed RNG bytes changed'
    assert digest(checkpoint.read_bytes()) == manifest['checkpoint_sha256'], 'Validation checkpoint changed'
    result = json.loads(result_bytes)
    assert encoded(result) == result_bytes
    assert result['checkpoint_sha256'] == manifest['checkpoint_sha256']
    if metrics.exists():
        assert metrics.read_bytes() == result_bytes, 'Published metrics changed'
    restore_rng(rng_bytes)
    publish_immutable(metrics, result_bytes)
    return result


def preserve_uncommitted(out, name):
    """Retain only this epoch's partial validation artifacts before another attempt."""
    out, commit, metrics, checkpoint = paths(out, name)
    assert not commit.exists() and not metrics.exists()
    prefixes = (name + '_validation',)
    partials = []
    for p in out.iterdir():
        suffix = p.name[len(prefixes[0]):] if p.name.startswith(prefixes[0]) else None
        native_validation = suffix is not None and (suffix == '' or suffix.isdigit())
        if p == checkpoint or p.name in (name + '_validation_pending', metrics.name + '.publishing') or native_validation:
            partials.append(p)
    if not partials:
        return
    archive = out / 'interrupted_validation_attempts'
    archive.mkdir(exist_ok=True)
    index = 1
    while (archive / f'{name}_attempt{index:03d}').exists():
        index += 1
    destination = archive / f'{name}_attempt{index:03d}'
    destination.mkdir()
    for p in sorted(partials):
        p.rename(destination / p.name)
    sync_directory(destination)
    sync_directory(out)


def run_validation(out, name, bindings, infer, capture_rng, restore_rng, fault=lambda point: None):
    """Run once or restore a completed validation, including its RNG transition.

The optional fault callback is for CPU tests only. Production does not supply it.
Only atomic-directory publication establishes completion; partial inference can
be retried after preservation, whereas committed inference must never be repeated.
"""
    recovered = recover_validation(out, name, bindings, restore_rng)
    if recovered is not None:
        return recovered
    out, commit, metrics, checkpoint = paths(out, name)
    preserve_uncommitted(out, name)
    fault('before_inference')
    result = infer()
    # Capture after the original evaluation and cleanup, not before it. This keeps
    # the original uninterrupted RNG transition instead of isolating validation.
    rng_bytes = capture_rng()
    assert isinstance(rng_bytes, bytes) and rng_bytes
    fault('after_inference')
    assert result['checkpoint_sha256'] == digest(checkpoint.read_bytes())
    result_bytes = encoded(result)
    pending = out / (name + '_validation_pending')
    pending.mkdir()
    durable_write(pending / 'result.json', result_bytes)
    durable_write(pending / 'post_rng.bin', rng_bytes)
    manifest = {'schema': 'validation_rng_commit_v1', 'bindings': bindings,
                'result_sha256': digest(result_bytes), 'post_rng_sha256': digest(rng_bytes),
                'checkpoint_sha256': result['checkpoint_sha256']}
    durable_write(pending / 'manifest.json', encoded(manifest))
    sync_directory(pending)
    fault('before_commit')
    assert not commit.exists(), 'Never replace a validation commit'
    pending.rename(commit)
    sync_directory(out)
    fault('after_commit')
    publish_immutable(metrics, result_bytes)
    fault('after_publish')
    return json.loads(result_bytes)
