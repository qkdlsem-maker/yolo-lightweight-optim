"""Bounded, single-use current evaluation input authentication during training.

The existing collector is unchanged. This wrapper admits no evaluation and has
no retry, resume, model loading or GPU execution option.
"""
import fcntl
import os
from pathlib import Path
import resource
import signal
import sys
import threading
import time
import traceback

from continuation_artifact_receipts import ROOT, PROTOCOL_SHA, Files, loads, encoded
from continuation_preflight_runtime import check_limits, process_command
from incident020_resources import resources
from run_continuations import register_attempt
from continuation_wave_runner import finish
from validation_journal import publish_immutable
import continuation_after020_evidence as guarded
import factorial_current_evaluation_inputs as evidence

SELF = ROOT / 'run_factorial_current_inputs_auth.py'
PREFIX = ROOT / 'factorial_current_inputs_auth'
MANIFEST = ROOT / 'factorial_current_inputs_auth_sources.json'
PREPARED = ROOT / 'factorial_training_acceptance_sources.json'
PREPARED_SHA = 'ef0f0fe9313f0eacbb5c68a29f88f5b38fe14d8ae1898bd22c80f41ca83ea298'
SPEC_SHA = '7841a7ec64bcdd67addc18c077d2c5b63a3ed1da42bd5432d93e15d660f89df5'
WALL_SECONDS = 1800
CPU_SECONDS = 1800
POLL_SECONDS = 5
JOIN_SECONDS = 20


def command(files, expected):
    return [str(files.project / 'venv/bin/python'), '-B', '-u', str(SELF), expected]


def verify_sources(files, expected):
    assert len(expected) == 64 and all(c in '0123456789abcdef' for c in expected)
    manifest = loads(files.read(str(MANIFEST), expected))
    assert manifest['schema'] == 'factorial_current_inputs_auth_sources_v1'
    assert manifest['protocol_sha256'] == PROTOCOL_SHA
    assert manifest['execution_admitted'] is False
    assert manifest['wall_seconds_limit'] == WALL_SECONDS
    assert manifest['CPU_seconds_limit'] == CPU_SECONDS
    bindings = {str(ROOT / v['name']): v['sha256'] for v in manifest['files']}
    assert len(bindings) == len(manifest['files']) and str(SELF) in bindings
    assert bindings[str(ROOT / 'factorial_current_inputs_spec.json')] == SPEC_SHA
    assert str(ROOT / 'factorial_current_evaluation_inputs.py') in bindings
    assert Path(evidence.__file__).resolve() == files.path(str(ROOT / 'factorial_current_evaluation_inputs.py')).resolve()
    prepared = loads(files.read(str(PREPARED), PREPARED_SHA))
    assert bindings[str(PREPARED)] == PREPARED_SHA
    for item in prepared['files']:
        assert bindings[str(ROOT / item['name'])] == item['sha256']
    assert Path(__file__).resolve() == files.path(str(SELF)).resolve()
    files.verify(bindings)
    return bindings


def gate(files):
    # This CPU-only byte scan may overlap training; it never owns a GPU.
    guarded.guard(files)
    guarded.latches(files, loads(files.read(str(guarded.REVIEW))))
    rows, usage = resources(files)
    check_limits(usage)
    assert 'torch' not in sys.modules and os.environ.get('CUDA_VISIBLE_DEVICES') == ''
    return usage


def validate_result(value):
    assert value['schema'] == 'factorial_current_evaluation_inputs_v1'
    assert value['status'] == 'current_input_bytes_authenticated_not_evaluation_admission'
    assert value['protocol_sha256'] == PROTOCOL_SHA
    assert value['preparation_sha256'] == SPEC_SHA
    assert value['reused24_authentication_sha256'] == evidence.REUSE_SHA
    assert value['image_counts'] == {'bdd': 10000, 'kitti': 7481}
    assert value['BDD_labels']['images'] == 10000 and value['BDD_labels']['boxes'] == 185526
    assert value['KITTI_label_members'] == 7481
    for name in ('model_loaded', 'new_GPU_work', 'new_inference', 'new_scoring', 'old_evaluation_audit_repeated', 'evaluation_admitted'):
        assert value[name] is False
    assert value['runtime']['GPU_runtime_observed'] is False


def run(project, expected):
    assert os.name == 'posix' and 'torch' not in sys.modules
    assert os.environ.get('CUDA_VISIBLE_DEVICES') == ''
    files = Files(project)
    # A duplicate must not write a failure into the active/completed operation.
    lock = files.path(str(PREFIX) + '.lock').open('a')
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    result_path = files.path(str(PREFIX) + '.json')
    failure_path = files.path(str(PREFIX) + '_FAILURE.json')
    intent_path = files.path(str(PREFIX) + '_execution.json')
    assert not any(p.exists() for p in (result_path, failure_path, intent_path)), 'Single-use acceptance; no automatic retry'
    started = time.time()
    cmd = command(files, expected)
    assert process_command(os.getpid()) == cmd
    assert os.getsid(0) == os.getpgid(0) == os.getpid()
    name, row = register_attempt(files, 'factorial_current_inputs_auth_CPU', cmd, None, pid=os.getpid())
    stopped, faults = threading.Event(), []
    watcher = None

    def interrupted(signum, frame):
        raise RuntimeError('Bounded CPU acceptance interrupted by signal ' + str(signum))

    handlers = {s: signal.signal(s, interrupted) for s in (signal.SIGTERM, signal.SIGINT, signal.SIGALRM, signal.SIGXCPU)}
    signal.alarm(WALL_SECONDS)
    try:
        resource.setrlimit(resource.RLIMIT_CPU, (max(1, CPU_SECONDS - 10), CPU_SECONDS))
        os.nice(15)
        publish_immutable(intent_path, encoded({'attempt': name, 'pid': os.getpid(), 'command': cmd,
            'started_unix': started, 'source_manifest_sha256': expected, 'GPU_job': False,
            'wall_seconds_limit': WALL_SECONDS, 'CPU_seconds_limit': CPU_SECONDS}))
        initial = gate(files)

        def watch():
            while not stopped.wait(POLL_SECONDS):
                try:
                    gate(files)
                    assert not failure_path.exists()
                    assert loads(files.read(name)) == row, 'Attempt stopped by independent guard'
                except BaseException as error:
                    faults.append(repr(error))
                    os.kill(os.getpid(), signal.SIGTERM)
                    return

        watcher = threading.Thread(target=watch, daemon=True)
        watcher.start()
        bindings = verify_sources(files, expected)
        value = evidence.collect(files.project, SPEC_SHA)
        validate_result(value)
        stopped.set()
        watcher.join(JOIN_SECONDS)
        assert not watcher.is_alive() and not faults, 'CPU supervisor failed'
        final = gate(files)
        files.verify(bindings)
        assert loads(files.read(name)) == row, 'Terminal guard record cannot be replaced'
        value.update(attempt=name, command=cmd, pid=os.getpid(), started_unix=started,
            ended_unix=time.time(), source_manifest_sha256=expected,
            wrapper_initial_usage=initial, wrapper_final_usage=final,
            CPU_seconds=time.process_time(), wall_seconds_limit=WALL_SECONDS,
            CPU_seconds_limit=CPU_SECONDS, runtime_model_imported=False)
        publish_immutable(result_path, encoded(value))
        terminal = finish(files, name, row, 0)
        assert terminal['status'] == 'completed' and terminal['returncode'] == 0
        print('CURRENT_INPUT_BYTE_AUTHENTICATION_PASSED_NOT_EVALUATION_ADMISSION', flush=True)
        return value
    except BaseException as error:
        stopped.set()
        if watcher is not None:
            watcher.join(JOIN_SECONDS)
        publish_immutable(failure_path, encoded({'attempt': name, 'pid': os.getpid(),
            'source_manifest_sha256': expected, 'error': repr(error),
            'traceback': traceback.format_exc(), 'watchdog_errors': faults,
            'automatic_retry': False, 'scientific_artifacts_modified': False,
            'new_GPU_work': False, 'unix': time.time()}))
        finish(files, name, row, 1, error)
        raise
    finally:
        stopped.set()
        signal.alarm(0)
        for sig, handler in handlers.items():
            signal.signal(sig, handler)
        lock.close()


if __name__ == '__main__':
    assert len(sys.argv) == 2, 'Only the frozen source-manifest SHA is accepted'
    run(Path.cwd(), sys.argv[1])
