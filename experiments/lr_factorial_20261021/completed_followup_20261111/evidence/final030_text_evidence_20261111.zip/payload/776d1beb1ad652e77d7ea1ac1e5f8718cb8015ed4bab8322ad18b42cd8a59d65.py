"""Read-only consumer of the remaining15 completed training receipt chains.

This has no launcher and cannot admit evaluation. The caller must authenticate
the frozen scientific context, fixed plan, original12 acceptance and authority
before using it. It consumes completed independent audits as byte evidence; it
does not load tensors, repeat audits, train, or initialize CUDA.
"""
from pathlib import Path

from continuation_artifact_receipts import ROOT, PROTOCOL_SHA, loads
from continuation_execution_runtime import job_for_label, checkpoint_bindings
from continuation_wave_evidence import audit_report, closed_attempt

HERE = ROOT / 'continuation_after020'
RUNNER = ROOT / 'continuation_after020_runner.py'


def command(files, number=None, label=None):
    value = [str(files.project/'venv/bin/python'), '-u', str(RUNNER)]
    return value if number is None else value + ['--wave', str(number), '--label', label]


def merge(target, other):
    for name, sha in other.items():
        assert name not in target or target[name] == sha, 'Conflicting evidence binding: ' + name
        target[name] = sha


def registered_prefix(closed, initial):
    assert initial['status'] in ('starting', 'running')
    assert not {'ended_unix', 'returncode', 'stop_reason'} & initial.keys()
    assert {k: closed[k] for k in initial if k != 'status'} == {
        k: v for k, v in initial.items() if k != 'status'}


def completed_wave(context, wave, authority, parent, review):
    """Require all peer exits, sequential audits and exact immutable seal."""
    f = context.files
    number = wave['wave']
    assert type(number) is int and 6 <= number <= 13
    assert len(wave['jobs']) == (1 if number == 13 else 2)
    assert [i['device'] for i in wave['jobs']] == ([0] if number == 13 else [0, 1])
    labels = [i['label'] for i in wave['jobs']]
    assert len(set(labels)) == len(labels)
    folder = HERE / f'wave_{number:02d}'
    wa = loads(f.read(str(folder/'authority.json')))
    wh = f.sha(str(folder/'authority.json'))
    assert wa['protocol_sha256'] == PROTOCOL_SHA
    assert wa['wave'] == wave and wa['parent_pid'] == parent['pid']
    assert wa['global_authority_sha256'] == f.sha(str(HERE/'authority.json'))
    assert set(wa['inputs']) == set(labels)
    release = loads(f.read(str(folder/'release.json')))
    assert release['status'] == 'both_CPU_admissions_passed_GPU_wave_released'
    assert release['wave'] == number and release['parent_pid'] == parent['pid']
    assert release['authority_sha256'] == wh
    assert release['GPU_uuid'] == {str(i['device']): review['GPU_uuid'][str(i['device'])] for i in wave['jobs']}
    assert set(release['ready_sha256']) == set(labels)
    reservations = release['reservations']
    assert len(reservations) == len(labels)
    assert {r['device'] for r in reservations.values()} == {i['device'] for i in wave['jobs']}
    bound, reservation_rows = {}, []
    for name, initial in reservations.items():
        row = closed_attempt(f, name, command(f))
        assert row['GPU_job'] is True and row['reservation'] is True and row['pid'] == parent['pid']
        assert row['wave'] == number and row['label'] == f'continuation_after020_wave_{number:02d}_GPU{row["device"]}_reservation'
        registered_prefix(row, initial)
        assert parent['started_unix'] <= row['started_unix'] <= release['released_unix'] <= row['ended_unix'] <= parent['ended_unix']
        reservation_rows.append(row)
        bound[name] = f.sha(name)
    workers, audits, receipts = [], [], {}
    for item in wave['jobs']:
        label = item['label']
        assert item['args']['resume'] is False and item['args']['device'] == item['device']
        sub = folder / label
        receipt_path = str(HERE/'receipts'/f'{label}.json')
        receipt = loads(f.read(receipt_path))
        assert receipt['schema'] == 'continuation_after020_completed_receipt_v1'
        assert receipt['status'] == 'initial_execution_and_independent_CPU_audit_passed'
        assert receipt['protocol_sha256'] == PROTOCOL_SHA and receipt['wave'] == number
        for key in ('label', 'device', 'args'):
            assert receipt[key] == item[key] and type(receipt[key]) is type(item[key])
        ticket = loads(f.read(str(sub/'ticket.json')))
        ready = loads(f.read(str(sub/'ready.json'), release['ready_sha256'][label]))
        returned = loads(f.read(str(sub/'returned.json')))
        assert ticket['command'] == command(f, number, label) and ticket['parent_pid'] == parent['pid']
        assert ready['parent_pid'] == parent['pid'] and ready['args'] == item['args']
        assert ready['device'] == item['device'] and ready['label'] == label
        assert ready['status'] == 'CPU_contract_passed_waiting_for_wave_release'
        assert ready['CUDA_visible_devices_before_release'] == ''
        assert ready['contract']['mode'] == 'production' and ready['contract']['label'] == label
        assert ready['contract']['protocol_sha256'] == PROTOCOL_SHA
        for value in (ticket, ready, returned):
            assert value['pid'] == ticket['pid'] and value['authority_sha256'] == wh
        assert returned['status'] == 'trainer_returned_independent_audit_pending'
        assert returned['release_sha256'] == f.sha(str(folder/'release.json'))
        assert receipt['worker_attempt'] == ticket['attempt'] == ready['attempt']
        worker = closed_attempt(f, ticket['attempt'], ticket['command'])
        assert worker['GPU_job'] is False and worker['parent_pid'] == parent['pid'] and worker['pid'] == ticket['pid']
        assert worker['label'] == 'continuation_after020_worker__' + label
        registered_prefix(worker, ticket['registered'])
        assert parent['started_unix'] <= worker['started_unix'] <= ready['ready_unix'] <= release['released_unix'] <= returned['returned_unix'] <= worker['ended_unix']
        assert all(worker['ended_unix'] <= r['ended_unix'] for r in reservation_rows)
        assert receipt['reservation_attempts'] == sorted(reservations)
        audit_cmd = [str(f.project/'venv/bin/python'), '-u', str(ROOT/'continuation_completion_audit.py'), '--label', label]
        audit = closed_attempt(f, receipt['audit_attempt'], audit_cmd)
        assert audit['GPU_job'] is False and audit['parent_pid'] == parent['pid']
        assert audit['label'] == 'continuation_after020_audit__' + label
        assert max(r['ended_unix'] for r in reservation_rows) <= audit['started_unix'] <= audit['ended_unix'] <= parent['ended_unix']
        job, design = job_for_label(context, label)
        inputs = checkpoint_bindings(context, job, design)
        assert wa['inputs'][label] == inputs
        assert returned['complete_sha256'] == f.sha(job['run_directory']+'/COMPLETE.json')
        report = loads(f.read(str(sub/'audit.json')))
        expected = dict(audit_report(context, job, report, authority['bases'], inputs))
        for key in ('source', 'bases', 'new_sources', 'reuse'):
            merge(expected, authority[key])
        merge(expected, {n: f.sha(n) for n in reservations})
        for path in (folder/'authority.json', folder/'release.json', sub/'ticket.json', sub/'ready.json',
                     sub/'returned.json', sub/'worker.log', sub/'audit.json', sub/'audit.log',
                     HERE/'authority.json', Path(receipt['worker_attempt']), Path(receipt['audit_attempt'])):
            merge(expected, {str(path): f.sha(str(path))})
        assert receipt['bound_file_sha256'] == expected, 'Missing, extra or altered completed receipt binding'
        assert receipt['actual_step_counts'] == report['actual_step_counts']
        f.verify(expected)
        merge(bound, expected)
        receipts[receipt_path] = f.sha(receipt_path)
        workers.append(worker)
        audits.append(audit)
    assert len({w['pid'] for w in workers}) == len(workers)
    assert len({a['pid'] for a in audits}) == len(audits)
    assert all(set(r['worker_PIDs']) == {w['pid'] for w in workers} for r in reservation_rows)
    for previous, following in zip(audits, audits[1:]):
        assert previous['ended_unix'] <= following['started_unix'], 'Overlapping or reordered CPU audits'
    seal = loads(f.read(str(folder/'SEALED.json')))
    assert seal['wave'] == number and seal['all_worker_processes_exited'] is True
    assert seal['receipt_sha256'] == receipts and seal['release_sha256'] == f.sha(str(folder/'release.json'))
    assert seal['not_full_phase_completion'] is True
    assert max(a['ended_unix'] for a in audits) <= seal['sealed_unix'] <= parent['ended_unix']
    merge(bound, receipts)
    bound[str(folder/'SEALED.json')] = f.sha(str(folder/'SEALED.json'))
    return {'bound': bound, 'receipts': receipts,
            'first_worker_started_unix': min(w['started_unix'] for w in workers),
            'sealed_unix': seal['sealed_unix']}


def completed_remaining15(context, plan, authority, parent_name, review):
    """Consume all8 completed waves, including the final one-device wave.

    The full parent completion marker AND successful closed parent are required.
    A running parent or a subset of sealed waves cannot pass this boundary.
    """
    f = context.files
    assert not f.path(str(HERE/'FAILURE.json')).exists()
    assert loads(f.read(str(HERE/'authority.json'))) == authority
    assert [w['wave'] for w in plan['waves']] == list(range(6, 14))
    assert sum(len(w['jobs']) for w in plan['waves']) == 15
    labels = [i['label'] for w in plan['waves'] for i in w['jobs']]
    assert len(set(labels)) == 15
    parent = closed_attempt(f, parent_name, command(f))
    assert parent['label'] == 'continuation_after020_parent_CPU' and parent['GPU_job'] is False
    assert parent['device'] is None
    complete_path = str(HERE/'TRAINING_RECEIPTS_COMPLETE.json')
    complete = loads(f.read(complete_path))
    assert complete['status'] == '15_new_wave_receipts_plus_twelve_prior_paths_accepted'
    assert complete['protocol_sha256'] == PROTOCOL_SHA and complete['prior_reuse_sha256'] == authority['reuse']
    assert complete['whole_phase_complete'] is False
    assert complete['new_evaluation_diagnostics_and_documents_complete'] is False
    expected_paths = {str(HERE/'receipts'/f'{label}.json') for label in labels}
    assert set(complete['receipt_sha256']) == expected_paths
    actual = {p.relative_to(f.project).as_posix() for p in f.path(str(HERE/'receipts')).iterdir()}
    assert actual == expected_paths, 'Extra or missing receipt files'
    assert {p.name for p in f.path(str(HERE)).glob('wave_*')} == {f'wave_{w:02d}' for w in range(6, 14)}
    bound, receipts = {}, {}
    previous_seal = parent['started_unix']
    for wave in plan['waves']:
        result = completed_wave(context, wave, authority, parent, review)
        assert previous_seal <= result['first_worker_started_unix'], 'Next wave began before prior seal'
        previous_seal = result['sealed_unix']
        merge(bound, result['bound'])
        merge(receipts, result['receipts'])
    assert complete['receipt_sha256'] == receipts
    for name in (parent_name, complete_path):
        bound[name] = f.sha(name)
    return {'status': 'all_fifteen_completed_receipts_and_closed_parent_authenticated',
            'protocol_sha256': PROTOCOL_SHA, 'bound_file_sha256': dict(sorted(bound.items())),
            'receipt_sha256': receipts, 'parent_attempt': parent_name,
            'model_audit_repeated': False, 'new_GPU_work': False, 'evaluation_admitted': False}
