"""Remaining15 initial-only waves after incident020: CPU readiness, shared GPU reservation, exit, audit, seal.

No scientific source is patched. A whole wave exits before sequential independent
audits and before any next wave. Every failure stops owned children and leaves
all files/attempts intact. This program has no retry, resume or test-mode option.
GPU_job rows are parent-owned reservations; worker rows explicitly refer to
that accounting, so GPU time is charged once per device, including idle peers.
"""
import argparse
import os
from pathlib import Path
import signal
import subprocess
import threading
import time
import traceback
from types import SimpleNamespace
from continuation_artifact_receipts import ROOT, PROTOCOL_SHA, Files, Context, loads, encoded
from continuation_contract import enforce_contract
from continuation_execution_runtime import job_for_label, arguments, checkpoint_bindings, untouched_destination
from continuation_preflight_runtime import check_limits, process_command, gpu_idle_uuid
from incident020_resources import resources
from continuation_production_receipts import CPU_ENVIRONMENT
from run_continuation_production_job import execute_trainer
from run_continuations import register_attempt
from run_continuation_preflight import update_owned, stop_owned_child
from validation_journal import publish_immutable
import continuation_after020_evidence as evidence
import continuation_after020_evidence as recovery

SELF=ROOT/'continuation_after020_runner.py'
HERE=evidence.HERE


def command(files,wave=None,label=None):
    result=[str(files.project/'venv/bin/python'),'-u',SELF.as_posix()]
    if wave is not None:result+=['--wave',str(wave),'--label',label]
    return result


def check_self(files):
    assert Path(__file__).resolve()==files.path(SELF.as_posix()).resolve()


def put(files,path,value):
    destination=files.path(str(path));destination.parent.mkdir(parents=True,exist_ok=True)
    publish_immutable(destination,encoded(value))


def wave_path(number):
    assert type(number) is int and 6<=number<=13
    return HERE/f'wave_{number:02d}'


def failure(files,error):
    # First latch plus every distinct process's exception; never alter incident018.
    import uuid
    value={'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'pid':os.getpid(),
           'error':repr(error),'traceback':traceback.format_exc(),'automatic_retry':False,
           'last_atomic_state_and_all_attempts_preserved':True}
    put(files,HERE/'failures'/f'{os.getpid()}_{uuid.uuid4().hex}.json',value)
    p=files.path((HERE/'FAILURE.json').as_posix())
    try:publish_immutable(p,encoded(value))
    except (FileExistsError,AssertionError):
        assert p.exists()


def finish(files,name,initial,code,error=None):
    current=loads(files.read(name))
    if 'ended_unix' in current:return current  # A budget guard terminal always wins.
    assert current==initial
    row=dict(initial,ended_unix=time.time(),returncode=code,
             status='completed' if code==0 and error is None else 'failed')
    if error is not None:row['stop_reason']=repr(error)
    update_owned(files,name,initial,row)
    return loads(files.read(name))


def add_fields(files,name,row,**fields):
    updated=dict(row,**fields);assert update_owned(files,name,row,updated)
    return updated


def closed_children(files,children,error=None):
    """Tear down only exact owned sessions; never close a still-live allocation."""
    for child in children:
        proc=child.get('proc')
        if proc is not None and proc.poll() is None:
            assert error is not None
            stop_owned_child(proc,child['command'])
        if proc is None or proc.poll() is not None:
            for h in child.get('handles',[]):h.close()
            finish(files,child['attempt'],child['row'],1 if proc is None else proc.returncode,error)


def start(files,label,cmd,log,children,stdout=None):
    """Register before Popen. The caller retains the row even when Popen fails."""
    name,row=register_attempt(files,label,cmd,None,parent_pid=os.getpid())
    row=add_fields(files,name,row,log=str(log),GPU_accounting='covered_by_wave_reservations_if_worker_else_CPU_only')
    child={'attempt':name,'row':row,'command':cmd,'handles':[]};children.append(child)
    err=files.path(str(log)).open('xb');child['handles'].append(err)
    out=err
    if stdout is not None:
        out=files.path(str(stdout)).open('xb');child['handles'].append(out)
    env=os.environ.copy();env.update(CPU_ENVIRONMENT)
    env['YOLO_CONFIG_DIR']=str(files.path(str(ROOT/'config')))
    proc=subprocess.Popen(cmd,cwd=files.project,env=env,stdout=out,stderr=err,
                          stdin=subprocess.DEVNULL,start_new_session=True)
    child['proc']=proc
    child['row']=add_fields(files,name,row,pid=proc.pid,status='running')
    return child


def ready_value(files,folder,item,child,authority_sha):
    value=loads(files.read(str(folder/item['label']/'ready.json')))
    assert value['status']=='CPU_contract_passed_waiting_for_wave_release'
    assert value['label']==item['label'] and value['device']==item['device']
    assert value['pid']==child['proc'].pid and value['parent_pid']==os.getpid()
    assert value['authority_sha256']==authority_sha and value['attempt']==child['attempt']
    assert value['args']==item['args'] and value['CUDA_visible_devices_before_release']==''
    assert value['contract']['label']==item['label'] and value['contract']['mode']=='production'
    assert value['contract']['protocol_sha256']==PROTOCOL_SHA
    assert child['proc'].poll() is None and process_command(child['proc'].pid)==child['command']
    return value


def run_wave(context,wave,global_authority,review,check):
    f=context.files;folder=wave_path(wave['wave']);children=[];reservations={}
    assert not f.path(folder.as_posix()).exists(),'Never repeat an admitted wave'
    f.path(folder.as_posix()).mkdir()
    authority={'protocol_sha256':PROTOCOL_SHA,'wave':wave,'parent_pid':os.getpid(),
        'global_authority_sha256':f.sha((HERE/'authority.json').as_posix()),'inputs':{}}
    for item in wave['jobs']:
        job,design=job_for_label(context,item['label']);untouched_destination(context,job)
        authority['inputs'][item['label']]=checkpoint_bindings(context,job,design)
    put(f,folder/'authority.json',authority);authority_sha=f.sha(str(folder/'authority.json'))
    try:
        for item in wave['jobs']:
            check(reservations)
            sub=folder/item['label'];f.path(str(sub)).mkdir()
            cmd=command(f,wave['wave'],item['label'])
            child=start(f,'continuation_after020_worker__'+item['label'],cmd,sub/'worker.log',children)
            child['item']=item
            put(f,sub/'ticket.json',{'pid':child['proc'].pid,'parent_pid':os.getpid(),
                'command':cmd,'attempt':child['attempt'],'registered':child['row'],
                'authority_sha256':authority_sha})
        deadline=time.monotonic()+3600  # technical admission timeout, not an added resource budget
        while True:
            check(reservations)
            assert all(c['proc'].poll() is None for c in children),'Worker exited before readiness release'
            if all(f.path(str(folder/c['item']['label']/'ready.json')).exists() for c in children):break
            assert time.monotonic()<deadline,'CPU admission exceeded one hour'
            time.sleep(.2)
        ready={c['item']['label']:ready_value(f,folder,c['item'],c,authority_sha) for c in children}
        devices=[i['device'] for i in wave['jobs']]
        uuids={str(d):gpu_idle_uuid(d) for d in devices}
        assert uuids=={str(d):review['GPU_uuid'][str(d)] for d in devices}
        # Parent owns one charged reservation per device; worker attempts are
        # tracked but have GPU_job=False to avoid charging their elapsed twice.
        for device in devices:
            n,row=register_attempt(f,f'continuation_after020_wave_{wave["wave"]:02d}_GPU{device}_reservation',command(f),device,pid=os.getpid())
            reservations[n]=add_fields(f,n,row,reservation=True,
                worker_PIDs=[c['proc'].pid for c in children],wave=wave['wave'])
        check(reservations)
        release={'status':'both_CPU_admissions_passed_GPU_wave_released','wave':wave['wave'],
            'parent_pid':os.getpid(),'authority_sha256':authority_sha,'released_unix':time.time(),
            'ready_sha256':{label:f.sha(str(folder/label/'ready.json')) for label in ready},
            'GPU_uuid':uuids,'reservations':reservations}
        put(f,folder/'release.json',release)
        print('WAVE_RELEASED',wave['wave'],[c['proc'].pid for c in children],flush=True)
        while True:
            check(reservations)
            codes=[c['proc'].poll() for c in children]
            assert all(code in (None,0) for code in codes),'Scientific or technical worker failure; no automatic retry'
            if all(code==0 for code in codes):break
            time.sleep(.5)
        closed_children(f,children)
        for name,row in reservations.items():finish(f,name,row,0)
        closed_reservations=dict(reservations);reservations.clear()
        # Both contexts have exited. No hot fill, and only one CPU audit at a time.
        sealed={}
        for child in list(children):
            check(reservations);item=child['item'];sub=folder/item['label']
            returned=loads(f.read(str(sub/'returned.json')))
            job,_=job_for_label(context,item['label'])
            assert returned['pid']==child['proc'].pid and returned['authority_sha256']==authority_sha
            assert returned['complete_sha256']==f.sha(job['run_directory']+'/COMPLETE.json')
            cmd=[str(f.project/'venv/bin/python'),'-u',(ROOT/'continuation_completion_audit.py').as_posix(),'--label',item['label']]
            cpu=start(f,'continuation_after020_audit__'+item['label'],cmd,sub/'audit.log',children,sub/'audit.json')
            while cpu['proc'].poll() is None:check(reservations);time.sleep(.2)
            closed_children(f,[cpu]);assert cpu['proc'].returncode==0,'Independent audit failed'
            receipt=receipt_value(context,wave,item,child,cpu,closed_reservations,global_authority)
            target=HERE/'receipts'/f'{item["label"]}.json';put(f,target,receipt)
            sealed[target.as_posix()]=f.sha(target.as_posix())
            print('WAVE_PATH_AUDITED_SEALED',item['label'],flush=True)
        check(reservations)
        put(f,folder/'SEALED.json',{'wave':wave['wave'],'all_worker_processes_exited':True,
            'receipt_sha256':sealed,'release_sha256':f.sha(str(folder/'release.json')),
            'sealed_unix':time.time(),'not_full_phase_completion':True})
        return sealed
    except BaseException as error:
        failure(f,error);closed_children(f,children,error)
        assert all(c.get('proc') is None or c['proc'].poll() is not None for c in children)
        for name,row in reservations.items():finish(f,name,row,1,error)
        raise


def receipt_value(context,wave,item,child,cpu,reservations,global_authority):
    f=context.files;folder=wave_path(wave['wave']);sub=folder/item['label']
    authority=loads(f.read(str(folder/'authority.json')))
    assert authority['wave']==wave and authority['parent_pid']==os.getpid()
    assert authority['global_authority_sha256']==f.sha(str(HERE/'authority.json'))
    ticket=loads(f.read(str(sub/'ticket.json')));ready=loads(f.read(str(sub/'ready.json')))
    release=loads(f.read(str(folder/'release.json')));returned=loads(f.read(str(sub/'returned.json')))
    assert release['ready_sha256'][item['label']]==f.sha(str(sub/'ready.json'))
    assert release['reservations']==reservations and len(reservations)==len(wave['jobs'])
    assert {r['device'] for r in reservations.values()}=={i['device'] for i in wave['jobs']}
    ah=f.sha(str(folder/'authority.json'))
    for value in (ticket,ready,returned):
        assert value['pid']==child['proc'].pid and value['authority_sha256']==ah
    assert ready['args']==item['args'] and ready['ready_unix']<=release['released_unix']<=returned['returned_unix']
    assert returned['release_sha256']==f.sha(str(folder/'release.json'))
    assert ticket['command']==command(f,wave['wave'],item['label'])
    assert ticket['registered']==child['row'] and ticket['attempt']==child['attempt']
    worker=evidence.closed_attempt(f,child['attempt'],ticket['command'])
    assert worker['GPU_job'] is False and worker['parent_pid']==os.getpid()
    assert worker['started_unix']<=ready['ready_unix']<=returned['returned_unix']<=worker['ended_unix']
    ends=[];bound={}
    for n,initial in reservations.items():
        row=loads(f.read(n))
        assert row['status']=='completed' and row['returncode']==0 and row['GPU_job'] is True
        assert row['pid']==os.getpid() and row['command']==command(f) and row['reservation'] is True
        assert {k:row[k] for k in initial if k!='status'}=={k:v for k,v in initial.items() if k!='status'}
        assert row['started_unix']<=release['released_unix'] and row['ended_unix']>=worker['ended_unix']
        ends.append(row['ended_unix']);bound[n]=f.sha(n)
    audit=evidence.closed_attempt(f,cpu['attempt'],cpu['command'])
    assert audit['GPU_job'] is False and audit['parent_pid']==os.getpid() and audit['started_unix']>=max(ends)
    job,_=job_for_label(context,item['label']);report=loads(f.read(str(sub/'audit.json')))
    bound.update(evidence.audit_report(context,job,report,global_authority['bases'],authority['inputs'][item['label']]))
    for key in ('source','bases','new_sources','reuse'):f.verify(global_authority[key]);bound.update(global_authority[key])
    for p in (folder/'authority.json',folder/'release.json',sub/'ticket.json',sub/'ready.json',
              sub/'returned.json',sub/'worker.log',sub/'audit.json',sub/'audit.log',HERE/'authority.json',
              Path(child['attempt']),Path(cpu['attempt'])):bound[str(p)]=f.sha(str(p))
    assert returned['complete_sha256']==f.sha(job['run_directory']+'/COMPLETE.json')
    return {'schema':'continuation_after020_completed_receipt_v1','protocol_sha256':PROTOCOL_SHA,
        'status':'initial_execution_and_independent_CPU_audit_passed','label':item['label'],
        'wave':wave['wave'],'device':item['device'],'args':item['args'],
        'worker_attempt':child['attempt'],'audit_attempt':cpu['attempt'],
        'reservation_attempts':sorted(reservations),'bound_file_sha256':dict(sorted(bound.items())),
        'actual_step_counts':report['actual_step_counts'],
        'limits':['GPU time charged by wave reservations, not worker-row GPU_job flag.',
                  'Recorded execution/file integrity; no independent training replication.',
                  'External evaluation, diagnostics, analysis and documents remain separate.']}


def worker(number,label):
    f=Files(Path.cwd());pid=os.getpid();parent=os.getppid();folder=wave_path(number);sub=folder/label
    check_self(f)
    assert os.getsid(pid)==os.getpgid(pid)==pid
    assert process_command(pid)==command(f,number,label) and os.environ.get('CUDA_VISIBLE_DEVICES')==''
    deadline=time.monotonic()+10
    while not f.path(str(sub/'ticket.json')).exists():
        assert time.monotonic()<deadline;time.sleep(.05)
    ticket=loads(f.read(str(sub/'ticket.json')))
    assert ticket['pid']==pid and ticket['parent_pid']==parent and ticket['command']==command(f,number,label)
    authority=loads(f.read(str(folder/'authority.json'),ticket['authority_sha256']))
    global_authority=loads(f.read(str(HERE/'authority.json'),authority['global_authority_sha256']))
    review=loads(f.read(recovery.REVIEW.as_posix()));stopped=threading.Event()
    def sample():
        evidence.latches(f,review);recovery.guard(f);rows,usage=resources(f);check_limits(usage)
        assert process_command(parent)==command(f),'Wave parent lost'
        assert rows[ticket['attempt']]==ticket['registered'] and rows[ticket['attempt']]['pid']==pid
        return usage
    def watch():
        while not stopped.wait(1):
            try:sample()
            except BaseException as error:
                failure(f,error);os.killpg(pid,signal.SIGTERM);return
    watcher=threading.Thread(target=watch,daemon=True);watcher.start()
    try:
        sample();new=evidence.sources(f);context=Context(f.project);plan,_=evidence.plan_for(context)
        wave=next(w for w in plan['waves'] if w['wave']==number);assert authority['wave']==wave
        matches=[i for i in wave['jobs'] if i['label']==label];assert len(matches)==1
        item=matches[0];job,design=job_for_label(context,label)
        assert item['args']==arguments(job,design,item['device']) and item['args']['resume'] is False
        untouched_destination(context,job)
        for key in ('source','bases','new_sources','reuse'):f.verify(global_authority[key])
        assert new==global_authority['new_sources']
        assert authority['inputs'][label]==checkpoint_bindings(context,job,design)
        contract=enforce_contract(SimpleNamespace(**item['args']))  # CPU only, no Torch import.
        sample();assert 'torch' not in __import__('sys').modules
        put(f,sub/'ready.json',{'status':'CPU_contract_passed_waiting_for_wave_release','label':label,
            'pid':pid,'parent_pid':parent,'device':item['device'],'attempt':ticket['attempt'],
            'authority_sha256':ticket['authority_sha256'],'args':item['args'],'contract':contract,
            'CUDA_visible_devices_before_release':os.environ.get('CUDA_VISIBLE_DEVICES'),
            'ready_unix':time.time()})
        while not f.path(str(folder/'release.json')).exists():sample();time.sleep(.1)
        release=loads(f.read(str(folder/'release.json')))
        assert release['parent_pid']==parent and release['authority_sha256']==ticket['authority_sha256']
        assert release['wave']==number and release['status']=='both_CPU_admissions_passed_GPU_wave_released'
        assert set(release['ready_sha256'])=={i['label'] for i in wave['jobs']}
        for peer,h in release['ready_sha256'].items():
            row=loads(f.read(str(folder/peer/'ready.json'),h))
            assert row['ready_unix']<=release['released_unix'] and row['parent_pid']==parent
        rows,usage=resources(f);check_limits(usage)
        active={n:r for n,r in rows.items() if r['GPU_job'] and 'ended_unix' not in r}
        assert active==release['reservations'] and len(active)==len(wave['jobs'])
        assert {r['device'] for r in active.values()}=={i['device'] for i in wave['jobs']}
        assert all(r['pid']==parent and r['command']==command(f) and r['reservation'] is True for r in active.values())
        sample();os.environ.pop('CUDA_VISIBLE_DEVICES')
        trainer=(ROOT/'continuation.py').as_posix()
        execute_trainer(f.path(trainer),item['args'],context.bindings[trainer],lambda p:f.sha(Path(p).relative_to(f.project).as_posix()))
        context.verify();f.verify(new);sample()
        for key in ('source','bases','new_sources','reuse'):f.verify(global_authority[key])
        f.verify(authority['inputs'][label])
        put(f,sub/'returned.json',{'status':'trainer_returned_independent_audit_pending','pid':pid,
            'authority_sha256':ticket['authority_sha256'],'release_sha256':f.sha(str(folder/'release.json')),
            'complete_sha256':f.sha(job['run_directory']+'/COMPLETE.json'),'returned_unix':time.time()})
    except BaseException as error:failure(f,error);raise
    finally:stopped.set();watcher.join(20);assert not watcher.is_alive()


def parent():
    import fcntl
    f=Files(Path.cwd());pid=os.getpid();locks=[];parent_attempt=None;interrupted=threading.Event();created=False
    check_self(f)
    assert os.getsid(pid)==os.getpgid(pid)==pid and process_command(pid)==command(f)
    os.environ.update(CPU_ENVIRONMENT)
    for sig in (signal.SIGTERM,signal.SIGINT):signal.signal(sig,lambda *_:interrupted.set())
    try:
        for name in ('continuation_dispatcher.lock','continuation_production_gpu0.lock','continuation_production_gpu1.lock'):
            handle=f.path(str(ROOT/name)).open('a');fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(handle)
        assert not f.path(HERE.as_posix()).exists(),'Single launch only; investigate existing wave evidence'
        f.path(HERE.as_posix()).mkdir()
        created=True
        parent_attempt,parent_row=register_attempt(f,'continuation_after020_parent_CPU',command(f),None,pid=pid)
        context,plan,review,authority=evidence.authenticate(f)
        put(f,HERE/'authority.json',authority)
        def check(reservations):
            assert not interrupted.is_set(),'Wave parent interrupted'
            evidence.latches(f,review);recovery.guard(f);rows,usage=resources(f);check_limits(usage)
            active={n:r for n,r in rows.items() if r['GPU_job'] and 'ended_unix' not in r}
            assert active==reservations,'Unknown/stale/changed GPU allocation'
            assert rows[parent_attempt]==parent_row and process_command(pid)==command(f)
            return usage
        accepted={}
        for wave in plan['waves']:
            check({});accepted.update(run_wave(context,wave,authority,review,check))
        check({});assert len(accepted)==15
        f.verify(accepted);f.verify(authority['reuse']);context.verify()
        put(f,HERE/'TRAINING_RECEIPTS_COMPLETE.json',{'status':'15_new_wave_receipts_plus_twelve_prior_paths_accepted',
            'protocol_sha256':PROTOCOL_SHA,'receipt_sha256':accepted,'prior_reuse_sha256':authority['reuse'],
            'whole_phase_complete':False,'new_evaluation_diagnostics_and_documents_complete':False})
        finish(f,parent_attempt,parent_row,0);parent_attempt=None
        print('REMAINING15_TRAINING_AUDITS_SEALED',flush=True)
    except BaseException as error:
        # A rejected second launcher must not poison an existing healthy wave
        # or append a failure to an already completed run it does not own.
        if created:failure(f,error)
        if parent_attempt is not None:finish(f,parent_attempt,parent_row,1,error)
        raise
    finally:
        for h in reversed(locks):h.close()


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--wave',type=int);parser.add_argument('--label')
    args=parser.parse_args();assert (args.wave is None)==(args.label is None)
    parent() if args.wave is None else worker(args.wave,args.label)
