"""Reuse the frozen input reader's exact BDD leaf-link policy, without relaxing Files."""
import copy,hashlib,json,time,platform
from pathlib import Path
from study_runtime import PROJECT,PHASE,HERE,read,need,file_sha
from continuation_artifact_receipts import loads
import factorial_current_evaluation_inputs as original

HISTORICAL_PLATFORM='Linux-6.17.0-40-generic-x86_64-with-glibc2.39'
CURRENT_PLATFORM='Linux-7.0.0-38-generic-x86_64-with-glibc2.39'
CURRENT_BOOT='d76aa9d4-e680-4e18-b3c1-01b9d02260b1'

def canonical_sha(value):
    return hashlib.sha256((json.dumps(value,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()).hexdigest()

def authenticate(ctx):
    manifest=read(HERE/'SOURCE_MANIFEST.json');name=PHASE+'/factorial_current_inputs_auth.json'
    need(file_sha(PROJECT/name)==manifest['prior_evidence'][name],'Original input authentication changed')
    prior=loads((PROJECT/name).read_bytes());reader=original.CurrentBytes;runtime_reader=original.runtime_sources
    need(prior['runtime']['platform']==HISTORICAL_PLATFORM and platform.platform()==CURRENT_PLATFORM,'Unreviewed host platform')
    need(Path('/proc/sys/kernel/random/boot_id').read_text().strip()==CURRENT_BOOT,'Host rebooted since inspected transition')
    class PulsedCurrentBytes(reader):
        def __init__(self,project):super().__init__(project);self.next_pulse=time.monotonic()+5
        def read(self,*args,**kwargs):
            if time.monotonic()>=self.next_pulse:ctx.check();self.next_pulse=time.monotonic()+5
            return super().read(*args,**kwargs)
    def disclosed_runtime(reader,native,common,isolated_expected):
        # Keep actual platform reporting. Only the already observed kernel
        # expectation is amended; all Python/package/source checks still run
        # in the immutable original runtime reader. No global platform spoofing.
        need(native['runtime']['platform']==HISTORICAL_PLATFORM,'Historical reference platform differs')
        amended=copy.deepcopy(native);amended['runtime']['platform']=CURRENT_PLATFORM
        return runtime_reader(reader,amended,common,isolated_expected)
    original.CurrentBytes=PulsedCurrentBytes;original.runtime_sources=disclosed_runtime
    try:current=original.collect(PROJECT,prior['preparation_sha256'])
    finally:original.CurrentBytes=reader;original.runtime_sources=runtime_reader
    for key in ('schema','status','protocol_sha256','preparation_sha256','blueprint_sha256','reused24_authentication_sha256',
                'image_counts','BDD_labels','annotation_views','KITTI_label_members','bound_artifacts'):
        need(current[key]==prior[key],'Frozen evaluation input changed: '+key)
    expected_runtime=copy.deepcopy(prior['runtime']);expected_runtime['platform']=CURRENT_PLATFORM
    need(current['runtime']==expected_runtime,'Runtime differs beyond the disclosed kernel string')
    need(set(current['path_observations'])==set(prior['path_observations']),'Input path roster changed')
    links=0
    for path,observation in current['path_observations'].items():
        old=prior['path_observations'][path]
        need(all(observation[k]==old[k] for k in ('link_target','resolved_path')),'Input route changed: '+path)
        if observation['link_target'] is not None:
            need(Path(path).parent.as_posix()=='review_20260929_clean/clean_data/images/val','Link outside fixed BDD view')
            need(observation['resolved_path']=='data/raw/val/images/'+Path(path).name,'Link outside matching fixed raw image')
            links+=1
    need(links==10000 and current['image_counts']=={'bdd':10000,'kitti':7481},'Fixed input population')
    ctx.check()
    proof={'status':'current_inputs_reauthenticated_with_frozen_leaf_link_policy','source':name,'sha256':file_sha(PROJECT/name),
        'reader_sha256':file_sha(PROJECT/PHASE/'factorial_current_evaluation_inputs.py'),
        'verified_files':len(current['bound_artifacts']),'bytes_read':current['bytes_read'],'approved_BDD_leaf_links':links,
        'bound_artifacts_canonical_sha256':canonical_sha(current['bound_artifacts']),
        'fresh_path_observations_canonical_sha256':canonical_sha(current['path_observations']),
        'started_unix':current['started_unix'],'ended_unix':current['ended_unix'],
        'environment_transition':{'historical_platform':HISTORICAL_PLATFORM,'current_platform':CURRENT_PLATFORM,'current_boot_id':CURRENT_BOOT,
            'only_allowed_runtime_metadata_difference':'platform','python_packages_native_python_sources_and_isolated_evaluator_bytes_verified':True,
            'historical_results_recomputed':False,'numerical_equivalence_due_to_kernel_change_established':False,
            'limitation':'Historical reused scores and new scores were produced under different Linux kernels. Package and source identity does not establish numerical equivalence across kernels; this remains an unisolated execution-period difference.'},
        'strict_general_file_reader_unchanged':True,'model_loads':0,'GPU_work':False,'new_inference':False,'new_scoring':False}
    return current,proof
