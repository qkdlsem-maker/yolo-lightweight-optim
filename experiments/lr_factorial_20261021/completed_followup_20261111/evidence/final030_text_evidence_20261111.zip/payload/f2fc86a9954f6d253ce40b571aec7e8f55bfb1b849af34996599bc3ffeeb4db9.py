"""Actual filesystem mapping/rejection tests using the exact frozen84 roster.

All model/audit/receipt payloads in the separate fixture are fabricated. This
tests the60 mapping boundary, not tensor audits or the production collect().
"""
import copy
import hashlib
import json
import sys
from pathlib import Path

from continuation_artifact_receipts import encoded, loads
from test_factorial_after020_completion import Overlay
import factorial_training_model_bindings as m


def main(folder):
    folder.mkdir(exist_ok=False)
    f = Overlay(folder)
    source = Path(__file__).parent
    loc_raw = (source/'factorial_endpoint_location_plan.json').read_bytes()
    routes_raw = (source/'continuation_result_evidence_routes_after020.json').read_bytes()
    assert hashlib.sha256(loc_raw).hexdigest() == m.LOCATIONS_SHA
    assert hashlib.sha256(routes_raw).hexdigest() == m.ROUTES_SHA
    locations, routes = loads(loc_raw), loads(routes_raw)
    by_label = {r['label']: r for r in routes['routes']}
    bound, receipts, audits, seals = {}, {}, {}, {}

    def put(name, value):
        path = f.path(name)
        path.parent.mkdir(parents=True, exist_ok=True)
        data = value if isinstance(value, bytes) else encoded(value)
        path.write_bytes(data)
        bound[str(name)] = hashlib.sha256(data).hexdigest()

    for row in locations['endpoints']:
        if row['action'] != 'new_evaluation_after_admission':
            continue
        cp = row['checkpoint']['path']
        put(cp, ('synthetic model '+cp).encode())
        if row['stage'] == 'base':
            proof = row['completion_evidence_required']
            put(proof['aggregate_gate'], {'status': 'all_six_completed_bases_passed', 'protocol_sha256': m.PROTOCOL_SHA})
            put(proof['independent_audit'], {'status': 'passed', 'protocol_sha256': m.PROTOCOL_SHA,
                'run': {'model': row['architecture'], 'seed': row['pair_seed'], 'epochs': 100, 'checkpoint_sha256': bound[cp]}})
        else:
            label = row['path_label']
            route = by_label[label]
            raw = route['raw_epoch40']
            if raw not in bound:
                put(raw, ('synthetic raw state '+raw).encode())
            receipts.setdefault(label, {'label': label, 'protocol_sha256': m.PROTOCOL_SHA, 'bound_file_sha256': {raw: bound[raw]}})
            receipts[label]['bound_file_sha256'][cp] = bound[cp]
            audits.setdefault(label, {'schema': 'completed_continuation_file_audit_v1', 'status': 'completed_evidence_passed',
                'protocol_sha256': m.PROTOCOL_SHA, 'label': label, 'epochs': 40, 'pair_seed': row['pair_seed'],
                'arm': row['arm'], 'lr': row['lr'], 'bound_input_sha256': {raw: bound[raw]}, 'endpoints': {}})
            audits[label]['bound_input_sha256'][cp] = bound[cp]
            audits[label]['endpoints'][str(row['epoch'])] = {'role': row['role']}
    for label, receipt in receipts.items():
        route = by_label[label]
        put(route['receipt'], receipt)
        put(route['independent_audit'], audits[label])
        if route['required_wave_seal'] is not None:
            seal = seals.setdefault(route['required_wave_seal'], {'wave': route['wave'], 'all_worker_processes_exited': True, 'receipt_sha256': {}})
            seal['receipt_sha256'][route['receipt']] = bound[route['receipt']]
    for name, value in seals.items():
        put(name, value)
    baseline = copy.deepcopy(bound)

    def run(ls=locations, rs=routes, bindings=None):
        return m.bind_endpoints(f, ls, rs, baseline if bindings is None else bindings)

    accepted = run()
    assert len(accepted) == 60 and len([e for e in accepted if e['stage'] == 'base']) == 6
    first = next(r for r in locations['endpoints'] if r['action'].startswith('new') and r['stage'] == 'continuation')
    route = by_label[first['path_label']]
    cp = first['checkpoint']['path']
    base = next(r for r in locations['endpoints'] if r['action'].startswith('new') and r['stage'] == 'base')
    cases = []

    def corrupted(name, path, mutation, rebind=True):
        value = copy.deepcopy(loads(f.read(path)))
        mutation(value)
        data = encoded(value)
        b = dict(baseline)
        if rebind:
            b[path] = hashlib.sha256(data).hexdigest()
        cases.append((name, {path: data}, b, locations, routes))

    for key, value in [('label', 'wrong'), ('protocol_sha256', '0'*64)]:
        corrupted('receipt_'+key, route['receipt'], lambda x, k=key, v=value: x.__setitem__(k, v))
    corrupted('checkpoint_unbound_in_receipt', route['receipt'], lambda x: x['bound_file_sha256'].pop(cp))
    corrupted('checkpoint_hash_disagrees_with_receipt', route['receipt'], lambda x: x['bound_file_sha256'].__setitem__(cp, '1'*64))
    corrupted('raw40_unbound_in_receipt', route['receipt'], lambda x: x['bound_file_sha256'].pop(route['raw_epoch40']))
    for key, value in [('label', 'wrong'), ('status', 'failed'), ('schema', 'wrong'), ('protocol_sha256', '0'*64),
                       ('epochs', 20), ('pair_seed', 999), ('arm', 'wrong'), ('lr', 1.0)]:
        corrupted('audit_'+key, route['independent_audit'], lambda x, k=key, v=value: x.__setitem__(k, v))
    corrupted('audit_checkpoint_hash_changed', route['independent_audit'], lambda x: x['bound_input_sha256'].__setitem__(cp, '2'*64))
    corrupted('audit_raw40_hash_changed', route['independent_audit'], lambda x: x['bound_input_sha256'].__setitem__(route['raw_epoch40'], '2'*64))
    corrupted('audit_role_changed', route['independent_audit'], lambda x: x['endpoints']['20'].__setitem__('role', 'primary'))
    br = base['completion_evidence_required']
    corrupted('base_gate_failed', br['aggregate_gate'], lambda x: x.__setitem__('status', 'failed'))
    corrupted('base_audit_failed', br['independent_audit'], lambda x: x.__setitem__('status', 'failed'))
    for key, value in [('model', 'wrong'), ('seed', 999), ('epochs', 99), ('checkpoint_sha256', '3'*64)]:
        corrupted('base_run_'+key, br['independent_audit'], lambda x, k=key, v=value: x['run'].__setitem__(k, v))
    sealed = next(r for r in routes['routes'] if r['kind'] == 'after020_initial_wave')
    corrupted('seal_not_exited', sealed['required_wave_seal'], lambda x: x.__setitem__('all_worker_processes_exited', False))
    corrupted('seal_missing_receipt', sealed['required_wave_seal'], lambda x: x['receipt_sha256'].pop(sealed['receipt']))
    corrupted('seal_wrong_wave', sealed['required_wave_seal'], lambda x: x.__setitem__('wave', 99))
    cases.append(('changed_model_bytes', {cp: b'changed'}, dict(baseline), locations, routes))
    cases.append(('missing_checkpoint_file', {cp: None}, dict(baseline), locations, routes))
    cases.append(('changed_raw_bytes', {route['raw_epoch40']: b'changed'}, dict(baseline), locations, routes))
    b = dict(baseline); b.pop(cp)
    cases.append(('model_missing_from_authenticated_chain', {}, b, locations, routes))
    ls = copy.deepcopy(locations); ls['endpoints'][1]['endpoint_id'] = ls['endpoints'][0]['endpoint_id']
    cases.append(('duplicate_endpoint', {}, dict(baseline), ls, routes))
    ls = copy.deepcopy(locations); ls['endpoints'].pop()
    cases.append(('missing_endpoint', {}, dict(baseline), ls, routes))
    for key, value in [('role', 'primary'), ('epoch', 10)]:
        ls = copy.deepcopy(locations)
        next(x for x in ls['endpoints'] if x['endpoint_id'] == first['endpoint_id'])[key] = value
        cases.append(('invalid_'+key, {}, dict(baseline), ls, routes))
    rs = copy.deepcopy(routes); rs['routes'][0]['EMA_endpoints']['20'] = rs['routes'][0]['EMA_endpoints']['40']
    cases.append(('endpoint20_swapped_for40', {}, dict(baseline), locations, rs))
    rs = copy.deepcopy(routes); rs['routes'][0]['completion_claim'] = True
    cases.append(('lookup_claims_completion', {}, dict(baseline), locations, rs))
    for name, overlay, bindings, ls, rs in cases:
        f.overrides = overlay
        try:
            run(ls, rs, bindings)
        except (AssertionError, KeyError, TypeError):
            pass
        else:
            raise AssertionError('Invalid model mapping accepted: '+name)
    f.overrides = {}
    assert run() == accepted
    assert 'torch' not in sys.modules
    return {'status': 'passed', 'positive_endpoints': 60, 'positive_new_paths': 27, 'positive_bases': 6,
            'exact_frozen_location_and_updated_route_bytes_used': True, 'rejection_cases': len(cases),
            'cases': [c[0] for c in cases], 'fixture': str(folder.resolve()), 'new_GPU_work': False,
            'tested_sources_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(m.__file__), Path(__file__))},
            'limits': ['Synthetic model/receipt/audit bytes on actual Linux filesystem; authentic fixed84 endpoint and27 route plans.',
                       'Tests bind_endpoints mapping and independent evidence consistency; not production collect acceptance or numerical validation.']}


if __name__ == '__main__':
    print(json.dumps(main(Path(sys.argv[1]).resolve()), indent=2))
