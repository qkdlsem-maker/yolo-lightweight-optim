"""Read-only acceptance of both incident020 recoveries and the fixed remaining15.

This module loads no tensor and repeats no audit or GPU numerical experiment.
Every receipt is tied to actual closed sessions, the unchanged independent audit,
the copied pre-recovery state and immutable original sources/failure evidence.
"""
from pathlib import Path
from continuation_artifact_receipts import ROOT, PROTOCOL_SHA, Context, loads
from continuation_execution_runtime import (job_for_label, arguments, checkpoint_bindings,
    source_bindings, untouched_destination)
from continuation_preflight_runtime import verify_completed_bases, check_limits, process_command
from continuation_production_gate import verify_gate
from continuation_wave_evidence import audit_report, closed_attempt
from incident020_resources import resources
import incident020_evidence as recovered
import continuation_wave_evidence as original

HERE=ROOT/'continuation_after020'
REVIEW=recovered.REVIEW
MANIFEST=ROOT/'continuation_after020_sources.json'
PLAN=ROOT/'incident020_remaining15_plan.json'
PLAN_SHA='8145ec441c2b1f162560fc0552d5e52534d214d57f75a46838305ae875f42184'
RECOVERY_SOURCE_SHA='ad12d078c211ea84d7d11be45af25ed3629d20aa686639d5d48f7abfa93fb727'
guard=recovered.guard


def plan_for(context):
    old,design=original.plan_for(context)
    prepared=loads(context.files.read(str(PLAN),PLAN_SHA))
    assert prepared['protocol_sha256']==PROTOCOL_SHA and prepared['resume'] is False
    waves=old['waves'][5:]
    assert prepared['waves']==waves and [w['wave'] for w in waves]==list(range(6,14))
    assert sum(len(w['jobs']) for w in waves)==15
    assert len(waves[-1]['jobs'])==1 and waves[-1]['jobs'][0]['device']==0
    for w in waves:
        for item in w['jobs']:
            job,_=job_for_label(context,item['label'])
            assert item['args']==arguments(job,design,item['device']) and item['args']['resume'] is False
    return {'waves':waves},design


def sources(files):
    assert Path(__file__).resolve()==files.path(str(ROOT/'continuation_after020_evidence.py')).resolve()
    value=loads(files.read(str(MANIFEST)))
    assert value['schema']=='continuation_after020_sources_v1'
    assert value['status']=='frozen_after_CPU_integration_and_source_review'
    assert value['protocol_sha256']==PROTOCOL_SHA and value['plan_sha256']==PLAN_SHA
    bindings={str(ROOT/r['name']):r['sha256'] for r in value['files']}
    required={'continuation_after020_runner.py','continuation_after020_evidence.py',
        'test_continuation_after020_processes.py','test_continuation_after020_evidence.py',
        'continuation_after020_CPU.json','continuation_after020_review.json',
        'incident020_sources.json','incident020_resources.py','incident020_evidence.py',
        'incident020_remaining15_plan.json','incident020_dispatch_partition.json'}
    assert {str(ROOT/n) for n in required}<=bindings.keys() and len(bindings)==len(value['files'])
    assert bindings[str(recovered.MANIFEST)]==RECOVERY_SOURCE_SHA
    files.verify(bindings)
    proof=loads(files.read(str(ROOT/'continuation_after020_CPU.json')))
    assert proof['status']=='passed' and proof['processes']['real_subprocess_cases']>=13
    assert proof['evidence']['status']=='passed' and proof['evidence']['rejection_cases']>=10
    for n,h in proof['tested_sources_sha256'].items():assert bindings[str(ROOT/n)]==h
    review=loads(files.read(str(ROOT/'continuation_after020_review.json')))
    assert review['status']=='reviewed_for_initial_only_remaining15'
    assert review['scientific_sources_changed'] is False and review['automatic_retry'] is False
    assert review['both_readiness_and_completion_barriers'] is True
    assert review['CPU_proof_sha256']==files.sha(str(ROOT/'continuation_after020_CPU.json'))
    bindings[str(MANIFEST)]=files.sha(str(MANIFEST))
    return bindings


def latches(files,review):
    recovered.latches(files,review)
    assert not files.path(str(HERE/'FAILURE.json')).exists(),'New remaining15 failure'


def recovery_command(files,label=None):
    cmd=[str(files.project/'venv/bin/python'),'-u',str(ROOT/'incident020_runner.py')]
    return cmd if label is None else cmd+['--wave','5','--label',label]


def recovered_receipts(context,bases,source,gate):
    f=context.files;h=recovered.HERE;folder=h/'wave_05'
    assert f.sha(str(recovered.MANIFEST))==RECOVERY_SOURCE_SHA
    old_sources=recovered.sources(f)
    review=loads(f.read(str(REVIEW)));recovered.latches(f,review)
    a=loads(f.read(str(h/'authority.json')))
    for key,value in [('source',source),('bases',bases),('gate',gate),('new_sources',old_sources)]:
        assert a[key]==value,'Recovery authority differs: '+key
    for key in ('source','bases','new_sources','reuse'):f.verify(a[key])
    plan,_=recovered.plan_for(context);wave=plan['waves'][0]
    wa=loads(f.read(str(folder/'authority.json')));wh=f.sha(str(folder/'authority.json'))
    assert wa['wave']==wave and wa['global_authority_sha256']==f.sha(str(h/'authority.json'))
    parent_pid=wa['parent_pid'];rows,_=resources(f)
    parents=[n for n,r in rows.items() if r['label']=='incident020_parent_CPU']
    assert len(parents)==1
    parent_name=parents[0];parent=closed_attempt(f,parent_name,recovery_command(f))
    assert parent['pid']==parent_pid and parent['GPU_job'] is False
    release=loads(f.read(str(folder/'release.json')))
    assert release['status']=='both_CPU_admissions_passed_GPU_wave_released'
    assert release['wave']==5 and release['parent_pid']==parent_pid and release['authority_sha256']==wh
    assert release['GPU_uuid']==review['GPU_uuid']
    assert set(release['ready_sha256'])==set(recovered.LABELS)
    reservations=release['reservations'];assert len(reservations)==2
    assert {r['device'] for r in reservations.values()}=={0,1}
    reservation_rows=[];bound=dict(a['reuse'])
    for n,initial in reservations.items():
        row=closed_attempt(f,n,recovery_command(f));reservation_rows.append(row)
        assert row['GPU_job'] is True and row['reservation'] is True and row['pid']==parent_pid
        assert row['label']==f'incident020_wave_05_GPU{row["device"]}_reservation'
        assert {k:row[k] for k in initial if k!='status'}=={k:v for k,v in initial.items() if k!='status'}
        assert row['started_unix']<=release['released_unix']<=row['ended_unix']
        bound[n]=f.sha(n)
    audit_rows=[];worker_rows=[];receipt_hashes={}
    for item in wave['jobs']:
        label=item['label'];sub=folder/label;path=h/'receipts'/f'{label}.json'
        receipt=loads(f.read(str(path)))
        assert receipt['schema']=='incident020_recovered_continuation_receipt_v1'
        assert receipt['status']=='same_state_recovery_and_independent_CPU_audit_passed'
        assert receipt['protocol_sha256']==PROTOCOL_SHA and receipt['wave']==5
        for key in ('label','device','args'):assert receipt[key]==item[key]
        assert receipt['args']['resume'] is True
        ticket=loads(f.read(str(sub/'ticket.json')))
        ready=loads(f.read(str(sub/'ready.json'),release['ready_sha256'][label]))
        returned=loads(f.read(str(sub/'returned.json')))
        assert ticket['command']==recovery_command(f,label) and ticket['parent_pid']==parent_pid
        assert ready['parent_pid']==parent_pid and ready['args']==item['args'] and ready['device']==item['device']
        assert ready['label']==label and ready['status']=='CPU_contract_passed_waiting_for_wave_release'
        assert ready['CUDA_visible_devices_before_release']==''
        assert ready['contract']['mode']=='production' and ready['contract']['label']==label
        assert ready['contract']['protocol_sha256']==PROTOCOL_SHA
        for v in (ticket,ready,returned):assert v['pid']==ticket['pid'] and v['authority_sha256']==wh
        assert returned['status']=='trainer_returned_independent_audit_pending'
        assert returned['release_sha256']==f.sha(str(folder/'release.json'))
        assert ready['ready_unix']<=release['released_unix']<=returned['returned_unix']
        assert receipt['worker_attempt']==ticket['attempt']==ready['attempt']
        worker=closed_attempt(f,ticket['attempt'],ticket['command']);worker_rows.append(worker)
        assert worker['pid']==ticket['pid'] and worker['parent_pid']==parent_pid and worker['GPU_job'] is False
        assert worker['label']=='incident020_worker__'+label
        assert {k:worker[k] for k in ticket['registered'] if k!='status'}=={k:v for k,v in ticket['registered'].items() if k!='status'}
        assert worker['started_unix']<=ready['ready_unix']<=returned['returned_unix']<=worker['ended_unix']
        assert all(r['ended_unix']>=worker['ended_unix'] for r in reservation_rows)
        assert receipt['reservation_attempts']==sorted(reservations)
        audit_cmd=[str(f.project/'venv/bin/python'),'-u',str(ROOT/'continuation_completion_audit.py'),'--label',label]
        audit=closed_attempt(f,receipt['audit_attempt'],audit_cmd);audit_rows.append(audit)
        assert audit['GPU_job'] is False and audit['parent_pid']==parent_pid and audit['label']=='incident020_audit__'+label
        assert audit['started_unix']>=max(r['ended_unix'] for r in reservation_rows)
        job,design=job_for_label(context,label);inputs=checkpoint_bindings(context,job,design)
        assert wa['inputs'][label]==inputs and returned['complete_sha256']==f.sha(job['run_directory']+'/COMPLETE.json')
        report=loads(f.read(str(sub/'audit.json')))
        expected=dict(audit_report(context,job,report,bases,inputs))
        for key in ('source','bases','new_sources','reuse'):expected.update(a[key])
        for n in reservations:expected[n]=f.sha(n)
        for p in (folder/'authority.json',folder/'release.json',sub/'ticket.json',sub/'ready.json',sub/'returned.json',
                  sub/'worker.log',sub/'audit.json',sub/'audit.log',h/'authority.json',
                  Path(receipt['worker_attempt']),Path(receipt['audit_attempt'])):expected[str(p)]=f.sha(str(p))
        prior,copies=recovered.preserved_prior(f,label);expected.update(prior);expected.update(copies)
        capsule,_,_=recovered.capsule(f,label)
        assert receipt['capsule']==capsule['capsule'] and receipt['capsule_complete_sha256']==capsule['capsule_complete_sha256']
        assert receipt['unchanged_committed_prior_sha256']==prior
        assert receipt['bound_file_sha256']==expected,'Recovery receipt missing or changed required binding'
        assert receipt['actual_step_counts']==report['actual_step_counts']
        f.verify(expected);bound.update(expected);receipt_hashes[str(path)]=f.sha(str(path))
    assert len({r['pid'] for r in worker_rows})==2
    assert all(set(r['worker_PIDs'])=={w['pid'] for w in worker_rows} for r in reservation_rows)
    assert audit_rows[1]['started_unix']>=audit_rows[0]['ended_unix'],'Overlapping or reordered audits'
    seal=loads(f.read(str(folder/'SEALED.json')))
    assert seal['wave']==5 and seal['all_worker_processes_exited'] is True
    assert seal['receipt_sha256']==receipt_hashes and seal['release_sha256']==f.sha(str(folder/'release.json'))
    assert max(r['ended_unix'] for r in audit_rows)<=seal['sealed_unix']<=parent['ended_unix']
    complete=loads(f.read(str(h/'RECOVERY_RECEIPTS_COMPLETE.json')))
    assert complete['status']=='two_interrupted_paths_recovered_and_independently_audited'
    assert complete['protocol_sha256']==PROTOCOL_SHA and complete['receipt_sha256']==receipt_hashes
    assert complete['prior_reuse_sha256']==a['reuse'] and complete['whole_phase_complete'] is False
    assert complete['new_evaluation_diagnostics_and_documents_complete'] is False
    bound.update(receipt_hashes)
    for p in (folder/'SEALED.json',h/'RECOVERY_RECEIPTS_COMPLETE.json',Path(parent_name)):
        bound[str(p)]=f.sha(str(p))
    return bound


def authenticate(files):
    new=sources(files);review=loads(files.read(str(REVIEW)));latches(files,review);guard(files)
    rows,usage=resources(files);check_limits(usage);assert not usage['active_GPU_attempts']
    assert all('ended_unix' in r for r in rows.values() if r.get('label')!='continuation_after020_parent_CPU')
    for pid in (2678690,2944716,2944719,3005548,3005834,3005838):assert process_command(pid) is None
    context=Context(files.project);source=source_bindings(context);bases=verify_completed_bases(context)
    gate=verify_gate(files.project,context.manifest_hash);plan,design=plan_for(context)
    reuse=recovered_receipts(context,bases,source,gate)
    # These proofs bind original audits/receipts of eight waves' paths plus
    # the original control and incident018 MSE. Reauthenticate, never retrain.
    files.verify(review['completed_wave_proof_sha256'])
    for n,h in review['completed_wave_proof_sha256'].items():
        proof=loads(files.read(n,h));assert proof['all_worker_processes_exited'] is True
        assert proof['sequential_independent_audits'] is True and proof['new_GPU_work'] is False
        files.verify(proof['bound_sha256']);reuse.update(proof['bound_sha256']);reuse[n]=h
    reuse.update(original.recovered_receipt(context,bases,source,gate))
    from continuation_production_receipts import verify_receipt
    control,_=job_for_label(context,original.recovery.CONTROL)
    _,digest=verify_receipt(context,control['label'],{'execution_source_sha256':source,
        'completed_base_bindings':bases,'preflight_gate':gate,'checkpoint_bindings':checkpoint_bindings(context,control,design)})
    reuse[str(ROOT/'production_receipts'/f'{control["label"]}.json')]=digest
    for wave in plan['waves']:
        assert not files.path(str(original.HERE/f'wave_{wave["wave"]:02d}')).exists()
        for item in wave['jobs']:
            job,_=job_for_label(context,item['label']);untouched_destination(context,job)
            assert not files.path(str(HERE/'receipts'/f'{item["label"]}.json')).exists()
    reuse.update(review['known_failure_sha256']);reuse.update(review['supporting_evidence_sha256'])
    return context,plan,review,{'source':source,'bases':bases,'gate':gate,'new_sources':new,'reuse':reuse}
