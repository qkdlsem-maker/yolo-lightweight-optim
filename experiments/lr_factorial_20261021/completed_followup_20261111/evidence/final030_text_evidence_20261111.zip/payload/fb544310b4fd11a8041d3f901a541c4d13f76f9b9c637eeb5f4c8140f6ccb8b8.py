"""Bind the fixed101/404 completed bases and isolated validation fixture.

Read-only unless --publish is explicitly requested. No torch, CUDA, training,
cache construction or inference. Never manufacture an audit or readiness marker.
The public entry point always uses pinned anchors; tests call the internal pure
collector with explicitly fabricated anchors in a temporary project.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
from continuation_contract import ROOT, PROTOCOL_SHA, INTERPRETATION_SHA, REUSE_SHA
from continuation_fixture_roster import build_roster

OLD_ROOT = Path('review_20261017_independent')
OLD_PROTOCOL_SHA = 'c2de04c650b0a3553aef88712a8cc4b8521fe8dbdd4f8fee589766248da1c8ba'
# The old CPU audit was captured locally and published; import its exact bytes
# into the new phase without creating or replacing anything in the old root.
OLD_AUDIT = ROOT / 'historical_evidence/completed_base_states_20261019.json'
AUDIT_SOURCE = ROOT / 'audit_completed_base.py'
READY = ROOT / 'VALIDATION_VIEW_READY.json'
VIEW = ROOT / 'continuation_preflight/inputs'
ANCHORS = {
    (ROOT / 'protocol.json').as_posix(): PROTOCOL_SHA,
    (ROOT / 'protocol_interpretation.json').as_posix(): INTERPRETATION_SHA,
    (ROOT / 'historical_reuse_manifest.json').as_posix(): REUSE_SHA,
    OLD_AUDIT.as_posix(): '0229b92f72cc5bdc5b299ab212a395b6cf4362e0dc313ea06e93905c064e4e03',
    AUDIT_SOURCE.as_posix(): '2bdef65c7de87ec12e6533d211ce324381f15c9f398e998ae021c66a815542fc',
    READY.as_posix(): '8566bb527bc50ba6ef4af2954d167c8823cada263407d1b982ba8b29fcadb128',
    (ROOT / 'validation_view_sources.json').as_posix(): '73fe3efdfb69f707410c27fa26def750bacec3ff86afafcf6aee25078d9eba4f',
    (VIEW / 'view_manifest.json').as_posix(): '3e0c5f35476fb16c7f0a9d895422b51dc70be55489533e506984bef4dbecc414',
    (VIEW / 'data.yaml').as_posix(): 'fc2ee8ad1285e5491186fcf076dcb9e38f7d1c168abee5e477eb115c51cdd802',
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode()


class BoundFiles:
    def __init__(self, project):
        self.project = Path(project).resolve()
        self.files = {}
        self.source_image_links = {}

    def path(self, name):
        path = Path(name)
        assert '..' not in path.parts, 'Parent traversal'
        path = path if path.is_absolute() else self.project / path
        resolved = path.resolve()
        assert resolved.is_relative_to(self.project) and resolved != self.project, 'Outside project'
        # Preserve canonical relative bindings; disallow symlink aliases entirely.
        relative = path.relative_to(self.project)
        current = self.project
        for part in relative.parts:
            current /= part
            assert not current.is_symlink(), 'Symlink in evidence path'
        return path

    def key(self, name):
        return self.path(name).relative_to(self.project).as_posix()

    def bytes(self, name, expected=None):
        path = self.path(name)
        assert path.is_file(), f'Missing regular evidence file: {name}'
        data = path.read_bytes(); value = digest(data); key = self.key(name)
        if expected is not None:
            assert value == expected, f'Evidence hash mismatch: {key}'
        if key in self.files:
            assert self.files[key] == value, f'Evidence changed during collection: {key}'
        self.files[key] = value
        return data

    def bind(self, name, expected=None):
        return digest(self.bytes(name, expected))

    def read(self, name, expected=None):
        return json.loads(self.bytes(name, expected))

    def source_image(self, name, expected):
        """Bind the known legacy image target, keeping all other paths strict.

        Only final-component clean validation-image links to the same filename
        in data/raw/val/images are supported. The independent fixture itself
        must remain a regular copy. No link, target or image bytes are changed.
        """
        path = Path(name)
        assert '..' not in path.parts
        path = path if path.is_absolute() else self.project / path
        if not path.is_symlink():
            self.bind(path, expected)
            return self.path(path)
        assert path.parent == self.project / 'review_20260929_clean/clean_data/images/val'
        assert path.suffix == '.jpg' and path.name not in ('.', '..')
        self.path(path.parent)  # no directory-link chains
        target = self.project / 'data/raw/val/images' / path.name
        self.path(target)  # reject any target-link chain or outside-project path
        assert path.resolve(strict=True) == target
        text = os.readlink(path)
        self.bind(target, expected)
        assert path.is_symlink() and os.readlink(path) == text and path.resolve(strict=True) == target
        key = path.relative_to(self.project).as_posix()
        value = {'target': target.relative_to(self.project).as_posix(), 'link_text': text, 'sha256': expected}
        if key in self.source_image_links:
            assert self.source_image_links[key] == value, 'Source image link changed during collection'
        self.source_image_links[key] = value
        return target

    def verify(self):
        for name, value in list(self.source_image_links.items()):
            path = self.project / name
            assert path.is_symlink() and os.readlink(path) == value['link_text']
            assert path.resolve(strict=True) == self.project / value['target']
            self.source_image(name, value['sha256'])
        for name, value in list(self.files.items()):
            self.bind(name, value)


def missing_representative_evidence(project):
    root = Path(project)
    expected = [ROOT / group / f'{model}_seed404' / 'COMPLETE.json'
                for model in ('nano', 'large') for group in ('base_records',)]
    expected += [ROOT / 'completed_base_audits' / f'{model}_seed404.json' for model in ('nano', 'large')]
    return [p.as_posix() for p in expected if not (root / p).is_file()]


def _collect(bound, anchors):
    """Internal collector; fabricated anchors are used only in synthetic tests."""
    assert not bound.path(ROOT / 'BUDGET_STOP.json').exists(), 'Global budget stop is latched'
    assert not bound.path(ROOT / 'CONTINUATION_PREFLIGHT_BUDGET_STOP.json').exists(), 'Preflight budget stopped'
    for name, value in anchors.items():
        bound.bind(name, value)
    protocol = bound.read(ROOT / 'protocol.json')
    assert protocol['root'] == ROOT.as_posix()
    assert protocol['pair_seeds'] == [404, 505, 606] and protocol['all_pair_seeds'] == [101, 202, 303, 404, 505, 606]
    reuse = bound.read(ROOT / 'historical_reuse_manifest.json')
    old = bound.read(OLD_AUDIT)
    assert old['status'] == 'passed' and old['protocol_sha256'] == OLD_PROTOCOL_SHA
    assert old['base_stage'] == {'status': 'complete', 'jobs': 6}
    assert len(old['runs']) == 6 and {(x['model'], x['seed']) for x in old['runs']} == {
        (m, s) for m in ('nano', 'large') for s in (101, 202, 303)}
    checkpoints = {}
    for model in ('nano', 'large'):
        rows = [x for x in old['runs'] if x['model'] == model and x['seed'] == 101]
        assert len(rows) == 1
        row = rows[0]
        endpoint = [x for x in reuse['endpoints'] if x['stage'] == 'base' and
                    x['architecture'] == model and x['pair_seed'] == 101]
        assert len(endpoint) == 1
        path = OLD_ROOT / 'base' / f'{model}_seed101' / 'weights/last.pt'
        assert endpoint[0]['checkpoint']['path'] == path.as_posix()
        assert endpoint[0]['checkpoint']['sha256'] == row['checkpoint_sha256']
        assert row['epoch'] == 100 and row['raw_float32_changed_parameter_tensors'] > 0
        for key in ('fixed_dfl_preserved', 'finite_raw_ema_checkpoint_and_optimizer_tensors',
                    'checkpoint_matches_final_ema_at_saved_precision'):
            assert row[key] is True
        folder = OLD_ROOT / 'base_records' / f'{model}_seed101'
        for file, key in [('COMPLETE.json', 'complete_record_sha256'), ('resume_state.pt', 'resume_state_sha256'),
                          ('initial_parameters.json', 'initial_parameters_sha256')]:
            bound.bind(folder / file, row[key])
        bound.bind(path, row['checkpoint_sha256'])
        assert bound.path(path).stat().st_size == row['checkpoint_bytes']
        checkpoints[f'{model}_101'] = {'path': path.as_posix(), 'sha256': row['checkpoint_sha256'],
                                      'audit_sha256': bound.bind(OLD_AUDIT)}
    for model in ('nano', 'large'):
        folder = ROOT / 'base_records' / f'{model}_seed404'
        done = bound.read(folder / 'COMPLETE.json')  # Require completed bytes before any new raw-state access.
        assert (done['status'], done['model'], done['seed'], done['epochs']) == ('complete', model, 404, 100)
        assert done['finite_state'] is True and done['fixed_dfl_preserved'] is True
        assert type(done['changed_parameter_tensors']) is int and done['changed_parameter_tensors'] > 0
        proof_path = ROOT / 'completed_base_audits' / f'{model}_seed404.json'
        proof = bound.read(proof_path)
        assert proof['status'] == 'passed'
        assert proof['protocol_sha256'] == anchors[(ROOT / 'protocol.json').as_posix()]
        assert proof['script_sha256'] == anchors[AUDIT_SOURCE.as_posix()]
        row = proof['run']
        assert (row['model'], row['seed'], row['epochs']) == (model, 404, 100)
        assert row['checkpoint_sha256'] == done['checkpoint_sha256']
        assert row['actual_step_counts'] == done['actual_step_counts']
        counts = row['actual_step_counts']
        assert counts.keys() == {'attempted', 'applied', 'skipped'}
        assert all(type(v) is int and v >= 0 for v in counts.values())
        assert counts['attempted'] == counts['applied'] + counts['skipped'] and counts['applied'] > 0
        assert row['native_EMA_updates'] == counts['attempted']
        for key in ('fixed_dfl_preserved', 'checkpoint_matches_raw_EMA_at_saved_precision', 'finite_saved_tensors'):
            assert row[key] is True
        path = ROOT / 'base' / f'{model}_seed404' / 'weights/last.pt'
        inputs = {bound.key(k): v for k, v in proof['bound_input_sha256'].items()}
        assert len(inputs) == len(proof['bound_input_sha256']), 'Duplicate canonical audit bindings'
        required = [folder / 'COMPLETE.json', folder / 'config.json', folder / 'resume_state.pt',
                    folder / 'initial_parameters.json', path, AUDIT_SOURCE, ROOT / 'protocol.json']
        assert {bound.key(p) for p in required} <= inputs.keys()
        assert inputs[bound.key(path)] == row['checkpoint_sha256']
        for name, value in inputs.items():
            bound.bind(name, value)
        checkpoints[f'{model}_404'] = {'path': path.as_posix(), 'sha256': bound.bind(path, row['checkpoint_sha256']),
                                      'audit_sha256': bound.bind(proof_path)}
    ready = bound.read(READY)
    assert ready['status'] == 'isolated_validation_view_and_CPU_loader_verified_only'
    assert ready['CUDA_initialized'] is False and ready['inference_or_training_performed'] is False
    assert ready['fixture_boxes'] == 637
    manifest = bound.read(VIEW / 'view_manifest.json')
    assert manifest['train_images'] == 69863 and manifest['validation_images'] == 32
    assert len(manifest['entries']) == 32
    assert len({x['name'] for x in manifest['entries']}) == 32
    assert ready['view']['data_yaml_sha256'] == bound.bind(VIEW / 'data.yaml')
    assert ready['view']['view_manifest_sha256'] == bound.bind(VIEW / 'view_manifest.json')
    assert ready['source_manifest_sha256'] == bound.bind(ROOT / 'validation_view_sources.json')
    source_manifest = bound.read(ROOT / 'validation_view_sources.json')
    for source in source_manifest['files']:
        assert not Path(source['name']).is_absolute() and '..' not in Path(source['name']).parts
        bound.bind(ROOT / source['name'], source['sha256'])
    bound.bind(ready['native_cache_path'], ready['native_cache_sha256'])
    bound.bind(ready['loader_log'], ready['loader_log_sha256'])
    bound.bind(manifest['source_yaml'], protocol['data']['yaml_sha256'])
    for name, value in manifest['shared_cache_sha256'].items():
        assert value is not None, 'Prepared fixture must bind both existing shared caches'
        bound.bind(name, value)
    for entry in manifest['entries']:
        for role in ('image', 'label'):
            source, view = entry['source_' + role], entry['view_' + role]
            if role == 'image':
                source_path = bound.source_image(source, entry['image_sha256'])
            else:
                bound.bind(source, entry['label_sha256']); source_path = bound.path(source)
            bound.bind(view, entry[role + '_sha256'])
            assert bound.path(view).is_relative_to(bound.path(VIEW))
            assert not bound.path(view).samefile(source_path), 'Fixture must be an independent copy'
    data = {'path': (VIEW / 'data.yaml').as_posix(), 'sha256': bound.bind(VIEW / 'data.yaml'),
            'view_manifest_sha256': bound.bind(VIEW / 'view_manifest.json'),
            'train_images': 69863, 'validation_images': 32}
    roster = build_roster(checkpoints, data)
    bound.verify()
    evidence = {'schema': 'continuation_preflight_input_bindings_v1',
                'status': 'fixed_inputs_verified_only_not_GPU_ready',
                'protocol_sha256': anchors[(ROOT / 'protocol.json').as_posix()],
                'requests_sha256': digest(encoded(roster)), 'bound_input_sha256': dict(sorted(bound.files.items())),
                'original_validation_image_links_checked_at_collection': dict(sorted(bound.source_image_links.items())),
                'limits': ['Historical base AMP counts remain unavailable; old audit is reused, not rerun.',
                           'Representative101/404 bases suffice only for technical fixtures; all six new audits gate production.',
                           'This file never authorizes training or substitutes for actual GPU preflight.']}
    return roster, evidence


def collect_inputs(project):
    bound = BoundFiles(project)
    roster, evidence = _collect(bound, ANCHORS)
    # Bind these preparatory sources separately; the later full source manifest binds them again.
    for name in ('continuation_input_bindings.py', 'continuation_fixture_roster.py', 'continuation_contract.py'):
        bound.bind(ROOT / name)
    evidence['bound_input_sha256'] = dict(sorted(bound.files.items()))
    bound.verify()
    return roster, evidence, bound


def publish(path, value):
    """Exclusive hardlink publication; identical completed bytes may only be reused."""
    data = encoded(value)
    if path.exists():
        assert path.read_bytes() == data, 'Never overwrite an existing fixture binding'
        return
    pending = path.with_suffix(path.suffix + '.pending')
    if pending.exists():
        assert pending.read_bytes() == data, 'Preserve differing partial bindings'
    else:
        with pending.open('xb') as stream:
            stream.write(data); stream.flush(); os.fsync(stream.fileno())
    os.link(pending, path)
    pending.unlink()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--project', type=Path, default=Path.cwd())
    parser.add_argument('--publish', action='store_true')
    args = parser.parse_args()
    pending = missing_representative_evidence(args.project)
    if pending:
        print(json.dumps({'status': 'waiting_for_representative_completed_bases_and_audits',
                          'missing': pending, 'published': False}, indent=2))
        return
    roster, evidence, bound = collect_inputs(args.project)
    if args.publish:
        publish(bound.path(ROOT / 'continuation_preflight_inputs.json'), evidence)
        bound.verify()
        publish(bound.path(ROOT / 'continuation_preflight_requests.json'), roster)
    print(json.dumps({'status': evidence['status'], 'published': args.publish,
                      'bound_files': len(bound.files), 'requests_sha256': evidence['requests_sha256'],
                      'no_GPU_readiness_established': True}, indent=2))


if __name__ == '__main__':
    main()
