"""Real Linux processes; GPU/model/guard/artifact boundaries are synthetic."""
import copy
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

import factorial_evaluation_stage_runtime_v2 as w
from continuation_artifact_receipts import Files, ROOT, loads, encoded
from continuation_preflight_runtime import read_records, account, check_limits, process_command
from run_continuations import register_attempt
from continuation_wave_runner import finish


def worker(mode, output, device):
    if device == '-': device = ''
    assert os.environ['CUDA_VISIBLE_DEVICES'] == device
    assert os.environ['OMP_NUM_THREADS'] == os.environ['MKL_NUM_THREADS'] == '2'
    assert os.getsid(0) == os.getpgid(0) == os.getpid()
    path = Path(output)
    path.with_suffix('.started').write_text(str(os.getpid()))
    if mode == 'nonzero':
        time.sleep(.1)
        return 7
    if mode == 'descendant':
        p = subprocess.Popen([sys.executable, '-c', 'import time;time.sleep(20)'])
        path.with_suffix('.descendant').write_text(str(p.pid))
        return 0
    if mode == 'ignore_signal':
        signal.signal(signal.SIGTERM, signal.SIG_IGN)
    time.sleep(5 if mode in ('long', 'ignore_signal') else (.35 if mode == 'slow' else .03))
    path.write_bytes(b'synthetic artifact, not model output')
    return 0


def child(case, root):
    f = Files(Path(root))
    stage_folder = ROOT/'stage_fixture'
    phase = f.path(str(ROOT))
    phase.mkdir(parents=True)
    cmd = process_command(os.getpid())
    parent_name, parent = register_attempt(f, 'synthetic_evaluation_parent_CPU', cmd, None, pid=os.getpid())
    (phase/'parent.json').write_bytes(encoded({'attempt': parent_name, 'row': parent}))
    stage = 'independent_audit' if case == 'CPU_success' else 'native_bdd'
    count = 1 if case in ('CPU_success', 'GPU_single_success') else 2
    tasks = []
    for i in range(count):
        mode = 'slow' if i else 'fast'
        if case == 'worker_nonzero' and i == 0: mode = 'nonzero'
        if case == 'worker_nonzero' and i == 1: mode = 'long'
        if case == 'descendant_survives' and i == 0: mode = 'descendant'
        if case in ('wall_limit', 'external_SIGTERM', 'active_duplicate', 'guard_failure', 'resource_cap',
                    'parent_terminal', 'worker_terminal', 'unknown_allocation'): mode = 'long'
        if case == 'kill_escalation': mode = 'ignore_signal'
        output = str(ROOT/('artifact%d.bin' % i))
        tasks.append({'endpoint_id': 'endpoint%d' % i, 'device': None if stage == 'independent_audit' else i,
            'command': [sys.executable, '-B', '-u', str(Path(__file__).resolve()), '--worker', mode,
                        output, '-' if stage == 'independent_audit' else str(i)], 'environment': {}})
    if case == 'spawn_failure': tasks[-1]['command'] = ['/no/such/executable/synthetic']
    start = time.monotonic()
    if case == 'failure_marker_IO_error':
        original_put = w.put
        def faulty_publish(files, path, value):
            if Path(path).name == 'FAILURE.json':
                raise OSError('Synthetic failure-marker storage error')
            return original_put(files, path, value)
        w.put = faulty_publish
    duplicate_checked = False
    callback_fault = False
    usage = {'allocated_GPU_hours': 0, 'preflight_GPU_hours': 0, 'wall_days': 0,
             'phase_disk_GiB': 0, 'free_disk_GiB': 1000}

    def monitor(reservations):
        nonlocal duplicate_checked, callback_fault
        rows = read_records(f)
        active = {n: r for n, r in rows.items() if r['GPU_job'] and 'ended_unix' not in r}
        assert active == reservations
        assert not any(r.get('label', '').startswith('continuation_after020_') and 'ended_unix' not in r for r in rows.values())
        check_limits(usage)
        workers = [r for r in rows.values() if r['label'].startswith('factorial_eval_stage_') and not r['GPU_job']]
        launched = len(workers) == count and all('pid' in r for r in workers)
        ready = launched and all((phase/('artifact%d.started' % i)).exists() for i in range(count))
        if ready and not callback_fault:
            if case in ('guard_failure', 'failure_marker_IO_error'): raise RuntimeError('synthetic guard disappeared')
            if case == 'resource_cap':
                usage['allocated_GPU_hours'] = 220
                check_limits(usage)
            if case == 'unknown_allocation': raise RuntimeError('synthetic foreign GPU allocation')
            if case in ('parent_terminal', 'worker_terminal'):
                name = parent_name if case == 'parent_terminal' else next(n for n,r in rows.items() if r in workers)
                r = rows[name]
                f.path(name).write_bytes(encoded(dict(r, status='budget_stopped', returncode=1,
                    ended_unix=time.time(), stop_reason='synthetic independent guard terminal')))
                callback_fault = True
        if launched and case == 'active_duplicate' and not duplicate_checked:
            before = {str(p.relative_to(phase)): hashlib.sha256(p.read_bytes()).hexdigest()
                      for p in phase.rglob('*.json')}
            try:
                w.run_stage(f, stage_folder, stage, tasks, parent_name, parent, monitor,
                            lambda d: str(d), {'0': '0', '1': '1'}, verify, 1)
            except FileExistsError:
                pass
            else:
                raise AssertionError('Active duplicate admitted')
            after = {str(p.relative_to(phase)): hashlib.sha256(p.read_bytes()).hexdigest()
                     for p in phase.rglob('*.json')}
            assert before == after and not f.path(str(stage_folder/'FAILURE.json')).exists()
            duplicate_checked = True
        if case == 'early_cap':
            usage['free_disk_GiB'] = 149
            check_limits(usage)

    def verify(task):
        assert not any('ended_unix' not in r and r['GPU_job'] for r in read_records(f).values())
        i = int(task['endpoint_id'][-1])
        name = str(ROOT/('artifact%d.bin' % i))
        return {name: '0'*64 if case == 'artifact_reject' else f.sha(name)}

    wall = .8 if case in ('wall_limit', 'kill_escalation') else 10
    error = None
    try:
        value = w.run_stage(f, stage_folder, stage, tasks, parent_name, parent, monitor,
            lambda d: 'wrong' if case == 'GPU_identity_reject' else str(d), {'0':'0','1':'1'}, verify, wall)
        assert value['sessions_drained'] and not value['endpoint_independent_audit_and_seal_complete']
    except BaseException as caught:
        error = caught
    finish(f, parent_name, parent, 0 if error is None else 1, error)
    rows = read_records(f)
    assert all('ended_unix' in r for r in rows.values())
    for r in rows.values():
        if r.get('parent_pid') == os.getpid():
            assert r['GPU_job'] is False
            if 'pid' in r: assert process_command(r['pid']) is None
    for p in phase.glob('*.descendant'):
        ident = w.proc_identity(int(p.read_text()))
        assert ident is None or ident['state'] == 'Z'
    reservations = [r for r in rows.values() if r['GPU_job']]
    workers = [r for r in rows.values() if r['label'].startswith('factorial_eval_stage_') and not r['GPU_job']]
    for r in reservations:
        assert r['reservation'] is True and r['pid'] == os.getpid()
        assert all(r['started_unix'] <= c['started_unix'] <= c['ended_unix'] <= r['ended_unix'] for c in workers)
    u = account(rows, time.time(), 0, 1000*2**30)
    assert abs(u['allocated_GPU_hours'] - sum(r['ended_unix']-r['started_unix'] for r in reservations)/3600) < 1e-10
    if stage == 'independent_audit': assert not reservations
    if case in ('parent_terminal', 'worker_terminal'):
        assert any(r.get('stop_reason') == 'synthetic independent guard terminal' for r in rows.values())
    # Terminal duplicates preserve original stage evidence and shared attempts.
    before = {str(p.relative_to(phase)): hashlib.sha256(p.read_bytes()).hexdigest() for p in phase.rglob('*') if p.is_file()}
    try:
        w.run_stage(f, stage_folder, stage, tasks, parent_name, parent, monitor,
                    lambda d: str(d), {'0':'0','1':'1'}, verify, 1)
    except (AssertionError, FileExistsError):
        pass
    else:
        raise AssertionError('Terminal duplicate admitted')
    assert before == {str(p.relative_to(phase)): hashlib.sha256(p.read_bytes()).hexdigest() for p in phase.rglob('*') if p.is_file()}
    outcome = {'case': case, 'stage_succeeded': error is None, 'error': repr(error),
        'shared_attempts_closed': len(rows), 'charged_reservations': len(reservations),
        'GPU_hours_count_reservations_once': True, 'owned_sessions_drained': True,
        'terminal_duplicate_preserved': True, 'active_duplicate_checked': duplicate_checked,
        'elapsed': time.monotonic()-start, 'CUDA_or_Torch_imported': 'torch' in sys.modules}
    (phase/'CASE_RESULT.json').write_bytes(encoded(outcome))


def main(folder):
    folder = Path(folder).resolve()
    folder.mkdir()
    cases = ('GPU_pair_success', 'GPU_single_success', 'CPU_success', 'worker_nonzero',
        'spawn_failure', 'artifact_reject', 'GPU_identity_reject', 'guard_failure',
        'resource_cap', 'early_cap', 'parent_terminal', 'worker_terminal', 'unknown_allocation',
        'descendant_survives', 'wall_limit', 'external_SIGTERM', 'kill_escalation', 'active_duplicate', 'failure_marker_IO_error')
    outcomes = []
    for case in cases:
        root = folder/case
        cmd = [sys.executable, '-B', '-u', str(Path(__file__).resolve()), '--child', case, str(root)]
        with (folder/(case+'.log')).open('xb') as log:
            p = subprocess.Popen(cmd, stdout=log, stderr=subprocess.STDOUT,
                env=dict(os.environ, CUDA_VISIBLE_DEVICES=''), start_new_session=True)
            if case in ('external_SIGTERM', 'active_duplicate'):
                deadline = time.monotonic()+10
                while not (root/ROOT/'artifact1.started').exists() and p.poll() is None:
                    assert time.monotonic() < deadline
                    time.sleep(.02)
                time.sleep(.3)
                os.kill(p.pid, signal.SIGTERM)
            assert p.wait(timeout=20) == 0, 'Fixture failed: '+case
        assert process_command(p.pid) is None
        result = loads((root/ROOT/'CASE_RESULT.json').read_bytes())
        assert result['stage_succeeded'] == (case in cases[:3]), result
        assert result['CUDA_or_Torch_imported'] is False
        if case == 'active_duplicate': assert result['active_duplicate_checked']
        outcomes.append(result)
    result = {'status': 'passed', 'real_Linux_process_cases': len(outcomes), 'cases': outcomes,
        'GPU_work': False, 'production_training_or_evaluation_launched': False,
        'limits': 'Real process/session/signal/accounting tests; GPU idle/identity, global guard, completed-model admission and produced artifacts are synthetic. Not GPU numerical or actual evaluation admission evidence.',
        'source_sha256': {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in (Path(__file__), Path(w.__file__))}}
    (folder/'RESULT.json').write_bytes(encoded(result))
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    if len(sys.argv) == 5 and sys.argv[1] == '--worker':
        raise SystemExit(worker(*sys.argv[2:]))
    if len(sys.argv) == 4 and sys.argv[1] == '--child':
        child(sys.argv[2], sys.argv[3])
    else:
        assert len(sys.argv) == 2
        main(sys.argv[1])
