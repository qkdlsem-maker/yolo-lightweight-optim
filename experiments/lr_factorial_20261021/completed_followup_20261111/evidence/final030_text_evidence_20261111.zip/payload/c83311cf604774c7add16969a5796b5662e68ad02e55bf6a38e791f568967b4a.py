"""Explicitly join the closed 24-path certificate, two restarts, and final CWD."""
import copy,json,time
from pathlib import Path
from study_runtime import PROJECT,PHASE,AUX,OLD,HERE,read,file_sha,need,identity,members
from continuation_artifact_receipts import Files,loads,PROTOCOL_SHA
import factorial_evaluation_adapter as adapter

RESTARTS=('pair606_control_w0_lr0.001','pair606_mse_w0.3_lr0.001')
CWD='pair606_cwd_w0.3_lr0.001'


def merge(target,incoming):
    for name,digest in incoming.items():
        need(name not in target or target[name]==digest,'Conflicting completed evidence: '+name)
        target[name]=digest


def actual_route(row):
    result=copy.deepcopy(row);wave=row['wave']
    if wave is not None and 7<=wave<=11:
        namespace={7:'incident026_recovery',8:'continuation_after026',9:'continuation_after026',10:'continuation_after026',11:'incident027_recovery'}[wave]
        result.update(receipt=f'{PHASE}/{namespace}/receipts/{row["label"]}.json',independent_audit=f'{PHASE}/{namespace}/wave_{wave:02d}/{row["label"]}/audit.json',required_wave_seal=f'{PHASE}/{namespace}/wave_{wave:02d}/SEALED.json')
    return result


def reroute_checkpoint(path,label):
    if label not in RESTARTS:return path
    prefix=PHASE+'/continuations/'+label+'/'
    need(path.startswith(prefix),'Restart source checkpoint route')
    return PHASE+'/continuations_restart028/'+label+'/'+path[len(prefix):]


def routed_blueprint(original):
    value=copy.deepcopy(original);changed=[]
    for job in value['jobs']:
        matches=[label for label in RESTARTS if job['endpoint_id'] in (label+'_e20',label+'_e40')]
        if not matches:continue
        label=matches[0]
        for q in (job['native_bdd_request'],*job['prediction_requests'].values()):
            old=q['checkpoint']['path'];q['checkpoint']['path']=reroute_checkpoint(old,label)
            changed.append({'endpoint_id':job['endpoint_id'],'from':old,'to':q['checkpoint']['path']})
    need(len(changed)==12,'Exactly four restarted evaluation endpoints have three requests each')
    return value,changed


class PulsedFiles(Files):
    def __init__(self,project,pulse):super().__init__(project);self.pulse=pulse;self.next_pulse=time.monotonic()+5
    def tick(self):
        if time.monotonic()>=self.next_pulse:self.pulse();self.next_pulse=time.monotonic()+5
    def sha(self,name):self.tick();return super().sha(name)
    def read(self,name,expected=None):self.tick();return super().read(name,expected)


def collect(ctx):
    f=PulsedFiles(PROJECT,ctx.check);bound={};prior=read(OLD/'PRIOR_BINDINGS.json')
    cert_path=AUX+'/after027_initial_accept_attempt01/result.json'
    cert=loads(f.read(cert_path,prior['bindings'][cert_path]));merge(bound,{cert_path:prior['bindings'][cert_path]})
    need(cert['status']=='passed' and cert['completed_new_bases']==6 and cert['completed_new_continuations']==24,'Closed prior24 certificate')
    for key in ('bases','source','new_sources','reuse'):merge(bound,cert['authority'][key])
    f.verify(bound)
    # The new manifest pins closed rows/leases and the actual latest three audit publications.
    manifest=read(HERE/'SOURCE_MANIFEST.json');f.verify(manifest['prior_evidence'])
    routes=loads(f.read(PHASE+'/continuation_result_evidence_routes_after020.json'))['routes']
    audits={};proofs={}
    pair_seal_path=AUX+'/remedy028_20261109_v3/restart_attempt01/SEALED.json'
    pair_seal=loads(f.read(pair_seal_path,manifest['prior_evidence'][pair_seal_path]))
    cwd_seal_path=AUX+'/remaining029_20261110_v2/cwd_attempt01/SEALED.json'
    cwd_seal=loads(f.read(cwd_seal_path,manifest['prior_evidence'][cwd_seal_path]))
    need(pair_seal['status']=='both_cold_restarts_completed_and_independently_audited','Two restart completion')
    need(cwd_seal['status']=='original_remaining_CWD_completed_and_independently_audited','Final CWD completion')
    need(identity(cwd_seal['owner']['pid']) is None and not members(cwd_seal['token']),'Final CWD not closed')
    for old_route in routes:
        label=old_route['label'];route=actual_route(old_route)
        if label in RESTARTS:
            audit_path=AUX+'/remedy028_20261109_v3/restart_attempt01/'+label+'/AUDIT.json'
            expected=pair_seal['audit_sha256'][label]
            proof={'kind':'completed_disclosed_cold_restart','independent_audit':audit_path,'closed_seal':pair_seal_path}
        elif label==CWD:
            audit_path=AUX+'/remaining029_20261110_v2/cwd_attempt01/'+label+'/AUDIT.json';expected=cwd_seal['audit_sha256']
            proof={'kind':'original_final_CWD','independent_audit':audit_path,'closed_seal':cwd_seal_path}
        else:
            receipt_path=route['receipt'];receipt=loads(f.read(receipt_path,bound[receipt_path]))
            need(receipt['label']==label and receipt['protocol_sha256']==PROTOCOL_SHA,'Prior receipt scope')
            merge(bound,receipt['bound_file_sha256'])
            audit_path=route['independent_audit']
            if route['kind']=='incident018_recovery':merge(bound,{audit_path:receipt['audit_sha256']})
            expected=bound[audit_path]
            if route['required_wave_seal']:
                seal_path=route['required_wave_seal'];seal=loads(f.read(seal_path,bound[seal_path]))
                need(seal['receipt_sha256'][receipt_path]==bound[receipt_path] and seal['wave']==route['wave'],'Prior wave seal')
            proof={'kind':'prior24_closed_certificate','receipt':receipt_path,'independent_audit':audit_path,'certificate':cert_path}
        report=loads(f.read(audit_path,expected));merge(bound,{audit_path:expected})
        need(report['schema']=='completed_continuation_file_audit_v1' and report['status']=='completed_evidence_passed' and
            report['protocol_sha256']==PROTOCOL_SHA and report['label']==label and report['epochs']==40 and report['finite_saved_states'],'Completed path audit semantics')
        merge(bound,report['bound_input_sha256']);audits[label]=report;proofs[label]=proof
    need(len(audits)==27,'Missing continuation audit')
    f.verify(bound)
    locations=loads(f.read(PHASE+'/factorial_endpoint_location_plan.json'))
    endpoints=[]
    for row in locations['endpoints']:
        if row['action']!='new_evaluation_after_admission':continue
        cp=copy.deepcopy(row['checkpoint'])
        if row['stage']=='base':
            proof=row['completion_evidence_required'];audit=loads(f.read(proof['independent_audit'],bound[proof['independent_audit']]))
            need(audit['status']=='passed' and audit['protocol_sha256']==PROTOCOL_SHA,'Completed base audit')
            run=audit['run'];need((run['model'],run['seed'],run['epochs'])==(row['architecture'],row['pair_seed'],100),'Base endpoint identity')
            cp['sha256']=run['checkpoint_sha256'];need(bound[cp['path']]==cp['sha256'],'Base checkpoint binding')
        else:
            label=row['path_label'];report=audits[label];proof=proofs[label]
            need((report['pair_seed'],report['arm'],report['lr'])==(row['pair_seed'],row['arm'],row['lr']),'Continuation design identity')
            need(report['endpoints'][str(row['epoch'])]['role']==row['role'],'Fixed checkpoint role')
            cp['path']=reroute_checkpoint(cp['path'],label);cp['sha256']=report['bound_input_sha256'][cp['path']]
        need(f.sha(cp['path'])==cp['sha256'],'Actual checkpoint changed')
        endpoints.append(dict(endpoint_id=row['endpoint_id'],role=row['role'],stage=row['stage'],epoch=row['epoch'],checkpoint=cp,completion_evidence=proof))
    need(len(endpoints)==60 and len({x['checkpoint']['path'] for x in endpoints})==60,'Fixed60 checkpoint roster')
    blueprint=loads(f.read(PHASE+'/factorial_evaluation_request_blueprint.json',adapter.BLUEPRINT_SHA))
    routed,delta=routed_blueprint(blueprint);prepared=copy.deepcopy(routed)
    for job,endpoint in zip(prepared['jobs'],endpoints):
        need(job['endpoint_id']==endpoint['endpoint_id'],'Fixed evaluation order')
        for q in (job['native_bdd_request'],*job['prediction_requests'].values()):
            need(q['checkpoint']['path']==endpoint['checkpoint']['path'],'Explicit checkpoint routing');q['checkpoint']=copy.deepcopy(endpoint['checkpoint'])
        job['completion_evidence_required']=copy.deepcopy(endpoint['completion_evidence'])
    prepared['status']='completed_model_hashes_bound_current_data_and_execution_admission_pending'
    accepted=dict(schema='factorial_training_model_bindings_v1',status='completed_training_model_bytes_bound_not_evaluation_admission',
        protocol_sha256=PROTOCOL_SHA,completed_new_bases=6,completed_new_continuations=27,new_evaluation_endpoints=endpoints,
        model_bound_request_blueprint=prepared,bound_file_sha256=bound,explicit_restart_path_changes=delta,
        model_loaded=False,model_audit_repeated=False,new_GPU_work=False,evaluation_admitted=False)
    return accepted,routed,audits
