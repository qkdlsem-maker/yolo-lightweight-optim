"""Actual Linux paired process workflow; evaluator/audit/guard boundaries synthetic."""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import time

import factorial_evaluation_adapter as a
import factorial_evaluation_workflow as w
from test_factorial_evaluation_adapter import synthetic_acceptance
from continuation_artifact_receipts import Files,ROOT,loads,encoded
from continuation_preflight_runtime import read_records,process_command
from continuation_wave_runner import finish,put
from run_continuations import register_attempt


def worker(plan_name,eid,step,case):
    plan=loads(Path(plan_name).read_bytes());job=next(j for j in plan['jobs'] if j['endpoint_id']==eid)
    f=Files(Path.cwd());audit=step=='independent_audit';gpu=step in ('native_bdd','bdd_predictions','kitti_predictions')
    assert os.environ['CUDA_VISIBLE_DEVICES']==(str(job['lane']) if gpu else '')
    assert os.getsid(0)==os.getpgid(0)==os.getpid()
    # Deliberate lightweight evaluator boundary: no model, image, tensors,
    # predictions, scoring or original auditor is executed by these children.
    if case=='worker_failure' and step=='kitti_predictions' and job['lane']==0:return 7
    if audit:
        ep=job['output']+'/ENDPOINT_COMPLETE.json'
        result={'status':'passed','endpoint_id':eid,'plan_sha256':f.sha(plan_name),
            'endpoint_complete_sha256':f.sha(ep),'audit_source_sha256':a.AUDITOR_SHA,
            'native_bdd':{'synthetic':True},'bdd_common':{'synthetic':True},'kitti_common':{'synthetic':True},
            'native_kitti':{'synthetic':True},'scope':'Synthetic audit boundary, not numerical validation'}
        if case=='audit_reject' and job['lane']==1:result['status']='failed'
        if case=='audit_plan_mismatch':result['plan_sha256']='0'*64
        if case=='audit_source_mismatch':result['audit_source_sha256']='0'*64
        if case=='audit_endpoint_mismatch':result['endpoint_complete_sha256']='0'*64
        put(f,Path(plan['output_root'])/'audits'/(eid+'.json'),result)
    else:
        qp=a.request_path(plan,job,step);q=loads(f.read(qp))
        if step.endswith('_predictions'):
            m={'schema':'prediction_archive_v1','bindings':{'endpoint_id':eid,'dataset_id':q['dataset_id'],
                'checkpoint_sha256':q['checkpoint']['sha256'],'protocol_sha256':a.PROTOCOL_SHA,
                'source_sha256':dict(q['source_sha256'],frozen_request=a.digest(a.canonical(q)))}}
            c={'schema':'prediction_archive_complete_v1'}
        else:m={'synthetic_stage':step,'request':q};c={'synthetic_complete':True}
        m['fixture']={'stage':step,'request_sha256':f.sha(qp),'endpoint_id':eid,'device':job['lane'] if gpu else None}
        out=Path(job['output'])/step;put(f,out/'MANIFEST.json',m)
        c['manifest_sha256']=f.sha(str(out/'MANIFEST.json'));put(f,out/'COMPLETE.json',c)
    assert 'torch' not in sys.modules
    return 0


class FixtureAdapter:
    STEPS=a.STEPS
    canonical=staticmethod(a.canonical)
    request_path=staticmethod(a.request_path)
    request=staticmethod(a.request)
    def __init__(self,plan_name,case):self.plan_name,self.case=plan_name,case
    def task(self,f,plan,job,stage):
        t=a.task(f,plan,job,stage)
        t['command']=[sys.executable,'-B','-u',str(Path(__file__).resolve()),'--worker',self.plan_name,job['endpoint_id'],stage,self.case]
        return t
    def audit_task(self,f,plan,job,ref):
        t=a.audit_task(f,plan,job,ref)
        t['command']=[sys.executable,'-B','-u',str(Path(__file__).resolve()),'--worker',self.plan_name,job['endpoint_id'],'independent_audit',self.case]
        return t
    def verify_step(self,f,plan,job,stage,qh,uuid,contract):
        q=a.request_path(plan,job,stage);mp=job['output']+'/'+stage+'/MANIFEST.json';cp=job['output']+'/'+stage+'/COMPLETE.json'
        assert f.sha(q)==qh
        m=loads(f.read(mp));c=loads(f.read(cp));assert c['manifest_sha256']==f.sha(mp)
        assert m['fixture']['endpoint_id']==job['endpoint_id'] and m['fixture']['stage']==stage and m['fixture']['request_sha256']==qh
        if self.case=='artifact_reject' and stage=='bdd_common':raise AssertionError('Injected output rejection')
        return {q:qh,mp:f.sha(mp),cp:f.sha(cp)}


def child(case,root):
    root=Path(root).resolve();root.mkdir(exist_ok=False);f=Files(root)
    source=Path(__file__).resolve().parent
    raw=(source/'factorial_evaluation_request_blueprint.json').read_bytes();assert a.digest(raw)==a.BLUEPRINT_SHA
    bp=loads(raw);plan=a.plan_from_bound(synthetic_acceptance(bp),bp,
        {'path':str(ROOT/'factorial_training_acceptance.json'),'sha256':'1'*64})
    plan_name=str(ROOT/'fixture_plan.json');put(f,Path(plan_name),plan);ref={'path':plan_name,'sha256':f.sha(plan_name)}
    parent_name,parent=register_attempt(f,'synthetic_evaluation_workflow_CPU',process_command(os.getpid()),None,pid=os.getpid())
    uuids={'0':'GPU-fixture0','1':'GPU-fixture1'};adapter=FixtureAdapter(plan_name,case)
    monitors=0
    def monitor(reservations):
        nonlocal monitors
        monitors+=1;rows=read_records(f)
        active={n:r for n,r in rows.items() if r['GPU_job'] and 'ended_unix' not in r}
        assert active==reservations
        children=[r for r in rows.values() if r['label'].startswith('factorial_eval_stage_') and not r['GPU_job'] and 'ended_unix' not in r]
        if reservations:assert len(children)<=2
        else:assert len(children)<=1
        if case=='between_wave_guard' and f.path(str(ROOT/'factorial_evaluation/workflow/wave_01/SEALED.json')).exists():
            raise AssertionError('Synthetic global cap before second pair')
    result=None;error=None
    try:result=w.run_all(f,plan,ref,parent_name,parent,{},monitor,lambda d:uuids[str(d)],uuids,
                        stage_wall_seconds=30,adapter=adapter)
    except BaseException as exc:error=exc
    terminal=finish(f,parent_name,parent,0 if error is None else 1,error)
    rows=read_records(f);assert all('ended_unix' in r for r in rows.values())
    assert all(r.get('pid')==os.getpid() or process_command(r.get('pid',0)) is None for r in rows.values())
    output=Path(plan['output_root']);marker=f.path(str(output/'EVALUATION_RECEIPTS_COMPLETE.json'))
    seals=list(f.path(str(output/'workflow')).glob('wave_*/SEALED.json'))
    if case=='success60':
        assert error is None,repr(error)
        assert len(seals)==30 and len(result['receipt_sha256'])==60 and len(result['stage_receipt_sha256'])==330
        gpu=[r for r in rows.values() if r['GPU_job']];children=[r for r in rows.values() if r['label'].startswith('factorial_eval_stage_') and not r['GPU_job']]
        assert len(gpu)==180 and len(children)==420
        assert sum(r['stage']=='independent_audit' for r in children)==60
        assert all(r['status']=='completed' and r['returncode']==0 for r in rows.values())
        for wave in range(1,31):
            wd=output/'workflow'/('wave_%02d'%wave);jobs=plan['jobs'][(wave-1)*2:wave*2]
            last=loads(f.read(str(wd/'authority.json')))['started_unix']
            for stage,_,is_gpu in a.STEPS:
                dirs=[wd/stage] if is_gpu else [wd/(stage+'_'+j['endpoint_id']) for j in jobs]
                for directory in dirs:
                    sr=loads(f.read(str(directory/'STAGE_COMPLETE.json')))
                    workers=[rows[n] for n in sr['worker_attempt_sha256']]
                    reservations=[rows[n] for n in sr['reservation_attempt_sha256']]
                    assert min(r['started_unix'] for r in workers)>=last
                    if is_gpu:
                        assert len(reservations)==2
                        assert min(r['ended_unix'] for r in reservations)>=max(r['ended_unix'] for r in workers)
                        assert all(r['GPU_job'] is False and r['GPU_accounting']=='parent_stage_reservations' for r in workers)
                    else:assert not reservations and len(workers)==1
                    last=sr['ended_unix']
            for job in jobs:
                sr=loads(f.read(str(wd/('independent_audit_'+job['endpoint_id'])/'STAGE_COMPLETE.json')))
                ar=rows[next(iter(sr['worker_attempt_sha256']))]
                assert ar['started_unix']>=last and not sr['reservation_attempt_sha256'];last=sr['ended_unix']
            seal=loads(f.read(str(wd/'SEALED.json')));assert seal['sealed_unix']>=last
            if wave<30:assert loads(f.read(str(output/'workflow'/('wave_%02d'%(wave+1))/'authority.json')))['started_unix']>=seal['sealed_unix']
        before={str(p.relative_to(root)):a.digest(p.read_bytes()) for p in f.path(str(output)).rglob('*') if p.is_file()}
        # Re-entry refuses the existing output root before any destructive work.
        try:w.run_all(f,plan,ref,parent_name,parent,{},monitor,lambda d:uuids[str(d)],uuids,adapter=adapter)
        except FileExistsError:pass
        else:raise AssertionError('Duplicate workflow accepted')
        assert before=={str(p.relative_to(root)):a.digest(p.read_bytes()) for p in f.path(str(output)).rglob('*') if p.is_file()}
        assert not f.path(str(output/'FAILURE.json')).exists()
    else:
        assert error is not None and not marker.exists() and f.path(str(output/'FAILURE.json')).exists()
        assert len(seals)==(1 if case=='between_wave_guard' else 0)
        assert not f.path(str(output/'workflow/wave_02')).exists()
        receipts=list(f.path(str(output/'receipts')).glob('*.json')) if f.path(str(output/'receipts')).exists() else []
        if case=='audit_reject':assert len(receipts)==1
        elif case=='between_wave_guard':assert len(receipts)==2
        else:assert not receipts
        before={str(p.relative_to(root)):a.digest(p.read_bytes()) for p in f.path(str(output)).rglob('*') if p.is_file()}
        try:w.run_all(f,plan,ref,parent_name,parent,{},lambda _:None,lambda d:uuids[str(d)],uuids,adapter=adapter)
        except FileExistsError:pass
        else:raise AssertionError('Failed workflow retried')
        assert before=={str(p.relative_to(root)):a.digest(p.read_bytes()) for p in f.path(str(output)).rglob('*') if p.is_file()}
    assert 'torch' not in sys.modules
    put(f,ROOT/'TEST_RESULT.json',{'case':case,'status':'passed','shared_fixture_attempts':len(rows),
        'monitors':monitors,'all_attempts_closed':True,'all_children_exited':True,'seals':len(seals),
        'parent_returncode':terminal['returncode'],'error':repr(error) if error else None,
        'simulated_GPU_reservations_only_in_fixture':True})


def main(folder):
    folder.mkdir(exist_ok=False)
    cases=['success60','worker_failure','artifact_reject','audit_reject','audit_plan_mismatch',
           'audit_source_mismatch','audit_endpoint_mismatch','between_wave_guard']
    results=[];started=time.time()
    for case in cases:
        with (folder/(case+'.log')).open('xb') as log:
            proc=subprocess.run([sys.executable,'-B','-u',str(Path(__file__).resolve()),'--child',case,str(folder/case)],
                stdout=log,stderr=subprocess.STDOUT,timeout=220,env=dict(os.environ,CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1'))
        assert proc.returncode==0,case
        results.append(loads((folder/case/ROOT/'TEST_RESULT.json').read_bytes()))
    report={'status':'passed','real_Linux_process_cases':len(cases),'full_success_new_endpoints':60,
        'full_success_paired_waves':30,'full_success_actual_child_processes':420,
        'simulated_GPU_reservations_in_separate_fixture':180,'full_success_stage_receipts':330,
        'test_results':results,'wall_seconds':time.time()-started,'GPU_work':False,'production_evaluation_launched':False,
        'source_sha256':{p.name:a.digest(p.read_bytes()) for p in (Path(w.__file__),Path(__file__),Path(a.__file__))},
        'limits':['Real Linux child/session/ledger/ordering/receipt/seal workflow. All evaluator, model, GPU UUID, numerical-audit and global-monitor boundaries synthetic.',
            'Actual immutable blueprint used with synthetic model hashes. Original request builders are used; evaluator commands and artifact-metadata verifier are replaced by the explicit fixture adapter.',
            'Separate adapter111-rejection tests cover real command construction/output metadata. This process proof is not GPU numerical validation or actual60 evaluation completion.',
            'Production admission, runtime/source guard and durable parent launcher remain pending; no automatic launch.']}
    (folder/'RESULT.json').write_bytes(encoded(report));print(json.dumps(report,indent=2))


if __name__=='__main__':
    if sys.argv[1]=='--worker':sys.exit(worker(*sys.argv[2:]))
    elif sys.argv[1]=='--child':child(*sys.argv[2:])
    else:main(Path(sys.argv[1]).resolve())
