"""One fixed sequential dispatch; no models, GPU context, retry or chat schedule.

Each child owns its scientific lease, independent guard, scanner and complete
attempt ledger. This control-plane process can only advance after that child's
actual exit and independent consumption of its immutable completion evidence.
"""
import os,subprocess,sys,time
from pathlib import Path
from study_runtime import PROJECT,HERE,source_check,consume,publish,read,need,file_sha,identity,members,WINDOW_END

STAGES=('evaluation','gradient','metrics','analysis')


def run(expected):
    source_check(expected);consume('CPU_integration',expected,full=True)
    folder=HERE/'fixed_final_dispatch';folder.mkdir(exist_ok=False)
    need(all(not (HERE/(stage+'_attempt01')).exists() for stage in STAGES),'Existing scientific attempt; no re-dispatch')
    started=dict(owner=identity(os.getpid()),manifest_sha256=expected,stages=STAGES,unix=time.time(),
        scope='dispatch_control_plane_only',model_loads=0,GPU_work=False,automatic_retry=False,wall_end_unix=WINDOW_END)
    publish(folder/'STARTED.json',started);consumed={};child=None;current=None
    try:
        for stage in STAGES:
            source_check(expected);need(time.time()<WINDOW_END-180,'Original global deadline')
            need(not (HERE/(stage+'_attempt01')).exists(),'Stage already exists; no retry')
            command=[sys.executable,'-B',str(HERE/(stage+'_run.py')),expected]
            publish(folder/(stage+'_INTENT.json'),dict(command=command,unix=time.time(),previous_consumptions=dict(consumed),automatic_retry=False))
            environment=dict(os.environ,CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1',PYTHONUNBUFFERED='1')
            # No ownership token or lease from another stage crosses this boundary.
            for key in ('INCIDENT028_OWNED_TOKEN','INCIDENT028_ROOT_TOKEN','INCIDENT028_ROOT_LEASE_FD'):
                need(key not in environment,'Dispatcher inherited another execution owner')
            with (folder/(stage+'.stdout')).open('xb',buffering=0) as out,(folder/(stage+'.stderr')).open('xb',buffering=0) as err:
                child=subprocess.Popen(command,cwd=PROJECT,env=environment,stdin=subprocess.DEVNULL,stdout=out,stderr=err,start_new_session=True,close_fds=True)
                current=dict(pid=child.pid,identity=identity(child.pid),command=command,unix=time.time())
                need(current['identity'] is not None,'Stage parent identity unavailable')
                publish(folder/(stage+'_DISPATCHED.json'),current)
                # The admitted child owns the absolute deadline and cleanup.
                # A controller interruption cannot dispatch a following stage.
                returncode=child.wait()
            publish(folder/(stage+'_EXIT.json'),dict(returncode=returncode,pid=child.pid,observed_unix=time.time()))
            need(returncode==0,'Scientific stage failed; automatic retry forbidden')
            sealed=consume(stage,expected,full=True)
            need(sealed['owner']['pid']==current['pid'] and identity(current['pid']) is None,'Closed stage owner differs')
            source_check(expected)
            proof=dict(status='actual_exit_and_independent_full_consumption_passed',stage=stage,returncode=returncode,
                seal_sha256=file_sha(HERE/(stage+'_attempt01')/'SEALED.json'),manifest_sha256=expected,unix=time.time())
            publish(folder/(stage+'_CONSUMED.json'),proof);consumed[stage]=file_sha(folder/(stage+'_CONSUMED.json'))
        publish(folder/'COMPLETE.json',dict(status='all_fixed_scientific_stages_exited_and_independently_consumed',
            consumed=consumed,whole_research_complete=False,remaining='local final report, figures, document review and delivery',unix=time.time()))
    except BaseException as error:
        publish(folder/'FAILURE.json',dict(error=repr(error),current=current,consumed=consumed,
            child_returncode=None if child is None else child.poll(),automatic_retry=False,unix=time.time()))
        raise


if __name__=='__main__':run(sys.argv[1])
