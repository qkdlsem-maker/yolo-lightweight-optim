"""Bounded sequential study stages with common ownership and retained evidence."""
import copy,json,os,signal,sys,threading,time,uuid
from contextlib import contextmanager
from pathlib import Path
HERE=Path(__file__).resolve().parent
PROJECT=Path('/home/futurenetworklab/choihyerim1129/yolo_lightweight_optim')
PHASE='review_20261021_lr_factorial';AUX=PHASE+'_auxiliary026'
OLD=PROJECT/AUX/'remedy028_20261109_v3'
sys.path.insert(0,str(OLD));sys.path.insert(1,str(PROJECT/PHASE))
from retained_io import publish,read,update,Journal,read_journal
from owned_runtime import Owner,identity,members,same,cpu_seconds
from research_admission import file_sha,need,rows,usage,limits,gpu_state,verify_history,WINDOW_END
from fresh_monitor import Client
from restart_runner import watch,alive_context,stop_signal,failure
from validation_cases import wait_file
from incident026_execution_lease import Lease,process

# These tested kernels were preserved in immutable history, never deployed at
# the phase root. Import those exact bytes without copying or modifying them.
ARCHIVED_SOURCES={
    PHASE+'/prepared_history/factorial_contrasts_20261022_0838/factorial_contrasts.py':'d92db30b09f3b9d96e9b6a2a59d7ffb9c53bb09a37f91f28235bf183094a770c',
    PHASE+'/prepared_history/gradient_core_preparation_20261021_2228/gradient_probe_core.py':'81959ff2ecf19aebe2bdde266ae26ab1f21193eb2413605a55ef9f9e1c92ab74',
    PHASE+'/prepared_history/gradient_objectives_preparation_20261022_0535/gradient_probe_objectives.py':'61f70d96e36e805bdc4777b18c79538852842530cca3d47444c6e9910813e0b9'}
for archived,digest in ARCHIVED_SOURCES.items():
    need(file_sha(PROJECT/archived)==digest,'Archived scientific kernel changed: '+archived)
    sys.path.insert(2,str((PROJECT/archived).parent))


@contextmanager
def defer_cleanup_SIGTERM():
    """A guard stop must not interrupt the already requested bounded child drain.

    The first failure/stop still ends work. SIGALRM and the original absolute
    deadline remain active, and this scope never permits another dispatch.
    """
    previous=signal.getsignal(signal.SIGTERM);received=[]
    signal.signal(signal.SIGTERM,lambda number,frame:received.append(number))
    try:yield received
    finally:signal.signal(signal.SIGTERM,previous)


def source_check(expected):
    from validation_stage import source_check as inherited_source_check
    inherited_source_check('6ff0ce152fe24e3ae6c3f96559006eaef3081da107a60726db5a3549942e1748')
    need(Path.cwd()==PROJECT,'Study project route')
    need(file_sha(HERE/'SOURCE_MANIFEST.json')==expected,'Study source manifest')
    manifest=read(HERE/'SOURCE_MANIFEST.json')
    need(HERE==PROJECT/manifest['remote_folder'],'Study bundle route')
    for name,digest in manifest['files'].items():
        need(Path(name).name==name and file_sha(HERE/name)==digest,'Study source changed: '+name)
    for name,digest in manifest['scientific_sources'].items():
        need(file_sha(PROJECT/name)==digest,'Frozen scientific source changed: '+name)
    for name,digest in manifest['prior_evidence'].items():
        need(file_sha(PROJECT/name)==digest,'Prior completed evidence changed: '+name)
    return manifest


def consume(name,expected,full=False):
    folder=HERE/(name+'_attempt01');value=read(folder/'SEALED.json')
    need(not (folder/'FAILURE.json').exists() and not (folder/'BUDGET_STOP.json').exists(),'Prior study stage failed')
    need(value['status']=='completed' and value['stage']==name and value['manifest_sha256']==expected,'Prior study seal binding')
    need(identity(value['owner']['pid']) is None and not members(value['token']),'Prior study still owned')
    need(value['terminal']['absent'] and not value['terminal']['errors'],'Prior study terminal errors')
    if name=='CPU_integration':
        from cpu_integration import CASES
        need(value['result']['status']=='all_native_operational_cases_passed' and value['result']['case_count']==len(CASES) and set(value['result']['cases'])==set(CASES),'Native operational case roster')
        need(value['result']['model_loads']==0 and value['result']['GPU_work'] is False and
             value['wall_seconds']<1800 and value['CPU_seconds']<1800 and not value['scientific_GPU_work'],'CPU integration scope/cap')
    for path,digest in value['rows'].items():
        row=read(PROJECT/path)
        need(file_sha(PROJECT/path)==digest and row.get('ended_unix') and identity(row['pid']) is None,'Prior study row not closed')
        allowed=value['result'].get('expected_failure_rows',{}) if name=='CPU_integration' else {}
        need(row['status']=='completed' and row['returncode']==0 or allowed.get(path)==digest,'Unexpected failed prior study row')
    closure=read(PROJECT/value['closed_lease'])
    need(file_sha(PROJECT/value['closed_lease'])==value['closed_lease_sha256'] and closure['status']=='completed' and closure['all_registered_sessions_drained'],'Prior study lease')
    if full:
        for path,binding in value['artifacts'].items():
            need((PROJECT/path).stat().st_size==binding['bytes'] and file_sha(PROJECT/path)==binding['sha256'],'Study operational artifact changed')
        verify_journals(folder)
    return value


def verify_journals(folder):
    from segmented_journal import verify
    from fresh_monitor import LANES
    index,last=verify(folder/'service.jsonl')
    need(last['kind']=='service_terminal' and set(last['value']['retired'])==set(LANES) and not last['value']['live_threads'] and last['value']['failure'] is None,'Study scanner terminal evidence')
    for name,kind in (('owner.jsonl','terminal'),('guard.jsonl','guard_terminal')):
        events,binding=read_journal(folder/name,128*1024*1024,300000)
        need(events[-1]['kind']==kind,'Study journal terminal event')
        if kind=='terminal':need(events[-1]['value']['absent'] and not events[-1]['value']['errors'],'Study owner terminal event')
        else:need(events[-1]['value']['failure'] is None,'Study guard terminal event')
    return index


class Study:
    def __init__(self,name,expected,wall_seconds,GPU_hours_limit,validation=False,CPU_hours_limit=None):
        need(name in ('CPU_integration','evaluation','gradient','metrics','analysis'),'Unexpected study stage')
        self.name,self.expected,self.validation=name,expected,validation
        self.began=time.monotonic();self.cpu=cpu_seconds()
        self.deadline=min(self.began+wall_seconds,self.began+WINDOW_END-time.time())
        self.gpu_limit=GPU_hours_limit
        self.cpu_limit=CPU_hours_limit
        self.folder=HERE/(name+'_attempt01');self.additional=[];self.charges={};self.closed_hashes={}
        self.lease=self.owner=self.journal=self.root_path=self.root=None
        self.watcher=None;self.stop=threading.Event();self.errors=[];self.index=0;self.next_history=0;self.next_heartbeat=0
        self.guard=self.service=None
        self.terminal_done=False

    def history(self,full=False):
        baseline=read(HERE/'BASELINE.json');prior=read(OLD/'PRIOR_BINDINGS.json')
        prior=copy.deepcopy(prior);prior['original_paths'].pop('pair606_cwd_w0.3_lr0.001')
        extra=set(baseline['baseline_rows'])-set(prior['baseline_rows'])
        sequence=('CPU_integration','evaluation','gradient','metrics','analysis')
        for name in sequence[:sequence.index(self.name)]:
            sealed=consume(name,self.expected);extra.update(sealed['rows'])
        actual=verify_history(PROJECT,prior,extra|set(self.additional),full=full)
        for name,value in baseline['baseline_rows'].items():
            need(actual[name]==value and file_sha(PROJECT/name)==baseline['baseline_attempts'][name],'Completed row changed')
        for name,digest in self.closed_hashes.items(): need(file_sha(PROJECT/name)==digest,'Closed stage row changed')
        return actual

    def _add_children(self,owner):
        for item in owner.children:
            name=item['path'].relative_to(PROJECT).as_posix()
            if name not in self.additional:self.additional.append(name)

    def _setup(self):
        source_check(self.expected)
        need(os.environ.get('CUDA_VISIBLE_DEVICES')=='','Study parent must be CPU only')
        need(not self.folder.exists(),'Study stage already consumed')
        sequence=('CPU_integration','evaluation','gradient','metrics','analysis')
        for name in sequence[:sequence.index(self.name)]:consume(name,self.expected,full=True)
        self.history(full=True)
        self.uuids=gpu_state()
        self.lease=Lease(PROJECT,'auxiliary' if self.validation else 'production','remaining_'+self.name+'_once').acquire()
        self.folder.mkdir();(self.folder/'heartbeats').mkdir()
        self.journal=Journal(self.folder/'owner.jsonl',128*1024*1024,300000)
        self.owner=Owner(self.folder,PROJECT/PHASE/'attempts',self.deadline,self.journal,self.lease)
        self.root_path=PROJECT/PHASE/'attempts'/('remaining_'+self.name+'_root_'+uuid.uuid4().hex+'.json')
        self.root=dict(label='remaining_'+self.name+'_parent_CPU',command=process(os.getpid())['command'],GPU_job=False,device=None,
            pid=os.getpid(),token=self.owner.token,started_unix=time.time(),status='running')
        publish(self.root_path,self.root);self.additional.append(self.root_path.relative_to(PROJECT).as_posix())
        self.started=dict(owner=identity(os.getpid()),token=self.owner.token,deadline=self.deadline,work_deadline=self.deadline-60,
            mode=self.name,manifest_sha256=self.expected,attempt=self.additional[-1],lease_claim=self.lease.claim.relative_to(PROJECT).as_posix(),lease_owner=self.lease.owner)
        publish(self.folder/'STARTED.json',self.started)
        # Guard and parent share one scanner; both receive independent fresh replies.
        from research_admission import disk_size
        initial_bytes=disk_size(PROJECT/PHASE)+disk_size(PROJECT/AUX)
        plan=dict(self.started,folder=str(self.folder),project=str(PROJECT),GPU_hours_limit=self.gpu_limit,CPU_hours_limit=self.cpu_limit,validation=self.validation,initial_disk_bytes=initial_bytes)
        publish(self.folder/'GUARD_PLAN.json',plan)
        self.guard=self.owner.spawn('remaining_study_guard',[sys.executable,'-B',str(HERE/'study_guard.py'),str(self.folder/'GUARD_PLAN.json')],cwd=PROJECT)
        self._add_children(self.owner)
        wait_file(self.folder/'GUARD_READY.json',min(time.monotonic()+30,self.deadline-60))
        lanes={name:identity(os.getpid()) for name in ('parent.main','parent.watch','worker0.main','worker0.watch','worker1.main','worker1.watch')}
        lanes['worker1.main']=identity(self.guard.pid);held=os.fstat(self.lease.fd)
        monitor=dict(generation=uuid.uuid4().hex,token=uuid.uuid4().hex,owner=identity(os.getpid()),lanes=lanes,
            phase=str(PROJECT/PHASE),auxiliary=str(PROJECT/AUX),socket='\0study_'+uuid.uuid4().hex,
            ready=str(self.folder/'MONITOR_READY.json'),journal=str(self.folder/'service.jsonl'),deadline=self.deadline-30,
            root_lease_identity=[held.st_dev,held.st_ino],journal_max_bytes=128*1024*1024,journal_max_events=300000)
        publish(self.folder/'MONITOR_PLAN.json',monitor)
        self.service=self.owner.spawn('remaining_study_monitor',[sys.executable,'-B',str(HERE/'evaluation_monitor.py'),str(self.folder/'MONITOR_PLAN.json')],cwd=PROJECT)
        self._add_children(self.owner)
        config=wait_file(self.folder/'MONITOR_READY.json',min(time.monotonic()+30,self.deadline-60))
        for lane in ('worker0.main','worker0.watch','worker1.watch'):
            client=Client(config,lane);client.sample();client.retire()
        self.client=Client(config,'parent.main')
        self.watcher=threading.Thread(target=watch,args=(self.folder,self.started,Client(config,'parent.watch'),self.stop,self.errors))
        self.watcher.start();self.check()
        publish(self.folder/'RELEASE.json',dict(owner=self.started['owner'],token=self.owner.token,manifest_sha256=self.expected))

    def check(self,unused=None):
        alive_context(self.folder,self.started)
        need(not self.errors and self.guard.poll() is None and self.service.poll() is None,'Independent monitoring failed')
        sample=self.client.sample();records=rows(PROJECT)
        snapshot=usage(PROJECT,records,sample['phase_bytes'],sample['auxiliary_bytes']);limits(snapshot)
        need(set(snapshot['active_GPU_attempts'])==set(self.charges),'Unexpected live GPU allocation')
        local=sum(r.get('ended_unix',time.time())-r['started_unix'] for r in records.values() if r['GPU_job'] and r.get('token')==self.owner.token)
        need(local<=self.gpu_limit*3600,'Study GPU allowance')
        if self.cpu_limit is not None:
            from study_guard import owned_CPU_seconds
            need(owned_CPU_seconds(self.started['owner'],self.owner.token)<self.cpu_limit*3600,'Study aggregate CPU allowance')
        if self.validation: need(cpu_seconds()-self.cpu<1700,'Study CPU validation allowance')
        if time.monotonic()>=self.next_history:
            self.history();self.next_history=time.monotonic()+60
        # Every resource observation remains in the scanner and guard journals.
        # Retain a parent heartbeat every ten seconds, keeping the final artifact
        # manifest bounded during a full24-hour evaluation (40-second expiry).
        if time.monotonic()>=self.next_heartbeat:
            self.index+=1
            publish(self.folder/'heartbeats'/f'{self.index:06d}.json',dict(owner=self.started['owner'],token=self.owner.token,unix=time.time(),usage=snapshot))
            self.next_heartbeat=time.monotonic()+10
        return snapshot

    def stage(self,folder,stage,tasks,verify,wall_seconds=7200,synthetic_devices=False):
        """One or two fixed jobs. GPU reservations remain until both sessions drain."""
        need(1<=len(tasks)<=2 and len({t['endpoint_id'] for t in tasks})==len(tasks),'Stage task count')
        devices=[t['device'] for t in tasks if t['device'] is not None]
        need(not devices or len(devices)==len(tasks) and set(devices)<=set((0,1)) and len(set(devices))==len(devices),'Stage device routing')
        need(not synthetic_devices or self.validation,'Synthetic devices outside CPU fixtures')
        need(not self.validation or not devices or synthetic_devices,'Actual GPU work forbidden in CPU validation')
        destination=PROJECT/folder;need(destination.is_relative_to(PROJECT/PHASE) or destination.is_relative_to(self.folder),'Stage destination')
        destination.mkdir(parents=True,exist_ok=False)
        journal=Journal(destination/'owner.jsonl');owner=Owner(destination,PROJECT/PHASE/'attempts',min(self.deadline,time.monotonic()+wall_seconds),journal,self.lease)
        owned_reservations={};terminal=None;drained=False;reservation_hashes={}
        try:
            self.check();publish(destination/'intent.json',dict(stage=stage,tasks=tasks,synthetic_devices=synthetic_devices,parent_attempt=self.started['attempt']))
            if devices:
                need(gpu_state()==self.uuids,'GPU identity or idle state changed')
                for device in devices:
                    path=PROJECT/PHASE/'attempts'/('remaining_'+self.name+'_GPU'+str(device)+'_'+uuid.uuid4().hex+'.json')
                    row=dict(self.root,label='remaining_'+self.name+'_GPU'+str(device)+'_reservation',GPU_job=not synthetic_devices,
                        device=device,started_unix=time.time(),reservation=True,synthetic_devices=synthetic_devices,stage=stage)
                    publish(path,row);name=path.relative_to(PROJECT).as_posix();self.additional.append(name);owned_reservations[name]=row
                    if row['GPU_job']:self.charges[name]=row
            children=[]
            for task in tasks:
                need(Path(task['endpoint_id']).name==task['endpoint_id'],'Task identity')
                env=dict(task.get('environment',{}),CUDA_VISIBLE_DEVICES='' if task['device'] is None or synthetic_devices else str(task['device']),
                    OMP_NUM_THREADS='2',MKL_NUM_THREADS='2',OPENBLAS_NUM_THREADS='1',PYTHONUNBUFFERED='1')
                child=owner.spawn(stage+'_'+task['endpoint_id'],task['command'],env=env,cwd=PROJECT)
                children.append(child);self._add_children(owner)
            while True:
                self.check();need(time.monotonic()<owner.deadline-10,'Stage deadline')
                codes=[p.poll() for p in children]
                need(all(code in (None,0) for code in codes),'Stage worker failed; no automatic retry')
                if all(code==0 for code in codes):break
                time.sleep(1)
            terminal=owner.terminal('completed',close_lease=False);drained=True
            need(terminal['absent'] and not terminal['errors'],'Stage descendants or terminal failure')
            for name,row in owned_reservations.items():
                update(PROJECT/name,row,dict(row,status='completed',ended_unix=time.time(),returncode=0,worker_drained=True))
                self.charges.pop(name,None);self.closed_hashes[name]=file_sha(PROJECT/name)
                reservation_hashes[name]=self.closed_hashes[name]
            owned_reservations={}
            for item in owner.children:self.closed_hashes[item['path'].relative_to(PROJECT).as_posix()]=file_sha(item['path'])
            need(gpu_state()==self.uuids,'GPU contexts remain after stage')
            self.check();artifacts={}
            for task in tasks:
                bindings=verify(task);need(bool(bindings),'Empty stage evidence')
                for name,digest in bindings.items():need(file_sha(PROJECT/name)==digest,'Stage output changed')
                artifacts[task['endpoint_id']]=bindings
            receipt=dict(status='stage_processes_exited_and_artifact_bytes_verified',stage=stage,parent_attempt=self.started['attempt'],
                parent_pid=os.getpid(),ended_unix=time.time(),artifacts=artifacts,sessions_drained=True,
                worker_attempt_sha256={x['path'].relative_to(PROJECT).as_posix():file_sha(x['path']) for x in owner.children},
                reservation_attempt_sha256=reservation_hashes,
                terminal=terminal,synthetic_devices=synthetic_devices,endpoint_independent_audit_and_seal_complete=False)
            publish(destination/'STAGE_COMPLETE.json',receipt);return receipt
        except BaseException as error:
            try:publish(destination/'FAILURE.json',dict(error=repr(error),automatic_retry=False))
            finally:
                if not drained:terminal=owner.terminal('failed',close_lease=False);drained=True
                if terminal and terminal['absent']:
                    for name,row in owned_reservations.items():
                        update(PROJECT/name,row,dict(row,status='failed',ended_unix=time.time(),returncode=1,worker_drained=True));self.charges.pop(name,None)
            raise
        finally:journal.close()

    def _finish(self,result):
        self.check();source_check(self.expected)
        self.stop.set();self.watcher.join(30)
        need(not self.watcher.is_alive() and not self.errors,'Parent watcher retirement')
        self.client.retire();publish(self.folder/'GUARD_FINISH.json',dict(owner=self.started['owner'],token=self.owner.token))
        need(self.guard.wait(timeout=max(.01,self.deadline-35-time.monotonic()))==0,'Guard retirement')
        need(self.service.wait(timeout=max(.01,self.deadline-20-time.monotonic()))==0,'Scanner retirement')
        terminal=self.owner.terminal('completed',close_lease=False)
        self.terminal_done=True
        need(terminal['absent'] and not terminal['errors'] and not self.charges,'Study terminal state')
        update(self.root_path,self.root,dict(self.root,status='completed',ended_unix=time.time(),returncode=0))
        self.journal.close();self.journal=None;self.lease.close('completed')
        verify_journals(self.folder)
        closure=self.lease.claim.with_name(self.lease.claim.name.replace('.started.json','.closed.json'))
        artifacts={p.relative_to(PROJECT).as_posix():{'bytes':p.stat().st_size,'sha256':file_sha(p)} for p in sorted(self.folder.rglob('*')) if p.is_file()}
        publish(self.folder/'SEALED.json',dict(status='completed',stage=self.name,manifest_sha256=self.expected,owner=self.started['owner'],token=self.owner.token,
            terminal=terminal,result=result,rows={n:file_sha(PROJECT/n) for n in self.additional},closed_lease=closure.relative_to(PROJECT).as_posix(),
            artifacts=artifacts,
            closed_lease_sha256=file_sha(closure),wall_seconds=time.monotonic()-self.began,CPU_seconds=cpu_seconds()-self.cpu,
            scientific_GPU_work=not self.validation and self.gpu_limit>0,whole_research_complete=False))

    def run(self,callback):
        for sig in (signal.SIGINT,signal.SIGTERM,signal.SIGALRM):signal.signal(sig,stop_signal)
        signal.setitimer(signal.ITIMER_REAL,max(.01,self.deadline-time.monotonic()-5))
        try:self._setup();result=callback(self);self._finish(result);return result
        except BaseException as error:
            with defer_cleanup_SIGTERM() as deferred:
                if self.folder.is_dir():failure(self.folder,error)
                self.stop.set()
                if self.watcher is not None:self.watcher.join(max(0,min(5,self.deadline-time.monotonic())))
                if self.owner is not None and not self.terminal_done:
                    self.owner.deadline=min(self.owner.deadline,time.monotonic()+15)
                    terminal=self.owner.terminal('failed',close_lease=False)
                    if terminal['absent'] and not terminal['errors'] and not self.charges:
                        if self.root_path and 'ended_unix' not in read(self.root_path):update(self.root_path,self.root,dict(self.root,status='failed',ended_unix=time.time(),returncode=1))
                        if self.lease.fd is not None:self.lease.close('failed')
                if self.folder.is_dir():publish(self.folder/'FAILURE_CLEANUP_SIGNALS.json',dict(deferred_SIGTERM=deferred,original_deadline_not_extended=True))
            raise
        finally:
            signal.setitimer(signal.ITIMER_REAL,0)
            if self.journal is not None:self.journal.close()
            if self.lease is not None and self.lease.fd is not None:self.lease.abandon()
