"""Real Linux file/link/hash tests with synthetic images and runtime metadata."""
import copy
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import zipfile

from PIL import Image
import factorial_current_evaluation_inputs as m


class Tests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.p = Path(self.temp.name)
        self.r = m.CurrentBytes(self.p)
        self.put('inputs/one.bin', b'first')

    def tearDown(self):
        self.temp.cleanup()

    def put(self, name, raw):
        path = self.p/name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(raw)
        return {'path':name, 'sha256':m.digest(raw)}

    def js(self, name, value):
        return self.put(name, json.dumps(value,sort_keys=True).encode())

    def population(self, links=False):
        stream=io.BytesIO();Image.new('RGB',(3,2),(4,5,6)).save(stream,format='PNG')
        raw=stream.getvalue()
        if links:
            self.put(str(m.RAW_BDD/'a.png'),raw)
            (self.p/'images').mkdir()
            (self.p/'images/a.png').symlink_to(self.p/m.RAW_BDD/'a.png')
        else:self.put('images/a.png',raw)
        rows=[{'id':1,'file_name':'a.png','width':3,'height':2,'sha256':m.digest(raw)}]
        req={'image_dir':'images','image_manifest':self.js('inputs/images.json',rows)}
        return req,rows

    def labels(self):
        req,rows=self.population()
        raw=b'0 0.5 0.5 0.2 0.2\n'
        self.put('labels/a.txt',raw)
        req.update(label_dir='labels', data_yaml=self.put('inputs/data.yaml',b'names: [person]\n'),
            dataset_manifest=self.js('inputs/data.json',{'splits':{'val':{'images':1,'boxes':1,
                'ordered_label_content_sha256':m.digest(b'a.txt\0'+raw)}}}))
        return req,rows

    def zip_fixture(self, duplicate=False):
        raw=io.BytesIO()
        with zipfile.ZipFile(raw,'w') as z:
            z.writestr('training/label_2/000000.txt',b'Car')
            if duplicate:z.writestr('training/label_2/000000.txt',b'Car')
        return self.put('inputs/labels.zip',raw.getvalue()),{'000000.txt':m.digest(b'Car')}

    def test_regular_read_and_end_identity(self):
        self.assertEqual(self.r.read('inputs/one.bin',m.digest(b'first')),b'first')
        self.r.final_identity_check()

    def test_changed_hash(self):
        with self.assertRaises(AssertionError):self.r.read('inputs/one.bin','0'*64)

    def test_no_unexpected_symlink(self):
        (self.p/'inputs/link').symlink_to(self.p/'inputs/one.bin')
        with self.assertRaises(AssertionError):self.r.read('inputs/link')

    def test_link_exact_target_required(self):
        (self.p/'inputs/link').symlink_to(self.p/'inputs/one.bin')
        self.put('inputs/two.bin',b'first')
        with self.assertRaises(AssertionError):self.r.read('inputs/link',allowed_link_target='inputs/two.bin')

    def test_link_chain_rejected(self):
        (self.p/'inputs/a').symlink_to(self.p/'inputs/one.bin')
        (self.p/'inputs/b').symlink_to(self.p/'inputs/a')
        with self.assertRaises(AssertionError):self.r.read('inputs/b',allowed_link_target='inputs/a')

    def test_directory_link_rejected(self):
        (self.p/'alias').symlink_to(self.p/'inputs')
        with self.assertRaises(AssertionError):self.r.read('alias/one.bin')

    def test_path_escape_rejected(self):
        for name in ('../one.bin','/etc/passwd','inputs/../one.bin','inputs\\one.bin','C:one.bin'):
            with self.subTest(name=name),self.assertRaises(AssertionError):self.r.read(name)

    def test_changed_after_read(self):
        self.r.read('inputs/one.bin')
        self.put('inputs/one.bin',b'changed')
        with self.assertRaises(AssertionError):self.r.final_identity_check()

    def test_replaced_after_read_same_bytes(self):
        self.r.read('inputs/one.bin')
        self.put('inputs/replacement',b'first')
        os.replace(self.p/'inputs/replacement',self.p/'inputs/one.bin')
        with self.assertRaises(AssertionError):self.r.final_identity_check()

    def test_changed_during_read(self):
        original=m.CurrentBytes.target
        calls=[]
        def changed(instance,*args,**kwargs):
            calls.append(1)
            if len(calls)==2:self.put('inputs/one.bin',b'changed')
            return original(instance,*args,**kwargs)
        with patch.object(m.CurrentBytes,'target',changed),self.assertRaises(AssertionError):self.r.read('inputs/one.bin')

    def test_size_bound(self):
        with self.assertRaises(AssertionError):self.r.read('inputs/one.bin',max_bytes=2)

    def test_regular_image_population(self):
        q,rows=self.population();self.assertEqual(m.image_population(self.r,q,1,False),rows)

    def test_controlled_image_link_bytes_read(self):
        q,rows=self.population(True);m.image_population(self.r,q,1,True)
        self.assertEqual(self.r.bound['images/a.png'],rows[0]['sha256'])
        self.r.final_identity_check()

    def test_image_link_forbidden_in_kitti(self):
        q,_=self.population(True)
        with self.assertRaises(AssertionError):m.image_population(self.r,q,1,False)

    def test_changed_link_payload(self):
        q,_=self.population(True);self.put(str(m.RAW_BDD/'a.png'),b'bad')
        with self.assertRaises(AssertionError):m.image_population(self.r,q,1,True)

    def test_image_dimension_mismatch(self):
        q,rows=self.population();rows[0]['width']=4;q['image_manifest']=self.js('inputs/images.json',rows)
        with self.assertRaises(AssertionError):m.image_population(self.r,q,1,False)

    def test_extra_image(self):
        q,_=self.population();self.put('images/extra.png',b'extra')
        with self.assertRaises(AssertionError):m.image_population(self.r,q,1,False)

    def test_missing_image(self):
        q,_=self.population();(self.p/'images/a.png').unlink()
        with self.assertRaises(AssertionError):m.image_population(self.r,q,1,False)

    def test_bad_image_id(self):
        q,rows=self.population();rows[0]['id']=2;q['image_manifest']=self.js('inputs/images.json',rows)
        with self.assertRaises(AssertionError):m.image_population(self.r,q,1,False)

    def test_image_count_mismatch(self):
        q,_=self.population()
        with self.assertRaises(AssertionError):m.image_population(self.r,q,2,False)

    def test_duplicate_image_name(self):
        q,rows=self.population();rows.append(dict(rows[0],id=2));q['image_manifest']=self.js('inputs/images.json',rows)
        with self.assertRaises(AssertionError):m.image_population(self.r,q,2,False)

    def test_label_population(self):
        q,rows=self.labels();self.assertEqual(m.label_population(self.r,q,rows)['boxes'],1)

    def test_changed_label(self):
        q,rows=self.labels();self.put('labels/a.txt',b'2 0.5 0.5 0.2 0.2\n')
        with self.assertRaises(AssertionError):m.label_population(self.r,q,rows)

    def test_extra_label(self):
        q,rows=self.labels();self.put('labels/b.txt',b'')
        with self.assertRaises(AssertionError):m.label_population(self.r,q,rows)

    def test_label_link_rejected(self):
        q,rows=self.labels();(self.p/'labels/a.txt').unlink();(self.p/'labels/a.txt').symlink_to(self.p/'inputs/one.bin')
        with self.assertRaises(AssertionError):m.label_population(self.r,q,rows)

    def test_changed_yaml(self):
        q,rows=self.labels();self.put('inputs/data.yaml',b'other')
        with self.assertRaises(AssertionError):m.label_population(self.r,q,rows)

    def test_label_box_count_mismatch(self):
        q,rows=self.labels();data=json.loads((self.p/q['dataset_manifest']['path']).read_bytes());data['splits']['val']['boxes']=2
        q['dataset_manifest']=self.js('inputs/data.json',data)
        with self.assertRaises(AssertionError):m.label_population(self.r,q,rows)

    def test_kitti_original_basename_to_zip_mapping(self):
        b,e=self.zip_fixture();self.assertEqual(m.kitti_labels(self.r,b,e),1)

    def test_kitti_duplicate_member(self):
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter('ignore');b,e=self.zip_fixture(True)
        with self.assertRaises(AssertionError):m.kitti_labels(self.r,b,e)

    def test_kitti_changed_member(self):
        b,e=self.zip_fixture();e['000000.txt']='0'*64
        with self.assertRaises(AssertionError):m.kitti_labels(self.r,b,e)

    def test_kitti_wrong_frame(self):
        b,e=self.zip_fixture();e={'000001.txt':next(iter(e.values()))}
        with self.assertRaises(AssertionError):m.kitti_labels(self.r,b,e)

    def annotation(self):
        _,rows=self.population()
        view={'images':[{k:v for k,v in rows[0].items() if k!='sha256'}], 'annotations':[],
            'categories':[{'id':0,'name':'person'},{'id':2,'name':'car'}],
            'info':{'annotation_variant':'bdd_common','policy_sha256':'1'*64}}
        binding={'annotation_views':{'bdd_common':self.js('inputs/view.json',view)},'common_source_sha256':{'common_annotation_policy.json':'1'*64}}
        return binding,{'bdd':rows},view

    def test_annotations_pinned_population(self):
        b,p,_=self.annotation();self.assertEqual(m.annotation_views(self.r,b,p)['bdd_common']['images'],1)

    def test_annotations_wrong_image_dimensions(self):
        b,p,v=self.annotation();v['images'][0]['width']=9;b['annotation_views']['bdd_common']=self.js('inputs/view.json',v)
        with self.assertRaises(AssertionError):m.annotation_views(self.r,b,p)

    def test_annotations_wrong_policy(self):
        b,p,v=self.annotation();v['info']['policy_sha256']='2'*64;b['annotation_views']['bdd_common']=self.js('inputs/view.json',v)
        with self.assertRaises(AssertionError):m.annotation_views(self.r,b,p)

    def test_annotations_wrong_categories(self):
        b,p,v=self.annotation();v['categories'][1]['id']=3;b['annotation_views']['bdd_common']=self.js('inputs/view.json',v)
        with self.assertRaises(AssertionError):m.annotation_views(self.r,b,p)

    def test_annotations_wrong_variant(self):
        b,p,v=self.annotation();v['info']['annotation_variant']='kitti_source_ignore';b['annotation_views']['bdd_common']=self.js('inputs/view.json',v)
        with self.assertRaises(AssertionError):m.annotation_views(self.r,b,p)

    def test_invalid_preparation_hash_rejected_before_data(self):
        self.put(str(m.ROOT/'factorial_current_inputs_spec.json'),b'{}')
        with patch.dict(os.environ,{'CUDA_VISIBLE_DEVICES':''}),self.assertRaises(AssertionError):m.collect(self.p,'0'*64)

    def test_no_cuda_admission(self):
        with patch.dict(os.environ,{'CUDA_VISIBLE_DEVICES':'0'}),self.assertRaises(AssertionError):m.collect(self.p,'0'*64)

    def runtime(self):
        from types import SimpleNamespace
        root=self.p/'venv/lib/site-packages'
        self.put('venv/lib/site-packages/ultralytics/model.py',b'unchanged native source')
        self.put('venv/lib/site-packages/ultralytics/cfg/default.yaml',b'unchanged yaml')
        isolated=self.put(str(m.ISOLATED/'pycocotools/cocoeval.py'),b'unchanged scorer')
        self.put(str(m.ISOLATED/'pycocotools/_mask.so'),b'extension bytes')
        deps={'pycocotools/cocoeval.py':isolated['sha256'],'pycocotools/_mask.so':m.digest(b'extension bytes')}
        dists={'ultralytics':SimpleNamespace(version='8.2.103',locate_file=lambda x:root/x),
            'numpy':SimpleNamespace(version='1.26.4',locate_file=lambda x:root/x)}
        native={'runtime':{'python':m.platform.python_version(),'platform':m.platform.platform(),
            'packages':{n:d.version for n,d in dists.items()},
            'native_source_sha256':{'ultralytics.model':m.digest(b'unchanged native source')}},
            'native_validation_source_sha256':{'default_cfg_yaml':m.digest(b'unchanged yaml')}}
        common={'runtime':{'numpy_version':'1.26.4','pycocotools_version':'2.0.11','cocoeval_python_sha256':isolated['sha256']}}
        coco=SimpleNamespace(metadata={'Name':'pycocotools'},version='2.0.11',files=list(deps))
        return native,common,deps,dists,coco

    def call_runtime(self, fixture):
        native,common,deps,dists,coco=fixture
        with patch.object(m.metadata,'distribution',side_effect=lambda n:dists[n]),patch.object(m.metadata,'distributions',return_value=[coco]):
            return m.runtime_sources(self.r,native,common,deps)

    def test_runtime_metadata_and_actual_sources(self):
        result=self.call_runtime(self.runtime());self.assertFalse(result['GPU_runtime_observed'])
        self.r.final_identity_check();self.assertNotIn('torch',m.sys.modules)

    def test_runtime_package_version_changed(self):
        f=self.runtime();f[3]['numpy'].version='different'
        with self.assertRaises(AssertionError):self.call_runtime(f)

    def test_runtime_native_source_changed(self):
        f=self.runtime();self.put('venv/lib/site-packages/ultralytics/model.py',b'changed')
        with self.assertRaises(AssertionError):self.call_runtime(f)

    def test_runtime_native_module_ambiguous(self):
        f=self.runtime();self.put('venv/lib/site-packages/ultralytics/model/__init__.py',b'unchanged native source')
        with self.assertRaises(AssertionError):self.call_runtime(f)

    def test_runtime_native_module_absent(self):
        f=self.runtime();(self.p/'venv/lib/site-packages/ultralytics/model.py').unlink()
        with self.assertRaises(AssertionError):self.call_runtime(f)

    def test_runtime_cfg_changed(self):
        f=self.runtime();self.put('venv/lib/site-packages/ultralytics/cfg/default.yaml',b'changed')
        with self.assertRaises(AssertionError):self.call_runtime(f)

    def test_runtime_isolated_version_changed(self):
        f=self.runtime();f[4].version='different'
        with self.assertRaises(AssertionError):self.call_runtime(f)

    def test_runtime_extension_changed(self):
        f=self.runtime();self.put(str(m.ISOLATED/'pycocotools/_mask.so'),b'changed')
        with self.assertRaises(AssertionError):self.call_runtime(f)

    def test_runtime_isolated_file_missing_from_record(self):
        f=self.runtime();f[4].files.pop()
        with self.assertRaises(AssertionError):self.call_runtime(f)

    def test_runtime_python_changed(self):
        f=self.runtime();f[0]['runtime']['python']='different'
        with self.assertRaises(AssertionError):self.call_runtime(f)

    def test_runtime_platform_changed(self):
        f=self.runtime();f[0]['runtime']['platform']='different'
        with self.assertRaises(AssertionError):self.call_runtime(f)

    def test_runtime_wrong_package_location(self):
        f=self.runtime();f[3]['numpy'].locate_file=lambda x:self.p/'other'/x
        with self.assertRaises(AssertionError):self.call_runtime(f)


if __name__=='__main__':
    assert os.name=='posix' and 'torch' not in m.sys.modules
    unittest.main(verbosity=2)
