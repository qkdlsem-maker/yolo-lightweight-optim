"""Run the fixed60 evaluation workflow using authenticated completed checkpoints."""
import json,sys,time
from pathlib import Path
from study_runtime import Study,PROJECT,PHASE,HERE,source_check,publish,read,need,file_sha
from completed_training_bridge import collect,PulsedFiles
from continuation_artifact_receipts import loads
import factorial_evaluation_adapter as adapter
import factorial_evaluation_workflow as workflow
from factorial_evaluation_stage_runtime_v2 import validate as validate_stage
from current_input_verification import authenticate as authenticate_inputs
from retained_io import encode


def authenticate_reuse(ctx):
    import factorial_reused_evaluation_evidence_v2 as reuse
    original= reuse.Reader
    class PulsedReader(original):
        def __init__(self,project):
            super().__init__(project);self.files=PulsedFiles(project,ctx.check)
    reuse.Reader=PulsedReader
    try:value=reuse.collect(PROJECT,progress=lambda eid:ctx.check())
    finally:reuse.Reader=original
    previous=loads((PROJECT/PHASE/'factorial_reuse_auth_v2.json').read_bytes())
    need(value['endpoints']==previous['endpoints'] and value['bound_artifacts']==previous['bound_artifacts'],'Historical reuse bytes or endpoint chain changed')
    path=ctx.folder/'HISTORICAL_24_CURRENT_BYTES.json';publish(path,value)
    return path


def run(ctx):
    f=PulsedFiles(PROJECT,ctx.check)
    accepted,routed,audits=collect(ctx)
    acceptance=PROJECT/PHASE/'factorial_training_acceptance.json'
    manifest=read(HERE/'SOURCE_MANIFEST.json')
    if acceptance.exists():
        # The prior attempt stopped before model dispatch, after this exact
        # immutable acceptance was published. Adopt only its pinned equal bytes.
        key=acceptance.relative_to(PROJECT).as_posix()
        need(file_sha(acceptance)==manifest['prior_evidence'][key] and acceptance.read_bytes()==encode(accepted),'Previously published acceptance differs')
    else:publish(acceptance,accepted)
    acceptance_ref={'path':acceptance.relative_to(PROJECT).as_posix(),'sha256':file_sha(acceptance)}
    publish(ctx.folder/'COMPLETED_27_AUDIT_ROUTES.json',{x['endpoint_id']:x['completion_evidence'] for x in accepted['new_evaluation_endpoints'] if x['stage']=='continuation'})
    inputs,input_proof=authenticate_inputs(ctx)
    publish(ctx.folder/'CURRENT_INPUT_BYTES.json',input_proof)
    reuse_path=authenticate_reuse(ctx)
    plan=adapter.plan_from_bound(accepted,routed,acceptance_ref)
    plan['explicit_restart_routing']=accepted['explicit_restart_path_changes']
    plan_path=PROJECT/PHASE/'factorial_evaluation_execution_plan.json';publish(plan_path,plan)
    plan_ref={'path':plan_path.relative_to(PROJECT).as_posix(),'sha256':file_sha(plan_path)}
    runtime=adapter.runtime_contract(inputs)
    previous=workflow.run_stage
    def owned_stage(files,folder,stage,tasks,parent_attempt,parent_row,monitor,idle_uuid,uuids,verify,wall_seconds):
        validate_stage(stage,tasks,folder,wall_seconds)
        need(parent_attempt==ctx.started['attempt'] and parent_row==ctx.root and uuids==ctx.uuids,'Workflow parent binding')
        return ctx.stage(folder,stage,tasks,verify,wall_seconds)
    workflow.run_stage=owned_stage
    try:
        result=workflow.run_all(f,plan,plan_ref,ctx.started['attempt'],ctx.root,runtime,ctx.check,
            lambda device:ctx.uuids[str(device)],ctx.uuids)
    finally:workflow.run_stage=previous
    need(result['new_endpoints']==60 and result['reused_endpoints']==24 and len(result['receipt_sha256'])==60,'Fixed evaluation completion')
    f.verify(result['receipt_sha256']);f.verify(result['wave_seal_sha256']);f.verify(result['stage_receipt_sha256'])
    return dict(new_endpoints=60,reused_endpoints=24,plan=plan_ref,acceptance=acceptance_ref,
        receipt_sha256=result['receipt_sha256'],historical_current_bytes={'path':reuse_path.relative_to(PROJECT).as_posix(),'sha256':file_sha(reuse_path)},
        complete={'path':PHASE+'/factorial_evaluation/EVALUATION_RECEIPTS_COMPLETE.json','sha256':f.sha(PHASE+'/factorial_evaluation/EVALUATION_RECEIPTS_COMPLETE.json')})

if __name__=='__main__':
    expected=sys.argv[1];source_check(expected)
    Study('evaluation',expected,24*3600,22).run(run)
